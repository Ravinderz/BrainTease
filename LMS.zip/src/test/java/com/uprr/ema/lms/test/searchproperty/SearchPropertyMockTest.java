package com.uprr.ema.lms.test.searchproperty;

import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.isA;
import static org.easymock.EasyMock.replay;
import static org.easymock.EasyMock.verify;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import junit.framework.Assert;

import org.easymock.EasyMockRunner;
import org.easymock.EasyMockSupport;
import org.easymock.Mock;
import org.easymock.TestSubject;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.util.ReflectionTestUtils;

import com.uprr.ema.lms.common.dao.api.LookupDao;
import com.uprr.ema.lms.common.dto.DropDownInfo;
import com.uprr.ema.lms.common.dto.ManagerDTO;
import com.uprr.ema.lms.common.service.util.ServiceConstants;
import com.uprr.ema.lms.common.vb.ManagerVB;
import com.uprr.ema.lms.searchproject.controller.SearchProjectController;
import com.uprr.ema.lms.searchproject.dao.api.ProjectSearchDao;
import com.uprr.ema.lms.searchproject.dto.ProjectSearchCriteriaDTO;
import com.uprr.ema.lms.searchproject.dto.SearchDTO;
import com.uprr.ema.lms.searchproject.helper.ProjectSearchHelper;
import com.uprr.ema.lms.searchproject.service.api.ProjectSearchService;
import com.uprr.ema.lms.searchproject.service.impl.ProjectSearchServiceImpl;
import com.uprr.ema.lms.searchproject.vb.ProjectSearchCriteriaVB;
import com.uprr.ema.lms.searchproject.vb.SearchCriteriaResponse;
import com.uprr.ema.lms.searchproject.vb.SearchOnloadVB;
import com.uprr.ema.lms.searchproject.vb.SearchVB;

@RunWith(EasyMockRunner.class)
public class SearchPropertyMockTest extends EasyMockSupport{
	@Mock
	private LookupDao lookupDao;
	@Mock
	private ProjectSearchDao projectSearchDao;
	
	@TestSubject
	private ProjectSearchService projectSearchService = new ProjectSearchServiceImpl();
	@TestSubject
	private ProjectSearchHelper projectSearchHelper = new ProjectSearchHelper();
	@TestSubject
	private SearchProjectController searchProjectController = new SearchProjectController();
	
	@Before
	public void initializeTestObjects() {

		ReflectionTestUtils.setField(projectSearchService, "lookupDao", lookupDao);
		ReflectionTestUtils.setField(projectSearchService, "projectSearchDao", projectSearchDao);
		ReflectionTestUtils.setField(projectSearchHelper, "projectSearchService", projectSearchService);
		ReflectionTestUtils.setField(searchProjectController, "searchHelper", projectSearchHelper);
	}
	
	@Test
	public void onLodTest(){
		//expect(lookupDao.getDropDownOnLoad(isA(String.class), isA(String.class), isA(String.class),isA(String.class))).andReturn(getDropDownList()).times(2);
		//expect(lookupDao.getDropDownOnLoad(isA(String.class), isA(String.class), isA(String.class))).andReturn(getDropDownList()).times(1);
		getSearchOnloadVB();
	    	setDaoExpectations();
		replay(lookupDao);
		//replayAll();
		projectSearchHelper.getOnloadData("xmie001");
		//verifyAll();
	}

	@Test
	public void testGetProjectNamesNegitive(){
		expect(lookupDao.getProjectNames(isA(String.class), isA(String.class), isA(String.class),isA(String.class))).andReturn(getDropDownList()).times(1);
		replay(lookupDao);
		
		List<DropDownInfo> list =searchProjectController.getOnload("ABC");
		//verify(lookupDao);
		if(list!=null)
		Assert.assertTrue(list.size()==0);
	}
	@Test
	public void testGetProjectNames(){
		expect(lookupDao.getProjectNames(isA(String.class), isA(String.class), isA(String.class),isA(String.class))).andReturn(getDropDownList()).times(1);
		replay(lookupDao);
		//
		List<DropDownInfo> list =searchProjectController.getOnload("Create Manager");
		//verify(lookupDao);
		if(list!=null)
		Assert.assertTrue(list.size()>0);
	}
	
	@Test
	public void testGetSecurityRolesThroughPagination(){
		expect(projectSearchDao.getSearchResultThroughPagination(isA(ProjectSearchCriteriaDTO.class))).andReturn(getSearchDtoList()).times(1);
		expect(projectSearchDao.getSearchResultRowCount(isA(ProjectSearchCriteriaDTO.class))).andReturn(1).times(1);
		replay(projectSearchDao);
		SearchCriteriaResponse<SearchVB> searchvb=searchProjectController.getSecurityRolesThroughPagination(cretaeProjectSearchCriteriaVb());
		verify(projectSearchDao);
		
		Assert.assertNotNull(searchvb);
	}
	
	@Test
	public void testGetExcelReport() throws Exception{
		expect(projectSearchDao.getExcelReport(isA(ProjectSearchCriteriaDTO.class))).andReturn(getSearchDtoList()).times(1);
		replay(projectSearchDao);
	
		MockHttpServletResponse resp=new MockHttpServletResponse();
		searchProjectController.getExcelReport(resp,new SearchVB());
		verify(projectSearchDao);
		
	}
	
	private List<DropDownInfo> getDropDownList(){
		List<DropDownInfo> list= new ArrayList<>();
		list.add(new DropDownInfo());
		return list;
	}
	
	private List<SearchDTO> getSearchDtoList(){
		List<SearchDTO> list= new ArrayList<SearchDTO>();
		list.add(new SearchDTO());
		return list;
	}
	
	private SearchOnloadVB getSearchOnloadVB(){
	    SearchOnloadVB vb = new SearchOnloadVB();
	    
	    vb.setStatusDesc("statusDesc");
	    vb.setStatusCode("statusCode");
	    vb.setStatusType("statusType") ;
	    vb.setRecordCount(1L) ;
	    vb.setDropDownList(createDropDownInfo()) ;
	    
	    vb.setTubeLevelList(createDropDownInfo()) ;
	    vb.setProjectNameList(createDropDownInfo()) ;
	    vb.setProjectStatusList(createDropDownInfo());
	    vb.setEstimators(createDropDownInfo());
	    //vb.setSiteRemManagers(createDropDownInfo()) ;
	    vb.getTubeLevelList() ;
	    vb.getProjectStatusList() ;
	    vb.getProjectNameList() ;
	    vb.getEstimators() ;
	    vb.getSiteRemManagers() ;
	    
	    vb.getStatusType() ;
	    vb.getStatusDesc() ;
	    vb.getRecordCount() ;
	    vb.getDropDownList() ;
	    vb.getStatusCode() ;
	    
	    
		return vb;
	}
	
	private ProjectSearchCriteriaVB cretaeProjectSearchCriteriaVb(){
		ProjectSearchCriteriaVB vb = new ProjectSearchCriteriaVB();
		vb.setRecordsPerPage(10);
		return vb;
	}
	
	private void setDaoExpectations(){
	    
	    
	    expect(lookupDao.getDropDownOnLoad(ServiceConstants.EMA_LMS_PROJ_ACTN_MSTR, ServiceConstants.ACTN_CODE, ServiceConstants.ACTN_DESC)).andReturn(
		    createDropDownInfo());
	    
	    expect(
		    lookupDao.getDropDownOnLoad(ServiceConstants.EMA_LMS_TUBE_LEVL_MSTR, 
			    ServiceConstants.TUBE_LEVL_ID, 
			    ServiceConstants.TUBE_LEVL_CODE, ServiceConstants.TUBE_LEVL_DESC)).
			    andReturn(createDropDownInfo());

	    expect( lookupDao.getDropDownOnLoad(ServiceConstants.EMA_LMS_PROJ_SRC_MSTR, ServiceConstants.PROJ_SRC_CODE,
		    ServiceConstants.PROJ_SRC_DESC, ServiceConstants.PROJ_SRC_ID, ServiceConstants.SORT_ORD_NBR)).andReturn(createDropDownInfo());

	    expect(
		    lookupDao.getDropDownOnLoad(ServiceConstants.EMA_LMS_PROJ_TYPE_MSTR, ServiceConstants.PROJ_TYPE_CODE,
			    ServiceConstants.PROJ_TYPE_DESC, ServiceConstants.PROJ_TYPE_ID, ServiceConstants.SORT_ORD))
			    .andReturn(createDropDownInfo());
	    expect(
		    lookupDao.getDropDownOnLoad(ServiceConstants.EMA_LMS_PROJ_DRIV_MSTR, ServiceConstants.PROJ_DRIV_CODE,
			    ServiceConstants.PROJ_DRIV_DESC, ServiceConstants.PROJ_DRIV_ID, ServiceConstants.SORT_ORD))
			    .andReturn(createDropDownInfo());
	    expect(
		    lookupDao.getDropDownOnLoad(ServiceConstants.EMA_LMS_PROJ_ESTM_MSTR, ServiceConstants.PROJ_ESTM_CODE,
			    ServiceConstants.PROJ_ESTM_DESC, ServiceConstants.PROJ_ESTM_ID, ServiceConstants.SORT_ORD))
			    .andReturn(createDropDownInfo());
	    expect(
		    lookupDao.getDropDownOnLoad(ServiceConstants.EMA_LMS_RAIL_RAOD_MSTR, ServiceConstants.RAIL_RAOD_CODE,
			    ServiceConstants.RAIL_RAOD_DESC, ServiceConstants.RAIL_RAOD_ID, ServiceConstants.SORT_ORD_NBR))
			    .andReturn(createDropDownInfo());
	    expect(
		    lookupDao.getDropDownOnLoad(ServiceConstants.EMA_LMS_FED_LEAD_MSTR, ServiceConstants.FED_LEAD_CODE,
			    ServiceConstants.FED_LEAD_DESC, ServiceConstants.FED_LEAD_ID, ServiceConstants.SORT_ORD_NBR))
			    .andReturn(createDropDownInfo());
	    expect(
		    lookupDao.getDropDownOnLoad(ServiceConstants.EMA_LMS_BLNC_SHT_MSTR, ServiceConstants.BLNC_SHT_CODE,
			    ServiceConstants.BLNC_SHT_DESC, ServiceConstants.BLNC_SHT_ID, ServiceConstants.SORT_ORD_NBR))
			    .andReturn(createDropDownInfo());
	    expect(
		    lookupDao.getDropDownOnLoad(ServiceConstants.EMA_LMS_SUB_ACCT_MSTR, ServiceConstants.SUB_ACCT_CODE,
			    ServiceConstants.SUB_ACCT_DESC, ServiceConstants.SUB_ACCT_ID, ServiceConstants.SORT_ORD_NBR))
			    .andReturn(createDropDownInfo());
	    expect(
		    lookupDao.getDropDownOnLoad(ServiceConstants.EMA_LMS_PROJ_COST_TYPE_MST,
			    ServiceConstants.PROJ_COST_TYPE_CODE, ServiceConstants.PROJ_COST_TYPE_DESC,
			    ServiceConstants.PROJ_COST_TYPE_ID, ServiceConstants.SORT_ORD_NBR)).andReturn(
				    createDropDownInfo());
	    
	    expect(
		    lookupDao.getDropDownOnLoadForId(ServiceConstants.EMA_LMS_TUBE_LEVL_MSTR,
			    ServiceConstants.TUBE_LEVL_ID, ServiceConstants.TUBE_LEVL_CODE,
			    ServiceConstants.TUBE_LEVL_DESC)).andReturn(
				    createDropDownInfo());
	    
	    expect(
		    lookupDao.getDropDownOnLoadForId(ServiceConstants.EMA_LMS_CHNG_RESN_MSTR, ServiceConstants.CHNG_RESN_MSTR_ID, ServiceConstants.CHNG_RESN_CODE, ServiceConstants.CHNG_RESN_DESC)).andReturn(
				    createDropDownInfo());
	    createManagerVBs() ;
	    expect(lookupDao.getManagers()).andReturn(createManagers());
	    expect(lookupDao.getStates()).andReturn(createDropDownInfo());
	    
	    expect(lookupDao.getDropDownOnLoad(ServiceConstants.EMA_LMS_PROJ, ServiceConstants.PROJ_ID, ServiceConstants.PROJ_NAME)).andReturn(createDropDownInfo());
	}
	
	private List<DropDownInfo> createDropDownInfo() {
		List<DropDownInfo> dropDownInfoList = new ArrayList<DropDownInfo>();

		DropDownInfo dropDownInfoInfo1 = new DropDownInfo();
		dropDownInfoInfo1.setCode(String.valueOf(9));
		dropDownInfoInfo1.setAlternateCode("B");
		dropDownInfoInfo1.setDescription("Building");
		dropDownInfoList.add(dropDownInfoInfo1);

		DropDownInfo dropDownInfoInfo2 = new DropDownInfo();
		dropDownInfoInfo2.setCode(String.valueOf(10));
		dropDownInfoInfo2.setAlternateCode("O");
		dropDownInfoInfo2.setDescription("Office");
		dropDownInfoList.add(dropDownInfoInfo2);

		DropDownInfo dropDownInfoInfo3 = new DropDownInfo();
		dropDownInfoInfo3.setCode(String.valueOf(11));
		dropDownInfoInfo3.setAlternateCode("W");
		dropDownInfoInfo3.setDescription("Warehouse");
		dropDownInfoList.add(dropDownInfoInfo3);

		DropDownInfo dropDownInfoInfo4 = new DropDownInfo();
		dropDownInfoInfo4.setCode(String.valueOf(12));
		dropDownInfoInfo4.setAlternateCode("S");
		dropDownInfoInfo4.setDescription("Structure");

		dropDownInfoList.add(dropDownInfoInfo4);

		return dropDownInfoList;
	}
	private List<ManagerDTO> createManagers() {
		List<ManagerDTO> managers = new ArrayList<ManagerDTO>();

		ManagerDTO managerDTOInfo1 = new ManagerDTO();
		managerDTOInfo1.setFirstName("xyz");
		managerDTOInfo1.setEmployeeId("1") ;
		 //managerDTOInfo1.setLastUpdatedDate((Timestamp) new Date()) ;
		 managerDTOInfo1.setCreatedUser( "iots331") ;
		// managerDTOInfo1.setCreatedDate((Timestamp) new Date()) ;
		 managerDTOInfo1.setFullName( "fullName") ;
		 managerDTOInfo1.setActiveFlag( "C");
		 managerDTOInfo1.setUserId( "123") ;
		 managerDTOInfo1.setFirstName( "Anil") ;
		 managerDTOInfo1.setMiddleName( "Kumar") ;
		 managerDTOInfo1.setLastName( "Manchala") ;
		 managerDTOInfo1.setLastUpdateddUser( "iots331");
		 managerDTOInfo1.getManagerId() ;
		 managerDTOInfo1.getEmployeeId() ;
		 managerDTOInfo1.getUserId() ;
		 managerDTOInfo1.getFirstName() ;
		
		 managerDTOInfo1.getMiddleName();
		 managerDTOInfo1.getLastName() ;
		 managerDTOInfo1.getLastUpdateddUser();
		 managerDTOInfo1.getLastUpdatedDate() ;
		 managerDTOInfo1.getCreatedUser();
		
		 managerDTOInfo1.getCreatedDate() ;
		 managerDTOInfo1.getActiveFlag();
		 managerDTOInfo1.getFullName();
		
		managers.add(managerDTOInfo1);
		ManagerDTO managerDTOInfo2 = new ManagerDTO();
		managerDTOInfo1.setFirstName("abc");
		managers.add(managerDTOInfo2);

		return managers;
	}
	
	private List<ManagerVB> createManagerVBs() {
		List<ManagerVB> managers = new ArrayList<ManagerVB>();

		ManagerVB managerVB = new ManagerVB();
		 managerVB.setManagerId( 12) ;
		 managerVB.setEmployeeId("1") ;
		 managerVB.setLastUpdatedDate( "01/01/2018") ;
		 managerVB.setCreatedUser( "iots331") ;
		 managerVB.setCreatedDate( "01/01/2018") ;
		 managerVB.setFullName( "fullName") ;
		 managerVB.setActiveFlag( "C");
		 managerVB.setUserId( "123") ;
		 managerVB.setFirstName( "Anil") ;
		 managerVB.setMiddleName( "Kumar") ;
		 managerVB.setLastName( "Manchala") ;
		 managerVB.setLastUpdateddUser( "iots331");
		 managerVB.getManagerId() ;
		 managerVB.getEmployeeId() ;
		 managerVB.getUserId() ;
		 managerVB.getFirstName() ;
		
		 managerVB.getMiddleName();
		 managerVB.getLastName() ;
		 managerVB.getLastUpdateddUser();
		 managerVB.getLastUpdatedDate() ;
		 managerVB.getCreatedUser();
		
		 managerVB.getCreatedDate() ;
		 managerVB.getActiveFlag();
		 managerVB.getFullName();
		managers.add(managerVB);
		ManagerVB managerVB2 = new ManagerVB();
		managerVB2.setFirstName("abc");
		managers.add(managerVB2);

		return managers;
	}
}
