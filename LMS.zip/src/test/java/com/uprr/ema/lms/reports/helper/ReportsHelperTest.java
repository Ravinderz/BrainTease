package com.uprr.ema.lms.reports.helper;

import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.replay;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Sheet;
import org.easymock.EasyMockRunner;
import org.easymock.EasyMockSupport;
import org.easymock.TestSubject;
import org.junit.Test;
import org.junit.runner.RunWith;

import com.uprr.ema.lms.common.service.util.XlsxBuilder;
import com.uprr.ema.lms.reports.dto.LCRRprtDTO;
import com.uprr.ema.lms.reports.dto.LCRRprtSearchCriteriaDTO;
import com.uprr.ema.lms.reports.dto.OverAllDataLCRRprtDTO;

@RunWith(EasyMockRunner.class)
public class ReportsHelperTest extends EasyMockSupport{
	
	@TestSubject
	private ReportsHelper reportsHelper = new ReportsHelper();
	
	@Test
	public void testGetLCRReport(){
		try {
			HttpServletResponse response = mock(HttpServletResponse.class);
			ServletOutputStream servletOutputStream = mock(ServletOutputStream.class);
			
			LCRRprtSearchCriteriaDTO lcrRprtSearchCriteriaDTO = mock(LCRRprtSearchCriteriaDTO.class);
			lcrRprtSearchCriteriaDTO.setMonth("August");
			lcrRprtSearchCriteriaDTO.setYear("2018");
			
			response.setHeader("Content-Disposition", "inline; filename=Projects Report.docx");
			response.setContentType("application/msword");
			response.setCharacterEncoding("UTF-8");
			expect(response.getOutputStream()).andReturn(servletOutputStream);
			
			replay(response);
			List<LCRRprtDTO> lcrRprtDTOLst = new ArrayList<>();
			List<List<LCRRprtDTO>> LstOfLstLCRRprtDTO = new ArrayList<>();
			
			LCRRprtDTO lcrRprtDTO1 = new LCRRprtDTO();
			LCRRprtDTO lcrRprtDTO2 = new LCRRprtDTO();
			LCRRprtDTO lcrRprtDTO3 = new LCRRprtDTO();
			LCRRprtDTO lcrRprtDTO4 = new LCRRprtDTO();
			
			lcrRprtDTO1.setProjID(208);
			lcrRprtDTO1.setProjectName("data1");;
			lcrRprtDTO1.setCity("Omaha");;
			lcrRprtDTO1.setState("NE");
			lcrRprtDTO1.setTubeLvlId(7L);
			lcrRprtDTO1.setTotalLiabEstAmt(65000);
			lcrRprtDTO1.setChangedLiabilityEstimate(65000);
			
			lcrRprtDTO2.setProjID(240);
			lcrRprtDTO2.setProjectName("data2");;
			lcrRprtDTO2.setCity("Omaha");;
			lcrRprtDTO2.setState("NE");
			lcrRprtDTO2.setTubeLvlId(7L);
			lcrRprtDTO2.setTotalLiabEstAmt(65000);
			lcrRprtDTO2.setChangedLiabilityEstimate(65000);
			
			lcrRprtDTO3.setProjID(239);
			lcrRprtDTO3.setProjectName("data2");;
			lcrRprtDTO3.setCity("Omaha");;
			lcrRprtDTO3.setState("NE");
			lcrRprtDTO3.setTubeLvlId(7L);
			lcrRprtDTO3.setTotalLiabEstAmt(-65000);
			lcrRprtDTO3.setChangedLiabilityEstimate(-65000);
			
			lcrRprtDTOLst.add(lcrRprtDTO1);
			lcrRprtDTOLst.add(lcrRprtDTO2);
			lcrRprtDTOLst.add(lcrRprtDTO3);
			
			LstOfLstLCRRprtDTO.add(new ArrayList<>(lcrRprtDTOLst));
			LstOfLstLCRRprtDTO.add(new ArrayList<>(lcrRprtDTOLst));
			
			List<String> monthYear = new ArrayList<>();
			monthYear.add("September");
			monthYear.add("2018");
			OverAllDataLCRRprtDTO overAllDataLCRRprtDTO = new OverAllDataLCRRprtDTO();
			overAllDataLCRRprtDTO.setLcrRprtChngedAmtIncDecBy10000List(lcrRprtDTOLst);
			overAllDataLCRRprtDTO.setLcrRprtDTOLstofLst(LstOfLstLCRRprtDTO);
			overAllDataLCRRprtDTO.setLcrRprtLiabEstAmt(lcrRprtDTOLst);
			overAllDataLCRRprtDTO.setLcrRptDTOAllNewProjectLst(lcrRprtDTOLst);
			overAllDataLCRRprtDTO.setLcrRptDTOAllPrjctLstforTubeLevelGrtrThanSix(lcrRprtDTOLst);
			overAllDataLCRRprtDTO.setTotalLiabilityEstAmt(65000);
			overAllDataLCRRprtDTO.setTotalLiabilityEstChanged(65000);
			overAllDataLCRRprtDTO.setTotalLiabilityEstChangedForQrtr(65000);
			String[] firstLastDayStrings = new String[]{"September 01, 2018","September 21, 2018","September 21, 2018"};
			overAllDataLCRRprtDTO.setFirstLastDayStrings(firstLastDayStrings);
			
			reportsHelper.getLCRReport(response,lcrRprtSearchCriteriaDTO,overAllDataLCRRprtDTO);
		} catch (Exception e) {
		}
		
	}
	
	@Test
	public void generateLEWBHeaders(){
		//ReportsHelper reportsHelper = EasyMock.createMock(ReportsHelper.class);
		XlsxBuilder xlsBuilder =	new XlsxBuilder().startBlankSheet("Test");
		Sheet sheet = xlsBuilder.getSheet();
		String[] excelHeader = {};
		reportsHelper.generateLEWBHeaders(sheet, excelHeader, 300, "September", "2018");
	}
}