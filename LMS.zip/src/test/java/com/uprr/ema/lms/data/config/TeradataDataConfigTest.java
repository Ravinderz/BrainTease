package com.uprr.ema.lms.data.config;

import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.replay;

import org.easymock.EasyMock;
import org.easymock.EasyMockRunner;
import org.easymock.Mock;
import org.easymock.TestSubject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.core.env.Environment;

import com.uprr.ema.lms.common.constant.DataSourcePropertyKeyConstants;

@RunWith(EasyMockRunner.class)
public class TeradataDataConfigTest {
	
	@Mock
	private Environment environment;
	

	@Test
	public void jdbcTemplateTest(){
		TeradataDataConfig teradataConfig = EasyMock.createMock(TeradataDataConfig.class);
		expect(environment.getProperty("TERADATA_DB_INSTANCE")).andReturn("edwprdi0.edw.tla.uprr.com");
		expect(environment.getProperty(DataSourcePropertyKeyConstants.APPLICATION_TLA)).andReturn("EMA");
		expect(environment.getProperty("TERADATA_DBMS")).andReturn("TERADATA");
		expect(environment.getProperty("uprr.implementation.environment")).andReturn("win");
		expect(environment.getProperty("TERADATA_DRIVER_CLASS")).andReturn("com.teradata.jdbc.TeraDriver");
		expect(environment.getProperty("TERADATA_DB_USER_NAME")).andReturn("dema001");
		expect(environment.getProperty("TERADATA_DB_LOCAL_PASSWORD")).andReturn("dema001");
		expect((environment.getProperty("INITIAL_SIZE"))).andReturn("2");
		expect((environment.getProperty("MAX_ACTIVE"))).andReturn("10");
		expect((environment.getProperty("MAX_IDLE"))).andReturn("2");
		expect((environment.getProperty("MIN_IDLE"))).andReturn("1");
		expect(environment.getProperty("VALIDATION_QUERY")).andReturn("select 1 from dbo.vw_da_audit");
		expect((environment.getProperty("TRUE_PROP"))).andReturn("true");
		expect((environment.getProperty("VALIDATION_INTERVAL"))).andReturn("6000");
		expect((environment.getProperty("TRUE_PROP"))).andReturn("true");
		replay();
		teradataConfig.jdbcTemplate();
	}
}
