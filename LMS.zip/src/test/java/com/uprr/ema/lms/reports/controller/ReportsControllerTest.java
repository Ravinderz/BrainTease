package com.uprr.ema.lms.reports.controller;

import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.replay;
import static org.mockito.Matchers.anyObject;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.easymock.EasyMock;
import org.easymock.EasyMockRunner;
import org.easymock.EasyMockSupport;
import org.easymock.Mock;
import org.easymock.TestSubject;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.util.ReflectionTestUtils;

import com.uprr.ema.lms.reports.controller.ReportsController;
import com.uprr.ema.lms.reports.dto.LCRRprtSearchCriteriaDTO;
import com.uprr.ema.lms.reports.helper.ReportsHelper;
import com.uprr.ema.lms.reports.service.api.ReportsService;

@RunWith(EasyMockRunner.class)
public class ReportsControllerTest extends EasyMockSupport{


	@TestSubject
	private ReportsHelper reportsHelper = new ReportsHelper();
	
	@Mock
	private ReportsService reportsService;
	
	@TestSubject
	private ReportsController reportsController = new ReportsController();
	
	/*@Before
	public void initializeTestObjects() {
		ReflectionTestUtils.setField(reportsController, "reportsHelper", reportsHelper);
	}*/

	@Test
	public void testGetLCRReport(){
		try {
			HttpServletResponse response = mock(HttpServletResponse.class);
			LCRRprtSearchCriteriaDTO lcrRprtSearchCriteriaDTO = new LCRRprtSearchCriteriaDTO();
			lcrRprtSearchCriteriaDTO.setMonth("August");
			lcrRprtSearchCriteriaDTO.setYear("2018");
			
			response.setHeader("Content-Disposition", "inline; filename=Projects Report.docx");
			response.setContentType("application/msword");
			response.setCharacterEncoding("UTF-8");
			replay(response);
			
			reportsController.getLCRReport(response,lcrRprtSearchCriteriaDTO);
		} catch (Exception e) {
		}
		
	}
	
	@Test
	public void testGenerateLCRBarChart(){
		try {
			HttpServletResponse response = mock(HttpServletResponse.class);
			LCRRprtSearchCriteriaDTO lcrRprtSearchCriteriaDTO = new LCRRprtSearchCriteriaDTO();
			lcrRprtSearchCriteriaDTO.setMonth("August");
			lcrRprtSearchCriteriaDTO.setYear("2018");
			
			response.setHeader("Content-Disposition", "inline; filename=Projects Report.docx");
			response.setContentType("application/msword");
			response.setCharacterEncoding("UTF-8");
			replay(response);
			
			reportsController.generateLCRBarChart(response,lcrRprtSearchCriteriaDTO.getMonth(),lcrRprtSearchCriteriaDTO.getYear());
		} catch (Exception e) {
		}
		
	}
	
	@Test
	public void generateBppdreportTest(){
		try {
			HttpServletResponse response = mock(HttpServletResponse.class);
			ServletOutputStream servletOutputStream = mock(ServletOutputStream.class);
			expect(response.getOutputStream()).andReturn(servletOutputStream).times(1);
			response.setHeader("Content-Disposition", "inline; filename=Business Plan Prep Report.xlsx");
			response.setContentType("application/vnd.ms-excel");
			response.setCharacterEncoding("UTF-8");
			replay(response);
			String month = "Feburary";
			String year = "2018";
			reportsService.getBppdExcelReport(response, month, year);
			EasyMock.expectLastCall();
			reportsController.generateBppdReport(response,month,year);
		} catch (Exception e) {
		}
		
	}
	
	@Test
	public void generateSiteSourceReportTest(){
		try {
			HttpServletResponse response = mock(HttpServletResponse.class);
			ServletOutputStream servletOutputStream = mock(ServletOutputStream.class);
			expect(response.getOutputStream()).andReturn(servletOutputStream).times(1);
			response.setHeader("Content-Disposition", "inline; filename=Site Source update.xlsx");
			response.setContentType("application/vnd.ms-excel");
			response.setCharacterEncoding("UTF-8");
			replay(response);
			String year = "2018";
			String month = "September";
			reportsService.getSiteSourceExcelReport(response,month, year);
			EasyMock.expectLastCall();
			reportsController.generateSiteSourceReport(response,month,year);
		} catch (Exception e) {
		}
		
	}
	
	@Test
	public void generateMonthlySpendReportTest(){
		try {
			HttpServletResponse response = mock(HttpServletResponse.class);
			ServletOutputStream servletOutputStream = mock(ServletOutputStream.class);
			expect(response.getOutputStream()).andReturn(servletOutputStream).times(1);
			response.setHeader("Content-Disposition", "inline; filename=Monthly Spend Report.xlsx");
			response.setContentType("application/vnd.ms-excel");
			response.setCharacterEncoding("UTF-8");
			replay(response);
			String year = "2018";
			String month = "September";
			reportsService.getSiteSourceExcelReport(response,month, year);
			EasyMock.expectLastCall();
			reportsController.generateMonthlySpendReport(response,month,year);
		} catch (Exception e) {
		}
		
	}
	
	
	
}
