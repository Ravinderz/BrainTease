package com.uprr.ema.lms.reports.service.impl;

import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.replay;
import static org.mockito.Matchers.anyString;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.easymock.EasyMock;
import org.easymock.EasyMockRunner;
import org.easymock.EasyMockSupport;
import org.easymock.Mock;
import org.easymock.TestSubject;
import org.junit.Test;
import org.junit.runner.RunWith;

import com.uprr.ema.lms.common.util.WebDateUtils;
import com.uprr.ema.lms.reports.dao.api.ReportsDao;
import com.uprr.ema.lms.reports.dao.api.ReportsOracleDao;
import com.uprr.ema.lms.reports.dao.impl.ReportsOracleDaoImpl;
import com.uprr.ema.lms.reports.dto.BusinessPrepPlanDTO;
import com.uprr.ema.lms.reports.dto.LCRRprtChartDTO;
import com.uprr.ema.lms.reports.dto.LCRRprtDTO;
import com.uprr.ema.lms.reports.dto.LCRRprtSearchCriteriaDTO;
import com.uprr.ema.lms.reports.dto.MonthlySpendDTO;
import com.uprr.ema.lms.reports.dto.SiteSourceDTO;
import com.uprr.ema.lms.reports.service.api.ReportsService;

@RunWith(EasyMockRunner.class)
public class ReportsServiceImplTest extends EasyMockSupport{
	
	@Mock
	private ReportsDao reportsDao;
	
	@Mock
	private ReportsOracleDao oracleDao;
	
	@Mock
	private WebDateUtils webDateUtils;
	
	
	@TestSubject
	private ReportsServiceImpl reportsServiceMock = new ReportsServiceImpl();
	
	@TestSubject
	private ReportsOracleDao oracleDaoSub= new ReportsOracleDaoImpl();
	
/*	@Before
	public void setUp() {
	}*/
	
	@Test
	public void GetBppdExcelReportTest() throws IOException{
		ReportsService reportsServiceImpl = EasyMock.createMock(ReportsServiceImpl.class);
		String month = "February";
		String year = "2018";
		BusinessPrepPlanDTO bppd1 = new BusinessPrepPlanDTO("EMA", "001/2018", "test", "test", "20394", "Unit Testing", "jd84jkads834", "203948", "Testing");
		BusinessPrepPlanDTO bppd2 = new BusinessPrepPlanDTO("EMA", "002/2018", "test", "test", "20393", "Unit Testing", "jd84jkads834", "203948", "Testing");
		List<BusinessPrepPlanDTO> teradataList = new ArrayList<>();
		teradataList.add(bppd1);
		teradataList.add(bppd2);
		expect(reportsDao.getBusinessPrepPlanData(anyString(),anyString())).andReturn(teradataList);
		
		BusinessPrepPlanDTO bppd3 = new BusinessPrepPlanDTO("EMA", "001/2018", "test", "test", "20394", "Unit Testing", "jd84jkads834", "203948", "Testing");
		BusinessPrepPlanDTO bppd4 = new BusinessPrepPlanDTO("EMA", "002/2018", "test", "test", "20393", "Unit Testing", "jd84jkads834", "203948", "Testing");
		List<BusinessPrepPlanDTO> oracleList = new ArrayList<>();
		oracleList.add(bppd3);
		oracleList.add(bppd4);
		
		Set<String> networkNumberSet = new HashSet<>();
		networkNumberSet.add("1234");
		networkNumberSet.add("2345");
		
		expect(oracleDao.getProjectDetailsBasedOnNetworkId(networkNumberSet)).andReturn(oracleList);
		HttpServletResponse response = mock(HttpServletResponse.class);
		ServletOutputStream servletOutputStream = mock(ServletOutputStream.class);
		expect(response.getOutputStream()).andReturn(servletOutputStream).times(1);
		replay(response);
		reportsServiceImpl.getBppdExcelReport(response, month, year);
	}
	  
	@Test
	public void GetSiteSourceReportTest() throws IOException{
		ReportsService reportsServiceImpl = EasyMock.createMock(ReportsServiceImpl.class);
		String year = "2018";
		String month = "September";
		SiteSourceDTO dto1 = new SiteSourceDTO();
		dto1.setNum(1);
		dto1.setNetwork("1234");
		SiteSourceDTO dto2 = new SiteSourceDTO();
		dto2.setNum(2);
		dto2.setNetwork("2345");
		List<SiteSourceDTO> list = new ArrayList<>();
		list.add(dto1);
		list.add(dto2);
		Set<String> networkNumberSet = new HashSet<>();
		networkNumberSet.add("1234");
		networkNumberSet.add("2345");
		expect(oracleDao.getSiteSourceProjDetailsBasedOnNetworkId(anyString())).andReturn(list);
		//expect(ReportsServiceImpl.getDistinctNetworkValues(list)).andReturn(networkNumberSet);
		List<String> spendingList = new ArrayList<>();
		spendingList.add("1200");
		spendingList.add("0");
		spendingList.add("112345");
		dto1.setSpendingPerYear(spendingList);
		dto2.setSpendingPerYear(spendingList);
		List<SiteSourceDTO> resultList = new ArrayList<>();
		resultList.add(dto1);
		resultList.add(dto2);
		expect(reportsDao.getPerYearSpendingData(networkNumberSet,"2018009")).andReturn(resultList);
		
		
		HttpServletResponse response = mock(HttpServletResponse.class);
		ServletOutputStream servletOutputStream = mock(ServletOutputStream.class);
		expect(response.getOutputStream()).andReturn(servletOutputStream).times(1);
		response.setHeader("Content-Disposition", "inline; filename="+ "Site Source List - 2018 update");
		response.setContentType("application/vnd.ms-excel");
		response.setCharacterEncoding("UTF-8");
		replay(response);
		reportsServiceImpl.getSiteSourceExcelReport(response, month,year);
	}
	
	@Test
	public void GetMonthlySpendReportTest() throws IOException{
		ReportsService reportsServiceImpl = EasyMock.createMock(ReportsServiceImpl.class);
		String month = "February";
		String year = "2018";
		MonthlySpendDTO dto1 = new MonthlySpendDTO("EMA1", "234345", "002/2018", "test", "test", "20394", "Testing","invoice", "id", "testingg ", "INV9493", "20000");
		MonthlySpendDTO dto2 = new MonthlySpendDTO("EMA1", "23435", "002/2018", "test", "test", "20394", "Testing","invocie", "id", "testingg ", "INV9493", "20000");
		List<MonthlySpendDTO> monthlySpendOracleList = new ArrayList<>();
		monthlySpendOracleList.add(dto1);
		monthlySpendOracleList.add(dto2);
		expect(oracleDao.getMonthlySpendDataFromOracle()).andReturn(monthlySpendOracleList);
		
		Set<String> networkNumberSet = new HashSet<>();
		networkNumberSet.add("234345");
		networkNumberSet.add("23435");
		
		MonthlySpendDTO dto3 = new MonthlySpendDTO("EMA1", "234345", "002/2018", "test", "test", "20394", "Testing","invoice", "id", "testingg ", "INV9493", "20000");
		MonthlySpendDTO dto4 = new MonthlySpendDTO("EMA1", "23435", "002/2018", "test", "test", "20394", "Testing","invoice", "id", "testingg ", "INV9493", "20000");
		List<MonthlySpendDTO> monthlySpendTeraDataList = new ArrayList<>();
		monthlySpendTeraDataList.add(dto3);
		monthlySpendTeraDataList.add(dto4);
		expect(reportsDao.getMonthlySpendDataFromTeradata(networkNumberSet,"2018001","2018002")).andReturn(monthlySpendTeraDataList);		
		HttpServletResponse response = mock(HttpServletResponse.class);
		ServletOutputStream servletOutputStream = mock(ServletOutputStream.class);
		expect(response.getOutputStream()).andReturn(servletOutputStream).times(1);
		replay(response);
		reportsServiceImpl.getBppdExcelReport(response, month, year);
	}
	
	@Test
	public void testGetLCRReport(){
		try {
			HttpServletResponse response = mock(HttpServletResponse.class);
			LCRRprtSearchCriteriaDTO lcrRprtSearchCriteriaDTO = new LCRRprtSearchCriteriaDTO();
			lcrRprtSearchCriteriaDTO.setMonth("August");
			lcrRprtSearchCriteriaDTO.setYear("2018");
			
			response.setHeader("Content-Disposition", "inline; filename=Projects Report.docx");
			response.setContentType("application/msword");
			response.setCharacterEncoding("UTF-8");
			replay(response);
			List<LCRRprtDTO> lcrRprtDTOLst = new ArrayList<>();
			
			LCRRprtDTO lcrRprtDTO1 = new LCRRprtDTO();
			LCRRprtDTO lcrRprtDTO2 = new LCRRprtDTO();
			LCRRprtDTO lcrRprtDTO3 = new LCRRprtDTO();
			
			lcrRprtDTO1.setProjID(208);
			lcrRprtDTO1.setProjectName("data1");;
			lcrRprtDTO1.setCity("Omaha");;
			lcrRprtDTO1.setState("NE");
			lcrRprtDTO1.setTubeLvlId(7L);
			lcrRprtDTO1.setTotalLiabEstAmt(65000);
			lcrRprtDTO1.setChangedLiabilityEstimate(65000);
			
			lcrRprtDTO2.setProjID(240);
			lcrRprtDTO2.setProjectName("data2");;
			lcrRprtDTO2.setCity("Omaha");;
			lcrRprtDTO2.setState("NE");
			lcrRprtDTO2.setTubeLvlId(7L);
			lcrRprtDTO2.setTotalLiabEstAmt(65000);
			lcrRprtDTO2.setChangedLiabilityEstimate(65000);
			
			lcrRprtDTO3.setProjID(239);
			lcrRprtDTO3.setProjectName("data2");;
			lcrRprtDTO3.setCity("Omaha");;
			lcrRprtDTO3.setState("NE");
			lcrRprtDTO3.setTubeLvlId(7L);
			lcrRprtDTO3.setTotalLiabEstAmt(-65000);
			lcrRprtDTO3.setChangedLiabilityEstimate(-65000);
			
			lcrRprtDTOLst.add(lcrRprtDTO1);
			lcrRprtDTOLst.add(lcrRprtDTO2);
			lcrRprtDTOLst.add(lcrRprtDTO3);
			
			List<String> monthYear = new ArrayList<>();
			monthYear.add("September");
			monthYear.add("2018");
			
			LCRRprtSearchCriteriaDTO lcrRprtSearchCriteriaForQuarter = new LCRRprtSearchCriteriaDTO();
			lcrRprtSearchCriteriaForQuarter.setMonth("August");
			lcrRprtSearchCriteriaForQuarter.setYear("2018");
			
			expect(oracleDao.getAllProjectLstforSumOfLiabEst(lcrRprtSearchCriteriaDTO)).andReturn(lcrRprtDTOLst);
			expect(oracleDao.getProjectListIncrsedChngdEstBy10000forMMYYYY(lcrRprtSearchCriteriaDTO)).andReturn(lcrRprtDTOLst);
			expect(oracleDao.getAllProjectLstforTubelevelGreaterThan6(lcrRprtSearchCriteriaDTO)).andReturn(lcrRprtDTOLst);
			expect(oracleDao.getNewProjectListforMMYYYY(lcrRprtSearchCriteriaDTO)).andReturn(lcrRprtDTOLst);
			replay(oracleDao);
			
			
			reportsServiceMock.getLCRReport(response,lcrRprtSearchCriteriaDTO);
		} catch (Exception e) {
		}
		catch (AssertionError error) {
		}
	}
	
	@Test
	public void testGetSumOfAllLiabilityEstOfQuarterLCRRpt(){
		try {
			HttpServletResponse response = mock(HttpServletResponse.class);
			LCRRprtSearchCriteriaDTO lcrRprtSearchCriteriaDTO = new LCRRprtSearchCriteriaDTO();
			ReportsOracleDao oracleDaoSub= mock(ReportsOracleDao.class);
			lcrRprtSearchCriteriaDTO.setMonth("August");
			lcrRprtSearchCriteriaDTO.setYear("2018");
			
			response.setHeader("Content-Disposition", "inline; filename=Projects Report.docx");
			response.setContentType("application/msword");
			response.setCharacterEncoding("UTF-8");
			replay(response);
			List<LCRRprtDTO> lcrRprtDTOLst = new ArrayList<>();
			
			LCRRprtDTO lcrRprtDTO1 = new LCRRprtDTO();
			LCRRprtDTO lcrRprtDTO2 = new LCRRprtDTO();
			LCRRprtDTO lcrRprtDTO3 = new LCRRprtDTO();
			
			lcrRprtDTO1.setProjID(208);
			lcrRprtDTO1.setProjectName("data1");;
			lcrRprtDTO1.setCity("Omaha");;
			lcrRprtDTO1.setState("NE");
			lcrRprtDTO1.setTubeLvlId(7L);
			lcrRprtDTO1.setTotalLiabEstAmt(65000);
			lcrRprtDTO1.setChangedLiabilityEstimate(65000);
			
			lcrRprtDTO2.setProjID(240);
			lcrRprtDTO2.setProjectName("data2");;
			lcrRprtDTO2.setCity("Omaha");;
			lcrRprtDTO2.setState("NE");
			lcrRprtDTO2.setTubeLvlId(7L);
			lcrRprtDTO2.setTotalLiabEstAmt(65000);
			lcrRprtDTO2.setChangedLiabilityEstimate(65000);
			
			lcrRprtDTO3.setProjID(239);
			lcrRprtDTO3.setProjectName("data2");;
			lcrRprtDTO3.setCity("Omaha");;
			lcrRprtDTO3.setState("NE");
			lcrRprtDTO3.setTubeLvlId(7L);
			lcrRprtDTO3.setTotalLiabEstAmt(-65000);
			lcrRprtDTO3.setChangedLiabilityEstimate(-65000);
			
			lcrRprtDTOLst.add(lcrRprtDTO1);
			lcrRprtDTOLst.add(lcrRprtDTO2);
			lcrRprtDTOLst.add(lcrRprtDTO3);
			
			List<String> monthYear = new ArrayList<>();
			monthYear.add("September");
			monthYear.add("2018");
			
			LCRRprtSearchCriteriaDTO lcrRprtSearchCriteriaForQuarter = new LCRRprtSearchCriteriaDTO();
			lcrRprtSearchCriteriaForQuarter.setMonth("August");
			lcrRprtSearchCriteriaForQuarter.setYear("2018");
			
			expect(oracleDaoSub.getProjectListIncrsedChngdEstBy10000forMMYYYY(lcrRprtSearchCriteriaDTO)).andReturn(lcrRprtDTOLst);
			replay(oracleDaoSub);
			
			
			reportsServiceMock.getSumOfAllLiabilityEstOfQuarterLCRRpt(lcrRprtSearchCriteriaDTO);
			reportsServiceMock.getSumAllChangedEstForLCRReport(lcrRprtDTOLst);
		} catch (Exception e) {
		}
	}	
	
	@Test
	public void testGetSumAllChangedEstForLCRReport(){
		try {
			HttpServletResponse response = mock(HttpServletResponse.class);
			LCRRprtSearchCriteriaDTO lcrRprtSearchCriteriaDTO = new LCRRprtSearchCriteriaDTO();
			ReportsOracleDao oracleDaoSub= mock(ReportsOracleDao.class);
			lcrRprtSearchCriteriaDTO.setMonth("August");
			lcrRprtSearchCriteriaDTO.setYear("2018");
			
			response.setHeader("Content-Disposition", "inline; filename=Projects Report.docx");
			response.setContentType("application/msword");
			response.setCharacterEncoding("UTF-8");
			replay(response);
			List<LCRRprtDTO> lcrRprtDTOLst = new ArrayList<>();
			
			LCRRprtDTO lcrRprtDTO1 = new LCRRprtDTO();
			LCRRprtDTO lcrRprtDTO2 = new LCRRprtDTO();
			LCRRprtDTO lcrRprtDTO3 = new LCRRprtDTO();
			
			lcrRprtDTO1.setProjID(208);
			lcrRprtDTO1.setProjectName("data1");;
			lcrRprtDTO1.setCity("Omaha");;
			lcrRprtDTO1.setState("NE");
			lcrRprtDTO1.setTubeLvlId(7L);
			lcrRprtDTO1.setTotalLiabEstAmt(65000);
			lcrRprtDTO1.setChangedLiabilityEstimate(65000);
			
			lcrRprtDTO2.setProjID(240);
			lcrRprtDTO2.setProjectName("data2");;
			lcrRprtDTO2.setCity("Omaha");;
			lcrRprtDTO2.setState("NE");
			lcrRprtDTO2.setTubeLvlId(7L);
			lcrRprtDTO2.setTotalLiabEstAmt(65000);
			lcrRprtDTO2.setChangedLiabilityEstimate(65000);
			
			lcrRprtDTO3.setProjID(239);
			lcrRprtDTO3.setProjectName("data2");;
			lcrRprtDTO3.setCity("Omaha");;
			lcrRprtDTO3.setState("NE");
			lcrRprtDTO3.setTubeLvlId(7L);
			lcrRprtDTO3.setTotalLiabEstAmt(-65000);
			lcrRprtDTO3.setChangedLiabilityEstimate(-65000);
			
			lcrRprtDTOLst.add(lcrRprtDTO1);
			lcrRprtDTOLst.add(lcrRprtDTO2);
			lcrRprtDTOLst.add(lcrRprtDTO3);
			
			List<String> monthYear = new ArrayList<>();
			monthYear.add("September");
			monthYear.add("2018");
			
			LCRRprtSearchCriteriaDTO lcrRprtSearchCriteriaForQuarter = new LCRRprtSearchCriteriaDTO();
			lcrRprtSearchCriteriaForQuarter.setMonth("August");
			lcrRprtSearchCriteriaForQuarter.setYear("2018");
			
			expect(oracleDaoSub.getProjectListIncrsedChngdEstBy10000forMMYYYY(lcrRprtSearchCriteriaDTO)).andReturn(lcrRprtDTOLst);
			
			
			reportsServiceMock.getSumAllChangedEstForLCRReport(lcrRprtDTOLst);
		} catch (Exception e) {
		}
	}
	
	@Test
	public void testGetSumAllLiabilityEstForLCRReport(){
		try {
			HttpServletResponse response = mock(HttpServletResponse.class);
			LCRRprtSearchCriteriaDTO lcrRprtSearchCriteriaDTO = new LCRRprtSearchCriteriaDTO();
			ReportsOracleDao oracleDaoSub= mock(ReportsOracleDao.class);
			lcrRprtSearchCriteriaDTO.setMonth("August");
			lcrRprtSearchCriteriaDTO.setYear("2018");
			
			response.setHeader("Content-Disposition", "inline; filename=Projects Report.docx");
			response.setContentType("application/msword");
			response.setCharacterEncoding("UTF-8");
			replay(response);
			List<LCRRprtDTO> lcrRprtDTOLst = new ArrayList<>();
			
			LCRRprtDTO lcrRprtDTO1 = new LCRRprtDTO();
			LCRRprtDTO lcrRprtDTO2 = new LCRRprtDTO();
			LCRRprtDTO lcrRprtDTO3 = new LCRRprtDTO();
			
			lcrRprtDTO1.setProjID(208);
			lcrRprtDTO1.setProjectName("data1");;
			lcrRprtDTO1.setCity("Omaha");;
			lcrRprtDTO1.setState("NE");
			lcrRprtDTO1.setTubeLvlId(7L);
			lcrRprtDTO1.setTotalLiabEstAmt(65000);
			lcrRprtDTO1.setChangedLiabilityEstimate(65000);
			
			lcrRprtDTO2.setProjID(240);
			lcrRprtDTO2.setProjectName("data2");;
			lcrRprtDTO2.setCity("Omaha");;
			lcrRprtDTO2.setState("NE");
			lcrRprtDTO2.setTubeLvlId(7L);
			lcrRprtDTO2.setTotalLiabEstAmt(65000);
			lcrRprtDTO2.setChangedLiabilityEstimate(65000);
			
			lcrRprtDTO3.setProjID(239);
			lcrRprtDTO3.setProjectName("data2");;
			lcrRprtDTO3.setCity("Omaha");;
			lcrRprtDTO3.setState("NE");
			lcrRprtDTO3.setTubeLvlId(7L);
			lcrRprtDTO3.setTotalLiabEstAmt(-65000);
			lcrRprtDTO3.setChangedLiabilityEstimate(-65000);
			
			lcrRprtDTOLst.add(lcrRprtDTO1);
			lcrRprtDTOLst.add(lcrRprtDTO2);
			lcrRprtDTOLst.add(lcrRprtDTO3);
			
			List<String> monthYear = new ArrayList<>();
			monthYear.add("September");
			monthYear.add("2018");
			
			LCRRprtSearchCriteriaDTO lcrRprtSearchCriteriaForQuarter = new LCRRprtSearchCriteriaDTO();
			lcrRprtSearchCriteriaForQuarter.setMonth("August");
			lcrRprtSearchCriteriaForQuarter.setYear("2018");
			
			expect(oracleDaoSub.getProjectListIncrsedChngdEstBy10000forMMYYYY(lcrRprtSearchCriteriaDTO)).andReturn(lcrRprtDTOLst);
			replay(oracleDaoSub);
			
			
			reportsServiceMock.getSumAllLiabilityEstForLCRReport(lcrRprtDTOLst);
		} catch (Exception e) {
		}
	}
	
	@Test
	public void testGenerateLCRBarChart(){
		try {
			HttpServletResponse response = mock(HttpServletResponse.class);
			LCRRprtSearchCriteriaDTO lcrRprtSearchCriteriaDTO = new LCRRprtSearchCriteriaDTO();
			lcrRprtSearchCriteriaDTO.setMonth("August");
			lcrRprtSearchCriteriaDTO.setYear("2018");
			
			response.setHeader("Content-Disposition", "inline; filename=Projects Report.docx");
			response.setContentType("application/msword");
			response.setCharacterEncoding("UTF-8");
			replay(response);
			List<LCRRprtDTO> lcrRprtDTOLst = new ArrayList<>();
			
			LCRRprtDTO lcrRprtDTO1 = new LCRRprtDTO();
			LCRRprtDTO lcrRprtDTO2 = new LCRRprtDTO();
			LCRRprtDTO lcrRprtDTO3 = new LCRRprtDTO();
			
			lcrRprtDTO1.setProjID(208);
			lcrRprtDTO1.setProjectName("data1");;
			lcrRprtDTO1.setCity("Omaha");;
			lcrRprtDTO1.setState("NE");
			lcrRprtDTO1.setTubeLvlId(7L);
			lcrRprtDTO1.setTotalLiabEstAmt(65000);
			lcrRprtDTO1.setChangedLiabilityEstimate(65000);
			
			lcrRprtDTO2.setProjID(240);
			lcrRprtDTO2.setProjectName("data2");;
			lcrRprtDTO2.setCity("Omaha");;
			lcrRprtDTO2.setState("NE");
			lcrRprtDTO2.setTubeLvlId(7L);
			lcrRprtDTO2.setTotalLiabEstAmt(65000);
			lcrRprtDTO2.setChangedLiabilityEstimate(65000);
			
			lcrRprtDTO3.setProjID(239);
			lcrRprtDTO3.setProjectName("data2");;
			lcrRprtDTO3.setCity("Omaha");;
			lcrRprtDTO3.setState("NE");
			lcrRprtDTO3.setTubeLvlId(7L);
			lcrRprtDTO3.setTotalLiabEstAmt(-65000);
			lcrRprtDTO3.setChangedLiabilityEstimate(-65000);
			
			lcrRprtDTOLst.add(lcrRprtDTO1);
			lcrRprtDTOLst.add(lcrRprtDTO2);
			lcrRprtDTOLst.add(lcrRprtDTO3);
			
			List<String> monthYear = new ArrayList<>();
			monthYear.add("September");
			monthYear.add("2018");
			
			LCRRprtSearchCriteriaDTO lcrRprtSearchCriteriaForQuarter = new LCRRprtSearchCriteriaDTO();
			lcrRprtSearchCriteriaForQuarter.setMonth("August");
			lcrRprtSearchCriteriaForQuarter.setYear("2018");
			List<LCRRprtChartDTO> lcrRprtChartDTOlst = new ArrayList<>(); 
			LCRRprtChartDTO lcrRprtChartDTO = new LCRRprtChartDTO();
			lcrRprtChartDTO.setMonthYear(10);
			lcrRprtChartDTO.setTotalLiabilityChangeAmtForMonth(20.10F);
			lcrRprtChartDTOlst.add(lcrRprtChartDTO);
			
			expect(reportsDao.getActualExpenditureData(lcrRprtSearchCriteriaDTO.getMonth(),lcrRprtSearchCriteriaDTO.getYear())).andReturn(lcrRprtChartDTOlst);
			replay(reportsDao);
			expect(oracleDao.getTotalCostPlannedExpndtrForYear(lcrRprtSearchCriteriaDTO.getYear())).andReturn(67000F);
			replay(oracleDao);
			reportsServiceMock.generateLCRBarChart(response,lcrRprtSearchCriteriaForQuarter.getMonth(),lcrRprtSearchCriteriaForQuarter.getYear());
		} catch (Exception e) {
		}
	}
	
	
	
	
}
