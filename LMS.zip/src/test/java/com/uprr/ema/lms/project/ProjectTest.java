package com.uprr.ema.lms.project;



import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.expectLastCall;
import static org.easymock.EasyMock.isA;
import static org.easymock.EasyMock.replay;
import static org.easymock.EasyMock.verify;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.easymock.EasyMockRunner;
import org.easymock.Mock;
import org.easymock.TestSubject;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.util.ReflectionTestUtils;

import com.uprr.ema.lms.common.dao.api.LookupDao;
import com.uprr.ema.lms.common.dto.DropDownInfo;
import com.uprr.ema.lms.common.dto.ManagerDTO;
import com.uprr.ema.lms.common.dto.SendMailDTO;
import com.uprr.ema.lms.common.service.api.CommonService;
import com.uprr.ema.lms.common.service.api.IAuthorizationService;
import com.uprr.ema.lms.common.service.api.IENAEmailService;
import com.uprr.ema.lms.common.service.api.LookupService;
import com.uprr.ema.lms.common.service.impl.CommonServiceImpl;
import com.uprr.ema.lms.common.service.impl.LookupServiceImpl;
import com.uprr.ema.lms.common.service.util.ServiceConstants;
import com.uprr.ema.lms.liabilityProject.controller.GenerateLEWBController;
import com.uprr.ema.lms.liabilityProject.dao.api.LiabilityProjectDao;
import com.uprr.ema.lms.liabilityProject.dto.DisapproveProjDTO;
import com.uprr.ema.lms.liabilityProject.dto.ProjectCostDTO;
import com.uprr.ema.lms.liabilityProject.dto.ProjectDTO;
import com.uprr.ema.lms.liabilityProject.helper.LiabilityProjectHelper;
import com.uprr.ema.lms.liabilityProject.service.api.LiabilityProjectService;
import com.uprr.ema.lms.liabilityProject.service.impl.LiabilityProjectServiceImpl;
import com.uprr.ema.lms.liabilityProject.vb.ProjectCostVB;
import com.uprr.ema.lms.liabilityProject.vb.ProjectVB;
import com.uprr.ema.lms.searchproject.dto.LEWBReportDto;
import com.uprr.ema.lms.searchproject.service.api.ProjectSearchService;
import com.uprr.ui.shared.user.ActiveUserId;



@RunWith(EasyMockRunner.class)
public class ProjectTest {

	private static final long INSP_ID = 318;
	private static final long DTL_ID = 10;

	@TestSubject
	private LiabilityProjectHelper lesseResponseHelper = new LiabilityProjectHelper();

	@TestSubject
	private LiabilityProjectService  liabProjService = new LiabilityProjectServiceImpl();
	
	@TestSubject
	private LiabilityProjectHelper liabilityProjectHelper = new LiabilityProjectHelper();
	
	
	

	LookupService lookupService = new LookupServiceImpl();

	CommonService commonTestService = new CommonServiceImpl();
	
	//IENAEmailService emailService = new ENAEmailServiceImpl();

	@Mock
	LiabilityProjectDao liabProjtDao;
	
	@Mock
	IAuthorizationService autherizationService;

	@Mock
	LookupDao lookupDao;
	
	@Mock
	IENAEmailService emailService;
	
	@Mock
	ProjectSearchService projectSearchService;

	@Before
	public void initializeTestObjects() {
	    ReflectionTestUtils.setField(liabilityProjectHelper, "liabProjService", liabProjService);
	    	ReflectionTestUtils.setField(lookupService, "lookupDao", lookupDao);
		ReflectionTestUtils.setField(liabProjService, "liabProjtDao", liabProjtDao);
		ReflectionTestUtils.setField(liabProjService, "lookupService", lookupService);
		
		ReflectionTestUtils.setField(liabProjService, "emailService", emailService);
		ReflectionTestUtils.setField(liabProjService, "autherizationService", autherizationService);
	}
	
	@Test
	public void getLookUpDataTest() throws Exception{
	    
	    setDaoExpectations();
	    replay(lookupDao);
	    liabilityProjectHelper.getLookUpData();
	}
	
	@Test
	public void getPendignApproalProjects() throws Exception{
	    expect( liabProjtDao.getPendignApprovalProjects()).andReturn(createProjectDTOs());
	    replay(liabProjtDao);
	    liabilityProjectHelper.getPendingApprovalProjects();
	}
	
	@Test
	public void getDisApprovedProjects() throws Exception{
	    expect( liabProjtDao.getDisApprovedProjects()).andReturn(createProjectDTOs());
	    replay(liabProjtDao);
	    DisapproveProjDTO disapproveProjDTO = createDisapproveProjDTO();
	   
	    liabilityProjectHelper.getDisApprovedProjects();
	}
	
	@Test
	public void getProjectDetailsById() throws Exception{
	    
	    setDaoExpectations();
	    expect( liabProjtDao.getProjectByProjId(1)).andReturn(createNewProject()).times(1);
	    expect( liabProjtDao.getProjNoneApprovedCosts(1)) .andReturn(createProjectCostDTOs()).times(1);
	    expect( liabProjtDao.getCosts( 1, ServiceConstants.ACTION_TYPE_PROJ,  ServiceConstants.ACTN_SUBMITTED)) .andReturn(createProjectCostDTOs()).times(1);
	    replay(lookupDao);
	    replay(liabProjtDao);
	    liabilityProjectHelper.getProjectByProjId(1);
	}
	
	
	@Test
	public void testSaveProjectDetails(){
		liabProjtDao.updateProjectDetails(isA(ProjectDTO.class));
		 expectLastCall().times(1);
		 liabProjtDao.updateApprovedProjToHistory(isA(ProjectDTO.class));
		 expectLastCall().times(1);
		// expect(liabProjtDao.saveProjId(isA(ProjectDTO.class))).andReturn(1l).times(1);
		 expect(liabProjtDao.saveProjectDetails(isA(ProjectDTO.class))).andReturn(1l).times(1);
		 liabProjtDao.updateProjectCostDetails(isA(ProjectCostDTO.class));
		 expectLastCall().times(1);
		 expect(liabProjtDao.saveProjectCostDetails(isA(ProjectCostDTO.class))).andReturn(1l).times(1);
		 replay(liabProjtDao);
		 emailService.sendEmailNotification(isA(SendMailDTO.class));
		 replay(emailService);
		 ProjectVB vb = createNewProjectVB();
		 vb.setCurrentCostVBList(createProjectCostVBs());
		 vb.setProposedCostVBList(createProjectCostVBs());
		 liabilityProjectHelper.saveProjectDetails(vb,createNewActiveUser());
		  // verify(liabProjtDao); 
	}
	
	@Test
	public void testSaveApproveProjectDetails(){
		liabProjtDao.updateProjectDetails(isA(ProjectDTO.class));
		 expectLastCall().times(1);
		 liabProjtDao.updateApprovedProjToHistory(createNewProject());
		 expectLastCall().times(1);
		// expect(liabProjtDao.saveProjId(isA(ProjectDTO.class))).andReturn(1l).times(1);
		 expect(liabProjtDao.saveProjectDetails(isA(ProjectDTO.class))).andReturn(1l).times(1);
		 liabProjtDao.updateProjectCostDetails(isA(ProjectCostDTO.class));
		 expectLastCall().times(1);
		 expect(liabProjtDao.saveProjectCostDetails(isA(ProjectCostDTO.class))).andReturn(1l).times(1);
		 replay(liabProjtDao);
		 emailService.sendEmailNotification(isA(SendMailDTO.class));
		 replay(emailService);
		 ProjectVB vb = createNewProjectVB();
		 vb.setCurrentCostVBList(createProjectCostVBs());
		 vb.setProposedCostVBList(createProjectCostVBs());
		 liabilityProjectHelper.saveUpdateProjectDetails(vb,createNewActiveUser());
		  // verify(liabProjtDao); 
	}
	
	@Test
	public void testsaveUpdateProjectDetails(){
	    liabProjtDao.updateApprovedProjToHistory(isA(ProjectDTO.class));
		 expectLastCall().times(1);
		 liabProjtDao.updateProjectDetails(isA(ProjectDTO.class));
		 expectLastCall().times(1);
		
		 //replay(liabProjtDao);
		 expect(liabProjtDao.saveProjId(isA(ProjectDTO.class))).andReturn(1l).times(1);
		 expect(liabProjtDao.saveProjectDetails(isA(ProjectDTO.class))).andReturn(1l).times(1);
		 liabProjtDao.updateProjectCostDetails(isA(ProjectCostDTO.class));
		 expectLastCall().times(1);
		 expect(liabProjtDao.saveProjectCostDetails(isA(ProjectCostDTO.class))).andReturn(1l).times(1);
		 replay(liabProjtDao);
		 emailService.sendEmailNotification(isA(SendMailDTO.class));
		 replay(emailService);
		 ProjectVB vb = createNewProjectVB();
		 vb.setCurrentCostVBList(createProjectCostVBs());
		 vb.setProposedCostVBList(createProjectCostVBs());
		 liabilityProjectHelper.saveUpdateProjectDetails(vb,createNewActiveUser());
		  // verify(liabProjtDao); 
	}
	
	@Test
	public void testDisApproveProject(){
		liabProjtDao.updateProjectDetails(isA(ProjectDTO.class));
		 expectLastCall().times(1);
		 liabProjtDao.updateApprovedProjToHistory(isA(ProjectDTO.class));
		 expectLastCall().times(2);
		// expect(liabProjtDao.saveProjId(isA(ProjectDTO.class))).andReturn(1l).times(1);
		 expect(liabProjtDao.saveProjectDetails(isA(ProjectDTO.class))).andReturn(1l).times(1);
		 expect(liabProjtDao.saveDisaprvProj(isA(DisapproveProjDTO.class))).andReturn(1l).times(1);
		 expect(autherizationService.canApprove("xmie001")).andStubReturn(true);
		 expect(liabProjtDao.getLastSubmittedProjUser(1)).andReturn("xmie001").times(1);
		 liabProjtDao.updateProjectCostDetails(isA(ProjectCostDTO.class));
		 expectLastCall().times(1);
		 expect(liabProjtDao.saveProjectCostDetails(isA(ProjectCostDTO.class))).andReturn(1l).times(1);
		 replay(autherizationService);
		 replay(liabProjtDao);
		 //emailService.sendEmailNotification(isA(SendMailDTO.class));
		 //replay(emailService);
		
		 ProjectVB vb = createNewProjectVB();
		 vb.setCurrentCostVBList(createProjectCostVBs());
		 vb.setProposedCostVBList(createProjectCostVBs());
		 liabilityProjectHelper.disApproveProject(vb,createNewActiveUser());
		   //verify(liabProjtDao); 
	}
	
	
	
	
	
	private void setDaoExpectations(){
	    expect(
		    lookupDao.getDropDownOnLoad(ServiceConstants.EMA_LMS_TUBE_LEVL_MSTR, 
			    ServiceConstants.TUBE_LEVL_ID, 
			    ServiceConstants.TUBE_LEVL_CODE, ServiceConstants.TUBE_LEVL_DESC)).
			    andReturn(createDropDownInfo());

	    expect( lookupDao.getDropDownOnLoad(ServiceConstants.EMA_LMS_PROJ_SRC_MSTR, ServiceConstants.PROJ_SRC_CODE,
		    ServiceConstants.PROJ_SRC_DESC, ServiceConstants.PROJ_SRC_ID, ServiceConstants.SORT_ORD_NBR)).andReturn(createDropDownInfo());


	    expect(
		    lookupDao.getDropDownOnLoad(ServiceConstants.EMA_LMS_PROJ_TYPE_MSTR, ServiceConstants.PROJ_TYPE_CODE,
			    ServiceConstants.PROJ_TYPE_DESC, ServiceConstants.PROJ_TYPE_ID, ServiceConstants.SORT_ORD))
			    .andReturn(createDropDownInfo());
	    expect(
		    lookupDao.getDropDownOnLoad(ServiceConstants.EMA_LMS_PROJ_DRIV_MSTR, ServiceConstants.PROJ_DRIV_CODE,
			    ServiceConstants.PROJ_DRIV_DESC, ServiceConstants.PROJ_DRIV_ID, ServiceConstants.SORT_ORD))
			    .andReturn(createDropDownInfo());
	    expect(
		    lookupDao.getDropDownOnLoad(ServiceConstants.EMA_LMS_PROJ_ESTM_MSTR, ServiceConstants.PROJ_ESTM_CODE,
			    ServiceConstants.PROJ_ESTM_DESC, ServiceConstants.PROJ_ESTM_ID, ServiceConstants.SORT_ORD))
			    .andReturn(createDropDownInfo());
	    expect(
		    lookupDao.getDropDownOnLoad(ServiceConstants.EMA_LMS_RAIL_RAOD_MSTR, ServiceConstants.RAIL_RAOD_CODE,
			    ServiceConstants.RAIL_RAOD_DESC, ServiceConstants.RAIL_RAOD_ID, ServiceConstants.SORT_ORD_NBR))
			    .andReturn(createDropDownInfo());
	    expect(
		    lookupDao.getDropDownOnLoad(ServiceConstants.EMA_LMS_FED_LEAD_MSTR, ServiceConstants.FED_LEAD_CODE,
			    ServiceConstants.FED_LEAD_DESC, ServiceConstants.FED_LEAD_ID, ServiceConstants.SORT_ORD_NBR))
			    .andReturn(createDropDownInfo());
	    expect(
		    lookupDao.getDropDownOnLoad(ServiceConstants.EMA_LMS_BLNC_SHT_MSTR, ServiceConstants.BLNC_SHT_CODE,
			    ServiceConstants.BLNC_SHT_DESC, ServiceConstants.BLNC_SHT_ID, ServiceConstants.SORT_ORD_NBR))
			    .andReturn(createDropDownInfo());
	    expect(
		    lookupDao.getDropDownOnLoad(ServiceConstants.EMA_LMS_SUB_ACCT_MSTR, ServiceConstants.SUB_ACCT_CODE,
			    ServiceConstants.SUB_ACCT_DESC, ServiceConstants.SUB_ACCT_ID, ServiceConstants.SORT_ORD_NBR))
			    .andReturn(createDropDownInfo());
	    expect(
		    lookupDao.getDropDownOnLoad(ServiceConstants.EMA_LMS_PROJ_COST_TYPE_MST,
			    ServiceConstants.PROJ_COST_TYPE_CODE, ServiceConstants.PROJ_COST_TYPE_DESC,
			    ServiceConstants.PROJ_COST_TYPE_ID, ServiceConstants.SORT_ORD_NBR)).andReturn(
				    createDropDownInfo());
	    
	    expect(
		    lookupDao.getDropDownOnLoadForId(ServiceConstants.EMA_LMS_TUBE_LEVL_MSTR,
			    ServiceConstants.TUBE_LEVL_ID, ServiceConstants.TUBE_LEVL_CODE,
			    ServiceConstants.TUBE_LEVL_DESC)).andReturn(
				    createDropDownInfo());
	    
	    expect(
		    lookupDao.getDropDownOnLoadForId(ServiceConstants.EMA_LMS_CHNG_RESN_MSTR, ServiceConstants.CHNG_RESN_MSTR_ID, ServiceConstants.CHNG_RESN_CODE, ServiceConstants.CHNG_RESN_DESC)).andReturn(
				    createDropDownInfo());

	    expect(lookupDao.getManagers()).andReturn(createManagers());
	    expect(lookupDao.getStates()).andReturn(createDropDownInfo());
	}

	private List<DropDownInfo> createDropDownInfo() {
		List<DropDownInfo> dropDownInfoList = new ArrayList<DropDownInfo>();

		DropDownInfo dropDownInfoInfo1 = new DropDownInfo();
		dropDownInfoInfo1.setCode(String.valueOf(9));
		dropDownInfoInfo1.setAlternateCode("B");
		dropDownInfoInfo1.setDescription("Building");
		dropDownInfoList.add(dropDownInfoInfo1);

		DropDownInfo dropDownInfoInfo2 = new DropDownInfo();
		dropDownInfoInfo2.setCode(String.valueOf(10));
		dropDownInfoInfo2.setAlternateCode("O");
		dropDownInfoInfo2.setDescription("Office");
		dropDownInfoList.add(dropDownInfoInfo2);

		DropDownInfo dropDownInfoInfo3 = new DropDownInfo();
		dropDownInfoInfo3.setCode(String.valueOf(11));
		dropDownInfoInfo3.setAlternateCode("W");
		dropDownInfoInfo3.setDescription("Warehouse");
		dropDownInfoList.add(dropDownInfoInfo3);

		DropDownInfo dropDownInfoInfo4 = new DropDownInfo();
		dropDownInfoInfo4.setCode(String.valueOf(12));
		dropDownInfoInfo4.setAlternateCode("S");
		dropDownInfoInfo4.setDescription("Structure");

		dropDownInfoList.add(dropDownInfoInfo4);

		return dropDownInfoList;
	}
	
	private List<ProjectDTO> createProjectDTOs() {
		List<ProjectDTO> projects = new ArrayList<ProjectDTO>();
		
		projects.add(createNewProject());
		return projects;
	}
	
	private ActiveUserId createNewActiveUser() {
	    ActiveUserId activeUserId = new ActiveUserId("xmie001", "044366");
	    return activeUserId;
	}
	
	
	private List<ManagerDTO> createManagers() {
		List<ManagerDTO> managers = new ArrayList<ManagerDTO>();

		ManagerDTO managerDTOInfo1 = new ManagerDTO();
		managerDTOInfo1.setFirstName("xyz");
		managers.add(managerDTOInfo1);
		ManagerDTO managerDTOInfo2 = new ManagerDTO();
		managerDTOInfo1.setFirstName("abc");
		managers.add(managerDTOInfo2);

		return managers;
	}
	
	private DisapproveProjDTO createDisapproveProjDTO(){
	    
	    DisapproveProjDTO disapproveProjDTO =  new DisapproveProjDTO();
	    disapproveProjDTO.setDisaprvComtDtlID( 1) ;
	    disapproveProjDTO.setCrtdDate(new Date()) ;
	    disapproveProjDTO.setLastUptdDate(new Date()) ;
	    disapproveProjDTO.setEmpId("0446778");
	    disapproveProjDTO.setDisaprvComments( "cost not valid") ;
	    disapproveProjDTO.setActFlag( "C") ;
	    disapproveProjDTO.setLastUptdUser( "xprk480") ;
	    disapproveProjDTO.setCrtdUser( "iots331") ;
	    
	    disapproveProjDTO.getDisaprvComtDtlID() ;
	    disapproveProjDTO.getDisaprvComments() ;
	    disapproveProjDTO.getActFlag() ;    
	    disapproveProjDTO.getCrtdUser() ;
	    disapproveProjDTO.getLastUptdUser() ;
	    disapproveProjDTO.getCrtdDate() ;
	    disapproveProjDTO.getLastUptdDate() ;
	    disapproveProjDTO.getEmpId();
	    
	    return disapproveProjDTO;
	    
	}
	private ProjectDTO createNewProject(){
	    ProjectDTO projectDTO = new ProjectDTO();
		projectDTO.setProjDtlID(1);
		projectDTO.setProjID(1) ;
		projectDTO.setProjectName("projectName");
		projectDTO.setProjSrcId(new Long(2)) ;
		projectDTO.setProjTypeId(new Long(2));
		projectDTO.setProjDriveId(new Long(2));
		projectDTO.setProjEstmId(new Long(2));
		projectDTO.setProjMgrId(new Long(2));
		projectDTO.setCity("city");
		projectDTO.setState("state");
		projectDTO.setRailRoadId(new Long(2));
		projectDTO.setProjOthDesc("projOthDesc");		
		projectDTO.setReqActgFlag("Y");		
		projectDTO.setUndergroundStorageTankFlag("Y");
		projectDTO.setNpvDiscountFlag("npvDiscountFlag");		  
		projectDTO.setUpprAllocPer(12d);		    
		projectDTO.setFnceAssurFlag("fnceAssurFlag");		  
		projectDTO.setdAndTListFlag("dAndTListFlag");		    
		projectDTO.setCostRcvyFlag("costRcvyFlag");		   
		projectDTO.setFedLeadId(new Long(2));
		projectDTO.setYear15RuleFlag("year15RuleFlag");		    
		projectDTO.setOperStatFlag("operStatFlag");		    
		projectDTO.setBalSheetId(new Long(2));		   
		projectDTO.setSubAccId(new Long(2));		   
		projectDTO.setAccountNbrData("accountNbrData");		    
		projectDTO.setMinStdgBlncFlag("minStdgBlncFlag");		    
		projectDTO.setMinStdBlncAmt(2d);		  
		projectDTO.setTubeLvlId(new Long(2));		   
		projectDTO.setChangeReasonMstrId(new Long(2));		    
		projectDTO.setChangeReasonDtlId(new Long(2));		   
		projectDTO.setChangeReasonDate(new Date());		    
		projectDTO.setChangeReasonComment("changeReasonComment");		   
		projectDTO.setAction("S");		    
		projectDTO.setActionType("P");		    
		projectDTO.setPreviousAction("S");		    
		projectDTO.setPreviousActionType("P");		   
		projectDTO.setClosedDate(new Date());		   
		projectDTO.setProjectDate(new Date());		    
		projectDTO.setActFlag("C");		    
		projectDTO.setCrtdUser("crtdUser");		  
		projectDTO.setLastUptdUser("lastUptdUser");		   
		projectDTO.setCrtdDate(new Date());		
		projectDTO.setLastUptdDate(new Date());		
		projectDTO.setIntUprrLaborFlag("intUprrLaborFlag");		   
		projectDTO.setTrackTimeFlag("trackTimeFlag");		    
		projectDTO.setTelecomFlag("telecomFlag");		    
		projectDTO.setDataChangedFlag(true);		    
		projectDTO.setChangeResnDataChangedFlag(true);		   
		projectDTO.setInputFrom("PS");		  
		projectDTO.setDisaprvComments("disaprvComments");		    
		projectDTO.setDisaprvCmtDtlId(new Long(2));	
		return projectDTO;
	}
	
	
	private ProjectVB createNewProjectVB(){
		ProjectVB projectVB = new ProjectVB();
		projectVB.setProjDtlID(1);
		projectVB.setProjID(1) ;
		projectVB.setProjectName("projectName");
		projectVB.setProjSrcId(new Long(2)) ;
		projectVB.setProjTypeId(new Long(2));
		projectVB.setProjDriveId(new Long(2));
		projectVB.setProjEstmId(new Long(2));
		projectVB.setProjMgrId(new Long(2));
		projectVB.setCity("city");
		projectVB.setState("state");
		projectVB.setRailRoadId(new Long(2));
		projectVB.setProjOthDesc("projOthDesc");		
		projectVB.setReqActgFlag("Y");		
		projectVB.setNpvDiscountFlag("npvDiscountFlag");		  
		//projectDTO.setUpprAllocPer("upprAllocPer");		    
		projectVB.setFnceAssurFlag("fnceAssurFlag");		  
		projectVB.setdAndTListFlag("dAndTListFlag");		    
		projectVB.setCostRcvyFlag("costRcvyFlag");		   
		projectVB.setFedLeadId(new Long(2));
		projectVB.setYear15RuleFlag("year15RuleFlag");		    
		projectVB.setOperStatFlag("operStatFlag");		    
		projectVB.setBalSheetId(new Long(2));		   
		projectVB.setSubAccId(new Long(2));		   
		projectVB.setAccountNbrData("accountNbrData");		    
		projectVB.setMinStdgBlncFlag("minStdgBlncFlag");		    
		projectVB.setMinStdBlncAmt(2d);		  
		projectVB.setTubeLvlId(new Long(2));		   
		projectVB.setChangeReasonMstrId(new Long(2));		    
		projectVB.setChangeReasonDtlId(new Long(2));		   
		//projectDTO.setChangeReasonDate(new Date());		    
		projectVB.setChangeReasonComment("changeReasonComment");		   
		projectVB.setAction("S");		    
		projectVB.setActionType("P");		    
		projectVB.setPreviousAction("S");		    
		projectVB.setPreviousActionType("P");		   
		//projectDTO.setClosedDate(new Date());		   
		//projectDTO.setProjectDate(new Date());		    
		projectVB.setActFlag("C");	
		projectVB.setUndergroundStorageTankFlag("Y");
		projectVB.setCrtdUser("crtdUser");		  
		projectVB.setLastUptdUser("lastUptdUser");		   
		//projectDTO.setCrtdDate(new Date());		
		//projectDTO.setLastUptdDate(new Date());		
		projectVB.setIntUprrLaborFlag("intUprrLaborFlag");		   
		projectVB.setTrackTimeFlag("trackTimeFlag");		    
		projectVB.setTelecomFlag("telecomFlag");		    
		projectVB.setDataChangedFlag(true);		    
		projectVB.setChangeResnDataChangedFlag(true);		   
		projectVB.setInputFrom("PS");		  
		projectVB.setDisaprvComments("disaprvComments");		    
		projectVB.setDisaprvCmtDtlId(new Long(2));
		projectVB.setClosedDate("01/01/2018");
		return projectVB;
	}
	private List<ProjectCostDTO> createProjectCostDTOs() {
	    List<ProjectCostDTO> projectCosts = new ArrayList<ProjectCostDTO>();
	    projectCosts.add(createNewCost());
	    return projectCosts;
	}
	private List<ProjectCostVB> createProjectCostVBs() {
	    List<ProjectCostVB> projectCosts = new ArrayList<ProjectCostVB>();
	    projectCosts.add(createNewCostVB());
	    return projectCosts;
	}
	
	private ProjectCostDTO createNewCost(){
	    ProjectCostDTO projectCostDTO = new ProjectCostDTO();
	    projectCostDTO.setCostId(new Long(2));	    
	    projectCostDTO.setProjID(new Long(2));	    
	    projectCostDTO.setCostTypeId(new Long(2));	    
	    projectCostDTO.setChangeReasonDtlId(new Long(2));	    
	    projectCostDTO.setYear(new Long(2018));	    
	    projectCostDTO.setCost(22.0);	    
	    projectCostDTO.setOprnAndMaintCost(12.9);	    
	    projectCostDTO.setSysClosureCost(13.0);	    
	    projectCostDTO.setCostType("1");	    
	    projectCostDTO.setAction("S");	    
	    projectCostDTO.setActionType("P");	   
	    projectCostDTO.setPreviousAction("S");	    
	    projectCostDTO.setPreviousActionType("P");	    
	    projectCostDTO.setActFlag("C");	   
	    projectCostDTO.setCrtdUser("crtdUser");	    
	    projectCostDTO.setLastUptdUser("lastUptdUser");	    
	    projectCostDTO.setCrtdDate(new Date());	    
	    projectCostDTO.setLastUptdDate(new Date());	    
	    projectCostDTO.setDataChangedFlag(true);	    
	    projectCostDTO.setDisaprvCmtDtlId(new Long(2));

	    return projectCostDTO;
	}
	private ProjectCostVB createNewCostVB(){
	    ProjectCostVB projectCostDTO = new ProjectCostVB();
	    projectCostDTO.setCostId(new Long(2));	    
	    projectCostDTO.setProjID(new Long(2));	    
	    projectCostDTO.setCostTypeId(new Long(2));	    
	    projectCostDTO.setChangeReasonDtlId(new Long(2));	    
	    projectCostDTO.setYear(new Long(2018));	    
	    projectCostDTO.setCost(22.0);	    
	    projectCostDTO.setOprnAndMaintCost(12.9);	    
	    projectCostDTO.setSysClosureCost(13.0);	    
	    projectCostDTO.setCostType("1");	    
	    projectCostDTO.setAction("S");	    
	    projectCostDTO.setActionType("P");	   
	    projectCostDTO.setPreviousAction("S");	    
	    projectCostDTO.setPreviousActionType("P");	    
	    projectCostDTO.setActFlag("C");	   
	    projectCostDTO.setCrtdUser("crtdUser");	    
	    projectCostDTO.setLastUptdUser("lastUptdUser");	    
	    projectCostDTO.setDataChangedFlag(true);	    
	    projectCostDTO.setDisaprvCmtDtlId(new Long(2));

	    return projectCostDTO;
	}
	
	@Test
	public void testgetExcelDataFromDb() throws Exception{
		//List<LEWBReportDto> dto=projectSearchService.geLEWBtExcelReport();
		   
	}
}
