/*package com.uprr.ema.lms.lookupTest;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.uprr.ema.lms.common.dao.api.LookupDao;
import com.uprr.ema.lms.springconfig.MainConfig;
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {MainConfig.class})
@WebAppConfiguration
public class LookupDaoImplTest {
	
	@Autowired
	private LookupDao lookupDaoImpl;
	
	@Test
	public void test(){
		//lookupDaoImpl.getManagers();
	}
	
	
}
*/