package com.uprr.ema.lms.common.service.impl;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.net.URI;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.impl.conn.SystemDefaultDnsResolver;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.uprr.ema.lms.common.enums.DocsServiceNames;
import com.uprr.ema.lms.common.service.api.IDocumentService;
import com.uprr.ema.lms.springconfig.PropertyConfig;
import com.uprr.ema.lms.springconfig.trn.ServiceConfig;
import com.uprr.enterprise.apache.http.PoolingHttpClientConnectionManagerBuilder;
import com.uprr.enterprise.client.auth.ApacheEsbClientRequestInterceptor;
import com.uprr.enterprise.client.auth.HttpAuthStrategy;
import com.uprr.enterprise.client.auth.UserConfiguredAuthStrategyBuilder;
import com.uprr.enterprise.client.auth.token.providers.RemoteTokenProvider;
import com.uprr.enterprise.client.auth.token.providers.TokenProvider;
import com.uprr.enterprise.security.credential.simple.SimpleCredentialProvider;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {ServiceConfig.class,PropertyConfig.class})
public class DocumentServiceImplTest {

	
	RestTemplate restTemplate;

	ResponseEntity responseEntity;
	
	@InjectMocks
	IDocumentService docService;
	
	@Before
	public void setup(){
		
		docService = new DocumentServiceImpl();
		System.setProperty("uprr.implementation.environment", "dev");
	}
	
    @Test
    public void uploadDocumentTest() throws Exception {
    	restTemplate = mock(RestTemplate.class);
    	responseEntity = mock(ResponseEntity.class);
    	String test ="{'document-identifiers':{'dcoument-id':'123456'}}";
    	MultipartFile file = mock(MultipartFile.class);
    	when(file.getOriginalFilename()).thenReturn("test");
    	when(file.getBytes()).thenReturn(test.getBytes());
        when(restTemplate.exchange(anyString(),any(HttpMethod.class),any(HttpEntity.class),any(Class.class))).thenReturn(responseEntity);
        when(responseEntity.getBody()).thenReturn(test);
        docService.uploadDocument(file);
    }
    
    @Test
    public void downloadDocumentTest() throws Exception {
    	String test ="this is get docs test";
        when(restTemplate.exchange(anyString(),any(HttpMethod.class),any(HttpEntity.class),any(Class.class))).thenReturn(responseEntity);
        when(responseEntity.getBody()).thenReturn(test.getBytes());
        docService.downloadDocument("123456");
        
    }
    
    @Test
    public void test_callToService() throws Exception {
    	
    	//Use RemoteTokenProvider locally.  JAAS Login Module is not available locally.   
    	//http://wiki.www.uprr.com/confluence/display/SYSENGR/Developing+ESB+HTTP+Clients+-+Spring+RestTemplate+and+Apache+HttpClient+QuickStart
    	TokenProvider applicationTokenProvider = new RemoteTokenProvider(new SimpleCredentialProvider("d00047f","Hoce6fsNLcwECii"));

        UserConfiguredAuthStrategyBuilder uAuthBuilder =
                HttpAuthStrategy
                        .authenticateApplicationWith(applicationTokenProvider)
                        .noUserPresent();

        ApacheEsbClientRequestInterceptor interceptor = new ApacheEsbClientRequestInterceptor(uAuthBuilder);

        // Better RR-DNS handling
        PoolingHttpClientConnectionManager manager =
                PoolingHttpClientConnectionManagerBuilder
                        .create()
                        .setDnsResolver(SystemDefaultDnsResolver.INSTANCE)
                        .useSystemProperties()
                        .build();

        HttpClient client = HttpClients.custom()
                .setConnectionManager(manager)
                .addInterceptorFirst(interceptor)
                .build();
        
        URI uri = new URIBuilder("http://esb-dev.esb.apps.uprr.com/services"+DocsServiceNames.getEchoServiceName())
        		.build();
        
        HttpGet httpGet = new HttpGet(uri);
        httpGet.addHeader("accept", MediaType.APPLICATION_JSON.toString());
        
        HttpResponse response = client.execute(httpGet);
        
        ObjectMapper mapper = new ObjectMapper();
        String reply = mapper.readValue(response.getEntity().getContent(), String.class);
        
        System.out.println(reply);
    }
}
