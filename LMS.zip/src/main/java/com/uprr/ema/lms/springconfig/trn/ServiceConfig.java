package com.uprr.ema.lms.springconfig.trn;

import java.util.Random;

import org.springframework.context.annotation.Configuration;

/**
 * The Spring configuration file for the sample application.
 */
@Configuration
public class ServiceConfig {
	
    private static final Random	RANDOM	= new Random();  //used for pseudo-data
    
	

   


	

}
