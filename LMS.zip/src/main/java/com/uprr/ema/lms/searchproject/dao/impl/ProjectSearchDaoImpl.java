package com.uprr.ema.lms.searchproject.dao.impl;

import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Repository;

import com.uprr.ema.lms.common.dao.impl.OracleDaoImpl;
import com.uprr.ema.lms.common.dto.DropDownInfo;
import com.uprr.ema.lms.common.web.util.WebDateUtil;
import com.uprr.ema.lms.searchproject.dao.api.ProjectSearchDao;
import com.uprr.ema.lms.searchproject.dto.LEWBReportDto;
import com.uprr.ema.lms.searchproject.dto.ProjectSearchCriteriaDTO;
import com.uprr.ema.lms.searchproject.dto.SearchDTO;

@Repository
@PropertySource(value={"classpath:ProejctSearch/projectsearch.properties"})
public class ProjectSearchDaoImpl extends OracleDaoImpl implements ProjectSearchDao {
	@Autowired
	public Environment environment;
	
	@Override
	public List<SearchDTO> getSearchResultThroughPagination(ProjectSearchCriteriaDTO projectSearchCriteriaDTO){
		//getNamedParameterJdbcTemplate().query("", "", "");
		
		StringBuilder builder = new StringBuilder(environment.getProperty("SEARCH_OUTER_QRY_PREFIX"));
		builder.append(environment.getProperty("PROJECT_SEARCH_QUERY"));
		MapSqlParameterSource params=createCriterias(projectSearchCriteriaDTO, builder);
		builder.append(" order by "+projectSearchCriteriaDTO.getOrderByColumn()+" "+projectSearchCriteriaDTO.getSortingType());
		builder.append(environment.getProperty("SEARCH_OUTER_QRY_SUFFIX"));
		return this.getNamedParamResultsList(builder.toString(), params, SearchDTO.class);
	}

	@Override
	public int getSearchResultRowCount(ProjectSearchCriteriaDTO projectSearchCriteriaDTO) {
		StringBuilder builder = new StringBuilder(environment.getProperty("PROJECT_SEARCH_COUNT_QUERY"));
		final MapSqlParameterSource params =createCriterias(projectSearchCriteriaDTO,builder);
		return getCount(builder.toString(), params);
	}
	
	private final MapSqlParameterSource createCriterias(ProjectSearchCriteriaDTO projectSearchCriteriaDTO,StringBuilder builder){
		final MapSqlParameterSource params = new MapSqlParameterSource();
		params.addValue("startRow", projectSearchCriteriaDTO.getStartIndex());
		params.addValue("endRow", projectSearchCriteriaDTO.getEndIndex());
		if(projectSearchCriteriaDTO.getProjectSearchCriteria()!=null){
			final SearchDTO dto = projectSearchCriteriaDTO.getProjectSearchCriteria();
			if(dto.getProjectId() !=null && dto.getProjectId()>0){
				builder.append(" and prj.proj_dtl_id = :projectId");
				params.addValue("projectId", dto.getProjectId());
			}else if(dto.getProjecName()!=null && !"".equalsIgnoreCase(dto.getProjecName().trim())){
			    builder.append(" and UPPER(prj.PROJ_NAME) LIKE :projecName");
			    params.addValue("projecName", "%"+dto.getProjecName().toUpperCase()+"%");
			}
			
			if(StringUtils.isNoneBlank(dto.getProjectActnCode())){
				builder.append(" and actn.ACTN_CODE=:projectActnCode");
				params.addValue("projectActnCode", dto.getProjectActnCode());
			}
			
			if(dto.getTubeLevelId() !=null && dto.getTubeLevelId()>0){
				builder.append(" and tub.tube_levl_id=:tubeLevelId");
				params.addValue("tubeLevelId", dto.getTubeLevelId());
			}
			
			if(dto.getProjEstmId() !=null && dto.getProjEstmId()>0){
				builder.append(" and est.PROJ_ESTM_ID=:projEstmId");
				params.addValue("projEstmId", dto.getProjEstmId());
			}
			
			if(dto.getProjMgrId() !=null && dto.getProjMgrId()>0){
				builder.append(" and mgr.PROJ_MGR_ID=:projMgrId");
				params.addValue("projMgrId", dto.getProjMgrId());
			}
			
			if(dto.getCreateDateFrm()!=null){
				builder.append(" and TRIM(prj.PROJ_DATE)>=TO_DATE(:createDateFrm, 'MM/DD/YYYY')");
				params.addValue("createDateFrm", WebDateUtil.getDateInMMDDYYYY(dto.getCreateDateFrm()));
			}
			if(dto.getCreateDateTo()!=null){
				builder.append(" and TRIM(prj.PROJ_DATE)<=TO_DATE(:createDateTo, 'MM/DD/YYYY')");
				params.addValue("createDateTo", WebDateUtil.getDateInMMDDYYYY(dto.getCreateDateTo()));
			}
			
			if(dto.getLastChangeDateFrm()!=null){
				builder.append(" and TRIM(prjchg.CHNG_DATE)>=TO_DATE(:lastChangeDateFrm, 'MM/DD/YYYY')");
				params.addValue("lastChangeDateFrm", WebDateUtil.getDateInMMDDYYYY(dto.getLastChangeDateFrm()));
			}
			if(dto.getLastChangeDateTo()!=null){
				builder.append(" and TRIM(prjchg.CHNG_DATE)<=TO_DATE(:lastChangeDateTo, 'MM/DD/YYYY')");
				params.addValue("lastChangeDateTo", WebDateUtil.getDateInMMDDYYYY(dto.getLastChangeDateTo()));
			}
			
			if(dto.getProjCloseDateFrm()!=null){
				builder.append(" and TRIM(prj.PROJ_DATE)>=TO_DATE(:projCloseDateFrm, 'MM/DD/YYYY')");
				params.addValue("projCloseDateFrm", WebDateUtil.getDateInMMDDYYYY(dto.getProjCloseDateFrm()));
			}
			if(dto.getProjCloseDateTo()!=null){
				builder.append(" and TRIM(prj.PROJ_DATE)<=TO_DATE(:projCloseDateTo, 'MM/DD/YYYY')");
				params.addValue("projCloseDateTo", WebDateUtil.getDateInMMDDYYYY(dto.getProjCloseDateTo()));
			}
			
		}
		return params;
		
	}

	@Override
	public List<SearchDTO> getExcelReport(ProjectSearchCriteriaDTO projectSearchCriteriaDTO) {
		StringBuilder builder = new StringBuilder(environment.getProperty("PROJECT_SEARCH_QUERY"));
		MapSqlParameterSource params=createCriterias(projectSearchCriteriaDTO, builder);
		return this.getNamedParamResultsList(builder.toString(), params, SearchDTO.class);
	}
	
	@Override
	public List<DropDownInfo> getProjectNames() {
	    return (List<DropDownInfo>)getNamedParamResultsList(environment.getProperty("PROJECT_SEARCH_NAME_QUERY"), new Object[] { }, DropDownInfo.class);
	}

	@Override
	public List<LEWBReportDto> geLEWBtExcelReport(String fromdate, String toDate) {
		// TODO Auto-generated method stub
		/*StringBuilder builder = new StringBuilder(environment.getProperty("LEWB_REPORT_QUERY"));
		MapSqlParameterSource params=new MapSqlParameterSource();
		params.addValue("endRow", 1);
		return getNamedParamResultsList(builder.toString(),params,LEWBReportDto.class);*/
		
		StringBuilder builder = new StringBuilder(environment.getProperty("LEWB_REPORT_QUERY"));
		MapSqlParameterSource params=new MapSqlParameterSource();
		params.addValue("startdate", fromdate);
		params.addValue("enddate", toDate);
		//MapSqlParameterSource params=createCriterias(projectSearchCriteriaDTO, builder);
		List<LEWBReportDto> dto=this.getNamedParamResultsList(builder.toString(), params, LEWBReportDto.class);
		return dto;
	}

	@Override
	public List<LEWBReportDto> getReasonChnage(Integer projectId) {
		// TODO Auto-generated method stub
		StringBuilder builder = new StringBuilder(environment.getProperty("LEWB_REASON_CHANGE_QUERY"));
		MapSqlParameterSource params=new MapSqlParameterSource();
		params.addValue("projectId", projectId.toString());
		//MapSqlParameterSource params=createCriterias(projectSearchCriteriaDTO, builder);
		List<LEWBReportDto> dto=this.getNamedParamResultsList(builder.toString(), params, LEWBReportDto.class);
		return dto;
	}
	@Override
	public List<LEWBReportDto> getCostsData(Integer projectId) {
		// TODO Auto-generated method stub
		StringBuilder builder = new StringBuilder(environment.getProperty("LEWB_COST_YEAR_QUERY"));
		MapSqlParameterSource params=new MapSqlParameterSource();
		params.addValue("projectId", projectId.toString());
		//MapSqlParameterSource params=createCriterias(projectSearchCriteriaDTO, builder);
		List<LEWBReportDto> dto=this.getNamedParamResultsList(builder.toString(), params, LEWBReportDto.class);
		return dto;
	}

	@Override
	public List<LEWBReportDto> getBeginingOfYearData(Integer projectId,String year) {
		// TODO Auto-generated method stub
		StringBuilder builder = new StringBuilder(environment.getProperty("LEWB_BEGININGYEAR_DATA"));
		MapSqlParameterSource params=new MapSqlParameterSource();
		params.addValue("projectid", projectId.toString());
		params.addValue("year", year);
		//MapSqlParameterSource params=createCriterias(projectSearchCriteriaDTO, builder);
		List<LEWBReportDto> dto=this.getNamedParamResultsList(builder.toString(), params, LEWBReportDto.class);
		return dto;
	}

	@Override
	public List<LEWBReportDto> getspentAmount(Set<String> networkNumberSet) {
		// TODO Auto-generated method stub
		StringBuilder builder = new StringBuilder(environment.getProperty("LEWB_PROJECTIDS_FROM_NETWORKIDS"));
		MapSqlParameterSource params=new MapSqlParameterSource();
		params.addValue("networkNumberSet", networkNumberSet);
		
		//MapSqlParameterSource params=createCriterias(projectSearchCriteriaDTO, builder);
		List<LEWBReportDto> dto=this.getNamedParamResultsList(builder.toString(), params, LEWBReportDto.class);
		return dto;
	}

	@Override
	public List<LEWBReportDto> getOmmCostsData(Integer projectId) {
		// TODO Auto-generated method stub
		StringBuilder builder = new StringBuilder(environment.getProperty("LEWB_OMM_COSTS_CLOSURE_DATA"));
		MapSqlParameterSource params=new MapSqlParameterSource();
		params.addValue("projectId", projectId);
		List<LEWBReportDto> dto=this.getNamedParamResultsList(builder.toString(), params, LEWBReportDto.class);
		return dto;
	}

	@Override
	public List<LEWBReportDto> getliabilityEstimateAmount(String liabiltyQueryString,Integer projectId) {
		// TODO Auto-generated method stub
		
		StringBuilder query = new StringBuilder(environment.getProperty("GET_LIABILITYESTIMATES_DATA"));
		String queryStr=query.toString();
		queryStr+=liabiltyQueryString;
		MapSqlParameterSource params=new MapSqlParameterSource();
		params.addValue("projectId", projectId);
		List<LEWBReportDto> list = this.getNamedParamResultsList(queryStr,  params,LEWBReportDto.class);
		
		return list;
	}


}
