package com.uprr.ema.lms.common.enums;

/**
 * RoleTypeEnum.java
 * This class will maintain all the constants for ROLE TYPE
 * @author Anil Kumar Manchala
 *
 */
public enum RoleType {

	ADMIN("EMA-LMS-Admin", "Lms admin",1),
	APPROVER("EMA-LMS-Approver", "LMS Approver",2),
	MANAGER("EMA-LMS-Manager", "Lms Manager",3),	
	LEGAL("EMA-LMS-View", "LMS Legal",4);
	
	
	private String name;
	private String description;
	private int priority;

	private RoleType(final String newName, final String newDescription,final int priority) {
		this.name			= newName;
		this.description 	= newDescription;
		this.priority       = priority;
	}
	public static boolean isAdmin(final String role) {
		return ADMIN.name.equalsIgnoreCase(role);
	}
	public static boolean isManager(final String role) {
		return MANAGER.name.equalsIgnoreCase(role);
	}
	public static boolean isApprover(final String role) {
		return APPROVER.name.equalsIgnoreCase(role);
	}
	public static boolean isLegal(final String role) {
		return LEGAL.name.equalsIgnoreCase(role);
	}
	public String getName() {
		return this.name;
	}
	public String getDescription() {
		return this.description;
	}
	public String getRoleType() {
		return this.name;
	}
	public int getPriority() {
		return this.priority;
	}
	public static String[] getRoles(){
		return new String[] {ADMIN.name,MANAGER.name,APPROVER.name,LEGAL.name};
	}
}
