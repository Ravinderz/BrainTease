package com.uprr.ema.lms.common.enums;

public enum GroupType {
	APPROVER("cn=EMA-LMS-Approver,ou=EMA,o=UPAPPS"),
	MANAGER("cn=EMA-LMS-Manager,ou=EMA,o=UPAPPS") ,
	ADMIN("cn=EMA-LMS-Admin,ou=EMA,o=UPAPPS"),
	VIEW("cn=EMA-LMS-View,ou=EMA,o=UPAPPS");
	private String value;
	GroupType(String value){
		this.value=value;
	}
	/**
	 * @return the value
	 */
	public String getValue() {
		return value;
	}
	/**
	 * @param value the value to set
	 */
	public void setValue(String value) {
		this.value = value;
	}
}
