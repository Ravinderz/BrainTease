package com.uprr.ema.lms.common.service.api;

import java.math.BigInteger;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uprr.ema.lms.common.service.util.LMSUtils;
import com.uprr.ema.lms.common.service.xmf.IXMFClientService;
import com.uprr.ema.lms.exception.LmsException;
import com.uprr.ema.lms.xmf.employeesummary.FilterCriteriaType;
import com.uprr.ema.lms.xmf.employeesummary.NameType;
import com.uprr.ema.lms.xmf.employeesummary.PagingCriteriaType;
import com.uprr.ema.lms.xmf.employeesummary.PersonSummaryListType;
import com.uprr.ema.lms.xmf.employeesummary.PersonSummaryType;
import com.uprr.ema.lms.xmf.employeesummary.RequestType;
import com.uprr.ema.lms.xmf.employeesummary.ResponseType;

@Service("getEmployeeDetails")
public class GetEmployeeDetails implements IGetEmployeeDetails{
	@Autowired
	private IXMFClientService xmfDtlsService;
	
	@Override
	public String getEmployeeName(String empId) {
		String employeeId = StringUtils.leftPad(empId, 8, "0");
		RequestType req=new RequestType();
		StringBuilder name =new StringBuilder();
		FilterCriteriaType filter = new FilterCriteriaType();
		List<String> empIdlist= filter.getPersonnelNumber();
		empIdlist.add(employeeId);
		req.setFilterCriteria(filter);
		req.setIncludeName(true);
		PagingCriteriaType paging = new PagingCriteriaType();
		paging.setPageNumber(new BigInteger("1"));
		paging.setPageSize(new BigInteger("100"));
		req.setPagingCriteria(paging);
		String xmlRequest = LMSUtils.marshal(req,RequestType.class);
		String xmfReplyMessage = xmfDtlsService.getXMFDataByServiceDtls(IXMFClientService.UNSECURE_TYPE, PERSON_GET_SERVICE_NAME,xmlRequest);
		
		ResponseType reply =parseGetEmployeeReply(xmfReplyMessage);
		if(reply!=null){
			PersonSummaryListType person=reply.getPersonSummaryList();
			if(person!=null){
				List<PersonSummaryType> list=person.getPersonSummary();
				if(LMSUtils.isNotEmpty(list)){
					PersonSummaryType summary = list.get(0);
					if (summary != null) {
						NameType nameType = summary.getName();
						if (LMSUtils.isNotNull(nameType.getFirstName()))
							name.append(nameType.getFirstName());
						if (LMSUtils.isNotNull(nameType.getMiddleName())) {
							name.append(" ");
							name.append(nameType.getMiddleName());
						}
						if (LMSUtils.isNotNull(nameType.getLastName())) {
							name.append(" ");
							name.append(nameType.getLastName());
						}
					}
				}
			}
		}
		return name.toString();
	}
	/**
	 * @param xmlString
	 * @return 
	 */
	private ResponseType parseGetEmployeeReply(String xmlString) throws LmsException{
		ResponseType	replyObj = (ResponseType)LMSUtils.unmarshal(xmlString, ResponseType.class);
		return replyObj;

	}
}
