/**
 * This CommonController is used to fetch common details like status details
 * @author xprk208
 * @version 1.0
 * @since 2018-04-30
 * 
 */
package com.uprr.ema.lms.common.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import com.uprr.ema.lms.common.helper.CommonHelper;

@RestController
public class CommonController {
	@Autowired
	CommonHelper commonHelper;
}
