package com.uprr.ema.lms.liabilityProject.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.uprr.azm.shared.mvc.security.authorization.Attribute;
import com.uprr.azm.shared.mvc.security.authorization.Authorize;
import com.uprr.ema.lms.common.service.util.ServiceConstants;
import com.uprr.ema.lms.liabilityProject.dto.AccountCostDTO;
import com.uprr.ema.lms.liabilityProject.helper.LiabilityProjectHelper;
import com.uprr.ema.lms.liabilityProject.vb.ProjectOnLoadVB;
import com.uprr.ema.lms.liabilityProject.vb.ProjectStatusVB;
import com.uprr.ema.lms.liabilityProject.vb.ProjectVB;
import com.uprr.ui.shared.user.ActiveUserId;
import com.uprr.ui.shared.user.spring.mvc.ActiveUser;

/**
 * This LiabilityProjectController is used to fetch look up data and save project details
 * details
 * 
 * @author xprk208
 * @version 1.0
 * @since 2018-04-30
 * 
 */
@RestController
@RequestMapping("/projectDetails")
public class LiabilityProjectController {
    @Autowired
    LiabilityProjectHelper liabProjHelper;

    /**
     * This method is used to fetch look up data
     * @param 
     * @return ProjectOnLoadVB
     * @
     */
    @GetMapping
    public ProjectOnLoadVB getLookUpData()  {
	return liabProjHelper.getLookUpData();
    }
    /**
     * This method is used to save or update the project details 
     * @param ProjectVB
     * @return ProjectStatusVB
     * @
     */
    @PostMapping(value = "/submitProjDtls")
    @ResponseBody
    @Authorize(
	    actions = {@Attribute(key="action-id", value="create")},
	    resources = {@Attribute(key="resource-id", value="environmental-liabilities"),@Attribute(key="feature-id", value="project")}
	    )
    public ProjectStatusVB saveProjectDetails(@RequestBody ProjectVB projectVB,@ActiveUser ActiveUserId activeUser){
	    return liabProjHelper.saveProjectDetails(projectVB,activeUser);
    }
    
    @PostMapping(value = "/saveChangesProjDtls")
    @ResponseBody
    @Authorize(
	    actions = {@Attribute(key="action-id", value="create")},
	    resources = {@Attribute(key="resource-id", value="environmental-liabilities"),@Attribute(key="feature-id", value="project")}
	    )
    public ProjectStatusVB saveProj(@RequestBody ProjectVB projectVB,@ActiveUser ActiveUserId activeUser){
	    return liabProjHelper.saveProjectDetails(projectVB,activeUser);
    }

    /**
     * This method is used to submit the project change details 
     * @param ProjectVB
     * @return ProjectStatusVB
     * @
     */
    @PostMapping(value = "/submitProjChngDtls")
    @ResponseBody
    @Authorize(
	    actions = {@Attribute(key="action-id", value="create")},
	    resources = {@Attribute(key="resource-id", value="environmental-liabilities"),@Attribute(key="feature-id", value="project-update")}
	    )
    public ProjectStatusVB saveProjectChngDetails(@RequestBody ProjectVB projectVB,@ActiveUser ActiveUserId activeUser){
	return liabProjHelper.saveProjectDetails(projectVB,activeUser);
    }
    /**
     * This method is used to approve the project details 
     * @param ProjectVB
     * @return ProjectStatusVB
     * @
     */
    @PostMapping(value = "/approveProjDtls")
    @ResponseBody
    @Authorize(
	    actions = {@Attribute(key="action-id", value="approve")},
	    resources = {@Attribute(key="resource-id", value="environmental-liabilities"),@Attribute(key="feature-id", value="project")}
	    )
    public ProjectStatusVB saveApproveProject(@RequestBody ProjectVB projectVB,
	    @ActiveUser ActiveUserId user){
	return liabProjHelper.saveUpdateProjectDetails(projectVB,user);
    }

    @PostMapping(value = "/approveProjChngDtls")
    @ResponseBody
    @Authorize(
	    actions = {@Attribute(key="action-id", value="approve")},
	    resources = {@Attribute(key="resource-id", value="environmental-liabilities"),@Attribute(key="feature-id", value="project-update")}
	    )
    public ProjectStatusVB saveApproveProjectChng(@RequestBody ProjectVB projectVB,
	    @ActiveUser ActiveUserId user){
	return liabProjHelper.saveUpdateProjectDetails(projectVB,user);
    }
    /**
     * This method is used to disApproves the project details 
     * @param ProjectVB
     * @return ProjectStatusVB
     * @
     */
    @PostMapping(value = "/disAprvProjDtls")
    @ResponseBody
    @Authorize(
	    actions = {@Attribute(key="action-id", value="disapprove")},
	    resources = {@Attribute(key="resource-id", value="environmental-liabilities"),@Attribute(key="feature-id", value="project")}
	    )
    public ProjectStatusVB disApproveProject(@RequestBody ProjectVB projectVB,
	    @ActiveUser ActiveUserId user){
	return liabProjHelper.disApproveProject(projectVB,user);
    }
    /**
     * This method is used to disapprove changes the project details 
     * @param ProjectVB
     * @return ProjectStatusVB
     * @
     */
    @PostMapping(value = "/disAprvProjChngDtls")
    @ResponseBody
    @Authorize(
	    actions = {@Attribute(key="action-id", value="disapprove")},
	    resources = {@Attribute(key="resource-id", value="environmental-liabilities"),@Attribute(key="feature-id", value="project-update")}
	    )
    public ProjectStatusVB disApproveProjectChngs(@RequestBody ProjectVB projectVB,
	    @ActiveUser ActiveUserId user){
	return null;
    }
    /**
     * This method is used to save changes the project details 
     * @param ProjectVB
     * @return ProjectStatusVB
     * @
     */
    @PostMapping(value = "/saveProjChangDtls")
    @ResponseBody
    @Authorize(
	    actions = {@Attribute(key="action-id", value="update")},
	    resources = {@Attribute(key="resource-id", value="environmental-liabilities"),@Attribute(key="feature-id", value="project-update")}
	    )
    public ProjectStatusVB saveChangesProject(@RequestBody ProjectVB projectVB,
	    @ActiveUser ActiveUserId user){
	return liabProjHelper.saveUpdateProjectDetails(projectVB,user);
    }

    @PostMapping(value = "/saveProjDtls")
    @ResponseBody
     @Authorize(
	    actions = {@Attribute(key="action-id", value="update")},
	    resources = {@Attribute(key="resource-id", value="environmental-liabilities"),@Attribute(key="feature-id", value="project")}
	    )
    public ProjectStatusVB saveUpdateProjectDetails(@RequestBody ProjectVB projectVB,@ActiveUser ActiveUserId activeUser){
	return liabProjHelper.saveUpdateProjectDetails(projectVB,activeUser);
    }

    @GetMapping(value = "approved/{projId}")
    @ResponseBody
    @Authorize(
	    actions = {@Attribute(key="action-id", value="view")},
	    resources = {@Attribute(key="resource-id", value="environmental-liabilities"),@Attribute(key="feature-id", value="project-summaries")}
	    )
    public ProjectOnLoadVB getApprovedProjectDetails(@PathVariable("projId") long projectId){
	return liabProjHelper.getApprovedProjectDetails(projectId);
    }

    
    @GetMapping(value = "/{projId}")
    @ResponseBody
    @Authorize(
	    actions = {@Attribute(key="action-id", value="view")},
	    resources = {@Attribute(key="resource-id", value="environmental-liabilities"),@Attribute(key="feature-id", value="project-summaries")}
	    )
    public ProjectOnLoadVB getProjectByProjId(@PathVariable("projId") long projectId){
	return liabProjHelper.getProjectByProjId(projectId);
    }
    
    
    @GetMapping(value = "/pendingApprovalProjects")
    @ResponseBody
    @Authorize(
	    actions = {@Attribute(key="action-id", value="view")},
	    resources = {@Attribute(key="resource-id", value="environmental-liabilities"),@Attribute(key="feature-id", value="project-summaries")}
	    )
    public ProjectStatusVB getPendingApprovalProjects(){
	return liabProjHelper.getPendingApprovalProjects();
    }
    
    @GetMapping(value = "/disApprovedProjects")
    @ResponseBody
    @Authorize(
	    actions = {@Attribute(key="action-id", value="view")},
	    resources = {@Attribute(key="resource-id", value="environmental-liabilities"),@Attribute(key="feature-id", value="project-summaries")}
	    )
    public ProjectStatusVB getDisApprovedProjects(){
	return liabProjHelper.getDisApprovedProjects();
    }

    
    @GetMapping(value = "/accountUpdates")
    @ResponseBody
    @Authorize(
	    actions = {@Attribute(key="action-id", value="approve")},
	    resources = {@Attribute(key="resource-id", value="environmental-liabilities"),@Attribute(key="feature-id", value="project")}
	    )
    public  List<AccountCostDTO> getAccountUpdate(){
	return liabProjHelper.getAccountUpdate();
    }
    
    @GetMapping(value = "/deleteProject/{projId}")
    @ResponseBody
    @Authorize(
	    actions = {@Attribute(key="action-id", value="delete")},
	    resources = {@Attribute(key="resource-id", value="environmental-liabilities"),@Attribute(key="feature-id", value="project")}
	    )
    public ProjectStatusVB deleteProject(@PathVariable("projId") long projectId,@ActiveUser ActiveUserId user){
	return liabProjHelper.deleteProjectOrChange(projectId,user,ServiceConstants.ACTION_TYPE_PROJ);
    }
    
    @GetMapping(value = "/deleteChange/{projId}")
    @ResponseBody
    @Authorize(
	    actions = {@Attribute(key="action-id", value="delete")},
	    resources = {@Attribute(key="resource-id", value="environmental-liabilities"),@Attribute(key="feature-id", value="project")}
	    )
    public ProjectStatusVB deleteChange(@PathVariable("projId") long projectId,@ActiveUser ActiveUserId user){
	return liabProjHelper.deleteProjectOrChange(projectId,user,ServiceConstants.ACTION_TYPE_CHANGE);
    }
    
    
    
    @GetMapping(value = "/yearslist")
    @ResponseBody
    public List<Integer> getYearsList(){
	return liabProjHelper.getYearsList();
    }
    
    @GetMapping(value = "/monthslist")
    @ResponseBody
    public List<String> getMonths(){
	return liabProjHelper.getMonths();
    }
}
