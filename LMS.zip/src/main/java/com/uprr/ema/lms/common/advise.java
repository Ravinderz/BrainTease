package com.uprr.ema.lms.common;

public class advise {

}
