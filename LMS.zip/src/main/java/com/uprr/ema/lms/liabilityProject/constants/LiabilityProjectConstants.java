package com.uprr.ema.lms.liabilityProject.constants;

public class LiabilityProjectConstants {

	public static final String OMM_COSTS = "OMM Costs";
	public static final String SYSTEM_CLOSURE_COSTS = "System Closure Costs";
	
}
