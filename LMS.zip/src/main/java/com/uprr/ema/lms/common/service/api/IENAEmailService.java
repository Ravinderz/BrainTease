package com.uprr.ema.lms.common.service.api;

import org.springframework.jms.JmsException;

import com.uprr.ema.lms.common.dto.SendMailDTO;

public interface IENAEmailService {

    	
    	/* This is used to send EMA notification*/
    	 
	void sendEmailNotification(SendMailDTO sendMailVO) throws JmsException;
}