package com.uprr.ema.lms.reports.vb;

import java.util.Arrays;

public class DocumentVB {

	private String guid;
	private String fileName;
	private byte[] response;
	
	public String getGuid() {
		return guid;
	}
	public void setGuid(String guid) {
		this.guid = guid;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public byte[] getResponse() {
		return response;
	}
	public void setResponse(byte[] response) {
		this.response = response;
	}
	
	public DocumentVB(String guid, String fileName, byte[] response) {
		super();
		this.guid = guid;
		this.fileName = fileName;
		this.response = response;
	}
	public DocumentVB() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "DocumentVB [guid=" + guid + ", fileName=" + fileName + ", response=" + Arrays.toString(response) + "]";
	}
	
	
	
}
