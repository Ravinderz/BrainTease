package com.uprr.ema.lms.reports.dto;

import java.util.Arrays;
import java.util.List;

public class OverAllDataLCRRprtDTO{
	
	private List<LCRRprtDTO> lcrRprtLiabEstAmt;
	private List<LCRRprtDTO> lcrRprtChngedAmtIncDecBy10000List;
	private List<List<LCRRprtDTO>> lcrRprtDTOLstofLst;
	private List<LCRRprtDTO> lcrRptDTOAllPrjctLstforTubeLevelGrtrThanSix;
	private List<LCRRprtDTO> lcrRptDTOAllNewProjectLst;
	private Integer totalLiabilityEstAmt;
	private Integer totalLiabilityEstChanged;	
	private Integer totalLiabilityEstChangedForQrtr;	
	private String[] firstLastDayStrings;

	public OverAllDataLCRRprtDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public List<LCRRprtDTO> getLcrRprtLiabEstAmt() {
		return lcrRprtLiabEstAmt;
	}

	public void setLcrRprtLiabEstAmt(List<LCRRprtDTO> lcrRprtLiabEstAmt) {
		this.lcrRprtLiabEstAmt = lcrRprtLiabEstAmt;
	}

	public List<LCRRprtDTO> getLcrRprtChngedAmtIncDecBy10000List() {
		return lcrRprtChngedAmtIncDecBy10000List;
	}

	public void setLcrRprtChngedAmtIncDecBy10000List(List<LCRRprtDTO> lcrRprtChngedAmtIncDecBy10000List) {
		this.lcrRprtChngedAmtIncDecBy10000List = lcrRprtChngedAmtIncDecBy10000List;
	}

	public List<List<LCRRprtDTO>> getLcrRprtDTOLstofLst() {
		return lcrRprtDTOLstofLst;
	}

	public void setLcrRprtDTOLstofLst(List<List<LCRRprtDTO>> lcrRprtDTOLstofLst) {
		this.lcrRprtDTOLstofLst = lcrRprtDTOLstofLst;
	}

	public List<LCRRprtDTO> getLcrRptDTOAllPrjctLstforTubeLevelGrtrThanSix() {
		return lcrRptDTOAllPrjctLstforTubeLevelGrtrThanSix;
	}

	public void setLcrRptDTOAllPrjctLstforTubeLevelGrtrThanSix(
			List<LCRRprtDTO> lcrRptDTOAllPrjctLstforTubeLevelGrtrThanSix) {
		this.lcrRptDTOAllPrjctLstforTubeLevelGrtrThanSix = lcrRptDTOAllPrjctLstforTubeLevelGrtrThanSix;
	}

	public List<LCRRprtDTO> getLcrRptDTOAllNewProjectLst() {
		return lcrRptDTOAllNewProjectLst;
	}

	public void setLcrRptDTOAllNewProjectLst(List<LCRRprtDTO> lcrRptDTOAllNewProjectLst) {
		this.lcrRptDTOAllNewProjectLst = lcrRptDTOAllNewProjectLst;
	}

	public Integer getTotalLiabilityEstAmt() {
		return totalLiabilityEstAmt;
	}

	public void setTotalLiabilityEstAmt(Integer totalLiabilityEstAmt) {
		this.totalLiabilityEstAmt = totalLiabilityEstAmt;
	}

	public Integer getTotalLiabilityEstChanged() {
		return totalLiabilityEstChanged;
	}

	public void setTotalLiabilityEstChanged(Integer totalLiabilityEstChanged) {
		this.totalLiabilityEstChanged = totalLiabilityEstChanged;
	}

	public Integer getTotalLiabilityEstChangedForQrtr() {
		return totalLiabilityEstChangedForQrtr;
	}

	public void setTotalLiabilityEstChangedForQrtr(Integer totalLiabilityEstChangedForQrtr) {
		this.totalLiabilityEstChangedForQrtr = totalLiabilityEstChangedForQrtr;
	}

	public String[] getFirstLastDayStrings() {
		return firstLastDayStrings;
	}

	public void setFirstLastDayStrings(String[] firstLastDayStrings) {
		this.firstLastDayStrings = firstLastDayStrings;
	}

	@Override
	public String toString() {
		return "OverAllDataLCRRprtDTO [lcrRprtLiabEstAmt=" + lcrRprtLiabEstAmt + ", lcrRprtChngedAmtIncDecBy10000List="
				+ lcrRprtChngedAmtIncDecBy10000List + ", lcrRprtDTOLstofLst=" + lcrRprtDTOLstofLst
				+ ", lcrRptDTOAllPrjctLstforTubeLevelGrtrThanSix=" + lcrRptDTOAllPrjctLstforTubeLevelGrtrThanSix
				+ ", lcrRptDTOAllNewProjectLst=" + lcrRptDTOAllNewProjectLst + ", totalLiabilityEstAmt="
				+ totalLiabilityEstAmt + ", totalLiabilityEstChanged=" + totalLiabilityEstChanged
				+ ", totalLiabilityEstChangedForQrtr=" + totalLiabilityEstChangedForQrtr + ", firstLastDayStrings="
				+ Arrays.toString(firstLastDayStrings) + "]";
	}

	public OverAllDataLCRRprtDTO(List<LCRRprtDTO> lcrRprtLiabEstAmt, List<LCRRprtDTO> lcrRprtChngedAmtIncDecBy10000List,
			List<List<LCRRprtDTO>> lcrRprtDTOLstofLst, List<LCRRprtDTO> lcrRptDTOAllPrjctLstforTubeLevelGrtrThanSix,
			List<LCRRprtDTO> lcrRptDTOAllNewProjectLst, Integer totalLiabilityEstAmt, Integer totalLiabilityEstChanged,
			Integer totalLiabilityEstChangedForQrtr, String[] firstLastDayStrings) {
		super();
		this.lcrRprtLiabEstAmt = lcrRprtLiabEstAmt;
		this.lcrRprtChngedAmtIncDecBy10000List = lcrRprtChngedAmtIncDecBy10000List;
		this.lcrRprtDTOLstofLst = lcrRprtDTOLstofLst;
		this.lcrRptDTOAllPrjctLstforTubeLevelGrtrThanSix = lcrRptDTOAllPrjctLstforTubeLevelGrtrThanSix;
		this.lcrRptDTOAllNewProjectLst = lcrRptDTOAllNewProjectLst;
		this.totalLiabilityEstAmt = totalLiabilityEstAmt;
		this.totalLiabilityEstChanged = totalLiabilityEstChanged;
		this.totalLiabilityEstChangedForQrtr = totalLiabilityEstChangedForQrtr;
		this.firstLastDayStrings = firstLastDayStrings;
	}
	
}
