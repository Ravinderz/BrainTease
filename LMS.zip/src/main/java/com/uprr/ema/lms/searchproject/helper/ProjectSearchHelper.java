package com.uprr.ema.lms.searchproject.helper;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Sheet;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import com.uprr.ema.lms.common.dto.DropDownInfo;
import com.uprr.ema.lms.common.service.util.ExcelUtils;
import com.uprr.ema.lms.common.service.util.LMSUtils;
import com.uprr.ema.lms.common.web.util.WebDateUtil;
import com.uprr.ema.lms.exception.ExcelReportException;
import com.uprr.ema.lms.searchproject.dto.ProjectSearchCriteriaDTO;
import com.uprr.ema.lms.searchproject.dto.SearchDTO;
import com.uprr.ema.lms.searchproject.service.api.ProjectSearchService;
import com.uprr.ema.lms.searchproject.vb.ProjectSearchCriteriaVB;
import com.uprr.ema.lms.searchproject.vb.SearchCriteriaResponse;
import com.uprr.ema.lms.searchproject.vb.SearchOnloadVB;
import com.uprr.ema.lms.searchproject.vb.SearchVB;

@Component
public class ProjectSearchHelper {
	
	@Autowired
	private ProjectSearchService projectSearchService;
	
	public SearchOnloadVB getOnloadData(String userId){
		return projectSearchService.getOnloadData(userId);
	}
	
	public List<DropDownInfo> getProjectNames(String projectName){
		
		return projectSearchService.getProjectNames(projectName);
	}
	
	public int getSearchResultRowCount(ProjectSearchCriteriaVB projectSearchCriteriaVB){
		
		return projectSearchService.getSearchResultRowCount(getProjectSearchCriteriaDTOFromVB(projectSearchCriteriaVB));
	}
	
	public SearchCriteriaResponse<SearchVB> getSecurityRolesThroughPagination(final ProjectSearchCriteriaVB projectSearchCriteriaVB){
		ProjectSearchCriteriaDTO projectSearchCriteriaDTO=null;
		if(projectSearchCriteriaVB !=null)
		projectSearchCriteriaDTO = getProjectSearchCriteriaDTOFromVB(projectSearchCriteriaVB);
		if(StringUtils.isBlank(projectSearchCriteriaDTO.getOrderByColumn())){
			projectSearchCriteriaDTO.setOrderByColumn("PROJ_NAME");
			projectSearchCriteriaDTO.setSortingType("ASC");
		}
		int totalCount = projectSearchCriteriaDTO.getRecordsCount();
		List<SearchVB> searchVbList=Collections.emptyList();
		if(totalCount == 0){
			totalCount = this.getSearchResultRowCount(projectSearchCriteriaVB);
		}
		
		if(totalCount > 0){
			final List<SearchDTO> searchDtoList = this.projectSearchService
					.getSearchResultThroughPagination(projectSearchCriteriaDTO);
			searchVbList = convertSearchProjectDTOCollection(searchDtoList);
		}
		return LMSUtils.preparePaginationSearchCriteriaResponse(projectSearchCriteriaVB, totalCount, searchVbList);
	}
	
	
	private ResponseEntity<ByteArrayResource> getResponse(byte[] contents, String fileName) {
		final HttpHeaders responseHeaders = new HttpHeaders();
		responseHeaders.setContentType(MediaType.APPLICATION_OCTET_STREAM);
		responseHeaders.setContentLength(contents.length);
		responseHeaders.setContentDispositionFormData(fileName, fileName);
		responseHeaders.set("x-filename", fileName);
		responseHeaders.setPragma("public");
		responseHeaders.setCacheControl("must-revalidate, post-check=0,pre-check=0");
		return new ResponseEntity<ByteArrayResource>(new ByteArrayResource(contents), responseHeaders, HttpStatus.OK);
	} 
	public void getExcelReport(HttpServletResponse response,SearchVB searchVB)throws Exception{
		SearchDTO searchDto= getSearchDTOFromVB(searchVB);
		ProjectSearchCriteriaDTO projectSearchCriteriaDTO = new ProjectSearchCriteriaDTO();
		projectSearchCriteriaDTO.setProjectSearchCriteria(searchDto);
		final List<SearchDTO> searchDtoList = this.projectSearchService
				.getExcelReport(projectSearchCriteriaDTO);
		Sheet sheet=exportDataToExcel(searchDtoList);
		write(response,sheet, "Projects Report.xls");
		
	}
	
	  
	public void write(HttpServletResponse response, Sheet worksheet,
			String fileName) throws Exception{


		response.setHeader("Content-Disposition", "inline; filename="
				+ fileName);
		// Make sure to set the correct content type
		response.setContentType("application/vnd.ms-excel");
		// Write to the output stream
		
		// Retrieve the output stream
		ServletOutputStream outputStream = response.getOutputStream();
		response.setCharacterEncoding("UTF-8");
		// Write to the output stream
		worksheet.getWorkbook().write(outputStream);
		// Flush the stream
		outputStream.flush();
		

	}
 
	
	public Sheet exportDataToExcel(List<SearchDTO> searchDtoList) {
		String workSheetName = "Projects Report";
		List<String[]> excelContentList = new ArrayList<String[]>();
		String[] exelHeaders = { "Project Name", "Created Date", "Last Change Date", "Tube Level"};
		excelContentList.add(exelHeaders);
		String[] contentArray = null;
		if (LMSUtils.isNotEmpty(searchDtoList)) {
			for (SearchDTO searchDTO : searchDtoList) {
				contentArray = new String[4];
				contentArray[0] = searchDTO.getProjecName();
				contentArray[1] = StringUtils.isNoneBlank(WebDateUtil.getDisplayformat(searchDTO.getCreationDate()))?WebDateUtil.getDisplayformat(searchDTO.getCreationDate()):"";
				contentArray[2] = StringUtils.isNoneBlank(WebDateUtil.getDisplayformat(searchDTO.getLastChngDate()))?WebDateUtil.getDisplayformat(searchDTO.getLastChngDate()):"";
				contentArray[3] = searchDTO.getTubLevelDesc();
				excelContentList.add(contentArray);
				contentArray = null;
			}
		}
		return ExcelUtils.generateExcel(workSheetName, excelContentList);

	} 
	
	
	private ProjectSearchCriteriaDTO getProjectSearchCriteriaDTOFromVB(ProjectSearchCriteriaVB projectSearchCriteriaVB){
		ProjectSearchCriteriaDTO projectSearchCriteriaDTO =new ProjectSearchCriteriaDTO();
		BeanUtils.copyProperties(projectSearchCriteriaVB, projectSearchCriteriaDTO);
		if(projectSearchCriteriaVB.getProjectSearchCriteria()!=null){
		projectSearchCriteriaDTO.setProjectSearchCriteria(getSearchDTOFromVB(projectSearchCriteriaVB.getProjectSearchCriteria()));
		
		}
		
		return projectSearchCriteriaDTO;
	}
	
	private ProjectSearchCriteriaVB getProjectSearchCriteriaVBFromDTO(ProjectSearchCriteriaDTO projectSearchCriteriaDTO){
		ProjectSearchCriteriaVB projectSearchCriteriaVB =new ProjectSearchCriteriaVB();
		BeanUtils.copyProperties(projectSearchCriteriaDTO, projectSearchCriteriaVB);
		if(projectSearchCriteriaDTO.getProjectSearchCriteria()!=null)
			projectSearchCriteriaVB.setProjectSearchCriteria(getSearchVBFromDTO(projectSearchCriteriaDTO.getProjectSearchCriteria()));
		
		return projectSearchCriteriaVB;
	}
	
	private List<SearchVB> convertSearchProjectDTOCollection(final List<SearchDTO> searchProjects) {
		List<SearchVB> searchVbs = Collections.emptyList();
		if (LMSUtils.isNotEmpty(searchProjects)) {
			searchVbs = new ArrayList<SearchVB>(searchProjects.size());
			for (final SearchDTO searchDto : searchProjects) {
				final SearchVB searchVB = getSearchVBFromDTO(searchDto);
				searchVbs.add(searchVB);
			}
		}
		return searchVbs;
	}

	
	private SearchDTO getSearchDTOFromVB(SearchVB searchVB){
		SearchDTO searchDTO = new SearchDTO();
		BeanUtils.copyProperties(searchVB, searchDTO);
		
		if(StringUtils.isNoneBlank(searchVB.getLastChngDate())){
			searchDTO.setLastChngDate(WebDateUtil.getDateFromddMMYYY(searchVB.getLastChngDate()));
		}
		if(StringUtils.isNoneBlank(searchVB.getCreationDate())){
			searchDTO.setCreationDate(WebDateUtil.getDateFromddMMYYY(searchVB.getCreationDate()));
		}
		
		if(StringUtils.isNoneBlank(searchVB.getCreateDateFrm())){
			searchDTO.setCreateDateFrm(WebDateUtil.getDateFromddMMYYY(searchVB.getCreateDateFrm()));
		}
		if(StringUtils.isNoneBlank(searchVB.getCreateDateTo())){
			searchDTO.setCreateDateTo(WebDateUtil.getDateFromddMMYYY(searchVB.getCreateDateTo()));
		}
		
		if(StringUtils.isNoneBlank(searchVB.getLastChangeDateFrm())){
			searchDTO.setLastChangeDateFrm(WebDateUtil.getDateFromddMMYYY(searchVB.getLastChangeDateFrm()));
		}
		if(StringUtils.isNoneBlank(searchVB.getLastChangeDateTo() )){
			searchDTO.setLastChangeDateTo(WebDateUtil.getDateFromddMMYYY(searchVB.getLastChangeDateTo()));
		}
		
		if(StringUtils.isNoneBlank(searchVB.getProjCloseDateFrm() )){
			searchDTO.setProjCloseDateFrm(WebDateUtil.getDateFromddMMYYY(searchVB.getProjCloseDateFrm()));
		}
		if(StringUtils.isNoneBlank(searchVB.getProjCloseDateTo() )){
			searchDTO.setProjCloseDateTo(WebDateUtil.getDateFromddMMYYY(searchVB.getProjCloseDateTo()));
		}
		return searchDTO;
	}
	
	private SearchVB getSearchVBFromDTO(SearchDTO searchDTO){
		
		SearchVB searchVB = new SearchVB();
		BeanUtils.copyProperties(searchDTO, searchVB);
		
		if(searchDTO.getLastChngDate() != null){
			searchVB.setLastChngDate(WebDateUtil.getDisplayformat(searchDTO.getLastChngDate()));
		}
		if(searchDTO.getCreationDate() != null){
			searchVB.setCreationDate(WebDateUtil.getDisplayformat(searchDTO.getCreationDate()));
		}
		
		if(searchDTO.getCreateDateFrm() != null){
			searchVB.setCreateDateFrm(WebDateUtil.getDisplayformat(searchDTO.getCreateDateFrm()));
		}
		if(searchDTO.getCreateDateTo() != null){
			searchVB.setCreateDateTo(WebDateUtil.getDisplayformat(searchDTO.getCreateDateTo()));
		}
		
		if(searchDTO.getLastChangeDateFrm()!= null){
			searchVB.setLastChangeDateFrm(WebDateUtil.getDisplayformat(searchDTO.getLastChangeDateFrm()));
		}
		if(searchDTO.getLastChangeDateTo() != null){
			searchVB.setLastChangeDateTo(WebDateUtil.getDisplayformat(searchDTO.getLastChangeDateTo()));
		}
		
		if(searchDTO.getProjCloseDateFrm() != null){
			searchVB.setProjCloseDateFrm(WebDateUtil.getDisplayformat(searchDTO.getProjCloseDateFrm()));
		}
		if(searchDTO.getProjCloseDateTo() != null){
			searchVB.setProjCloseDateTo(WebDateUtil.getDisplayformat(searchDTO.getProjCloseDateTo()));
		}
		return searchVB;
	}
}
