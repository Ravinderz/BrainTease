package com.uprr.ema.lms.scheduler.service.api;



public interface SchedulableService {

    public void saveLEWBMonthData();
    public void saveLEWBMonthData(String userId);
    public void saveLEWBQuarterData() ;
    public void saveLEWBQuarterData(String userId);
    public void saveLEWBMonthInQuarterData() ;
    public void saveLEWBMonthInQuarterData(String userId);
}
