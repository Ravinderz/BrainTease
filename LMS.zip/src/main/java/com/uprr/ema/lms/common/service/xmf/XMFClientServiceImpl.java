package com.uprr.ema.lms.common.service.xmf;

import org.acegisecurity.context.SecurityContextHolder;
import org.acegisecurity.providers.AbstractAuthenticationToken;
import org.acegisecurity.providers.ProviderManager;
import org.acegisecurity.providers.UsernamePasswordAuthenticationToken;
import org.springframework.aop.target.CommonsPool2TargetSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.uprr.app.xmf.MessageUtilities;
import com.uprr.app.xmf.client.ServiceProxy;
import com.uprr.app.xmf.client.ServiceProxyException;
import com.uprr.app.xmf.client.security.core.CredentialProviderUserDetailsService;
import com.uprr.app.xmf.client.security.core.UserPwdDetails;
import com.uprr.ema.lms.exception.LmsException;
/**
 * 
 * @author xprk481
 *
 */
@Service
public class XMFClientServiceImpl implements IXMFClientService {

	@Autowired
	@Qualifier("messageUtilities")
	private MessageUtilities messageUtilities;
	@Autowired
	@Qualifier("commonsPoolTargetSource")
	private CommonsPool2TargetSource commonsPoolTargetSource;
	@Autowired
	@Qualifier("authenticationManager")
	private ProviderManager authenticationManager;
	@Autowired
	@Qualifier("userDetailsService")
	private CredentialProviderUserDetailsService userDetailsService;

	/**
	 * This method talks to XMF Service and gets the requisite data
	 * 
	 * @param serviceSecurityType
	 *            : secure/unsecure
	 * @param serviceName
	 *            : XMF Service Name to get the requisite details
	 * @param empRequestXML
	 *            : Constructed request XML based on the Service Name
	 * @return
	 */
	public String getXMFDataByServiceDtls(String serviceSecurityType, String serviceName, String empRequestXML)
			throws LmsException {
		String empDtlsXMFBodyStr = null;
		if (serviceSecurityType == null) {
			throw (new LmsException("serviceSecurityType must to be supplied."));
		}
		if (serviceName == null || serviceName.trim().length() == 0) {
			throw (new LmsException("serviceName must be supplied"));
		}
		if (empRequestXML == null || empRequestXML.trim().length() == 0) {
			throw (new LmsException("empRequestXML should not be null"));
		}
		String replyEnvelope = null;
		ServiceProxy serviceProxyObj = null;
		String xmfReqHeaderStr = messageUtilities.createXMFRequestHeader("cn=dema001,ou=uprr,o=up", serviceName);
		String xmfMessageRequStr = messageUtilities.createXMFMessage(xmfReqHeaderStr, empRequestXML);
		try {
			try {
				if (IXMFClientService.SECURE_TYPE.equalsIgnoreCase(serviceSecurityType)) {
					
					  // Authenticate the Client Certificate
					authenticateByUserPwd();
					serviceProxyObj = (ServiceProxy)commonsPoolTargetSource.getTarget();
					 } else if (IXMFClientService.PRIVATE_TYPE.equalsIgnoreCase(serviceSecurityType)) {
					/*
					 * serviceProxyObj =
					 * (ServiceProxy)getPrivateCommonsPool2TargetSource().
					 * getTarget();
					 */} else {
					try {
						serviceProxyObj = (ServiceProxy)commonsPoolTargetSource.getTarget();
					} catch (Exception e) {
						throw new LmsException("Exception while getting Service proxy object.",e);
					}
				}
				// Call the invoke method on serviceProxy object.
				if (IXMFClientService.PERSON_GET_SERVICE_NAME.equals(serviceName)) {
					try {
						if(serviceProxyObj != null){
						replyEnvelope = serviceProxyObj.invoke(xmfMessageRequStr,
								IXMFClientService.SERVICE_UNIT_TIME_TO_LIVE);
						}
					} catch (ServiceProxyException e) {
						throw new LmsException("Exception while getting Service proxy object.",e);
					}
				} else {
					try {
						if (serviceProxyObj != null) {
						replyEnvelope = serviceProxyObj.invoke(xmfMessageRequStr, IXMFClientService.TIME_TO_LIVE);
						}
					} catch (ServiceProxyException e) {
						throw new LmsException("Exception while getting Service proxy object.",e);
					}
				}
			} finally {
				if (serviceProxyObj != null) {
					commonsPoolTargetSource.releaseTarget(serviceProxyObj);
				}
			}
		} catch (Exception e) {
			throw new LmsException("Exception while getting Service proxy object.", e);
		}
		if (replyEnvelope != null) {
			empDtlsXMFBodyStr = messageUtilities.getXMFBody(replyEnvelope);
		}
		return empDtlsXMFBodyStr;
	}

	
	private  void authenticateByUserPwd() throws Exception {
	    final String user = userDetailsService.getAppId();
	    String  pwdToken = userDetailsService.getToken();
	    if (pwdToken == null) {
	        throw new Exception("Unable to retrieve password from Vault for user -> " + user);
	    }
	    final UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken(user, pwdToken);
	    AbstractAuthenticationToken authn = null;
	    authn = (AbstractAuthenticationToken) authenticationManager.authenticate(token);
	    authn.setDetails(new UserPwdDetails());
	    SecurityContextHolder.getContext().setAuthentication(authn);
	}


	
	

}
