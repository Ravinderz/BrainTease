package com.uprr.ema.lms.common.security;

import java.nio.file.AccessDeniedException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.uprr.ema.lms.advise.ExceptionControllerAdvice;
import com.uprr.ema.lms.common.annotation.Authorize;
import com.uprr.ema.lms.common.aspectj.LoggingAspect;
import com.uprr.ema.lms.common.enums.RoleType;

/**
 * 
 * @author Anil Kumar Manchala
 *  This Class is used to intercept each request and determines the authorization.
 *
 */
public class AuthorizationInterceptor extends HandlerInterceptorAdapter {

	

	
	private static Logger LOGGER = LoggerFactory.getLogger(AuthorizationInterceptor.class);

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
		Boolean authStatus = null;
		if (handler instanceof HandlerMethod) {
			HandlerMethod handlerMethod = (HandlerMethod) handler;
			Authorize authorize = handlerMethod.getMethodAnnotation(Authorize.class);
			if (authorize != null && authorize.roles() != null && authorize.roles().length > 0) {            	
				if (userHasAnyRole(request, authorize.roles())) {
					authStatus = Boolean.TRUE;
				}/*else if(checkIfDefaultUserIsAllowed(authorize.roles())){
					authStatus = Boolean.TRUE;
				}*/else {
					authStatus = Boolean.FALSE;
				}
			}

		}
		
		
		if(authStatus != null){
			 if(!authStatus) { 
				 throw new AccessDeniedException("Unauthorized Access");
			 }
			return authStatus;
		} 
		return super.preHandle(request, response, handler);
	}

	private boolean userHasAnyRole(HttpServletRequest request, final String[] roles) {
		boolean status = false;
		for (String role : roles) {
			if (request.isUserInRole(role)) {
				LOGGER.info("Role Printing in Interceptor ::: ",role);
				status = true;
			}
		}
		return status;
	}

/*	private boolean checkIfDefaultUserIsAllowed(final String[] roles) {
		boolean status = false;
		for (String role : roles) {
			if (RoleType.isFieldManager(role)) {
				LOGGER.info("Default Role Allowed.");
				status =  true;
			}
		}
		return status;
	}*/

}
