package com.uprr.ema.lms.reports.dto;

public class LCRRprtDTO implements Comparable<LCRRprtDTO>{
	
	private long projID;
	private String projectName;
	private String city;
	private String state;
	private String projOthDesc;
	private Long tubeLvlId;
	private Integer totalLiabilityChangeAmtForMonth;	
	private Integer totalLiabilityChangeAmtForQuarter;	
	private Integer changedLiabilityEstimate;	
	private Integer selectedLiabEstAmt;	
	private Integer prevliabestamt;	
	private String changeReasonDesc;
	private String changeReasonComment;
	private Integer totalLiabEstAmt;
	private Integer monthYear;
	
	public long getProjID() {
		return projID;
	}
	public void setProjID(long projID) {
		this.projID = projID;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getProjOthDesc() {
		return projOthDesc;
	}
	public void setProjOthDesc(String projOthDesc) {
		this.projOthDesc = projOthDesc;
	}
	public Long getTubeLvlId() {
		return tubeLvlId;
	}
	public void setTubeLvlId(Long tubeLvlId) {
		this.tubeLvlId = tubeLvlId;
	}
	public Integer getTotalLiabilityChangeAmtForMonth() {
		return totalLiabilityChangeAmtForMonth;
	}
	public void setTotalLiabilityChangeAmtForMonth(Integer TotalLiabilityChangeAmtForMonth) {
		totalLiabilityChangeAmtForMonth = TotalLiabilityChangeAmtForMonth;
	}
	public Integer getTotalLiabilityChangeAmtForQuarter() {
		return totalLiabilityChangeAmtForQuarter;
	}
	public void setTotalLiabilityChangeAmtForQuarter(Integer TotalLiabilityChangeAmtForQuarter) {
		totalLiabilityChangeAmtForQuarter = TotalLiabilityChangeAmtForQuarter;
	}
	public Integer getChangedLiabilityEstimate() {
		return changedLiabilityEstimate;
	}
	public void setChangedLiabilityEstimate(Integer changedLiabilityEstimate) {
		this.changedLiabilityEstimate = changedLiabilityEstimate;
	}
	public void setSelectedLiabEstAmt(Integer selectedLiabEstAmt) {
		this.selectedLiabEstAmt = selectedLiabEstAmt;
	}
	public void setPrevliabestamt(Integer prevliabestamt) {
		this.prevliabestamt = prevliabestamt;
	}
	public void setTotalLiabEstAmt(Integer totalLiabEstAmt) {
		this.totalLiabEstAmt = totalLiabEstAmt;
	}
	public String getChangeReasonDesc() {
		return changeReasonDesc;
	}
	public void setChangeReasonDesc(String changeReasonDesc) {
		this.changeReasonDesc = changeReasonDesc;
	}
	public String getChangeReasonComment() {
		return changeReasonComment;
	}
	public void setChangeReasonComment(String changeReasonComment) {
		this.changeReasonComment = changeReasonComment;
	}
	public Integer getSelectedLiabEstAmt() {
		return selectedLiabEstAmt;
	}
	public Integer getPrevliabestamt() {
		return prevliabestamt;
	}
	public Integer getTotalLiabEstAmt() {
		return totalLiabEstAmt;
	}
	public Integer getMonthYear() {
		return monthYear;
	}
	public void setMonthYear(Integer monthYear) {
		this.monthYear = monthYear;
	}
	public LCRRprtDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

	public LCRRprtDTO(long projID, String projectName, String city, String state, String projOthDesc, Long tubeLvlId,
			Integer totalLiabilityChangeAmtForMonth, Integer totalLiabilityChangeAmtForQuarter,
			Integer changedLiabilityEstimate, Integer selectedLiabEstAmt, Integer prevliabestamt,
			String changeReasonDesc, String changeReasonComment, Integer totalLiabEstAmt, Integer monthYear) {
		super();
		this.projID = projID;
		this.projectName = projectName;
		this.city = city;
		this.state = state;
		this.projOthDesc = projOthDesc;
		this.tubeLvlId = tubeLvlId;
		this.totalLiabilityChangeAmtForMonth = totalLiabilityChangeAmtForMonth;
		this.totalLiabilityChangeAmtForQuarter = totalLiabilityChangeAmtForQuarter;
		this.changedLiabilityEstimate = changedLiabilityEstimate;
		this.selectedLiabEstAmt = selectedLiabEstAmt;
		this.prevliabestamt = prevliabestamt;
		this.changeReasonDesc = changeReasonDesc;
		this.changeReasonComment = changeReasonComment;
		this.totalLiabEstAmt = totalLiabEstAmt;
		this.monthYear = monthYear;
	}
	@Override
	public String toString() {
		return "LCRRprtDTO [projID=" + projID + ", projectName=" + projectName + ", city=" + city + ", state=" + state
				+ ", projOthDesc=" + projOthDesc + ", tubeLvlId=" + tubeLvlId + ", totalLiabilityChangeAmtForMonth="
				+ totalLiabilityChangeAmtForMonth + ", totalLiabilityChangeAmtForQuarter="
				+ totalLiabilityChangeAmtForQuarter + ", changedLiabilityEstimate=" + changedLiabilityEstimate
				+ ", selectedLiabEstAmt=" + selectedLiabEstAmt + ", prevliabestamt=" + prevliabestamt
				+ ", changeReasonDesc=" + changeReasonDesc + ", changeReasonComment=" + changeReasonComment
				+ ", totalLiabEstAmt=" + totalLiabEstAmt + ", monthYear=" + monthYear + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((changeReasonComment == null) ? 0 : changeReasonComment.hashCode());
		result = prime * result + ((changeReasonDesc == null) ? 0 : changeReasonDesc.hashCode());
		result = prime * result + ((changedLiabilityEstimate == null) ? 0 : changedLiabilityEstimate.hashCode());
		result = prime * result + ((city == null) ? 0 : city.hashCode());
		result = prime * result + ((monthYear == null) ? 0 : monthYear.hashCode());
		result = prime * result + ((prevliabestamt == null) ? 0 : prevliabestamt.hashCode());
		result = prime * result + (int) (projID ^ (projID >>> 32));
		result = prime * result + ((projOthDesc == null) ? 0 : projOthDesc.hashCode());
		result = prime * result + ((projectName == null) ? 0 : projectName.hashCode());
		result = prime * result + ((selectedLiabEstAmt == null) ? 0 : selectedLiabEstAmt.hashCode());
		result = prime * result + ((state == null) ? 0 : state.hashCode());
		result = prime * result + ((totalLiabEstAmt == null) ? 0 : totalLiabEstAmt.hashCode());
		result = prime * result
				+ ((totalLiabilityChangeAmtForMonth == null) ? 0 : totalLiabilityChangeAmtForMonth.hashCode());
		result = prime * result
				+ ((totalLiabilityChangeAmtForQuarter == null) ? 0 : totalLiabilityChangeAmtForQuarter.hashCode());
		result = prime * result + ((tubeLvlId == null) ? 0 : tubeLvlId.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LCRRprtDTO other = (LCRRprtDTO) obj;
		if (changeReasonComment == null) {
			if (other.changeReasonComment != null)
				return false;
		} else if (!changeReasonComment.equals(other.changeReasonComment))
			return false;
		if (changeReasonDesc == null) {
			if (other.changeReasonDesc != null)
				return false;
		} else if (!changeReasonDesc.equals(other.changeReasonDesc))
			return false;
		if (changedLiabilityEstimate == null) {
			if (other.changedLiabilityEstimate != null)
				return false;
		} else if (!changedLiabilityEstimate.equals(other.changedLiabilityEstimate))
			return false;
		if (city == null) {
			if (other.city != null)
				return false;
		} else if (!city.equals(other.city))
			return false;
		if (monthYear == null) {
			if (other.monthYear != null)
				return false;
		} else if (!monthYear.equals(other.monthYear))
			return false;
		if (prevliabestamt == null) {
			if (other.prevliabestamt != null)
				return false;
		} else if (!prevliabestamt.equals(other.prevliabestamt))
			return false;
		if (projID != other.projID)
			return false;
		if (projOthDesc == null) {
			if (other.projOthDesc != null)
				return false;
		} else if (!projOthDesc.equals(other.projOthDesc))
			return false;
		if (projectName == null) {
			if (other.projectName != null)
				return false;
		} else if (!projectName.equals(other.projectName))
			return false;
		if (selectedLiabEstAmt == null) {
			if (other.selectedLiabEstAmt != null)
				return false;
		} else if (!selectedLiabEstAmt.equals(other.selectedLiabEstAmt))
			return false;
		if (state == null) {
			if (other.state != null)
				return false;
		} else if (!state.equals(other.state))
			return false;
		if (totalLiabEstAmt == null) {
			if (other.totalLiabEstAmt != null)
				return false;
		} else if (!totalLiabEstAmt.equals(other.totalLiabEstAmt))
			return false;
		if (totalLiabilityChangeAmtForMonth == null) {
			if (other.totalLiabilityChangeAmtForMonth != null)
				return false;
		} else if (!totalLiabilityChangeAmtForMonth.equals(other.totalLiabilityChangeAmtForMonth))
			return false;
		if (totalLiabilityChangeAmtForQuarter == null) {
			if (other.totalLiabilityChangeAmtForQuarter != null)
				return false;
		} else if (!totalLiabilityChangeAmtForQuarter.equals(other.totalLiabilityChangeAmtForQuarter))
			return false;
		if (tubeLvlId == null) {
			if (other.tubeLvlId != null)
				return false;
		} else if (!tubeLvlId.equals(other.tubeLvlId))
			return false;
		return true;
	}
	@Override
	public int compareTo(LCRRprtDTO o) {
		// TODO Auto-generated method stub
		return this.getChangedLiabilityEstimate().compareTo(((LCRRprtDTO) o).getChangedLiabilityEstimate());
	}
	
}
