package com.uprr.ema.lms.common.helper;
/**
 * This class will accept the request from controller and copy the data from VB
 * to DTO and vice versa
 * 
 * @author xprk208
 * 
 */
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.uprr.ema.lms.common.service.api.CommonService;


@Component
public class CommonHelper {
	
	@Autowired
	CommonService commonService;
	
}
