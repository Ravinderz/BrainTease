package com.uprr.ema.lms.common.aspectj;


import java.util.Arrays;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.uprr.ema.lms.common.constant.LmsConstants;
import com.uprr.ema.lms.common.util.CommonUtils;

@Component
@Aspect
public class LoggingAspect extends Aspects {
Logger logger = LoggerFactory.getLogger(LoggingAspect.class);
	
	private String userName;

	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}	
	

	@Before("controllerBean() && methodPointcut()")
	public void beforeClassMethodCall(JoinPoint joinPoint) {
		logger.info("UserId "+this.userName+" Before execution of method >>>: "
				+ joinPoint.getTarget().getClass().getName() + "."
				+ joinPoint.getSignature().getName() + ". Args :"
				+ Arrays.toString(joinPoint.getArgs()));
	}

	@After("controllerBean() && methodPointcut()")
	public void afterClassMethodCall(JoinPoint joinPoint) {
		logger.info("UserId "+this.userName+" After execution of method >>>: "
				+ joinPoint.getTarget().getClass().getName() + "."
				+ joinPoint.getSignature().getName() + ". Args :"
				+ Arrays.toString(joinPoint.getArgs()));
	}

	@Before("service() && methodPointcut() ")
	public void beforeServiceClassCall(JoinPoint joinPoint) {
		logger.info("UserId "+this.userName+" Before Service method call >>>: "
				+ joinPoint.getTarget().getClass().getName() + "."
				+ joinPoint.getSignature().getName() + ". Args :"
				+ Arrays.toString(joinPoint.getArgs()));
	}

	@After(" service() && methodPointcut() ")
	public void afterServiceClassCall(JoinPoint joinPoint) {
		logger.info("UserId "+this.userName+" After Service method call >>> "
				+ joinPoint.getTarget().getClass().getName() + "."
				+ joinPoint.getSignature().getName() + ". Args :"
				+ Arrays.toString(joinPoint.getArgs()));
	}

	@After("dAO() && methodPointcut()")
	public void afterDAOClassMethodCall(JoinPoint joinPoint) {
		logger.info("UserId "+this.userName+" After execution of DAO method >>>: "
				+ joinPoint.getTarget().getClass().getName() + "."
				+ joinPoint.getSignature().getName() + ". Args :"
				+ Arrays.toString(joinPoint.getArgs()));
	}

	@Before("dAO() && methodPointcut()")
	public void beforeDAOClassMethodCall(JoinPoint joinPoint) {
		logger.info("UserId "+this.userName+" Before execution of DAO method >>>: "
				+ joinPoint.getTarget().getClass().getName() + "."
				+ joinPoint.getSignature().getName() + ". Args :"
				+ Arrays.toString(joinPoint.getArgs()));
	}

	@After("helper() && methodPointcut()")
	public void afterHelperClassMethodCall(JoinPoint joinPoint) {
		logger.info("UserId "+this.userName+" After execution of Helper method >>>: "
				+ joinPoint.getTarget().getClass().getName() + "."
				+ joinPoint.getSignature().getName() + ". Args :"
				+ Arrays.toString(joinPoint.getArgs()));
	}

	@Before("helper() && methodPointcut()")
	public void beforeHelperClassMethodCall(JoinPoint joinPoint) {
		logger.info("UserId "+this.userName+" Before execution of Helper method >>>: "
				+ joinPoint.getTarget().getClass().getName() + "."
				+ joinPoint.getSignature().getName() + ". Args :"
				+ Arrays.toString(joinPoint.getArgs()));
	}

	@AfterReturning(pointcut = "controllerBean() && methodPointcut()", returning = "result")
	public void afterReturning(JoinPoint joinPoint, Object result) {
		logger.info("UserId "+this.userName+" After Returning >>>: "
				+ joinPoint.getTarget().getClass().getName() + "."
				+ joinPoint.getSignature().getName() + " result is: " + result);
	}

	/*@AfterThrowing(pointcut = "(controllerBean() ) && methodPointcut() ", throwing = "error")
	public void afterthrowingException(JoinPoint joinPoint, Throwable error) {

			String environment = HMMUtils.getEnvironment();
			logger.error("EMA " + environment + " UserId "+ this.userName + " Exception Occured in :"
					+ joinPoint.getTarget().getClass().getName() + "-"
					+ joinPoint.getSignature().getName() + " Exception :",
					error);
	}
*/
	
	@AfterThrowing(pointcut = "(controllerBean() ) ", throwing = "error")
	public void afterthrowingException(JoinPoint joinPoint, Throwable error) {

		Environment environment = CommonUtils.getEnvironment();
		String env = environment.getProperty(LmsConstants.UPRR_IMPLEMENTATION_ENVIRONMENT);
	    logger.error("EMA " + env + " UserId "+ this.userName + " Exception Occured in :"
		    + joinPoint.getTarget().getClass().getName() + "-"
		    + joinPoint.getSignature().getName() + " Exception :",
		    error);
	}
	
}
