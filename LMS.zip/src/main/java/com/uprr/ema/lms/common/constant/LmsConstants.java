package com.uprr.ema.lms.common.constant;

public class LmsConstants {
	// Environment and URL related
    public static final String UP_ENV = "uprr.implementation.environment";
    public static final String WIN_ENV = "win";
    public static String LOCAL_ENV = "local";
    public static  String DEV_ENV = "dev";
    public static String TEST_ENV = "test";
    public static  String PROD_ENV = "prod";
    public static  String UPRR_ENV_CONSTANT = "uprr.implementation.environment";
    public static  String LOCAL_HOST_NAME = "http://localhost:8080";
    public static  String DEV_HOST_NAME = "http://xdev.home.www.uprr.com";
    public static  String TEST_HOST_NAME = "http://xtest.home.www.uprr.com";
    public static  String PROD_HOST_NAME = "http://home.www.uprr.com";
	public static final String UPRR_IMPLEMENTATION_ENVIRONMENT = "uprr.implementation.environment";
	public static final String PROD_ENVIRONMENT = "prod";
	public static final String TEST_ENVIRONMENT = "test";
	public static final String DEV_ENVIRONMENT = "dev";
	public static final String WIN_ENVIRONMENT = "win";

	public static final String USER_SESSION_TOKEN = "SMSESSION";
	public static final String SMUSER_HEADER_NAME = "SMUSER";
	public static final String HTML_CONTENT_TYPE = "text/html";
	
    public static final String  EMA_FROM_MAIL_ADDRESS = "EMA";
    public static final String  BREAK_LINE = "<br />";
	public static final int  THREE = 3;
	 
    public static final String  PDF_CONTENT_TYPE = "application/x-pdf";
	public static final String EMA_RPT_FILE_NAME = "EMATestReport";
	public static final String TO_ADDRESS_PRD = "EMA_SITEREM_TECH_SUPPORT@up.com";
	
	
	//Excel sheet Formulas
	
	 public static final String  LIABILITY_ESTIMATE = "IF($D19=\"NPV\",(NPV($D$6,$T19:$AI19)),(SUM($T19:$AI19)))*$E19";
	 public static final String  QUARTERLY_LIABILTY_CHANGE = "(C15-AQ15)+(AS15-AR15)*E15";
	 public static final String  CHANGE_CURRENT_YEAR_PLAN = "P18-Q18";
	 public static final String  CURRENT_YEAR_REMAINING_LIABILITY = "P19-S19";
	 
	
}
