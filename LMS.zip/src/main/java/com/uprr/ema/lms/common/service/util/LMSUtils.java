package com.uprr.ema.lms.common.service.util;

import java.io.StringReader;
import java.io.StringWriter;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.ValidationEvent;
import javax.xml.bind.ValidationEventHandler;
import javax.xml.transform.stream.StreamSource;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.uprr.ema.lms.common.enums.ActionInputType;
import com.uprr.ema.lms.common.enums.RoleType;
import com.uprr.ema.lms.common.vb.UserWebVB;
import com.uprr.ema.lms.exception.LmsException;
import com.uprr.ema.lms.liabilityProject.dto.ProjectDTO;
import com.uprr.ema.lms.searchproject.vb.ProjectSearchCriteriaVB;
import com.uprr.ema.lms.searchproject.vb.SearchCriteriaResponse;

/**
 * This is the utility class which contains utility methods which can be used.
 * 
 * @author xprk208
 *
 */
public class LMSUtils {

	public static final String LOCAL_URL_HEAD = "http://localhost:9000/index.html#";
	public static final String DEV_URL_HEAD = "http://xdev.home.www.uprr.com/ema/secure/lms/index.html#";
	public static final String TEST_URL_HEAD = "http://xtest.home.www.uprr.com/ema/secure/lms/index.html#";
	public static final String PROD_URL_HEAD = "http://home.www.uprr.com/ema/secure/lms/index.html#";
	private static Log log = LogFactory.getLog(LMSUtils.class);

	public static final String APPROVER_MAILS = "XPRK803";
	//public static final String SAP_TO_MAIL = "APAV159";
	public static final String SAP_TO_MAIL = "xprk803";
	
	
	public static final String LMS_MAIL = "LMS";
	
	 //  private Map<Set<StyleAttribute>, CellStyle> styleBank = new HashMap<Set<StyleAttribute>, CellStyle>();
	public static boolean isLocalEnvironment() {

		LogFactory.getLog(LMSUtils.class);

		return StringUtils.endsWithIgnoreCase("win", getEnvironment());
	}
	/*This method is written to check the collection is not Empty*/
	public static <T> boolean isNotEmpty(Collection<T> collection) {
		return collection != null && !collection.isEmpty();
	}
	
	/*This method is written to check the collection is Empty*/
	public static <T> boolean isEmpty(Collection<T> collection) {
		return collection == null || collection.isEmpty();
	}
	/** This method is used to get the environment */
	public static String getEnvironment() {
		return System.getProperty("uprr.implementation.environment");
	}
	
	public static boolean isNotNull(final Object object) {
		return !LMSUtils.isNull(object);
	}

	public static boolean isNull(final Object object) {
		return null == object;
	}
	public static String  getURL(){
		if (StringUtils.equalsIgnoreCase("test", getEnvironment())) {
			return TEST_URL_HEAD;
		}
		if (StringUtils.equalsIgnoreCase("prod", getEnvironment())) {
			return PROD_URL_HEAD;
		}
		if(StringUtils.equalsIgnoreCase("dev", getEnvironment())){
			return DEV_URL_HEAD;
		}
			return LOCAL_URL_HEAD;
	}
	
	public static String getPageURL(ProjectDTO projectDTO){
		StringBuilder s = new StringBuilder();
		s.append(getURL());
		s.append("/");
		s.append(ActionInputType.getPageByCode(projectDTO.getInputFrom()));
		s.append("/");
		return s.toString();
	}
	public static <T> SearchCriteriaResponse<T> preparePaginationSearchCriteriaResponse(
			final ProjectSearchCriteriaVB paginationVB, final int totalCount, final List<T> searchResults) {
		final SearchCriteriaResponse<T> resultVO = new SearchCriteriaResponse<>();
		resultVO.setStartIndex(paginationVB.getStartIndex());
		resultVO.setEndIndex(paginationVB.getEndIndex());
		resultVO.setRecordsCount(totalCount);
		resultVO.setCurrentPage(paginationVB.getCurrentPage());
		resultVO.setTotalPages((int) totalCount / paginationVB.getRecordsPerPage());
		resultVO.setRecordsPerPage(paginationVB.getRecordsPerPage());
		resultVO.setSearchDataList(searchResults);
		resultVO.setOrderByColumn(paginationVB.getOrderByColumn());
		resultVO.setSortingType(paginationVB.getSortingType());
		return resultVO;
	}
	
	
	/**
     * This method returns the User's Role
     * @param webRequest
     */
    public static  UserWebVB getUserRole(HttpServletRequest servletRequestObj,UserWebVB user) {
	//HttpServletRequest servletRequestObj = (HttpServletRequest) webRequest.getNativeRequest();
	//logger.info("getUserRole ::");

	//final Principal userPrincipal = servletRequestObj.getUserPrincipal();
	//GenericPrincipal genericPrincipal = (GenericPrincipal) userPrincipal;
	//logger.info("Pricipal Name ::"+userPrincipal.getName());;

	ArrayList<String> roleList = new ArrayList<String>(5);
	List<String> lDapRolesLst = Arrays.asList(RoleType.getRoles());
	for (String lDapRoleName : lDapRolesLst) {
	   // logger.info("Roles to be identified ::"+lDapRoleName);
	    if (servletRequestObj.isUserInRole(lDapRoleName)){
		if(RoleType.isAdmin(lDapRoleName)) {
		    user.setAdmin(true);	
		    roleList.add(RoleType.ADMIN.getName());
		} 
		if(RoleType.isManager(lDapRoleName)) {
		    user.setManager(true); 
		    roleList.add(RoleType.MANAGER.getName());
		}
		if(RoleType.isApprover(lDapRoleName)) {
		    user.setApprover(true); 
		    roleList.add(RoleType.APPROVER.getName());
		}
		if(RoleType.isLegal(lDapRoleName)) {
		    user.setLegal(true); 
		    roleList.add(RoleType.LEGAL.getName());
		}
		
		// logger.info("Valid user object::"+user);
	    }
	}	
	if(LMSUtils.isNotEmpty(roleList)){
		user.setUnAuthorized(false);
	}
	else{
		user.setUnAuthorized(true);
	}
	// logger.info("user object after roles set::"+user);
	return  user;
    }
    
    /**
	 * This method is to get the priority role from single/multiple role is
	 * assigned to user
	 * 
	 * @param ArrayList
	 * @return String
	 * @throws Exception
	 */
	public static String getPriorityRole(ArrayList<String> userRoleList) {

		HashMap<String, Integer> rolePriority = new HashMap<String, Integer>(5);
		rolePriority.put(RoleType.ADMIN.getName(), RoleType.ADMIN.getPriority());
		rolePriority.put(RoleType.MANAGER.getName(), RoleType.MANAGER.getPriority());
		rolePriority.put(RoleType.APPROVER.getName(), RoleType.APPROVER.getPriority());
		rolePriority.put(RoleType.LEGAL.getName(), RoleType.LEGAL.getPriority());
		int priority = 0;
		String priorityRole = "";
		if (userRoleList != null) {
			for (String role : userRoleList) {
				if (rolePriority.get(role) < priority) {
					priority = rolePriority.get(role);
					priorityRole = role;
				} else {
					if (priority <= 0) {
						priority = rolePriority.get(role);
						priorityRole = role;
					}
				}
			}
		}
		return priorityRole;
	}
	
	
	
	
	
	public static String[] getActionCodes(String inputFrom, String currentAction,
		String currentActionType){
	    String[] nextActionCodes = new String[3];
	   // String currentActionCodes = null;
	   /* if(StringUtils.isNotBlank(currentAction) && StringUtils.isNotBlank(currentActionType)){
		currentActionCodes = currentAction.concat(currentActionType);
	    }*/

	    if(inputFrom.equals(ActionInputType.PROJECT_SUBMITTED.getCode())){
		nextActionCodes[0] = "P";
		nextActionCodes[1] = "S";
	    }else if(inputFrom.equals(ActionInputType.PROJECT_APPROVED.getCode())){
		nextActionCodes[0] = "P";
		nextActionCodes[1] = "A";
	    }  else if(inputFrom.equals(ActionInputType.PROJECT_DISAPPROVED.getCode())){
		nextActionCodes[0] = "P";
		nextActionCodes[1] = "U";
	    } else if(inputFrom.equals(ActionInputType.CHANGE_SUBMITTED.getCode())){
		nextActionCodes[0] = "C";
		nextActionCodes[1] = "S";
	    }else if(inputFrom.equals(ActionInputType.CHANGE_APPROVED.getCode())){
		nextActionCodes[0]  = "C";
		nextActionCodes[1]  = "A";
	    }
	    else if(inputFrom.equals(ActionInputType.CHANGE_DISAPPROVED.getCode())){
		nextActionCodes[0]  = "C";
		nextActionCodes[1]  = "U";
	    }
	    
	    return nextActionCodes;
	}

	
	public static void setUserDetails(Object obj, String user){
	    if(obj instanceof ProjectDTO){
		ProjectDTO ProjectDTO = (ProjectDTO) obj;
		ProjectDTO.setCrtdUser(user);
		ProjectDTO.setLastUptdUser(user);
	    }
	}
	
	public static String getTesNoValues(String inputFlag){
	    if("Y".equalsIgnoreCase(inputFlag)){
		return "Yes";
	    }else if("N".equalsIgnoreCase(inputFlag)){
		return "No";
	    }else{
		return "";
	    }
	}
	
	public static String getCostAppendedToTwoDecimal(Double costObj){
	    String resultCost = null;
	    if(costObj!=null && costObj.doubleValue() >=0){
		DecimalFormat df = new DecimalFormat("#,###,##0.00");
		resultCost= df.format(costObj.doubleValue());
	    }
	    return resultCost;
	    
	}
	
	
	
	/**
	 * This method is used to marshal the given object
	 * 
	 * @param Object
	 * @param Class
	 * @return String
	 */
	@SuppressWarnings("rawtypes")
	public static String marshal(Object requestData, Class classType) {
		String requestXML = null;
		try {
			JAXBContext jc = JAXBContext.newInstance(classType);
			Marshaller marshaller = jc.createMarshaller();
			marshaller.setEventHandler(new ValidationEventHandler() {
				public boolean handleEvent(ValidationEvent event) {
					log.error("RunTimeException inside marshal, marshallRequest Message:- " + event.getMessage());
					throw new LmsException(event.getMessage(), event.getLinkedException());
				}
			});
			StringWriter stringWriter = new StringWriter();
			marshaller.marshal(requestData, stringWriter);
			requestXML = stringWriter.toString().substring(55);
		} catch (Exception e) {
			log.error("Exception while parsing the Object",e);
		    throw new LmsException("Exception while parsing the Object",e);
		}
		return requestXML;
	}

	/**
	 * This method is used to unmarshal the given data
	 * 
	 * @param String
	 * @param Class
	 * @return Object
	 */
	@SuppressWarnings("rawtypes")
	public static Object unmarshal(String replyData, Class classType) {
		Object obj = null;
		try {
			JAXBContext jc = JAXBContext.newInstance(classType);
			Unmarshaller unmarshaller = jc.createUnmarshaller();
			unmarshaller.setEventHandler(new ValidationEventHandler() {
				public boolean handleEvent(ValidationEvent event) {
					log.error("RunTimeException inside Unmarshaller, Reply Message:- " + event.getMessage());
					throw new LmsException(event.getMessage(), event.getLinkedException());
				}
			});
			obj = unmarshaller.unmarshal(new StreamSource(new StringReader(replyData)));
		} catch (Exception e) {
			throw new LmsException("Exception while unmarshaling the Object",e);
		}
		return obj;
	}
	
}
