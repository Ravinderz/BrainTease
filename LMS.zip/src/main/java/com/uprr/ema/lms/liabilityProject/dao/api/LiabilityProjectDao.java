package com.uprr.ema.lms.liabilityProject.dao.api;

import java.util.List;
import java.util.Set;

import com.uprr.ema.lms.liabilityProject.dto.AccountCostDTO;
import com.uprr.ema.lms.liabilityProject.dto.DisapproveProjDTO;
import com.uprr.ema.lms.liabilityProject.dto.ProjectCostDTO;
import com.uprr.ema.lms.liabilityProject.dto.ProjectDTO;

public interface LiabilityProjectDao {
	
	
	/**
     * To save project detail ID.
     * @param ProjectDTO
     * @return long
     * @
     */
	
	public long saveProjId(ProjectDTO projectDTO);

	/**
     * To save all the project detail values to database.
     * @param ProjectDTO
     * @return long
     * @
     */
	public long saveProjectDetails(ProjectDTO projectDTO);
	/**
     * To save the project cost detail values to database.
     * @param ProjectCostDTO
     * @return long
     * @
     */
	public long saveProjectCostDetails(ProjectCostDTO projectDTO);
	/**
     * To update the project details values to database.
     * @param ProjectCostDTO
     * @return long
     * @
     */
	
	/*public long saveApproval(ProjectStatusDetailsDTO projectStatusDTO);*/
	
	public void updateProjectDetails(ProjectDTO projectDTO);
	
	/**
	 * Update approved project to history. Either Project approved or Change approved
	 * @param projectDTO
	 */
	public void updateApprovedProjToHistory(ProjectDTO projectDTO) ;
	/**
     * To update the project cost details values to database.
     * @param ProjectCostDTO
     * @return long
     * @
     */
	public void updateProjectCostDetails(ProjectCostDTO projectDTO);
	/**
     * To get the project details from the database based on project id
     * @param ProjectDTO
     * @return long
     * @
     */
	public ProjectDTO getApprovedProjectDetails(long projectID);
	/**
     * To get the project details from the database based on project id
     * @param ProjectCostDTO
     * @return long
     * @
     */
	public List<ProjectCostDTO> getProjectCostDetails(long projectID);
	
	public List<ProjectCostDTO> getCosts(long projectID,String actionType,String action);
		
	public List<ProjectCostDTO> getCostsByprojIdAndCostType(long projectID, long costTypeId);
	
	public List<ProjectCostDTO> getProjSubmitCosts(long projectID);
	
	public List<ProjectCostDTO> getProjApprovedCosts(long projectID);
	
	public List<ProjectCostDTO> getProjNoneApprovedCosts(long projectID) ;
	
	public long saveChangeReason(ProjectDTO projectDTO);
	
	public void updateChangeReason(ProjectDTO projectDTO);
	
	public long saveDisaprvProj(DisapproveProjDTO disapproveProjDTO);
	
	public String getLastSubmittedProjUser(long projID);
	
	public String getLastChangeSubmittedProjUser(long projID) ;
	
	
	public String getLastChangeSubmittedCostUser(long projID);
	
	public List<ProjectDTO> getPendignApprovalProjects();
	
	public List<ProjectDTO> getDisApprovedProjects();
	
	public ProjectDTO getProjectByProjId(long projectID) ;
	
	public List<AccountCostDTO> getAccountUpdate() ;
	
	public List<AccountCostDTO> getOracleAccountUpdate();
	
	//public List<AccountCostDTO> getSAPAccountUpdate(Set<String> networkNumberSet) ;
	
	public boolean saveAccountUpdates(List<AccountCostDTO> accountUpdateList);
	
}
