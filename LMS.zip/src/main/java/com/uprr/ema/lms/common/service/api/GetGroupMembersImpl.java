package com.uprr.ema.lms.common.service.api;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uprr.ema.lms.common.service.util.LMSUtils;
import com.uprr.ema.lms.common.service.xmf.IXMFClientService;
import com.uprr.ema.lms.exception.LmsException;
import com.uprr.ema.lms.xmf.groupmemebers.GetGroupMembersReply;
import com.uprr.ema.lms.xmf.groupmemebers.GetGroupMembersRequest;
import com.uprr.ema.lms.xmf.groupmemebers.GroupMembershipListType;
import com.uprr.ema.lms.xmf.groupmemebers.GroupMembershipType;
import com.uprr.ema.lms.xmf.groupmemebers.GroupNameListType;
import com.uprr.ema.lms.xmf.groupmemebers.UserListType;
import com.uprr.ema.lms.xmf.groupmemebers.UserType;


@Service("groupMembers")
public class GetGroupMembersImpl implements IGetGroupMembers {
	@Autowired
	private IXMFClientService xmfDtlsService;
	@Override
	public List<String> getGroupMembers(String group) {
		List<String> idList=new ArrayList<String>();;
		GetGroupMembersRequest req = new GetGroupMembersRequest();
		req.setApplicationId("UPAPPS");
		GroupNameListType type= new GroupNameListType();
		List<String> groupList= type.getGroupName();
		groupList.add(group);
		req.setGroupList(type);
		String xmlRequest = LMSUtils.marshal(req,GetGroupMembersRequest.class);
		String xmfReplyMessage = xmfDtlsService.getXMFDataByServiceDtls(IXMFClientService.UNSECURE_TYPE, GET_GROUP_MEMEBERS_SERVICE_NAME,xmlRequest);
		GetGroupMembersReply reply =parseGetEmployeeReply(xmfReplyMessage);
		if(reply!=null){
			GroupMembershipListType memberList= reply.getGroupList();
			if(LMSUtils.isNotEmpty(memberList.getGroup())){
				final List<GroupMembershipType> memberShipeTest=memberList.getGroup();
				
				for (GroupMembershipType groupMembershipType : memberShipeTest) {
					UserListType userType=groupMembershipType.getUserList();
					if(userType!=null){
						List<UserType> users=userType.getUser();
						if(LMSUtils.isNotEmpty(users)){
							for (UserType user : users) {
								idList.add(user.getUserId());
							}
						}
					}
				}
			}
		}
		
		return idList;
	}
	/**
	 * @param xmlString
	 * @return 
	 */
	private GetGroupMembersReply parseGetEmployeeReply(String xmlString) throws LmsException{
		GetGroupMembersReply	replyObj = (GetGroupMembersReply)LMSUtils.unmarshal(xmlString, GetGroupMembersReply.class);
		return replyObj;

	}

}
