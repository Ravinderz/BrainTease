package com.uprr.ema.lms.common.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;

import com.uprr.ema.lms.exception.LmsException;

public class WebDateUtils {

	public static String DEFAULT_DISPLAY_FORMAT = "MM/dd/yyyy";

   /**
    * get date in specific format
    * 
    * @param date
    * @return
    */
   public static String getDisplayformat(Date date) {
      if (date == null){
         return null;
      }
      SimpleDateFormat format = new SimpleDateFormat(DEFAULT_DISPLAY_FORMAT);
      return format.format(date);
   }

   /**
    * get date in MM/dd/yyyy hh:mm a format
    * 
    * @param date
    * @return
    */
   public static String getDateInMMddyyyyhhmma(Date date) {
      if (date == null){
         return null;
      }
      SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss a");
      return format.format(date);
   }

   /**
    * This method will return the string date in MM-dd-yyyy hh:mm:ss
    * format
    * @param date
    * @return
    */
   
   public static Date getDateMMddyyyy(String date) {
	      try {
	         SimpleDateFormat format = new SimpleDateFormat("MM-dd-yyyy hh:mm:ss");
	         return format.parse(date);
	      } catch (ParseException pe) {
	         return null;
	      }
	   }
   
   /**
    * 
    * @param date
    * should be in yyyy-MM-dd-hh:mm format.
    * @return
    * @throws ParseException
    */
   public static Date getDate(String date) {
      try {
         SimpleDateFormat format = new SimpleDateFormat(DEFAULT_DISPLAY_FORMAT);
         return format.parse(date);
      } catch (ParseException pe) {
         return null;
      }
   }

   

   /**
    * This method is to get the difference of two dates
    * @param date1
    * @param date2
    * @return
    * @throws EMASITEREMException
    */
   public static long getDateDiff(Date date1, Date date2) {
      long diff = 0;
      try {
         Calendar c1 = new GregorianCalendar();
         c1.setTime(date1);
         Calendar c2 = new GregorianCalendar();
         c2.setTime(date2);

         diff = (c1.getTime().getTime() - c2.getTime().getTime()) ;
      } catch (Exception e) {
         throw new LmsException(e);
      }
      return diff;
   }

  
  
   
   public static String getDateInMMDDYYYY(Date date){
       DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
       String text = dateFormat.format(date);
       return text;
   }
  
   public static Date getDateFromddMMYYY(String inputDate) {
       DateFormat formatter;
       Date date;
       try{
       formatter = new SimpleDateFormat("MM/dd/yyyy");
        date = (Date) formatter.parse(inputDate);
       }catch(Exception e){
    	   throw new LmsException("Exception Occured while parsing Date");
       }
       return date;
   }
   
   /**
    * 
    * @param date
    * should be in yyyy-MM-dd-hh:mm format.
    * @return
    * @throws ParseException
    */
   public static String getCurrentDate() {
      try {
    	  SimpleDateFormat dateformat = new SimpleDateFormat(DEFAULT_DISPLAY_FORMAT);
    	  Date dateobj = new Date();
         return dateformat.format(dateobj);
      } catch (Exception pe) {
         return null;
      }
   }
    
   
   /**
    * Takes date as string  format "MM/dd/yyyy" and converts to String format "yyyyMMdd"
    * @param dateAsMMddyyyy
    * @return
    * @throws ParseException
    */
   public static String convertDateToyyyyMMddFormat(String dateAsMMddyyyy) {
	   String dateInString="";
	   try{
       DateFormat fromFormat = new SimpleDateFormat("MM/dd/yyyy");
       fromFormat.setLenient(false);
       DateFormat toFormat = new SimpleDateFormat("yyyyMMdd");
       toFormat.setLenient(false);
       Date date = fromFormat.parse(dateAsMMddyyyy);
       dateInString= toFormat.format(date);
	   }catch(Exception e){
		   throw new LmsException();
	   }
	   return dateInString;
   }
   
   	/**
	    * Takes date as string  format "Month" - "Year"  after calculating first day last day converts to String format "MMMMddyyyy"
	    * @param dateAsMMMMddyyyy
	    * @return
	    * @throws ParseException
	    */
		public static String[] getFirstLastDayInMMMMddyyyyFormat(String month, String year) {
			try {
				Date date1 = new SimpleDateFormat("MMMM", Locale.US).parse(month);
				Calendar cal = Calendar.getInstance();
				cal.setTime(date1);

				Calendar calendar = GregorianCalendar.getInstance();
				calendar.set(Integer.valueOf(year), cal.get(Calendar.MONTH), 1);
				Date sDate = calendar.getTime();
				Calendar calplusOneDay = Calendar.getInstance();
				calplusOneDay = calendar;
				calplusOneDay.add(Calendar.MONTH, 1);
				Date plusOneDate = calplusOneDay.getTime();

				calendar.add(Calendar.MONTH, 1);
				calendar.set(Calendar.DAY_OF_MONTH, 1);
				calendar.add(Calendar.DATE, -1);

				Date lastDayOfMonth = calendar.getTime();

				DateFormat sdf = new SimpleDateFormat("MMMM dd, yyyy");
				String[] stringArray = { sdf.format(sDate), sdf.format(lastDayOfMonth),sdf.format(plusOneDate)};
				return stringArray;
			} catch (Exception e) {
				throw new LmsException();
			}
		}
		
		/**
		 * @param month
		 * @param year
		 * @return
		 */
		public static String[] getFirstLastDayOfQutrInMMMMddyyyyFormat(String month, String year) {
			try {
				Date date1 = new SimpleDateFormat("MMMM", Locale.US).parse(month);
				Calendar cal = Calendar.getInstance();
				cal.setTime(date1);
				Calendar calendar = GregorianCalendar.getInstance();
				calendar.set(Integer.valueOf(year), cal.get(Calendar.MONTH), 1);
				Date sDate = calendar.getTime();
				DateFormat sdf = new SimpleDateFormat("MMMM dd, yyyy");
				System.out.println("FirstDayOfQuarter =" + getFirstDayOfQuarter(sDate) + " LastDayOfQuarter ="
						+ getLastDayOfQuarter(sDate));
				System.out.println("FirstDayOfQuarter =" + sdf.format(getFirstDayOfQuarter(sDate)) + " LastDayOfQuarter ="
						+ sdf.format(getLastDayOfQuarter(sDate)));
				String[] stringArray = { sdf.format(getFirstDayOfQuarter(sDate)), sdf.format(getLastDayOfQuarter(sDate))};
				return stringArray;
			} catch (Exception e) {
				throw new LmsException();
			}
		}

		/**
		 * @param date
		 * @return
		 */
		private static Date getFirstDayOfQuarter(Date date) {
		    Calendar cal = Calendar.getInstance();
		    cal.setTime(date);
		    cal.set(Calendar.MONTH, cal.get(Calendar.MONTH)/3 * 3);
		    cal.set(Calendar.DAY_OF_MONTH, 1);
		    return cal.getTime();
		}

		/**
		 * @param date
		 * @return
		 */
		private static Date getLastDayOfQuarter(Date date) {
		    Calendar cal = Calendar.getInstance();
		    cal.setTime(date);
		    cal.set(Calendar.MONTH, cal.get(Calendar.MONTH)/3 * 3 + 2);
		    cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
		    return cal.getTime();
		}
		
		/**
		 * @param date1
		 * @param date2
		 * @return
		 */
		public static List<String> getMonthYearLstForQuarter(String date1, String date2) {
			DateFormat formater = new SimpleDateFormat("MMMM-yyyy");
			Calendar beginCalendar = Calendar.getInstance();
			Calendar finishCalendar = Calendar.getInstance();
			try {
				beginCalendar.setTime(formater.parse(date1));
				finishCalendar.setTime(formater.parse(date2));

				List<String> Months = new ArrayList<String>();
				while (beginCalendar.before(finishCalendar)) {
					String date = formater.format(beginCalendar.getTime()).toUpperCase();
					beginCalendar.add(Calendar.MONTH, 1);
					Months.add(date);
				}
				return Months;
			} catch (ParseException e) {
				e.printStackTrace();
			}
			return null;
		}
		
		public static Date getLastDayOfMonthFormat(String month, String year) {
			try {
				Date date1 = new SimpleDateFormat("MMMM", Locale.US).parse(month);
				Calendar cal = Calendar.getInstance();
				cal.setTime(date1);
				Calendar calendar = GregorianCalendar.getInstance();
				calendar.set(Integer.valueOf(year), cal.get(Calendar.MONTH), 1);
				calendar.add(Calendar.MONTH, 1);
				calendar.set(Calendar.DAY_OF_MONTH, 1);
				calendar.add(Calendar.DATE, -1);

				Date lastDayOfMonth = calendar.getTime();
				DateFormat sdf = new SimpleDateFormat("MMMM dd, yyyy");
				return lastDayOfMonth;
			} catch (Exception e) {
				e.printStackTrace();
			}
			return null;
		}
		
		public static List<String> getAllMonthsOfQuarterInMMMYYYY(String month, String year) {
			Date date1;
			try {
				date1 = new SimpleDateFormat("MMMM", Locale.US).parse(month);
			
			Calendar cal = Calendar.getInstance();
			cal.setTime(date1);
			Calendar calendar = GregorianCalendar.getInstance();
			calendar.set(Integer.valueOf(year), cal.get(Calendar.MONTH), 1);
			Date sDate = calendar.getTime();
			
			DateFormat sdf1 = new SimpleDateFormat("MMM-yyyy");
			
			return getMonthYearLstForQuarter(sdf1.format(getFirstDayOfQuarter(sDate)).toUpperCase(),sdf1.format(getLastDayOfMonthFormat(month,year)).toUpperCase());
			} catch (ParseException e) {
				e.printStackTrace();
			}
			return null;
		}
		
		public static String getMonthYearInYYYYMMMFormat(String month, String year) {
			try {
				Date date1 = new SimpleDateFormat("MMMM", Locale.US).parse(month);
				Calendar cal = Calendar.getInstance();
				cal.setTime(date1);
				cal.set(Integer.parseInt(year), cal.get(Calendar.MONTH), 1);
				Date selectedMonthYear = cal.getTime();
				DateFormat sdf1 = new SimpleDateFormat("yyyy0MM");
				System.out.println("Today            : " + sdf1.format(selectedMonthYear));
				return sdf1.format(selectedMonthYear);
			} catch (Exception e) {
				e.printStackTrace();
			}
			return null;
		}
		
		
}
