package com.uprr.ema.lms.common.service.util;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;

import com.uprr.ema.lms.common.enums.StyleAttribute;
import com.uprr.ema.lms.exception.LmsException;
import com.uprr.ema.lms.reports.dto.BusinessPrepPlanDTO;
import com.uprr.ema.lms.reports.dto.MonthlySpendDTO;
import com.uprr.ema.lms.reports.dto.SiteSourceDTO;

public class ExcelUtils {
	/**
     * Style attributes for row.
     */
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ExcelUtils.class);
	
    private static Set<StyleAttribute> rowStyleAttributes = new HashSet<StyleAttribute>();
    private static Map<Set<StyleAttribute>, CellStyle> styleBank = new HashMap<Set<StyleAttribute>, CellStyle>();
	
	public static byte[] generateExcelAttachment(final String workSheetName, final List<String[]> excelContentList) {
		final ByteArrayOutputStream bos = new ByteArrayOutputStream();
		Workbook workbook = null;
		try {
			workbook = new HSSFWorkbook();
			final Sheet sheet = workbook.createSheet(workSheetName);

			if (LMSUtils.isNotEmpty(excelContentList)) {
				final String[] excelHeader = excelContentList.get(0);
				for(String header : excelHeader){
					System.out.println(header);	
				}
				final int columnSize = excelHeader.length;
				XlsxBuilder xlsBuilder =	new XlsxBuilder().startSheet(workSheetName);
				createHeadersRow(xlsBuilder, excelHeader,"Generic");

				int rowCount = 0;
				for (final String[] contents : excelContentList) {
					if (rowCount > 0) {
						populateExcelData(sheet, contents, rowCount);
					}
					rowCount++;
				}

				for (int j = 0; j < columnSize; j++) {
					sheet.autoSizeColumn(j);
				}
			}
			workbook.write(bos);
		} catch (Exception e) {
			throw new LmsException(e);
		} finally {
			if (LMSUtils.isNotNull(workbook)) {
				try {
					workbook.close();
				} catch (IOException e) {
					throw new LmsException("Exception Occured while closing the stream...", e);
				}
			}
		}
		System.out.println("inside generateExcelAttachment");
		return bos.toByteArray();
	}
	public static Sheet generateExcel(final String workSheetName, final List<String[]> excelContentList) {
		XlsxBuilder xlsBuilder =	new XlsxBuilder().startBlankSheet(workSheetName); 
		try {
			
			if (LMSUtils.isNotEmpty(excelContentList)) {
				final String[] excelHeader = excelContentList.get(0);
				final int columnSize = excelHeader.length;
				createHeadersRow(xlsBuilder,excelHeader,"Generic");
				
				int rowCount = 0;
				for (final String[] contents : excelContentList) {
					if (rowCount > 0) {
						populatelData(xlsBuilder, contents, rowCount);
					}
					rowCount++;
				}
				
				
				 CellRangeAddress ca = new CellRangeAddress(0, excelContentList.size(),
						    		xlsBuilder.getSheet().getRow(0).getFirstCellNum(),
						    		xlsBuilder.getSheet().getRow(0).getLastCellNum()-1);
				 xlsBuilder.getSheet().setAutoFilter(ca);
				 for (int j = 0; j < columnSize; j++) {
						xlsBuilder.getSheet().autoSizeColumn(j);
					}
			}
			
		} catch (Exception e) {
			throw new LmsException("Exception Occured while closing the stream...",e);
		} 
		
		return xlsBuilder.getSheet();
	}
	
	public static Sheet generateBusinessPrepPlanExcel(final String workSheetName, final List<String[]> headersList, List<BusinessPrepPlanDTO> resultList) {
		XlsxBuilder xlsBuilder =	new XlsxBuilder().startBlankSheet(workSheetName);
		try {
			
			if (LMSUtils.isNotEmpty(headersList)) {
				final String[] excelRecordHeader = headersList.get(0);
				final String[] excelHeader = headersList.get(1);
				final int columnSize = excelHeader.length;
				createRecordHeadersRow(xlsBuilder,excelRecordHeader);
				createHeadersRow(xlsBuilder,excelHeader,"BPPD");
				
				int rowCount = 0;
				for (final BusinessPrepPlanDTO bppDto : resultList) {
					if (rowCount >= 0) {
						populateBppdData(xlsBuilder, bppDto, rowCount);
					}
					rowCount++;
				}
				
				 for (int j = 0; j < columnSize; j++) {
						xlsBuilder.getSheet().autoSizeColumn(j);
					}
			}
			
		} catch (Exception e) {
			throw new LmsException("Exception Occured while closing the stream...",e);
		} 
		
		return xlsBuilder.getSheet();
	}
	
	public static Sheet generateSiteSourceExcel(final String workSheetName, final List<String[]> headersList, List<SiteSourceDTO> resultList) {
		XlsxBuilder xlsBuilder = new XlsxBuilder().startSheet(workSheetName);
		try {
			
			if (LMSUtils.isNotEmpty(headersList)) {
				final String[] excelRecordHeader = headersList.get(0);
				final int columnSize = excelRecordHeader.length; 
				createTopHeaderRow(xlsBuilder,excelRecordHeader);
				for(int i = 1; i < headersList.size();i++){
					if(i == headersList.size()-1){
						createMainHeadersRow(xlsBuilder,headersList.get(i),"SiteSource");
					}else if(i <= 3){
						createRightAlignHeadersRow(xlsBuilder,headersList.get(i),"SiteSource");	
					}else{
						createHeadersRow(xlsBuilder,headersList.get(i),"SiteSource");
					}
						
				}
				
				int rowCount = 0;
				for (final SiteSourceDTO dto : resultList) {
					if (rowCount >= 0) {
						populateSiteSourceData(xlsBuilder, dto, rowCount);
					}
					rowCount++;
				}
				
				/* for (int j = 0; j < columnSize; j++) {
						xlsBuilder.getSheet().autoSizeColumn(j);
					}*/
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			throw new LmsException("Exception Occured while closing the stream...",e);
		} 
		
		return xlsBuilder.getSheet();
	}
	
	public static Sheet generateMonthlySpendExcel(final String workSheetName, final List<String[]> headersList, List<MonthlySpendDTO> resultList) {
		XlsxBuilder xlsBuilder =	new XlsxBuilder().startBlankSheet(workSheetName);
		try {
			
			if (LMSUtils.isNotEmpty(headersList)) {
				
				final int columnSize = headersList.get(headersList.size()-1).length;
				for(int i = 0; i < headersList.size(); i++){
					if(i == headersList.size() - 1){
						createBoldHeaderRow(xlsBuilder,headersList.get(i),"Monthly Report");
					}else{
						createMonthlySpendHeadersRow(xlsBuilder,headersList.get(i),"Monthly Report");	
					}
						
				}
				
				
				int rowCount = 0;
				for (final MonthlySpendDTO dto : resultList) {
					if (rowCount >= 0) {
						populateMonthlySpendData(xlsBuilder, dto, rowCount);
					}
					rowCount++;
				}
				
				 for (int j = 0; j < columnSize; j++) {
						xlsBuilder.getSheet().autoSizeColumn(j);
					}
			}
			
		} catch (Exception e) {
			throw new LmsException("Exception Occured while closing the stream...",e);
		} 
		
		return xlsBuilder.getSheet();
	}
	
	
	private static  void createRecordHeadersRow(XlsxBuilder xlsBuilder, final String[] rowContent) {
		XlsxBuilder xlsBuilder1 =xlsBuilder.startRecordTitleRow();
		for (int i = 0; i < rowContent.length; i++) {
			xlsBuilder1 = xlsBuilder1.addReportHeaderTextColumn(rowContent[i],"BPPD");
		}
	} 
	
	private static  void createTopHeaderRow(XlsxBuilder xlsBuilder, final String[] rowContent) {
		XlsxBuilder xlsBuilder1 =xlsBuilder.startRow();
		for (int i = 0; i < rowContent.length; i++) {
			xlsBuilder1 = xlsBuilder1.addReportHeaderTextColumn(rowContent[i],"SiteSource");
		}
	}
	
	private static  void createMainHeadersRow(XlsxBuilder xlsBuilder, final String[] rowContent,String reportType) {
		XlsxBuilder xlsBuilder1 =xlsBuilder.startRow();
		for (int i = 0; i < rowContent.length; i++) {
			if(rowContent[i].contains(",")){
				for(String content : rowContent[i].split(",")){
					xlsBuilder1 = xlsBuilder1.addMainRowTextColumn(content);
				}
			}else{
				xlsBuilder1 = xlsBuilder1.addMainRowTextColumn(rowContent[i]);
			}
			
		}
	}
	
	private static  void createRightAlignHeadersRow(XlsxBuilder xlsBuilder, final String[] rowContent,String reportType) {
		XlsxBuilder xlsBuilder1 =xlsBuilder.startRow();
		boolean isLiabilityRow = false;
		if(rowContent[0].equalsIgnoreCase("Liability:")){
			isLiabilityRow = true;
		}
		for (int i = 0; i < rowContent.length; i++) {
			
			if(rowContent[i].contains("#")){
				for(String content : rowContent[i].split("#")){
					if(isLiabilityRow){
						xlsBuilder1 = xlsBuilder1.addTitleFormulaWithDoubleValueColumn(content,reportType,"ALIGN_RIGHT");
					}else{
						xlsBuilder1 = xlsBuilder1.addTitleFormulaColumn(content,reportType,"ALIGN_RIGHT");
					}
							
				}
			}else{
				if(rowContent[i].contains(",")){
					for(String content : rowContent[i].split(",")){
						xlsBuilder1 = xlsBuilder1.addRightAlignedTitleTextColumn(content,reportType);	
					}
				}else {
					xlsBuilder1 = xlsBuilder1.addRightAlignedTitleTextColumn(rowContent[i],reportType);	
				}
					
			}
		}
	}
	
	private static  void createMonthlySpendHeadersRow(XlsxBuilder xlsBuilder, final String[] rowContent,String reportType) {
		XlsxBuilder xlsBuilder1 =xlsBuilder.startRow();
		for (int i = 0; i < rowContent.length; i++) {
			if(rowContent[i].contains(",")){
				for(String content : rowContent[i].split(",")){
					xlsBuilder1 = xlsBuilder1.addSimpleHeaderColumn(content);	
				}
			}else {
				xlsBuilder1 = xlsBuilder1.addSimpleHeaderColumn(rowContent[i]);	
			}

		}
	}
	
	private static  void createBoldHeaderRow(XlsxBuilder xlsBuilder, final String[] rowContent,String reportType) {
		XlsxBuilder xlsBuilder1 =xlsBuilder.startRow();
		for (int i = 0; i < rowContent.length; i++) {
			if(rowContent[i].contains(",")){
				for(String content : rowContent[i].split(",")){
					xlsBuilder1 = xlsBuilder1.addSimpleBoldHeaderColumn(content);	
				}
			}else {
				xlsBuilder1 = xlsBuilder1.addSimpleBoldHeaderColumn(rowContent[i]);	
			}

		}
	}
	
	
	
	private static  void createHeadersRow(XlsxBuilder xlsBuilder, final String[] rowContent,String reportType) {
		XlsxBuilder xlsBuilder1 =xlsBuilder.startRow();
		int rowContentSize = 0;
		for (int i = 0; i < rowContent.length; i++) {
			if(rowContent[i].contains("#")){
				rowContentSize = rowContent[i].split("#").length;
				for(String content : rowContent[i].split("#")){
					if(!StringUtils.isEmpty(content)){
						if(rowContent[i].split("#").length == 1){
							xlsBuilder1 = xlsBuilder1.addTitleFormulaColumn(content,reportType,"ALIGN_LEFT");	
						}else{
							xlsBuilder1 = xlsBuilder1.addTitleFormulaColumn(content,reportType,"ALIGN_RIGHT");	
						}
						
					}
						
				}
			}else{
					if(rowContent[i].contains(",")){
						for(String content : rowContent[i].split(",")){
							xlsBuilder1 = xlsBuilder1.addTitleTextColumn(content,reportType);	
						}
					}else {
						xlsBuilder1 = xlsBuilder1.addTitleTextColumn(rowContent[i],reportType);	
					}	
					
			}
		}
	}
	
	private static   void populatelData(XlsxBuilder xlsBuilder, final String[] rowContent, int rowCount) {
		XlsxBuilder xlsBuilder1 = xlsBuilder.startRow();
		for (int j = 0; j < rowContent.length; j++) {
			xlsBuilder1 = xlsBuilder1.addTextLeftAlignedColumn(rowContent[j]);
		}
	}
	
	private static   void populateSiteSourceData(XlsxBuilder xlsBuilder,SiteSourceDTO dto, int rowCount) {
		XlsxBuilder xlsBuilder1 = xlsBuilder.startRow();
		xlsBuilder1 = xlsBuilder1.addTextLeftAlignedColumn(Integer.toString(rowCount+1));
		xlsBuilder1 = xlsBuilder1.addTextLeftAlignedColumn(dto.getProjName());
		xlsBuilder1 = xlsBuilder1.addTextLeftAlignedColumn(dto.getRailRoadCode());
		xlsBuilder1 = xlsBuilder1.addTextLeftAlignedColumn(dto.getProjSrcDesc());
		xlsBuilder1 = xlsBuilder1.addTextLeftAlignedColumn(dto.getState());
		xlsBuilder1 = xlsBuilder1.addTextLeftAlignedColumn(dto.getProjStartDate().split("-")[0]);
		if(dto.getProjClosedDate()!=null){
			xlsBuilder1 = xlsBuilder1.addTextLeftAlignedColumn(dto.getProjClosedDate().split("-")[0]);	
		}else{
			xlsBuilder1 = xlsBuilder1.addTextLeftAlignedColumn("Active");
		}
		for(String amount : dto.getSpendingPerYear()){
			if(Double.parseDouble(amount) == 0){
				xlsBuilder1 = xlsBuilder1.addGreyedOutColumn(amount);
			}else{
				xlsBuilder1 = xlsBuilder1.addDoubleColumn(Double.parseDouble(amount));
			}
		}
		LOGGER.info(dto.getTotalUpSpending());
		LOGGER.info(dto.getTotalProjectSpending());
		LOGGER.info(dto.getTotalCommittedCost());
		LOGGER.info(dto.getQuarterELC());
		LOGGER.info(dto.getTotalPreMergerSpending());
		xlsBuilder1 = xlsBuilder1.addFormulaWithDoubleColumn(dto.getTotalUpSpending());
		
		if(dto.getTotalPreMergerSpending() != null){
			xlsBuilder1 = xlsBuilder1.addDoubleColumn(Double.parseDouble(dto.getTotalPreMergerSpending()));	
		}else{
			xlsBuilder1 = xlsBuilder1.addDoubleColumn(Double.parseDouble("0"));
		}
		xlsBuilder1 = xlsBuilder1.addFormulaWithDoubleColumn(dto.getTotalProjectSpending());
		
		if(dto.getQuarterELC() != null){
			xlsBuilder1 = xlsBuilder1.addDoubleColumn(Double.parseDouble(dto.getQuarterELC()));	
		}else{
			xlsBuilder1 = xlsBuilder1.addDoubleColumn(Double.parseDouble("0"));
		}
		
		xlsBuilder1 = xlsBuilder1.addFormulaWithDoubleColumn(dto.getTotalCommittedCost());
		if(dto.getFifteenYrRule() != null){
			if(dto.getFifteenYrRule().equalsIgnoreCase("Y")){
				xlsBuilder1 = xlsBuilder1.addTextLeftAlignedColumn("x");		
			}
		}else{
			xlsBuilder1 = xlsBuilder1.addTextLeftAlignedColumn("");
		}
		
	}
	
	private static   void populateBppdData(XlsxBuilder xlsBuilder,BusinessPrepPlanDTO dto, int rowCount) {
		XlsxBuilder xlsBuilder1 = xlsBuilder.startRow();
		xlsBuilder1 = xlsBuilder1.addTextLeftAlignedColumnWithBordersAndDataFormat(dto.getEstimtor(),"String","BPPD");
		xlsBuilder1 = xlsBuilder1.addTextLeftAlignedColumnWithBordersAndDataFormat(dto.getFiscper().substring(4, 7)+"/"+dto.getFiscper().substring(0, 4),"String","BPPD");
		xlsBuilder1 = xlsBuilder1.addTextLeftAlignedColumnWithBordersAndDataFormat(dto.getWoDesc(),"String","BPPD");
		xlsBuilder1 = xlsBuilder1.addTextLeftAlignedColumnWithBordersAndDataFormat(dto.getNetwork(),"Number","BPPD");
		xlsBuilder1 = xlsBuilder1.addTextLeftAlignedColumnWithBordersAndDataFormat(dto.getDesc(),"String","BPPD");
		xlsBuilder1 = xlsBuilder1.addTextLeftAlignedColumnWithBordersAndDataFormat(dto.getInvoiceNumber(),"String","BPPD");
		xlsBuilder1 = xlsBuilder1.addTextLeftAlignedColumnWithBordersAndDataFormat(dto.getAmount(),"Decimal","BPPD");
		xlsBuilder1 = xlsBuilder1.addTextLeftAlignedColumnWithBordersAndDataFormat(dto.getSiteRemManager(),"String","BPPD");
	}
	
	private static   void populateMonthlySpendData(XlsxBuilder xlsBuilder,MonthlySpendDTO dto, int rowCount) {
		XlsxBuilder xlsBuilder1 = xlsBuilder.startRow();
		xlsBuilder1 = xlsBuilder1.addTextLeftAlignedColumnWithBordersAndDataFormat(dto.getFiscper().substring(4, 7)+"/"+dto.getFiscper().substring(0, 4),"String","MonthlySpend");
		xlsBuilder1 = xlsBuilder1.addTextLeftAlignedColumnWithBordersAndDataFormat(dto.getProjName(),"String","MonthlySpend");
		xlsBuilder1 = xlsBuilder1.addTextLeftAlignedColumnWithBordersAndDataFormat(dto.getNetwork(),"String","MonthlySpend");
		xlsBuilder1 = xlsBuilder1.addTextLeftAlignedColumnWithBordersAndDataFormat(dto.getActivity(),"String","MonthlySpend");
		xlsBuilder1 = xlsBuilder1.addTextLeftAlignedColumnWithBordersAndDataFormat(dto.getJob(),"String","MonthlySpend");
		xlsBuilder1 = xlsBuilder1.addTextLeftAlignedColumnWithBordersAndDataFormat(dto.getAccountInfo(),"String","MonthlySpend");
		xlsBuilder1 = xlsBuilder1.addTextLeftAlignedColumnWithBordersAndDataFormat(dto.getDocType(),"String","MonthlySpend");
		xlsBuilder1 = xlsBuilder1.addTextLeftAlignedColumnWithBordersAndDataFormat(dto.getType(),"String","MonthlySpend");
		xlsBuilder1 = xlsBuilder1.addTextLeftAlignedColumnWithBordersAndDataFormat(dto.getIdentifier(),"String","MonthlySpend");
		xlsBuilder1 = xlsBuilder1.addTextLeftAlignedColumnWithBordersAndDataFormat(dto.getDesc(),"String","MonthlySpend");
		xlsBuilder1 = xlsBuilder1.addTextLeftAlignedColumnWithBordersAndDataFormat(dto.getInvoiceNumber(),"String","MonthlySpend");
		xlsBuilder1 = xlsBuilder1.addTextLeftAlignedColumnWithBordersAndDataFormat(dto.getAmount(),"Decimal","MonthlySpend");
	}
		
		public static ResponseEntity<byte[]> getResponse(byte[] contents, String fileName) {
			final HttpHeaders responseHeaders = new HttpHeaders();
			responseHeaders.setContentType(MediaType.APPLICATION_OCTET_STREAM);
			responseHeaders.set("Content-Disposition", "attachment;filename=" + fileName);
			responseHeaders.set("x-filename", fileName);
			responseHeaders.setCacheControl("public");
			responseHeaders.setPragma("public");
			return new ResponseEntity<byte[]>(contents, responseHeaders, HttpStatus.OK);
		} 
		private static void populateExcelData(final Sheet sheet, final String[] rowContent, int rowCount) {
			final Row currentRow = sheet.createRow(rowCount);
			for (int j = 0; j < rowContent.length; j++) {
				Cell cell = currentRow.createCell(j);
				cell.setCellValue(rowContent[j]);
			}
		}

		private static void createHeaderRow(final Sheet sheet, final String[] rowContent) {
			final Row headerRow = sheet.createRow(0);
			final Workbook workbook = sheet.getWorkbook();
			for (int i = 0; i < rowContent.length; i++) {
				final Cell cell = headerRow.createCell(i);
				final CellStyle style = workbook.createCellStyle();
				final Font font = workbook.createFont();
				 style.setFont(font);
				font.setBold(true);
				style.setShrinkToFit(false);
				 style.setAlignment(CellStyle.ALIGN_CENTER);
				cell.setCellStyle(style);
				cell.setCellValue(rowContent[i]);
			}
		}
		
		
}
