package com.uprr.ema.lms.reports.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.uprr.azm.shared.mvc.security.authorization.Attribute;
import com.uprr.azm.shared.mvc.security.authorization.Authorize;
import com.uprr.ema.lms.reports.dto.LCRRprtSearchCriteriaDTO;
import com.uprr.ema.lms.reports.service.api.ReportsService;
import com.uprr.ema.lms.reports.vb.DocumentVB;

@RestController
@RequestMapping("/reports")
public class ReportsController {

	@Autowired
	private ReportsService reportsService;
	
	@RequestMapping(value = "/exportLCRReport", method = RequestMethod.POST)
	public void getLCRReport(HttpServletResponse response,@RequestBody LCRRprtSearchCriteriaDTO lcrRprtSearchCriteria)throws Exception {
	    	reportsService.getLCRReport(response,lcrRprtSearchCriteria);
	}
	
	@RequestMapping(value = "/generateLCRBarChart/{month}/{year}", method = RequestMethod.GET)
	public List<List<Float>> generateLCRBarChart(HttpServletResponse response,@PathVariable("month") String month,@PathVariable("year") String year)throws Exception {
			return reportsService.generateLCRBarChart(response,month,year);
	}
	 
	 @RequestMapping(value = "/generateBppdReport/{month}/{year}", method = RequestMethod.GET)
	 @ResponseBody
	 @Authorize(
		    actions = {@Attribute(key="action-id", value="view")},
		    resources = {@Attribute(key="resource-id", value="environmental-liabilities"),@Attribute(key="feature-id", value="less-sensitive-reports")}
		    )
		public void generateBppdReport(HttpServletResponse response,@PathVariable("month") String month,@PathVariable("year") String year)throws Exception {
		 	reportsService.getBppdExcelReport(response,month,year);
	}
	 
	 @RequestMapping(value = "/generateSiteSource/{month}/{year}", method = RequestMethod.GET)
	 @ResponseBody
	 @Authorize(
		    actions = {@Attribute(key="action-id", value="view")},
		    resources = {@Attribute(key="resource-id", value="environmental-liabilities"),@Attribute(key="feature-id", value="less-sensitive-reports")}
		    )
		public void generateSiteSourceReport(HttpServletResponse response,@PathVariable("month") String month,@PathVariable("year") String year)throws Exception {
		 	reportsService.getSiteSourceExcelReport(response,month,year);
	}
	 
	 @RequestMapping(value = "/generateMonthlySpendReport/{month}/{year}", method = RequestMethod.GET)
	 @ResponseBody
	 @Authorize(
		    actions = {@Attribute(key="action-id", value="view")},
		    resources = {@Attribute(key="resource-id", value="environmental-liabilities"),@Attribute(key="feature-id", value="less-sensitive-reports")}
		    )
		public void generateMonthlySpendReport(HttpServletResponse response,@PathVariable("month") String month,@PathVariable("year") String year)throws Exception {
		 	reportsService.getMonthlySpendReport(response,month,year);
	}
	 
	 @RequestMapping(value = "/generateProjectCountWaterfall/{month}/{year}", method = RequestMethod.GET)
	 @ResponseBody
	 @Authorize(
		    actions = {@Attribute(key="action-id", value="view")},
		    resources = {@Attribute(key="resource-id", value="environmental-liabilities"),@Attribute(key="feature-id", value="less-sensitive-reports")}
		    )
		public List<List<Integer>> generateProjectCountWaterfall(@PathVariable("month") String month,@PathVariable("year") String year)throws Exception {
		 	return reportsService.getProjectCountWaterfallReport(month,year);
	}
	 
	 @RequestMapping(value = "/generateQuarterlyAuditBackup/{month}/{year}", method = RequestMethod.GET)
	 @ResponseBody
	 @Authorize(
		    actions = {@Attribute(key="action-id", value="view")},
		    resources = {@Attribute(key="resource-id", value="environmental-liabilities"),@Attribute(key="feature-id", value="less-sensitive-reports")}
		    )
		public void generateQuarterlyAuditBackup(HttpServletResponse response,@PathVariable("month") String month,@PathVariable("year") String year)throws Exception {
		 	reportsService.getQuarterlyAuditBackupReport(response,month,year);
	}
	 
	 @RequestMapping(value = "/archieveLEWBReport/{month}/{year}", method = RequestMethod.POST)
	 public String archieveLEWBReport(@RequestParam("file") MultipartFile file,@PathVariable("month") String month,@PathVariable("year") String year) throws IOException {
		 System.out.println(file.getName());
		 System.out.println(file.getContentType());
		 System.out.println(file.getOriginalFilename());
		 System.out.println(file.getSize());
		 reportsService.archieveLEWBReport(file, month, year);
		 return "File received in the backend";
	 }
	 
	 @RequestMapping(value = "/downloadLEWBReport/{month}/{year}", method = RequestMethod.POST)
	 public DocumentVB downloadLEWBReport(HttpServletResponse response,@PathVariable("month") String month,@PathVariable("year") String year)throws Exception {
		 	return reportsService.downloadLEWBReport(month, year);
	 }
	 
	 @RequestMapping(value = "/archieveLCRReport/{month}/{year}", method = RequestMethod.POST)
	 public String archieveLCRReport(@RequestParam("file") MultipartFile file,@PathVariable("month") String month,@PathVariable("year") String year) throws IOException {
		 System.out.println(file.getName());
		 System.out.println(file.getContentType());
		 System.out.println(file.getOriginalFilename());
		 System.out.println(file.getSize());
		 reportsService.archieveLCRReport(file, month, year);
		 return "File received in the backend";
	 }
	 
	 @RequestMapping(value = "/downloadLCRReport/{month}/{year}", method = RequestMethod.POST)
	 public DocumentVB downloadLCRReport(HttpServletResponse response,@PathVariable("month") String month,@PathVariable("year") String year)throws Exception {
		 	return reportsService.downloadLCRReport(month, year);
	 }
	 
	
	
}
