package com.uprr.ema.lms.common.service.api;

public interface IAuthorizationService {
	boolean canSearchProject(String userId);
	boolean canUpdateProject(String userId);
	boolean canApprove(String userId);
	boolean canViewSummary(String userId);
	public boolean isAutherized(String userId,String action_id,String feature_id,String resource_id);
}
