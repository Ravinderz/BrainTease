package com.uprr.ema.lms.common.dao.impl;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlParameterValue;
import org.springframework.jdbc.core.SqlTypeValue;
import org.springframework.jdbc.core.StatementCreatorUtils;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;

import com.uprr.ema.lms.common.LmsLogger;
import com.uprr.ema.lms.common.dao.api.BaseDao;
import com.uprr.ema.lms.exception.LmsException;


public  class BaseDaoImpl  extends BaseDao {
	
	private static final LmsLogger logger = LmsLogger.getLogger(BaseDaoImpl.class);

	/*@Autowired
	@Qualifier(value = "oracleDataSource")
	DataSource oracleDataSource;

	@PostConstruct
	private void initialize() {
		setDataSource(oracleDataSource);
	}
	 */
	 
	   /**
	    * Gives the List<T> of objects based on the sql given
	    */
	   public <T> List<T> getNamedParamResultsList(final String sql, final Class<T> clazz)
	         throws LmsException {
	      try {
	         //return getJdbcTemplate().query(AIRSFortificationUtil.immuneOracleSQL(sql), ParameterizedBeanPropertyRowMapper.newInstance(clazz));
	         return getJdbcTemplate().query(sql, BeanPropertyRowMapper.newInstance(clazz));
	      } catch (EmptyResultDataAccessException e) {
	         throw new LmsException(e);
	      } catch (Exception e) {
	         logger.error(e.getMessage(), "getNamedParamResultsList()", new Object[] { sql });
	         throw new LmsException(e);
	      }
	   }

	   /**
	    * 
	    * @param sql
	    * @param params
	    * @param clazz
	    * @return
	    * @throws LmsException
	    */
	   public Object getNamedParamResultObject(final String sql, Object[] params,
	         final Class<? extends Object> clazz) throws LmsException {
	      try {
	         return getJdbcTemplate().queryForObject(sql, params,
	        	 BeanPropertyRowMapper.newInstance(clazz));
	      } catch (EmptyResultDataAccessException e) {
	         return null;
	      } catch (Exception e) {
	         logger.errorWithQryAndParams(e.getMessage(), "getNamedParamResultObject()", new Object[] { sql, params });
	         throw new LmsException(e);
	      }
	   }

	   /**
	    * It save/update/delete the given object based on the sql query passed.
	    */
	   public void saveOrUpdate(final String sql, final Object dataObject) throws LmsException {
	      try {
	    	  getNamedParameterJdbcTemplate().update(sql, new BeanPropertySqlParameterSource(dataObject));         
	      } catch (Exception e) {
	         logger.error(e.getMessage(), "saveOrUpdate()", new Object[] { sql, dataObject });
	         throw new LmsException(e);
	      }
	   }

	   /**
	    *  It save/update/delete the given object based on the sql query passed.
	    * @param sql
	    * @param params
	    * @throws LmsException
	    */
	   public void saveOrUpdate(final String sql, final Object[] params) throws LmsException {
	      try {
	         getJdbcTemplate().update(sql, params);
	      } catch (Exception e) {
	         logger.error(e.getMessage(), "saveOrUpdate()", new Object[] { sql, params });
	         throw new LmsException(e);
	      }
	   }

	/**
	 *    
	 * @param sql
	 * @param params
	 * @param clazz
	 * @return
	 * @throws LmsException
	 */
	   public <T> List<T> getNamedParamResultsList(final String sql, MapSqlParameterSource params, final Class<T> clazz)
	         throws LmsException {
	      try {
	         return getNamedParameterJdbcTemplate().query(sql, params, BeanPropertyRowMapper.newInstance(clazz));
	      } catch (EmptyResultDataAccessException e) {
	         throw new LmsException(e);
	      } catch (Exception e) {
	         logger.error(e.getMessage(), "getNamedParamResultsList():" ,new Object[] { sql, params });
	         throw new LmsException(e);
	      }
	   }
	   
	   /**
		 *    
		 * @param sql
		 * @param params
		 * @param clazz
		 * @return
		 * @throws LmsException
		 */
		   public <T> List<T> getNamedParamResultsListByRowMapper(final String sql, MapSqlParameterSource params, final RowMapper<T> rowMapper)
		         throws LmsException {
		      try {
		         return getNamedParameterJdbcTemplate().query(sql, params, rowMapper);
		      } catch (EmptyResultDataAccessException e) {
		         throw new LmsException(e);
		      } catch (Exception e) {
		         logger.error(e.getMessage(), "getNamedParamResultsList():" ,new Object[] { sql, params });
		         throw new LmsException(e);
		      }
		   }
	   
	   /**
		 *    
		 * @param sql
		 * @param params
		 * @param clazz
		 * @return
		 * @throws LmsException
		 */
		   public <T> List<T> getNamedParamResultsList(final String sql, Object[] params, final Class<T> clazz)
		         throws LmsException {
		      try {
		         return getJdbcTemplate().query(sql, params, BeanPropertyRowMapper.newInstance(clazz));
		      } catch (EmptyResultDataAccessException e) {
		         throw new LmsException(e);
		      } catch (Exception e) {
		         logger.error(e.getMessage(), "getNamedParamResultsList():" ,new Object[] { sql, params });
		         throw new LmsException(e);
		      }
		   }

	   /**
	    * This method is to retrieve count.
	    * 
	    * @param sql
	    * @param ObjectMap
	    * @return
	    * @throws LmsException
	    */
	   public int getCount(String sql, Object[] ObjectMap) throws LmsException {
	       try {
		   //return this.getJdbcTemplate().queryForInt(AIRSFortificationUtil.immuneOracleSQL(sql), ObjectMap);
		   return getJdbcTemplate().queryForObject(sql, ObjectMap,Integer.class);
	       }
	       catch (EmptyResultDataAccessException e) {
		   logger.error(e.getMessage(), "getCount()", ObjectMap);
		   return 0;
	       } catch (Exception e) {
		   logger.error(e.getMessage(), "getCount()", ObjectMap);
		   throw new LmsException(e);
	       }
	   }
	   /**
	    * This method is to retrieve count.
	    * 
	    * @param sql
	    * @param ObjectMap
	    * @return
	    * @throws LmsException
	    */
	   public int getCount(String sql,  MapSqlParameterSource map) throws LmsException {
	       try {
		   //return this.getJdbcTemplate().queryForInt(AIRSFortificationUtil.immuneOracleSQL(sql), ObjectMap);
		   return getNamedParameterJdbcTemplate().queryForObject(sql, map,Integer.class);
	       }
	       catch (EmptyResultDataAccessException e) {
		  // logger.error(e.getMessage(), "getCount()", map);
		   return 0;
	       } catch (Exception e) {
		   //logger.error(e.getMessage(), "getCount()", map);
		   throw new LmsException(e);
	       }
	   }

	   /**
	    * This method is to save.
	    * 
	    * @param sql
	    * @param ObjectMap
	    * @return
	    * @throws LmsException
	    */
	   public int insert(String sql, Object[] ObjectMap) throws LmsException {
	      try {
	         return getJdbcTemplate().update(sql, ObjectMap);
	      } catch (Exception e) {
	         logger.error(e.getMessage(), "insert()", ObjectMap);
	         throw new LmsException(e);
	      }
	   }


	  
	   
	   public <T> List<Map<String, Object>> getNamedParamResultsList(final String sql, Object[] params)
		         throws LmsException {
		      try {
		         return getJdbcTemplate().queryForList(sql, params);
		      } catch (EmptyResultDataAccessException e) {
		         throw new LmsException(e);
		      } catch (Exception e) {
		         logger.error(e.getMessage(), "getNamedParamResultsList():" ,new Object[] { sql, params });
		         throw new LmsException(e);
		      }
		   }

	   /**
	    * to point to all sql type params
	    * @param values
	    * @param ps
	    * @param columnTypes
	    * @throws SQLException
	    */
	   // TODO: PROPER TESTING IS REQUIRED
	   private void doSetStatementParameters(Object[] values, PreparedStatement ps, int[] columnTypes)
	         throws SQLException {
	      int colIndex = 0;
	      for (Object value : values) {
	         colIndex++;
	         if (value instanceof SqlParameterValue) {
	            SqlParameterValue paramValue = (SqlParameterValue) value;
	            StatementCreatorUtils.setParameterValue(ps, colIndex, paramValue, paramValue.getValue());
	         } else {
	            int colType;
	            if (columnTypes == null || columnTypes.length < colIndex) {
	               colType = SqlTypeValue.TYPE_UNKNOWN;
	            } else {
	               colType = columnTypes[colIndex - 1];
	            }
	            StatementCreatorUtils.setParameterValue(ps, colIndex, colType, value);
	         }
	      }
	   }

	   /**
	    * This method is to retrieve Max Value.
	    * 
	    * @param sql
	    * @param ObjectMap
	    * @return
	    * @throws LmsException
	    */
	   public int getMaxValue(String sql) throws LmsException {
	      try {
	         return getJdbcTemplate().queryForObject(sql,Integer.class);
	      } catch (Exception e) {
	         logger.error(e.getMessage(), "getMaxValue()", new Object[] { sql });
	         throw new LmsException(e);
	      }

	   }
	   
	   /**
	    *executes update or insert query
	    */
	   public int updateQry(final String sql)
	         throws LmsException {
	      try {
	         //return getJdbcTemplate().query(AIRSFortificationUtil.immuneOracleSQL(sql), ParameterizedBeanPropertyRowMapper.newInstance(clazz));
	         return getJdbcTemplate().update(sql);
	      } catch (EmptyResultDataAccessException e) {
	         throw new LmsException(e);
	      } catch (Exception e) {
	         logger.error(e.getMessage(), "getNamedParamResultsList()", new Object[] { sql });
	         throw new LmsException(e);
	      }
	   }


	  
}
