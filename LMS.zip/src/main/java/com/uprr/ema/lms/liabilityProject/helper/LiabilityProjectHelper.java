package com.uprr.ema.lms.liabilityProject.helper;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.uprr.ema.lms.common.service.util.LMSUtils;
import com.uprr.ema.lms.common.service.util.ServiceConstants;
import com.uprr.ema.lms.common.util.LMSResponseConstants;
import com.uprr.ema.lms.common.web.util.WebDateUtil;
import com.uprr.ema.lms.liabilityProject.dto.AccountCostDTO;
import com.uprr.ema.lms.liabilityProject.dto.DisapproveProjDTO;
import com.uprr.ema.lms.liabilityProject.dto.ProjectCostDTO;
import com.uprr.ema.lms.liabilityProject.dto.ProjectDTO;
import com.uprr.ema.lms.liabilityProject.service.api.LiabilityProjectService;
import com.uprr.ema.lms.liabilityProject.vb.DisapproveProjVB;
import com.uprr.ema.lms.liabilityProject.vb.ProjectCostVB;
import com.uprr.ema.lms.liabilityProject.vb.ProjectOnLoadVB;
import com.uprr.ema.lms.liabilityProject.vb.ProjectStatusVB;
import com.uprr.ema.lms.liabilityProject.vb.ProjectVB;
import com.uprr.ui.shared.user.ActiveUserId;

/**
 * This class will accept the request from controller and copy the data from VB
 * to DTO and vice versa
 * 
 * @author xprk208
 * 
 */
@Component
public class LiabilityProjectHelper {

	@Autowired
	LiabilityProjectService  liabProjService;
	/**
	 * This method will fetch all the dropdown values
	 * records
	 * 
	 * @return ProjectOnLoadVB
	 * @
	 */
	
	public ProjectOnLoadVB getLookUpData()  {
	    ProjectOnLoadVB projectOnLoadVB = liabProjService.getLookUpData();
	    projectOnLoadVB.setStatusCode(LMSResponseConstants.SUCESS_CODE);
	    return projectOnLoadVB;
	}
	
	public List<AccountCostDTO> getAccountUpdate(){
	    return liabProjService.getAccountUpdate();
	}
	
	public ProjectStatusVB getPendingApprovalProjects(){
	    ProjectStatusVB projectStatusVB = null;
	    List<ProjectVB> projectVBs = null;
	    projectStatusVB = new ProjectStatusVB();
	    try{

		List<ProjectDTO> projects = liabProjService.getPendignApprovalProjects();
		if(projects!=null && !projects.isEmpty()){
		    projectVBs = new ArrayList<ProjectVB>(projects.size());
		    for (ProjectDTO tempProjectDTO : projects) {
			projectVBs.add(getProjectDetailsVBFromDTO(tempProjectDTO));
		    }
		}
		projectStatusVB.setProjects(projectVBs);
		projectStatusVB.setStatusCode(LMSResponseConstants.SUCESS_CODE);

	    }
	    finally{
	    }
	    return projectStatusVB;
	}
	
	public ProjectStatusVB getDisApprovedProjects(){
	    ProjectStatusVB projectStatusVB = null;
	    List<ProjectVB> projectVBs = null;
	    projectStatusVB = new ProjectStatusVB();
	    try{

		List<ProjectDTO> projects = liabProjService.getDisApprovedProjects();
		if(projects!=null && !projects.isEmpty()){
		    projectVBs = new ArrayList<ProjectVB>(projects.size());
		    for (ProjectDTO tempProjectDTO : projects) {
			projectVBs.add(getProjectDetailsVBFromDTO(tempProjectDTO));
		    }
		}
		projectStatusVB.setProjects(projectVBs);
		projectStatusVB.setStatusCode(LMSResponseConstants.SUCESS_CODE);

	    }
	    finally{
	    }
	    return projectStatusVB;
	}
	

	/**
	 * This method will save or update project details
	 * records
	 * @param ProjectVB
	 * @return ProjectStatusVB
	 */

	public ProjectOnLoadVB getApprovedProjectDetails(long projectId){
	    ProjectOnLoadVB projectOnLoadVB = null;
	    ProjectVB projectVB= null;
	    try{
			projectOnLoadVB = liabProjService.getMasterData();
			ProjectDTO projectDTO = liabProjService.getApprovedProjectDetails(Long.valueOf(projectId));
			projectVB = getProjectDetailsVBFromDTO(projectDTO);
			projectVB.setCurrentCostVBList(getProjCostDtlsListVBFromDTO(projectDTO.getCurrentCostDTOList()));
			projectVB.setProposedCostVBList(getProjCostDtlsListVBFromDTO(projectDTO.getProposedCostDTOList()));
			projectOnLoadVB.setProjectVB(projectVB);
			projectOnLoadVB.setStatusCode(LMSResponseConstants.SUCESS_CODE);
	    }
	    finally{
	    	//projectOnLoadVB = null;
	    }
	    return projectOnLoadVB;
	}
	
	public ProjectOnLoadVB getProjectByProjId(long projectId){
	    ProjectOnLoadVB projectOnLoadVB = null;
	    ProjectVB projectVB= null;
	    try{
			projectOnLoadVB = liabProjService.getMasterData();
			ProjectDTO projectDTO = liabProjService.getProjectByProjId(projectId);
			projectVB = getProjectDetailsVBFromDTO(projectDTO);
			projectVB.setCurrentCostVBList(getProjCostDtlsListVBFromDTO(projectDTO.getCurrentCostDTOList()));
			projectVB.setProposedCostVBList(getProjCostDtlsListVBFromDTO(projectDTO.getProposedCostDTOList()));
			projectOnLoadVB.setProjectVB(projectVB);
			projectOnLoadVB.setStatusCode(LMSResponseConstants.SUCESS_CODE);
	    }
	    finally{
	    	//projectOnLoadVB = null;
	    }
	    return projectOnLoadVB;

	}
	
	
	
	public ProjectStatusVB saveProjectDetails(ProjectVB projectVB,ActiveUserId user){
	    ProjectStatusVB projectStatusVB = null;
	    ProjectDTO projectDTO = null;
	    projectDTO = getProjectDetailsDTOFromVB(projectVB);
	    try{
	    	projectDTO.setCrtdUser(user.getUserId());
	    	projectDTO.setLastUptdUser(user.getUserId());
	    	projectDTO.setEmpId(user.getEmployeeId());
		projectDTO = liabProjService.saveProjectDetails(projectDTO);
		projectVB = getProjectDetailsVBFromDTO(projectDTO);
		projectStatusVB = new ProjectStatusVB();
		projectStatusVB.setProjectVB(projectVB);
		projectStatusVB.setStatusCode(LMSResponseConstants.SUCESS_CODE);

	    }
	    finally{
			projectVB = null;
			projectDTO = null;
	    }
	    return projectStatusVB;
	}
	
	public ProjectStatusVB deleteProjectOrChange(long projectId,ActiveUserId user,String actionType){
	    ProjectDTO projectDTO = null;
	    ProjectStatusVB projectStatusVB = null;
	    try{
		projectDTO = liabProjService.getProjectByProjId(projectId);
		projectDTO.setAction(ServiceConstants.ACTION_PROJ_DELETED);
		projectDTO.setActionType(actionType);
		if(ServiceConstants.ACTION_TYPE_PROJ.equalsIgnoreCase(actionType)){
		    projectDTO.setInputFrom(ServiceConstants.ACTION_PROJ_DELETED);
		}else{
		    projectDTO.setInputFrom(ServiceConstants.ACTION_CHANGE_DELETED);
		}
		
		setProjectData( projectDTO, user);
		liabProjService.deleteProject(projectDTO);
		projectStatusVB = getProjectStatus();
		//projectStatusVB.setPendingApprovalProjects(getPendingApprovalProjects().getProjects());
		projectStatusVB.setDisApprovedProjects(getDisApprovedProjects().getProjects());
	    }
	    finally{
		projectDTO = null;
	    }
	    return projectStatusVB;
	}
	
	
	
	private void setProjectData(ProjectDTO projectDTO,ActiveUserId user){
	    projectDTO.setCrtdUser(user.getUserId());
	    projectDTO.setLastUptdUser(user.getUserId());
	    projectDTO.setEmpId(user.getEmployeeId());
	}
	
	private ProjectStatusVB getProjectStatus(){
	    ProjectStatusVB projectStatusVB = new ProjectStatusVB();
	    projectStatusVB.setStatusCode(LMSResponseConstants.SUCESS_CODE);
	    return projectStatusVB;
	}
	
	/*public ProjectStatusVB saveApproveProject(ProjectVB projectVB,ActiveUserId user){
	    ProjectStatusVB projectStatusVB = null;
	    ProjectDTO projectDTO = null;
	    projectDTO = getProjectDetailsDTOFromVB(projectVB);
	    try{
	    	projectDTO.setCrtdUser(user.getUserId());
	    	projectDTO.setLastUptdUser(user.getUserId());
	    	projectDTO.setEmpId(user.getEmployeeId());
			liabProjService.saveApproveProject(projectDTO);
			projectVB = getProjectDetailsVBFromDTO(projectDTO);
			projectStatusVB = new ProjectStatusVB();
			projectStatusVB.setProjectVB(projectVB);
			projectStatusVB.setStatusCode(LMSResponseConstants.SUCESS_CODE);
	    }
	    finally{
			projectVB = null;
			projectDTO = null;
	    }
	    return projectStatusVB;
	}*/
	
	public ProjectStatusVB disApproveProject(ProjectVB projectVB,ActiveUserId user){
	    ProjectStatusVB projectStatusVB = null;
	    ProjectDTO projectDTO = null;
	    DisapproveProjVB disapproveProjVB = null;
	    long disAprvCmntId = 0;
	    projectDTO = getProjectDetailsDTOFromVB(projectVB);
	    try{
	    	projectDTO.setCrtdUser(user.getUserId());
	    	projectDTO.setLastUptdUser(user.getUserId());
	    	disapproveProjVB = new DisapproveProjVB();
	    	disapproveProjVB.setDisaprvComments(projectVB.getDisaprvComments());
	    	disapproveProjVB.setCrtdUser(user.getUserId());
	    	disapproveProjVB.setLastUptdUser(user.getUserId());
	    	disapproveProjVB.setEmpId(user.getEmployeeId());
	    	projectDTO = liabProjService.saveDisapprvProj(getDisaprvProjVBToDTO(disapproveProjVB),projectDTO);
	    	//projectDTO.setDisaprvCmtDtlId(disAprvCmntId);
		//projectDTO = liabProjService.saveProjectDetails(projectDTO);
		projectVB = getProjectDetailsVBFromDTO(projectDTO);
		projectStatusVB = new ProjectStatusVB();
		projectStatusVB.setProjectVB(projectVB);
		projectStatusVB.setStatusCode(LMSResponseConstants.SUCESS_CODE);
	    }
	    finally{
			projectVB = null;
			projectDTO = null;
	    }
	    return projectStatusVB;
	}
	public ProjectStatusVB saveUpdateProjectDetails(ProjectVB projectVB,ActiveUserId user){
	    ProjectStatusVB projectStatusVB = null;
	    ProjectDTO projectDTO = null;
	    projectDTO = getProjectDetailsDTOFromVB(projectVB);
	    try{
	    	projectDTO.setCrtdUser(user.getUserId());
	    	projectDTO.setLastUptdUser(user.getUserId());
	    	projectDTO.setEmpId(user.getEmployeeId());
			projectDTO = liabProjService.saveOrUpdateProjectDetails(projectDTO);
			//projectDTO.setProjectCostDTOList(liabProjService.saveOrUpdateProjectCostDetails(projectDTO));
			
			projectVB = getProjectDetailsVBFromDTO(projectDTO);
			projectStatusVB = new ProjectStatusVB();
			projectStatusVB.setProjectVB(projectVB);
			projectStatusVB.setStatusCode(LMSResponseConstants.SUCESS_CODE);
	    }
	    finally{
			projectVB = null;
			projectDTO = null;
	    }
	    return projectStatusVB;
	}
	
	/**
	 * This method will convert ProjectVB To ProjectDTO 
	 * records
	 * @param ProjectVB
	 * @return ProjectDTO
	 */
	private ProjectDTO getProjectDetailsDTOFromVB(ProjectVB projectVB){
		ProjectDTO projectDTO = new ProjectDTO();
		if(projectVB != null){
			BeanUtils.copyProperties(projectVB, projectDTO);
			if(StringUtils.isNotEmpty(projectVB.getCrtdDate())){
				projectDTO.setCrtdDate(WebDateUtil.getDateFromddMMYYY(projectVB.getCrtdDate()));
			}
			if(StringUtils.isNotEmpty(projectVB.getLastUptdDate())){
				projectDTO.setLastUptdDate(WebDateUtil.getDateFromddMMYYY(projectVB.getLastUptdDate()));
			}
			if(StringUtils.isNotEmpty(projectVB.getClosedDate())){
				projectDTO.setClosedDate(WebDateUtil.getDateFromddMMYYY(projectVB.getClosedDate()));
			}
			if(StringUtils.isNotEmpty(projectVB.getProjectDate())){
				projectDTO.setProjectDate(WebDateUtil.getDateFromddMMYYY(projectVB.getProjectDate()));
			}
			
			if(StringUtils.isNotEmpty(projectVB.getChangeReasonDate())){
				projectDTO.setChangeReasonDate(WebDateUtil.getDateFromddMMYYY(projectVB.getChangeReasonDate()));
			}
			projectDTO.setProjectCostDTOList(getProjCostDtlListDTOFromVB(projectVB.getProjectCostVBList()));
			projectDTO.setCurrentCostDTOList(getProjCostDtlListDTOFromVB(projectVB.getCurrentCostVBList()));
			projectDTO.setProposedCostDTOList(getProjCostDtlListDTOFromVB(projectVB.getProposedCostVBList()));
		}
		return projectDTO;
	}
	
	/**
	 * This method will convert ProjectDTO To ProjectVB 
	 * records
	 * @param ProjectDTO
	 * @return ProjectVB
	 */
	private ProjectVB getProjectDetailsVBFromDTO(ProjectDTO projectDTO){
		ProjectVB projectVB = new ProjectVB();
		if(projectDTO!=null){
			BeanUtils.copyProperties(projectDTO, projectVB);
			if(projectDTO.getCrtdDate() != null){
				projectVB.setCrtdDate(WebDateUtil.getDisplayformat(projectDTO.getCrtdDate()));
			}
			if(projectDTO.getLastUptdDate() != null){
				projectVB.setLastUptdDate(WebDateUtil.getDisplayformat(projectDTO.getLastUptdDate()));
			}
			if(projectDTO.getClosedDate() != null){
				projectVB.setClosedDate(WebDateUtil.getDisplayformat(projectDTO.getClosedDate()));
			}
			if(projectDTO.getProjectDate() != null){
				projectVB.setProjectDate(WebDateUtil.getDisplayformat(projectDTO.getProjectDate()));
			}
			if(projectDTO.getChangeReasonDate() != null){
				projectVB.setChangeReasonDate(WebDateUtil.getDisplayformat(projectDTO.getChangeReasonDate()));
			}
			projectVB.setProjectCostVBList(getProjCostDtlsListVBFromDTO(projectDTO.getProjectCostDTOList()));
			projectVB.setCurrentCostVBList(getProjCostDtlsListVBFromDTO(projectDTO.getCurrentCostDTOList()));
			projectVB.setProposedCostVBList(getProjCostDtlsListVBFromDTO(projectDTO.getProposedCostDTOList()));
		}
		return projectVB;
	}
	
	/**
	 * This method will convert DisapproveProjVB To DisapproveProjDTO 
	 * records
	 * @param DisapproveProjVB
	 * @return DisapproveProjDTO
	 */
	private DisapproveProjDTO getDisaprvProjVBToDTO(DisapproveProjVB disapproveProjVB){
		DisapproveProjDTO disapproveProjDTO = new DisapproveProjDTO();
		if(disapproveProjVB!=null){
			BeanUtils.copyProperties(disapproveProjVB, disapproveProjDTO);
			if(StringUtils.isNotEmpty(disapproveProjVB.getCrtdDate())){
				disapproveProjDTO.setCrtdDate(WebDateUtil.getDateFromddMMYYY(disapproveProjVB.getCrtdDate()));
			}
			if(StringUtils.isNotEmpty(disapproveProjVB.getLastUptdDate())){
				disapproveProjDTO.setLastUptdDate(WebDateUtil.getDateFromddMMYYY(disapproveProjVB.getLastUptdDate()));
			}
		}
		return disapproveProjDTO;
	}
	/**
	 * This method will convert DisapproveProjDTO To DisapproveProjVB 
	 * records
	 * @param DisapproveProjDTO
	 * @return DisapproveProjVB
	 */
	private DisapproveProjVB getDisaprvProjVBToDTO(DisapproveProjDTO disapproveProjDTO){
		DisapproveProjVB  disapproveProjVB = new DisapproveProjVB();
		if(disapproveProjDTO!=null){
			BeanUtils.copyProperties(disapproveProjDTO, disapproveProjVB);
			if(disapproveProjDTO.getCrtdDate() != null){
				disapproveProjVB.setCrtdDate(WebDateUtil.getDisplayformat(disapproveProjDTO.getCrtdDate()));
			}
			if(disapproveProjDTO.getLastUptdDate() != null){
				disapproveProjVB.setLastUptdDate(WebDateUtil.getDisplayformat(disapproveProjDTO.getLastUptdDate()));
			}
		}
		return disapproveProjVB;
	}
	/**
	 * This method will convert ProjectCostVB list To ProjectCostDTO list 
	 * @param List<ProjectCostVB> 
	 * @return List<ProjectCostDTO>
	 */
	private List<ProjectCostDTO> getProjCostDtlListDTOFromVB(List<ProjectCostVB> projectCostVBList){
		List<ProjectCostDTO> projCostDTOList= null;
		if(LMSUtils.isNotEmpty(projectCostVBList)){
			projCostDTOList = new ArrayList<ProjectCostDTO>();
			for(ProjectCostVB projCostVB : projectCostVBList){
				if(projCostVB!=null){
					ProjectCostDTO projectCostDTO = new ProjectCostDTO();
					BeanUtils.copyProperties(projCostVB, projectCostDTO);
					if(StringUtils.isNotEmpty(projCostVB.getCrtdDate())){
						projectCostDTO.setCrtdDate(WebDateUtil.getDateFromddMMYYY(projCostVB.getCrtdDate()));
					}
					if(StringUtils.isNotEmpty(projCostVB.getLastUptdDate())){
						projectCostDTO.setLastUptdDate(WebDateUtil.getDateFromddMMYYY(projCostVB.getLastUptdDate()));
					}
					projCostDTOList.add(projectCostDTO);
				}
			}
		}
		return projCostDTOList;
	}
	
	/**
	 * This method will convert ProjectCostDTO list To ProjectCostVB list
	 * @param List<ProjectCostDTO>
	 * @return List<ProjectCostVB>
	 */
	private List<ProjectCostVB> getProjCostDtlsListVBFromDTO(List<ProjectCostDTO> projectCostDTOList){
		List<ProjectCostVB> projCostVBList = null;
		if(LMSUtils.isNotEmpty(projectCostDTOList)){
			projCostVBList= new ArrayList<ProjectCostVB>();
			for(ProjectCostDTO projCostDTO : projectCostDTOList){
				if(projCostDTO!=null){
					ProjectCostVB projectCostVB = new ProjectCostVB();
					BeanUtils.copyProperties(projCostDTO, projectCostVB);
					if(projCostDTO.getCrtdDate() != null){
						projectCostVB.setCrtdDate(WebDateUtil.getDisplayformat(projCostDTO.getCrtdDate()));
					}
					if(projCostDTO.getLastUptdDate() != null){
						projectCostVB.setLastUptdDate(WebDateUtil.getDisplayformat(projCostDTO.getLastUptdDate()));
					}
					projCostVBList.add(projectCostVB);
				}
			}
		}
		return projCostVBList;
	}
	
	public List<Integer> getYearsList()  {
	    List<Integer> yearsList= liabProjService.getUpto15Years();
	    
	    return yearsList;
	}
	
	public List<String> getMonths()  {
	    List<String> monthsList= new ArrayList<String>();
	    monthsList.add("January");
	    monthsList.add("February");
	    monthsList.add("March");
	    monthsList.add("April");
	    monthsList.add("May");
	    monthsList.add("June");
	    monthsList.add("July");
	    monthsList.add("August");
	    monthsList.add("September");
	    monthsList.add("October");
	    monthsList.add("November");
	    monthsList.add("December");
	   
	    
	    return monthsList;
	}
}
