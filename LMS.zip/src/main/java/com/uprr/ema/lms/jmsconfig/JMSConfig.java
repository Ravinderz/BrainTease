package com.uprr.ema.lms.jmsconfig;

import javax.jms.ConnectionFactory;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.connection.UserCredentialsConnectionFactoryAdapter;
import org.springframework.jndi.JndiObjectFactoryBean;

import com.uprr.ema.lms.common.constant.JMSPropertyKeyConstants;

@Configuration
public class JMSConfig extends JNDIConfig {

	
	@Bean(name="connectionFactory")
	public JndiObjectFactoryBean getConnectionFactory(){
		JndiObjectFactoryBean jndiObjectFactoryBean = new JndiObjectFactoryBean();
		jndiObjectFactoryBean.setJndiEnvironment(getJndiEnvironment());
		jndiObjectFactoryBean.setJndiName(getEnvironment().getProperty(JMSPropertyKeyConstants.XMF_CF_00));
		return jndiObjectFactoryBean;
	}
	
	@Bean(name="lmsQueue")
	public JndiObjectFactoryBean getLmsQueue(){
		JndiObjectFactoryBean jndiObjectFactoryBean = new JndiObjectFactoryBean();
		jndiObjectFactoryBean.setJndiEnvironment(getJndiEnvironment());
		jndiObjectFactoryBean.setJndiName(getEnvironment().getProperty(JMSPropertyKeyConstants.LMS_QUEUE));
		return jndiObjectFactoryBean;
	}
	
	@Bean(name = "authenticatingConnectionFactory")
	public UserCredentialsConnectionFactoryAdapter authenticatingConnectionFactory() {
		UserCredentialsConnectionFactoryAdapter connectionFactoryAdapter = new UserCredentialsConnectionFactoryAdapter();
		ConnectionFactory connectionFactory = (ConnectionFactory) getConnectionFactory().getObject();
		connectionFactoryAdapter.setTargetConnectionFactory(connectionFactory);
		connectionFactoryAdapter.setUsername(getEnvironment().getProperty("ENA_JMS_USER_NAME"));
		connectionFactoryAdapter.setPassword(jmsPasswordBean.getPasswordFromCyberArk());
		return connectionFactoryAdapter;
	}
	
	
}
