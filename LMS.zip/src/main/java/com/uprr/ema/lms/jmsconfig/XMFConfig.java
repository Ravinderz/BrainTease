package com.uprr.ema.lms.jmsconfig;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.jms.Destination;

import org.acegisecurity.providers.AuthenticationProvider;
import org.acegisecurity.providers.ProviderManager;
import org.acegisecurity.providers.dao.DaoAuthenticationProvider;
import org.acegisecurity.userdetails.UserDetailsService;
import org.springframework.aop.target.CommonsPool2TargetSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import com.uprr.app.xmf.RequestHandler;
import com.uprr.app.xmf.StaxMessageUtilities;
import com.uprr.app.xmf.client.ServiceProxy;
import com.uprr.app.xmf.client.ServiceProxyException;
import com.uprr.app.xmf.client.core.ServiceProxyFactoryImpl;
import com.uprr.app.xmf.client.security.core.CredentialProviderUserDetailsService;
import com.uprr.app.xmf.client.security.core.DefaultSecurityPolicy;
import com.uprr.app.xmf.client.security.core.SecurityHandler;
import com.uprr.app.xmf.client.security.core.SecurityTokenServiceProxy;
import com.uprr.ema.lms.common.constant.JMSPropertyKeyConstants;
import com.uprr.ema.lms.exception.LmsException;
import com.uprr.enterprise.shared.components.credential.CredentialProvider;
import com.uprr.enterprise.shared.components.credential.cyberark.FallbackTimeoutCyberArkCredentialProvider;
import com.uprr.enterprise.shared.components.credential.simple.SimpleCredentialProvider;

@Configuration
public class XMFConfig extends JMSConfig {
	
	
	@Bean(name="serviceProxyFactory")
	public ServiceProxyFactoryImpl getServiceProxyFactory() throws ServiceProxyException  {
		return new ServiceProxyFactoryImpl(authenticatingConnectionFactory(),getEnvironment().getProperty(
				JMSPropertyKeyConstants.XMF_CLIENT_ID), false);
	}
	
	@Bean(name = "serviceProxy")
	@Scope("prototype")
	public ServiceProxy getServiceProxy() throws ServiceProxyException {
		ServiceProxy serviceProxy = getServiceProxyFactory().createServiceProxy();
		serviceProxy.setRequestDestination((Destination) getLmsQueue().getObject());
		List<RequestHandler> requestHandlers = new ArrayList<RequestHandler>();
		requestHandlers.add(getSecurityHandler());
		serviceProxy.setRequestHandlers(requestHandlers);
		return serviceProxy;
	}

	@Bean(name = "securityHandler")
	public SecurityHandler getSecurityHandler() {
		SecurityHandler securityHandler = new SecurityHandler();
		Map<String, DefaultSecurityPolicy> policies = new HashMap<String, DefaultSecurityPolicy>();
		policies.put("person/get-cached-employee-details-3_0", getDefaultPolicy());
		securityHandler.setServicePolicies(policies);
		return securityHandler;
	}

	@Bean(name = "defaultPolicy")
	public DefaultSecurityPolicy getDefaultPolicy() {
		DefaultSecurityPolicy defaultSecurityPolicy = new DefaultSecurityPolicy();
		defaultSecurityPolicy.setSecurityTokenService(new SecurityTokenServiceProxy());
		/*defaultSecurityPolicy.setKeyStoreLocation("com/uprr/sbr/business/service/xmf/keystore.jks");
		defaultSecurityPolicy.setKeyStorePassword("6y7u8i");
		defaultSecurityPolicy.setCertificateAlias("SAIBRS");
		defaultSecurityPolicy.setPrivateKeyPassword(getJMSPasswordBean().getPassword());*/// need to get Provate key Password
		return defaultSecurityPolicy;
	}
	
	@Bean(name = "commonsPoolTargetSource")
	public CommonsPool2TargetSource getCommonsPoolTargetSource() throws ServiceProxyException {
		CommonsPool2TargetSource commonsPoolTargetSource = new CommonsPool2TargetSource();
		commonsPoolTargetSource.setTargetBeanName("serviceProxy");
		commonsPoolTargetSource.setMaxSize(3);
		commonsPoolTargetSource.setMaxIdle(3);
		commonsPoolTargetSource.setBlockWhenExhausted(false);
		return commonsPoolTargetSource;
	}
		
	@Bean(name="messageUtilities")
	public StaxMessageUtilities getMessageUtilities(){
		return new StaxMessageUtilities();
	}	
		
	@Bean(name="credentialProvider")
	public CredentialProvider getTimeOutCyberArkProvider() {
		if ("local".equalsIgnoreCase("local") == false) {
			FallbackTimeoutCyberArkCredentialProvider provider = new FallbackTimeoutCyberArkCredentialProvider(
					"Novell-eDirectory", "", "Dev", "EMA",
					"dema001");
			provider.setTimeout(15000);
			return provider;
		} else {
			CredentialProvider provider = new SimpleCredentialProvider("dema001", "GTC936eja");
			return provider;
		}
	}
		
	@Bean(name="userDetailsService")
	public UserDetailsService getCredentialsProviderUserDetailsService() {
		
		CredentialProviderUserDetailsService service=null;
		try {
			service = new CredentialProviderUserDetailsService(getTimeOutCyberArkProvider());
			
		} catch (Exception e) {
			throw new LmsException("Exception occured while creating CredentialProviderUserDetailsService object in XMFConfig.java class",e);
		}
		return service;
	}
	@Bean(name="daoAuthenticationProvider")
	public AuthenticationProvider getAuthenticationProvider() {
		DaoAuthenticationProvider auth = new DaoAuthenticationProvider();
		auth.setUserDetailsService(getCredentialsProviderUserDetailsService());
		auth.setHideUserNotFoundExceptions(false);
		return auth;
	}
	
	@Bean(name="authenticationManager")
	public ProviderManager getAuthenticationManager(){
		ProviderManager manager = new ProviderManager();
		List<AuthenticationProvider> providers = new ArrayList<AuthenticationProvider>();
		providers.add(getAuthenticationProvider());
		manager.setProviders(providers);
		return manager;
		
	}
		
}
