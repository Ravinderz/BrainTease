package com.uprr.ema.lms.common.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uprr.ema.lms.common.dao.api.CommonDao;
import com.uprr.ema.lms.common.service.api.CommonService;

@Service
public class CommonServiceImpl implements CommonService{

	@Autowired
	CommonDao commonDao;

}
