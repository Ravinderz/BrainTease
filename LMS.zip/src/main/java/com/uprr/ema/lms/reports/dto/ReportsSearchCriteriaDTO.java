package com.uprr.ema.lms.reports.dto;

import com.uprr.ema.lms.common.dto.SearchCriteriaDTO;

public class ReportsSearchCriteriaDTO extends SearchCriteriaDTO {
private static final long serialVersionUID = 1L;
}
