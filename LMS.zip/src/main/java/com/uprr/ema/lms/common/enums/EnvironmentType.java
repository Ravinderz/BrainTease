package com.uprr.ema.lms.common.enums;

import java.util.ArrayList;
import java.util.List;

public enum EnvironmentType { 

	LOCAL("local","LOCAL"),WIN("win", "WIN"), DEV("dev", "Development"), TEST("test", "Test"), PROD("prod", "Production");

	private String name;
	private String description;

	private EnvironmentType(final String newCode, final String newDescription) {
		this.name = newCode;
		this.description = newDescription;
	}
    public static boolean isLocal(final String environmentName) {
		return LOCAL.name.equalsIgnoreCase(environmentName);
	}
	public static boolean isWin(final String environmentName) {
		return WIN.name.equalsIgnoreCase(environmentName);
	}
    public static boolean isDevelopment(final String environmentName) {
		return DEV.name.equalsIgnoreCase(environmentName);
	}
    public static boolean isTest(final String environmentName) {
		return TEST.name.equalsIgnoreCase(environmentName);
	}
	public static boolean isProd(final String environmentName) {
		return PROD.name.equalsIgnoreCase(environmentName);
	}
    public static EnvironmentType getInstance(final String name) {
    	EnvironmentType env =null;
		for (EnvironmentType envType : values()) {
			if (null != envType.getName()
					&& envType.getName().equalsIgnoreCase(name)) {
				env= envType;
			}
		}
		return env;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	public static List<String> getListOfEnvironemnts() {
		List<String> envLst = new ArrayList<String>(3);
		envLst.add(EnvironmentType.DEV.getName());
		envLst.add(EnvironmentType.TEST.getName());
		envLst.add(EnvironmentType.PROD.getName());
		return envLst;
	}
}
