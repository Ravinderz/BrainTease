package com.uprr.ema.lms.liabilityProject.vb;

import java.io.Serializable;
import java.util.List;

//import com.uprr.ema.lms.common.vb.UserWebVB;


public class ProjectVB implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long projDtlID;
	private long projID;
	private String projectName;
	private Long projSrcId;
	private Long projTypeId;
	private Long projDriveId;
	private Long projEstmId;
	private Long projMgrId;
	private String city;
	private String state;
	private Long railRoadId;
	private String projOthDesc;
	private String reqActgFlag;
	private String npvDiscountFlag;
	private Double upprAllocPer;
	private String fnceAssurFlag;
	private String dAndTListFlag;
	private String costRcvyFlag;
	private Long fedLeadId;
	private String year15RuleFlag;
	private String operStatFlag;
	private Long balSheetId;
	private Long subAccId;
	private String accountNbrData;
	private String minStdgBlncFlag;
	private Double minStdBlncAmt;
	private List<ProjectCostVB> projectCostVBList;
	private List<ProjectCostVB> currentCostVBList;
	private List<ProjectCostVB> proposedCostVBList;
	private Long tubeLvlId;
	private Long changeReasonDtlId;
	private Long changeReasonMstrId;
	private String changeReasonDate;
	private String changeReasonComment;
	private String action;
	private String actionType;
	private String previousAction;
	private String previousActionType;
	private String closedMonth;
	private String closedYear;
	private String closedDate;
	private String projectDate;
	private String undergroundStorageTankFlag;
	private String actFlag;
	private String crtdUser;
	private String lastUptdUser;
	private String crtdDate;
	private String lastUptdDate;
	//private UserWebVB userWebVB;
	private String inputFrom;//represents what to do with the action like - P= project, C= change,S=Submitted
	private String intUprrLaborFlag;
	private String trackTimeFlag;
	private String telecomFlag;
	private boolean dataChangedFlag;
	private boolean changeResnDataChangedFlag;
	private boolean costDataChangedFlag;

	private String disaprvComments;
	private Long disaprvCmtDtlId;
	private String empId;
	/*
	 * This filed is used to track whether the changes are done to project 
	 * or cost or tube level. This data is used in mail notification of this project.
	*/
	private String changeType;
	
	/**
	 * @return the projectName
	 */
	public String getProjectName() {
		return projectName;
	}
	/**
	 * @param projectName the projectName to set
	 */
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	/**
	 * @return the projSrcId
	 */
	public Long getProjSrcId() {
		return projSrcId;
	}
	/**
	 * @param projSrcId the projSrcId to set
	 */
	public void setProjSrcId(Long projSrcId) {
		this.projSrcId = projSrcId;
	}
	/**
	 * @return the projTypeId
	 */
	public Long getProjTypeId() {
		return projTypeId;
	}
	/**
	 * @param projTypeId the projTypeId to set
	 */
	public void setProjTypeId(Long projTypeId) {
		this.projTypeId = projTypeId;
	}
	/**
	 * @return the projDriveId
	 */
	public Long getProjDriveId() {
		return projDriveId;
	}
	/**
	 * @param projDriveId the projDriveId to set
	 */
	public void setProjDriveId(Long projDriveId) {
		this.projDriveId = projDriveId;
	}
	/**
	 * @return the projEstmId
	 */
	public Long getProjEstmId() {
		return projEstmId;
	}
	/**
	 * @param projEstmId the projEstmId to set
	 */
	public void setProjEstmId(Long projEstmId) {
		this.projEstmId = projEstmId;
	}
	/**
	 * @return the projMgrId
	 */
	public Long getProjMgrId() {
		return projMgrId;
	}
	/**
	 * @param projMgrId the projMgrId to set
	 */
	public void setProjMgrId(Long projMgrId) {
		this.projMgrId = projMgrId;
	}
	/**
	 * @return the city
	 */
	public String getCity() {
		return city;
	}
	/**
	 * @param city the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}
	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}
	/**
	 * @param state the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}
	/**
	 * @return the railRoadId
	 */
	public Long getRailRoadId() {
		return railRoadId;
	}
	/**
	 * @param railRoadId the railRoadId to set
	 */
	public void setRailRoadId(Long railRoadId) {
		this.railRoadId = railRoadId;
	}
	/**
	 * @return the projOthDesc
	 */
	public String getProjOthDesc() {
		return projOthDesc;
	}
	/**
	 * @param projOthDesc the projOthDesc to set
	 */
	public void setProjOthDesc(String projOthDesc) {
		this.projOthDesc = projOthDesc;
	}
	/**
	 * @return the reqActgFlag
	 */
	public String getReqActgFlag() {
		return reqActgFlag;
	}
	/**
	 * @param reqActgFlag the reqActgFlag to set
	 */
	public void setReqActgFlag(String reqActgFlag) {
		this.reqActgFlag = reqActgFlag;
	}
	/**
	 * @return the npvDiscountFlag
	 */
	public String getNpvDiscountFlag() {
		return npvDiscountFlag;
	}
	/**
	 * @param npvDiscountFlag the npvDiscountFlag to set
	 */
	public void setNpvDiscountFlag(String npvDiscountFlag) {
		this.npvDiscountFlag = npvDiscountFlag;
	}
	/**
	 * @return the fnceAssurFlag
	 */
	public String getFnceAssurFlag() {
		return fnceAssurFlag;
	}
	/**
	 * @param fnceAssurFlag the fnceAssurFlag to set
	 */
	public void setFnceAssurFlag(String fnceAssurFlag) {
		this.fnceAssurFlag = fnceAssurFlag;
	}
	/**
	 * @return the costRcvyFlag
	 */
	public String getCostRcvyFlag() {
		return costRcvyFlag;
	}
	/**
	 * @param costRcvyFlag the costRcvyFlag to set
	 */
	public void setCostRcvyFlag(String costRcvyFlag) {
		this.costRcvyFlag = costRcvyFlag;
	}
	/**
	 * @return the fedLeadId
	 */
	public Long getFedLeadId() {
		return fedLeadId;
	}
	/**
	 * @param fedLeadId the fedLeadId to set
	 */
	public void setFedLeadId(Long fedLeadId) {
		this.fedLeadId = fedLeadId;
	}
	/**
	 * @return the year15RuleFlag
	 */
	public String getYear15RuleFlag() {
		return year15RuleFlag;
	}
	/**
	 * @param year15RuleFlag the year15RuleFlag to set
	 */
	public void setYear15RuleFlag(String year15RuleFlag) {
		this.year15RuleFlag = year15RuleFlag;
	}
	/**
	 * @return the operStatFlag
	 */
	public String getOperStatFlag() {
		return operStatFlag;
	}
	/**
	 * @param operStatFlag the operStatFlag to set
	 */
	public void setOperStatFlag(String operStatFlag) {
		this.operStatFlag = operStatFlag;
	}
	/**
	 * @return the balSheetId
	 */
	public Long getBalSheetId() {
		return balSheetId;
	}
	/**
	 * @param balSheetId the balSheetId to set
	 */
	public void setBalSheetId(Long balSheetId) {
		this.balSheetId = balSheetId;
	}
	/**
	 * @return the subAccId
	 */
	public Long getSubAccId() {
		return subAccId;
	}
	/**
	 * @param subAccId the subAccId to set
	 */
	public void setSubAccId(Long subAccId) {
		this.subAccId = subAccId;
	}
	/**
	 * @return the accountNbrData
	 */
	public String getAccountNbrData() {
		return accountNbrData;
	}
	/**
	 * @param accountNbrData the accountNbrData to set
	 */
	public void setAccountNbrData(String accountNbrData) {
		this.accountNbrData = accountNbrData;
	}
	/**
	 * @return the tubeLvlId
	 */
	public Long getTubeLvlId() {
		return tubeLvlId;
	}
	/**
	 * @param tubeLvlId the tubeLvlId to set
	 */
	public void setTubeLvlId(Long tubeLvlId) {
		this.tubeLvlId = tubeLvlId;
	}
	
	
	/**
	 * @return the changeReasonMstrId
	 */
	public Long getChangeReasonMstrId() {
	    return changeReasonMstrId;
	}
	/**
	 * @param changeReasonMstrId the changeReasonMstrId to set
	 */
	public void setChangeReasonMstrId(Long changeReasonMstrId) {
	    this.changeReasonMstrId = changeReasonMstrId;
	}
	/**
	 * @return the closedDate
	 */
	public String getClosedDate() {
		return closedDate;
	}
	/**
	 * @param closedDate the closedDate to set
	 */
	public void setClosedDate(String closedDate) {
		this.closedDate = closedDate;
	}
	/**
	 * @return the actFlag
	 */
	public String getActFlag() {
		return actFlag;
	}
	/**
	 * @param actFlag the actFlag to set
	 */
	public void setActFlag(String actFlag) {
		this.actFlag = actFlag;
	}
	/**
	 * @return the crtdUser
	 */
	public String getCrtdUser() {
		return crtdUser;
	}
	/**
	 * @param crtdUser the crtdUser to set
	 */
	public void setCrtdUser(String crtdUser) {
		this.crtdUser = crtdUser;
	}
	/**
	 * @return the lastUptdUser
	 */
	public String getLastUptdUser() {
		return lastUptdUser;
	}
	/**
	 * @param lastUptdUser the lastUptdUser to set
	 */
	public void setLastUptdUser(String lastUptdUser) {
		this.lastUptdUser = lastUptdUser;
	}
	/**
	 * @return the crtdDate
	 */
	public String getCrtdDate() {
		return crtdDate;
	}
	/**
	 * @param crtdDate the crtdDate to set
	 */
	public void setCrtdDate(String crtdDate) {
		this.crtdDate = crtdDate;
	}
	/**
	 * @return the lastUptdDate
	 */
	public String getLastUptdDate() {
		return lastUptdDate;
	}
	/**
	 * @param lastUptdDate the lastUptdDate to set
	 */
	public void setLastUptdDate(String lastUptdDate) {
		this.lastUptdDate = lastUptdDate;
	}
	/**
	 * @return the serialversionuid
	 */
	public static Long getSerialversionuid() {
		return serialVersionUID;
	}
	/**
	 * @return the minStdgBlncFlag
	 */
	public String getMinStdgBlncFlag() {
		return minStdgBlncFlag;
	}
	/**
	 * @param minStdgBlncFlag the minStdgBlncFlag to set
	 */
	public void setMinStdgBlncFlag(String minStdgBlncFlag) {
		this.minStdgBlncFlag = minStdgBlncFlag;
	}
	
	/**
	 * @return the projectCostVBList
	 */
	public List<ProjectCostVB> getProjectCostVBList() {
		return projectCostVBList;
	}
	/**
	 * @param projectCostVBList the projectCostVBList to set
	 */
	public void setProjectCostVBList(List<ProjectCostVB> projectCostVBList) {
		this.projectCostVBList = projectCostVBList;
	}
	
	
	/**
	 * @return the projectDate
	 */
	public String getProjectDate() {
		return projectDate;
	}
	/**
	 * @param projectDate the projectDate to set
	 */
	public void setProjectDate(String projectDate) {
		this.projectDate = projectDate;
	}
	public String getdAndTListFlag() {
		return dAndTListFlag;
	}
	public void setdAndTListFlag(String dAndTListFlag) {
		this.dAndTListFlag = dAndTListFlag;
	}
	/**
	 * @return the projID
	 */
	public long getProjID() {
		return projID;
	}
	/**
	 * @param projID the projID to set
	 */
	public void setProjID(long projID) {
		this.projID = projID;
	}
	/**
	 * @return the changeReasonDtlId
	 */
	public Long getChangeReasonDtlId() {
	    return changeReasonDtlId;
	}
	/**
	 * @param changeReasonDtlId the changeReasonDtlId to set
	 */
	public void setChangeReasonDtlId(Long changeReasonDtlId) {
	    this.changeReasonDtlId = changeReasonDtlId;
	}
	public String getChangeReasonDate() {
	    return changeReasonDate;
	}
	public void setChangeReasonDate(String changeReasonDate) {
	    this.changeReasonDate = changeReasonDate;
	}
	public String getChangeReasonComment() {
	    return changeReasonComment;
	}
	public void setChangeReasonComment(String changeReasonComment) {
	    this.changeReasonComment = changeReasonComment;
	}
	/**
	 * @return the action
	 */
	public String getAction() {
	    return action;
	}
	/**
	 * @param action the action to set
	 */
	public void setAction(String action) {
	    this.action = action;
	}
	/**
	 * @return the actionType
	 */
	public String getActionType() {
	    return actionType;
	}
	/**
	 * @param actionType the actionType to set
	 */
	public void setActionType(String actionType) {
	    this.actionType = actionType;
	}
	/**
	 * @return the currentCostVBList
	 */
	public List<ProjectCostVB> getCurrentCostVBList() {
	    return currentCostVBList;
	}
	/**
	 * @param currentCostVBList the currentCostVBList to set
	 */
	public void setCurrentCostVBList(List<ProjectCostVB> currentCostVBList) {
	    this.currentCostVBList = currentCostVBList;
	}
	/**
	 * @return the proposedCostVBList
	 */
	public List<ProjectCostVB> getProposedCostVBList() {
	    return proposedCostVBList;
	}
	/**
	 * @return the inputFrom
	 */
	public String getInputFrom() {
		return inputFrom;
	}
	/**
	 * @param inputFrom the inputFrom to set
	 */
	public void setInputFrom(String inputFrom) {
		this.inputFrom = inputFrom;
	}
	/**
	 * @return the intUprrLaborFlag
	 */
	public String getIntUprrLaborFlag() {
		return intUprrLaborFlag;
	}
	/**
	 * @param intUprrLaborFlag the intUprrLaborFlag to set
	 */
	public void setIntUprrLaborFlag(String intUprrLaborFlag) {
		this.intUprrLaborFlag = intUprrLaborFlag;
	}
	/**
	 * @return the trackTimeFlag
	 */
	public String getTrackTimeFlag() {
		return trackTimeFlag;
	}
	/**
	 * @param trackTimeFlag the trackTimeFlag to set
	 */
	public void setTrackTimeFlag(String trackTimeFlag) {
		this.trackTimeFlag = trackTimeFlag;
	}
	/**
	 * @return the telecomFlag
	 */
	public String getTelecomFlag() {
		return telecomFlag;
	}
	/**
	 * @param telecomFlag the telecomFlag to set
	 */
	public void setTelecomFlag(String telecomFlag) {
		this.telecomFlag = telecomFlag;
	}
	
	/**
	 * @return the projDtlID
	 */
	public long getProjDtlID() {
	    return projDtlID;
	}
	/**
	 * @param projDtlID the projDtlID to set
	 */
	public void setProjDtlID(long projDtlID) {
	    this.projDtlID = projDtlID;
	}
	
	
	/**
	 * @return the dataChangedFlag
	 */
	public boolean isDataChangedFlag() {
	    return dataChangedFlag;
	}
	/**
	 * @param dataChangedFlag the dataChangedFlag to set
	 */
	public void setDataChangedFlag(boolean dataChangedFlag) {
	    this.dataChangedFlag = dataChangedFlag;
	}
	/**
	 * @return the changeResnDataChangedFlag
	 */
	public boolean isChangeResnDataChangedFlag() {
	    return changeResnDataChangedFlag;
	}
	/**
	 * @param changeResnDataChangedFlag the changeResnDataChangedFlag to set
	 */
	public void setChangeResnDataChangedFlag(boolean changeResnDataChangedFlag) {
	    this.changeResnDataChangedFlag = changeResnDataChangedFlag;
	}
	/**
	 * @param proposedCostVBList the proposedCostVBList to set
	 */
	public void setProposedCostVBList(List<ProjectCostVB> proposedCostVBList) {
		this.proposedCostVBList = proposedCostVBList;
	}
	
	/**
	 * @return the previousAction
	 */
	public String getPreviousAction() {
	    return previousAction;
	}
	/**
	 * @param previousAction the previousAction to set
	 */
	public void setPreviousAction(String previousAction) {
	    this.previousAction = previousAction;
	}
	/**
	 * @return the previousActionType
	 */
	public String getPreviousActionType() {
	    return previousActionType;
	}
	/**
	 * @param previousActionType the previousActionType to set
	 */
	public void setPreviousActionType(String previousActionType) {
	    this.previousActionType = previousActionType;
	}
	/**
	 * @return the disaprvComments
	 */
	public String getDisaprvComments() {
		return disaprvComments;
	}
	/**
	 * @param disaprvComments the disaprvComments to set
	 */
	public void setDisaprvComments(String disaprvComments) {
		this.disaprvComments = disaprvComments;
	}
	/**
	 * @return the disaprvCmtDtlId
	 */
	public Long getDisaprvCmtDtlId() {
		return disaprvCmtDtlId;
	}
	/**
	 * @param disaprvCmtDtlId the disaprvCmtDtlId to set
	 */
	public void setDisaprvCmtDtlId(Long disaprvCmtDtlId) {
		this.disaprvCmtDtlId = disaprvCmtDtlId;
	}
	/**
	 * @return the changeType
	 */
	public String getChangeType() {
	    return changeType;
	}
	/**
	 * @param changeType the changeType to set
	 */
	public void setChangeType(String changeType) {
	    this.changeType = changeType;
	}
	public boolean isCostDataChangedFlag() {
	    return costDataChangedFlag;
	}
	public void setCostDataChangedFlag(boolean costDataChangedFlag) {
	    this.costDataChangedFlag = costDataChangedFlag;
	}
	
	public String getClosedMonth() {
	    return closedMonth;
	}
	public void setClosedMonth(String closedMonth) {
	    this.closedMonth = closedMonth;
	}
	public String getClosedYear() {
	    return closedYear;
	}
	public void setClosedYear(String closedYear) {
	    this.closedYear = closedYear;
	}
	/**
	 * @return the empId
	 */
	public String getEmpId() {
		return empId;
	}
	/**
	 * @param empId the empId to set
	 */
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public String getUndergroundStorageTankFlag() {
	    return undergroundStorageTankFlag;
	}
	public void setUndergroundStorageTankFlag(String undergroundStorageTankFlag) {
	    this.undergroundStorageTankFlag = undergroundStorageTankFlag;
	}
	public Double getUpprAllocPer() {
	    return upprAllocPer;
	}
	public void setUpprAllocPer(Double upprAllocPer) {
	    this.upprAllocPer = upprAllocPer;
	}
	public Double getMinStdBlncAmt() {
	    return minStdBlncAmt;
	}
	public void setMinStdBlncAmt(Double minStdBlncAmt) {
	    this.minStdBlncAmt = minStdBlncAmt;
	}
	
}
