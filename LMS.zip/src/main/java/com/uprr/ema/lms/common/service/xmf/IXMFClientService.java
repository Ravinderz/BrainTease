package com.uprr.ema.lms.common.service.xmf;

import com.uprr.ema.lms.exception.LmsException;

public interface IXMFClientService {


	String SECURE_TYPE = "SECURE";
	String UNSECURE_TYPE = "UNSECURE";
	String PRIVATE_TYPE = "PRIVATE";
	long SERVICE_UNIT_TIME_TO_LIVE = 1 * 60 * 1000L;    // 1 minutes
	long TIME_TO_LIVE = 5 * 60 * 1000L;    // 5 minutes
	String PERSON_GET_SERVICE_NAME = "person/get-cached-employee-details-3_0";
	String PERSON_GET_NAMESPACE = "http://services.www.up.com/" + PERSON_GET_SERVICE_NAME;
	
	

	/**
	 * @param serviceSecurityType
	 * @param serviceName
	 * @param empRequestXML
	 * @return
	 */
	public String getXMFDataByServiceDtls(String serviceSecurityType, String serviceName, String empRequestXML) throws LmsException;
	

}
