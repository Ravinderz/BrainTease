package com.uprr.ema.lms.common.dao.api;

public interface CommonDao {

}
