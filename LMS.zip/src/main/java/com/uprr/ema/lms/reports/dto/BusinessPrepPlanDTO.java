package com.uprr.ema.lms.reports.dto;

public class BusinessPrepPlanDTO {

	private String estimtor;
	private String fiscper;
	private String woDesc;
	private String activity;
	private String network;
	private String desc;
	private String invoiceNumber;
	private String amount;
	private String siteRemManager;
	public String getEstimtor() {
		return estimtor;
	}
	public void setEstimtor(String estimtor) {
		this.estimtor = estimtor;
	}
	public String getFiscper() {
		return fiscper;
	}
	public void setFiscper(String fiscper) {
		this.fiscper = fiscper;
	}
	public String getWoDesc() {
		return woDesc;
	}
	public void setWoDesc(String woDesc) {
		this.woDesc = woDesc;
	}
	public String getActivity() {
		return activity;
	}
	public void setActivity(String activity) {
		this.activity = activity;
	}
	public String getNetwork() {
		return network;
	}
	public void setNetwork(String network) {
		this.network = network;
	}

	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public String getInvoiceNumber() {
		return invoiceNumber;
	}
	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getSiteRemManager() {
		return siteRemManager;
	}
	public void setSiteRemManager(String siteRemManager) {
		this.siteRemManager = siteRemManager;
	}
	public BusinessPrepPlanDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public BusinessPrepPlanDTO(String estimtor, String fiscper, String woDesc, String activity, String network,
			String desc, String invoiceNumber, String amount, String siteRemManager) {
		super();
		this.estimtor = estimtor;
		this.fiscper = fiscper;
		this.woDesc = woDesc;
		this.activity = activity;
		this.network = network;
		this.desc = desc;
		this.invoiceNumber = invoiceNumber;
		this.amount = amount;
		this.siteRemManager = siteRemManager;
	}
	@Override
	public String toString() {
		return "BusinessPrepPlanDTO [estimtor=" + estimtor + ", fiscper=" + fiscper + ", woDesc=" + woDesc
				+ ", activity=" + activity + ", network=" + network + ", desc=" + desc + ", invoiceNumber="
				+ invoiceNumber + ", amount=" + amount + ", siteRemManager=" + siteRemManager + "]";
	}
	
	
	
}
