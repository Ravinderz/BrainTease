package com.uprr.ema.lms.common.dto;

public class DocumentDTO {

	private String docId;
	private String guid;
	private String docName;
	private String docDesc;
	private String docCmnt;
	private String docType;
	private String mimeType;
	private String activeFlag;
	private String selectedDate;
	private String createdBy;
	public String getDocId() {
		return docId;
	}
	public void setDocId(String docId) {
		this.docId = docId;
	}
	public String getGuid() {
		return guid;
	}
	public void setGuid(String guid) {
		this.guid = guid;
	}
	public String getDocName() {
		return docName;
	}
	public void setDocName(String docName) {
		this.docName = docName;
	}
	public String getDocDesc() {
		return docDesc;
	}
	public void setDocDesc(String docDesc) {
		this.docDesc = docDesc;
	}
	public String getDocCmnt() {
		return docCmnt;
	}
	public void setDocCmnt(String docCmnt) {
		this.docCmnt = docCmnt;
	}
	public String getDocType() {
		return docType;
	}
	public void setDocType(String docType) {
		this.docType = docType;
	}
	public String getMimeType() {
		return mimeType;
	}
	public void setMimeType(String mimeType) {
		this.mimeType = mimeType;
	}
	public String getActiveFlag() {
		return activeFlag;
	}
	public void setActiveFlag(String activeFlag) {
		this.activeFlag = activeFlag;
	}
	
	public String getSelectedDate() {
		return selectedDate;
	}
	public void setSelectedDate(String selectedDate) {
		this.selectedDate = selectedDate;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public DocumentDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public DocumentDTO(String docId, String guid, String docName, String docDesc, String docCmnt, String docType,
			String mimeType, String activeFlag, String selectedDate, String createdBy) {
		super();
		this.docId = docId;
		this.guid = guid;
		this.docName = docName;
		this.docDesc = docDesc;
		this.docCmnt = docCmnt;
		this.docType = docType;
		this.mimeType = mimeType;
		this.activeFlag = activeFlag;
		this.selectedDate = selectedDate;
		this.createdBy = createdBy;
	}
	@Override
	public String toString() {
		return "DocumentDTO [docId=" + docId + ", guid=" + guid + ", docName=" + docName + ", docDesc=" + docDesc
				+ ", docCmnt=" + docCmnt + ", docType=" + docType + ", mimeType=" + mimeType + ", activeFlag="
				+ activeFlag + ", selectedDate=" + selectedDate + ", createdBy=" + createdBy + "]";
	}
	
	
	
	 
	
}
