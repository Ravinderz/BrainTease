package com.uprr.ema.lms.liabilityProject.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.uprr.ema.lms.liabilityProject.helper.LiabilityProjectHelper;
import com.uprr.ema.lms.reports.helper.ReportsHelper;
import com.uprr.ema.lms.searchproject.service.api.ProjectSearchService;


@RestController
@RequestMapping("/lewbreports")
public class GenerateLEWBController {

    @Autowired
    LiabilityProjectHelper liabProjHelper;
    
    @Autowired
    ProjectSearchService projectSearchService;
    
    @Autowired
	 public Environment environment;
    

	@Autowired
	private ReportsHelper reportsHelper;

    /**
     * This method is used to fetch look up data
     * @param 
     * @return ProjectOnLoadVB
     * @
     */
    private static final Logger LOGGER = Logger.getLogger(GenerateLEWBController.class);
    
    @RequestMapping(value = "/generateLewbReport/{month}/{year}", method = RequestMethod.GET)
    @ResponseBody
    public void generateLewbReport(HttpServletResponse response,@PathVariable("month") String month,@PathVariable("year") String year) throws IOException{
    	try{
    		
    		reportsHelper.generateLewbReort(response,month,year,"LEWB");
		    	
    	}
		 	catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    } 
	

	
    
    
}
