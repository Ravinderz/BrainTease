package com.uprr.ema.lms.common.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.uprr.ema.lms.common.dao.api.LookupDao;
import com.uprr.ema.lms.common.dto.DropDownInfo;
import com.uprr.ema.lms.common.dto.ManagerDTO;
import com.uprr.ema.lms.common.service.api.LookupService;

/**
 * This class is used to deal with master data. This class talks with DAO later to get 
 * master data.
 * @author xprk803
 *
 */

@Service
public class LookupServiceImpl implements LookupService {

	@Autowired
	private LookupDao lookupDao;

	/**
	 * {@inheritDoc}
	 */
	@Transactional
	@Override
	public List<DropDownInfo> getDropDownOnLoad(String tableName, String code, String desc,String masterId,String sortOrdNbr)  {
		return lookupDao.getDropDownOnLoad(tableName, code, desc,masterId,sortOrdNbr);
	}
	
	
	@Override
	public List<DropDownInfo> getDropDownOnLoadForId(String tableName,String codeId, String code, String desc)  {
		return lookupDao.getDropDownOnLoadForId(tableName, codeId,code, desc);
	}
	
	
	
	
	
	
	/**
	 * {@inheritDoc}
	 */
	@Transactional
	@Override
	public List<ManagerDTO> getManagers() {
		return lookupDao.getManagers();
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Transactional
	@Override
	public List<DropDownInfo> getStates(){
		return lookupDao.getStates();
	}
	/* may be used later */


	@Override
	public DropDownInfo getDropDownInfoByCode(String tableName, String masterIdColumn, String codeColumn,
		String descprtionColumn, String codeValue) {
	    // TODO Auto-generated method stub
	    return null;
	}
	
	
	/**
	 * {@inheritDoc}
	 *//*
	@Override
	public List<DropDownInfo> getDropDownOnLoad(String tableName, String code, String alternateCode, String desc)
			 {
		// TODO Auto-generated method stub
		return lookupDao.getDropDownOnLoad(tableName, code, alternateCode, desc);
	}
	*//**
	 * {@inheritDoc}
	 *//*
	@Override
	public List<DropDownInfo> getDropDownOnLoadOrderBy(String tableName, String code, String alternateCode, String desc, String orderBy)
			 {
		// TODO Auto-generated method stub
		return lookupDao.getDropDownOnLoadOrderBy(tableName, code, alternateCode, desc, orderBy);
	}
	
	public List<DropDownInfo> getDropDownsBySortOrder(String tableName, String id, 
		String code, String desc, String orderByColumn){
	    return lookupDao.getDropDownsBySortOrder(tableName, id, code, desc, orderByColumn);
	}
	
	*//**
	 * This is used to get only the drop down values for EMA Group.
	 * Here all the groups from the database are not required.
	 * Some of the groups are added for the user purpose. Those groups are not be added.
	 * @param tableName
	 * @param code
	 * @param alternateCode
	 * @param desc
	 * @return
	 * @
	 *//*
	@Override
	public List<DropDownInfo> getDropDownOnLoadForGroups(String tableName, String code, String alternateCode, String desc)  {
	    List<DropDownInfo> groups =  lookupDao.getDropDownOnLoad(tableName, code, alternateCode, desc);
	    List<DropDownInfo> fianlgrps =  null;
	    if(groups!=null && !groups.isEmpty()){
		fianlgrps =  new ArrayList<DropDownInfo>(groups.size());
		for (DropDownInfo dropDownInfo : groups) {
		    if(!(dropDownInfo.getCode().equalsIgnoreCase(ServiceConstants.GRP_MSTR_CENOZOIC)
			    || dropDownInfo.getCode().equalsIgnoreCase(ServiceConstants.GRP_MSTR_UP_SITEREM) ||
			    dropDownInfo.getCode().equalsIgnoreCase(ServiceConstants.GRP_MSTR_DOC_CMR) ||
			    dropDownInfo.getCode().equalsIgnoreCase(ServiceConstants.GRP_MSTR_RCM) ||
			    dropDownInfo.getCode().equalsIgnoreCase(ServiceConstants.GRP_MSTR_KMS) ||
			    dropDownInfo.getCode().equalsIgnoreCase(ServiceConstants.GRP_MSTR_CRA))){
			fianlgrps.add(dropDownInfo);
		    }
		}
	    }
	    return fianlgrps;
	}
	
	
	
	*//**
	 * {@inheritDoc}
	 *//*
	@Override
	public List<DropDownInfo> getDropDownOnLoadForId(String tableName, 
		String codeId, String code, String desc)  {
		return lookupDao.getDropDownOnLoadForId(tableName, codeId, code, desc);
	}
	

	*//**
	 * {@inheritDoc}
	 *//*
	@Override
	public List<DropDownInfo> getInspListByRole(UserWebVB user)
			 {
		return lookupDao.getInspListByRole(user);
	}
	
	@Override
	public List<MultiSelect> getMultiSelectList(String id ,String tableName, String code, String desc)  {
		return lookupDao.getMultiSelectList(id, tableName, code, desc);
	}

	@Override
	public List<MailPropInspectionDTO> getInspectionPropDtls(String searchCriteria)  {
		 return this.lookupDao.getInspectionPropDtls(searchCriteria);
	}

	*//**
	 * {@inheritDoc}
	 *//*
	@Override
	public List<MultiSelect> getMultiSelectListForLeseResp(String id, String tableName, String code, String desc)  {
		return lookupDao.getMultiSelectListForLeseResp(id, tableName, code, desc);
	}
	
	*//**
	 * {@inheritDoc}
	 *//*
	//@Override
	public DropDownInfo getDropDownInfoByMstrId(long masterId, String tableName)  {
		return lookupDao.getDropDownInfoByMstrId(masterId, tableName);
	}
	
	public DropDownInfo getDropDownInfoByCode(String tableName,String masterIdColumn,
		String codeColumn,String descprtionColumn,String codeValue)  {
	    return lookupDao.getDropDownInfoByCode(tableName,masterIdColumn,
		    codeColumn,descprtionColumn,codeValue);
	}

	*//**
	 * {@inheritDoc}
	 *//*
	@Override
	public List<String> getCustomerNamesFromREMS(String custName)  {
		return propertyREMSDAO.getCustomerNamesFromREMS(custName);
	}
	
	*//**
	 * <p> Get Desription From Master Table based on Its Master Code </p>
	 *//*
	public String getDescription(String tableName,String masterCodeColumnName,String masterCode){
		return lookupDao.getDescription(tableName,masterCodeColumnName,masterCode);
	}

	@Override
	public List<DropDownInfo> getDropDownOnLoadForGroups(String tableName, String code, String alternateCode,
			String desc) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<String> getCustomerNamesFromREMS(String custName) {
		// TODO Auto-generated method stub
		return null;
	}*/

}
