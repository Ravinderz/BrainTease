package com.uprr.ema.lms.searchproject.controller;

import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.uprr.ema.lms.common.dto.DropDownInfo;
import com.uprr.ema.lms.common.service.api.IAuthorizationService;
import com.uprr.ema.lms.searchproject.helper.ProjectSearchHelper;
import com.uprr.ema.lms.searchproject.vb.ProjectSearchCriteriaVB;
import com.uprr.ema.lms.searchproject.vb.SearchCriteriaResponse;
import com.uprr.ema.lms.searchproject.vb.SearchOnloadVB;
import com.uprr.ema.lms.searchproject.vb.SearchVB;
import com.uprr.ui.shared.user.ActiveUserId;
import com.uprr.ui.shared.user.spring.mvc.ActiveUser;

@RestController
@RequestMapping("/projectsearch")
public class SearchProjectController {

	@Autowired
	private ProjectSearchHelper searchHelper;
	
	@Autowired
	private IAuthorizationService autherizationService;
	
	

	@GetMapping
	/*@Authorize(
    actions = {@Attribute(key="action-id", value="view")},
    resources = {@Attribute(key="resource-id", value="environmental-liabilities"),@Attribute(key="feature-id", value="project-summaries")}
    )*/
	public SearchOnloadVB getOnload(@ActiveUser ActiveUserId activeUser){
		//if(autherizationService.canSearchProject(activeUser.getUserId()))
		return searchHelper.getOnloadData(activeUser.getUserId());
	/*	else
		return null;*/
	}
	@RequestMapping(value="/project/{projectName}",method=RequestMethod.GET)
	public List<DropDownInfo> getOnload(@PathVariable("projectName") String projectName){
		return searchHelper.getProjectNames(projectName);
	}
	
	/***
	 * <p>
	 * Retrieves the {@link SecurityRoleVO} records with pagination concept
	 * </p>
	 * 
	 * @param paginationVO
	 *            - pagination information
	 * @return {@link List} containing {@link SecurityRoleVO} objects
	 **/
	@RequestMapping(value = "/projectSearchThroughPagination", method = RequestMethod.POST)
	public SearchCriteriaResponse<SearchVB> getSecurityRolesThroughPagination(
			@RequestBody final ProjectSearchCriteriaVB projectSearchCriteriaVB) {
		return searchHelper.getSecurityRolesThroughPagination(projectSearchCriteriaVB);
	}
	
	@RequestMapping(value = "/excelReport", method = RequestMethod.POST)
	public void getExcelReport(HttpServletResponse response,
			@RequestBody final SearchVB searchVB)throws Exception {
		    searchHelper.getExcelReport(response,searchVB);
	}
	
	
}
