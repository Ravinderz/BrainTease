package com.uprr.ema.lms.liabilityProject.service.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.uprr.ema.lms.common.LmsLogger;
import com.uprr.ema.lms.common.dao.api.LookupDao;
import com.uprr.ema.lms.common.dto.DropDownInfo;
import com.uprr.ema.lms.common.dto.SendMailDTO;
import com.uprr.ema.lms.common.enums.ActionInputType;
import com.uprr.ema.lms.common.enums.GroupType;
import com.uprr.ema.lms.common.service.api.IAuthorizationService;
import com.uprr.ema.lms.common.service.api.IENAEmailService;
import com.uprr.ema.lms.common.service.api.IGetEmployeeDetails;
import com.uprr.ema.lms.common.service.api.IGetGroupMembers;
import com.uprr.ema.lms.common.service.api.LookupService;
import com.uprr.ema.lms.common.service.util.LMSUtils;
import com.uprr.ema.lms.common.service.util.ServiceConstants;
import com.uprr.ema.lms.common.util.CommonUtils;
import com.uprr.ema.lms.common.web.util.WebDateUtil;
import com.uprr.ema.lms.liabilityProject.dao.api.LiabilityProjectDao;
import com.uprr.ema.lms.liabilityProject.dto.AccountCostDTO;
import com.uprr.ema.lms.liabilityProject.dto.DisapproveProjDTO;
import com.uprr.ema.lms.liabilityProject.dto.ProjectCostDTO;
import com.uprr.ema.lms.liabilityProject.dto.ProjectDTO;
import com.uprr.ema.lms.liabilityProject.service.api.LiabilityProjectService;
import com.uprr.ema.lms.liabilityProject.vb.ProjectCostVB;
import com.uprr.ema.lms.liabilityProject.vb.ProjectOnLoadVB;
import com.uprr.ema.lms.reports.service.api.ReportsService;

/**
 * This class delegates the request to DAO layer and sends the response back to
 * the called method.
 * 
 * The methods in this class will invoke the corresponding DAO methods to
 * process the request.
 * 
 * @author xprk208
 * 
 */
@Service
public class LiabilityProjectServiceImpl implements LiabilityProjectService {

	@Autowired
	LiabilityProjectDao liabProjtDao;

	@Autowired
	LookupService lookupService;
	
	@Autowired
	ReportsService reportsService;

	@Autowired
	IENAEmailService emailService;

	@Autowired
	LookupDao lookupDao;
	
	@Autowired
	private IGetEmployeeDetails getEmployeeDetails;
	
	@Autowired
	private IAuthorizationService autherizationService;
	
	@Autowired
	private IGetGroupMembers groupMembers;

	private static final LmsLogger logger = LmsLogger.getLogger(LiabilityProjectServiceImpl.class);

	/** {@inheritDoc} */
	@Transactional
	@Override
	public ProjectOnLoadVB getLookUpData() {
		ProjectOnLoadVB projectOnLoadVB = getMasterData();
		
		projectOnLoadVB.setCurrentCostVBList(getCurrentCosts());
		
		return projectOnLoadVB;
	}
	@Override
	public List<Integer> getUpto15Years() {
		Calendar now = Calendar.getInstance();   // Gets the current date and time
		int year = now.get(Calendar.YEAR); 
		List<Integer> next15Years=new ArrayList<Integer>();
		next15Years.add(year);
		for(int i=1;i<=3;i++){
			next15Years.add(year-i);
		}
		
		return next15Years;
	}

	@Override
	public List<ProjectDTO> getPendignApprovalProjects() {
		return liabProjtDao.getPendignApprovalProjects();
	}

	@Override
	public List<ProjectDTO> getDisApprovedProjects() {
		return liabProjtDao.getDisApprovedProjects();
	}
	
	public static Set<String> getDistinctValues(List<AccountCostDTO> list){
		Set<String> networkNumberSet = new HashSet<>();
		for(AccountCostDTO dto : list){
			networkNumberSet.add(dto.getNetwork());
		}
		return networkNumberSet;
	}
	
	/*@Override
	public List<AccountCostDTO> getAccountUpdate() {
	    List<AccountCostDTO> oracleCostList= liabProjtDao.getAccountUpdate();
	    HashMap<String, AccountCostDTO> oracleCostMap = new HashMap<String, AccountCostDTO>(oracleCostList.size());
	    //List<AccountCostDTO> netWorks = reportsService.getAccountData();
	    Set<AccountCostDTO> netWorkSet = null;
	    List<AccountCostDTO> negativeSpendProjs  = liabProjtDao.getSAPAccountUpdate(getDistinctValues(reportsService.getAccountData()));
	    //StringBuffer comaSeapratedNetworkNumbers = null;
	    //String networkNumbers = null;
	    if(netWorks!=null && !netWorks.isEmpty()){
		comaSeapratedNetworkNumbers = new StringBuffer("");
		for (Iterator<AccountCostDTO> iterator = netWorks.iterator(); iterator.hasNext();) {
		    AccountCostDTO accountCostDTO = (AccountCostDTO) iterator.next();
		    comaSeapratedNetworkNumbers = comaSeapratedNetworkNumbers.append(",").append(accountCostDTO.getNetwork());
		}
		networkNumbers = comaSeapratedNetworkNumbers.toString().substring(1);
		
		
		
		
		
		list2 = liabProjtDao.getSAPAccountUpdate(networkNumbers);
	    }
	    if(negativeEstmatesProjs!=null && negativeSpendProjs!=null && !negativeSpendProjs.isEmpty()){
		netWorkSet = new HashSet<AccountCostDTO>();
		for (AccountCostDTO accountCostDTO : negativeEstmatesProjs) {
		    netWorkSet.add(accountCostDTO);
		}
		for (AccountCostDTO accountCostDTO : negativeSpendProjs) {
		    netWorkSet.add(accountCostDTO);
		}
		negativeEstmatesProjs = new ArrayList<AccountCostDTO>(netWorkSet);
		
	    }else if(negativeEstmatesProjs!=null){
		return negativeEstmatesProjs;
	    }else if(negativeSpendProjs!=null){
		return negativeSpendProjs;
	    }
	    return negativeEstmatesProjs;
	}*/
	
	@Override
	public List<AccountCostDTO> getAccountUpdate() {
	    return liabProjtDao.getAccountUpdate();
	}
	
	@Override
	public void setAccountUpdate(String userId) {
	    List<AccountCostDTO> oracleCostList= liabProjtDao.getOracleAccountUpdate();
	    List<AccountCostDTO> oracleCostNegativeList = null;
	    List<AccountCostDTO> teradataCostNegativeList = null;
	    List<AccountCostDTO> balanceNegativeList = null;
	    List<AccountCostDTO> accountUpdateList = null;
	    String networkNumbers = null;
	    HashMap<String, AccountCostDTO> oracleCostMap =null;
	    StringBuffer comaSeapratedNetworkNumbers = null;
	    if(oracleCostList!=null && oracleCostList!=null && !oracleCostList.isEmpty()){
		oracleCostMap = new HashMap<String, AccountCostDTO>(oracleCostList.size());
		comaSeapratedNetworkNumbers = new StringBuffer("");
		for (AccountCostDTO accountCostDTO : oracleCostList) {
		    oracleCostMap.put(accountCostDTO.getAccountNbrData(),accountCostDTO);
		    comaSeapratedNetworkNumbers = comaSeapratedNetworkNumbers.append(",").append(accountCostDTO.getAccountNbrData());
		    if(accountCostDTO.getAmount()!=null && accountCostDTO.getAmount() < 0){
			if(oracleCostNegativeList == null){
			    oracleCostNegativeList = new ArrayList<AccountCostDTO> ();
			}
			//accountCostDTO.setAccountDesc("Liability Estimate Cost cannot be negative");
			accountCostDTO.setAccountTypeMstrId(2);
			setAccountCostDTOAuditVlaues(accountCostDTO,userId);
			oracleCostNegativeList.add(accountCostDTO);
		    }
		}
		networkNumbers = comaSeapratedNetworkNumbers.toString().substring(1);
	    }
	    List<AccountCostDTO>  teraDataCostList = reportsService.getAccountData(networkNumbers);
	    if(teraDataCostList!=null && teraDataCostList!=null && !teraDataCostList.isEmpty()){
		for (AccountCostDTO teraDataAccountCostDTO : teraDataCostList) {
		    if(teraDataAccountCostDTO.getAmount()!=null && teraDataAccountCostDTO.getAmount() < 0){
			if(teradataCostNegativeList == null){
			    teradataCostNegativeList = new ArrayList<AccountCostDTO> ();
			}
			AccountCostDTO accountCostDTOFromMap = oracleCostMap.get(teraDataAccountCostDTO.getAccountNbrData());
			//accountCostDTOFromMap.setAccountDesc("Spent Amount cannot be negative");
			accountCostDTOFromMap.setAccountTypeMstrId(1);
			accountCostDTOFromMap.setAmount(teraDataAccountCostDTO.getAmount());
			setAccountCostDTOAuditVlaues(accountCostDTOFromMap,userId);
			teradataCostNegativeList.add(accountCostDTOFromMap);
		    }else{
			AccountCostDTO accountCostDTOFromMap = oracleCostMap.get(teraDataAccountCostDTO.getAccountNbrData());
			if(accountCostDTOFromMap!=null && accountCostDTOFromMap.getAmount()!=null
				&& teraDataAccountCostDTO.getAmount()!=null && 
				(accountCostDTOFromMap.getAmount() - teraDataAccountCostDTO.getAmount() < 0)){
			    if(balanceNegativeList == null){
				balanceNegativeList = new ArrayList<AccountCostDTO> ();
			    }
			    //accountCostDTOFromMap.setAccountDesc("Spent Amount is more than Planned amount");
			    accountCostDTOFromMap.setAccountTypeMstrId(3);
			    setAccountCostDTOAuditVlaues(accountCostDTOFromMap,userId);
			    balanceNegativeList.add(accountCostDTOFromMap);
			}
		    }
		}
	    }
	    if((oracleCostNegativeList != null && !oracleCostNegativeList.isEmpty()) ||
		    (teradataCostNegativeList != null && !teradataCostNegativeList.isEmpty()) ||
		    (balanceNegativeList != null  && !balanceNegativeList.isEmpty() )){
		accountUpdateList = new ArrayList<AccountCostDTO> ();
		if(oracleCostNegativeList != null && !oracleCostNegativeList.isEmpty()){
		    accountUpdateList.addAll(oracleCostNegativeList);
		}
		if(teradataCostNegativeList != null && !teradataCostNegativeList.isEmpty()){
		    accountUpdateList.addAll(teradataCostNegativeList);
		}
		if(balanceNegativeList != null  && !balanceNegativeList.isEmpty() ){
		    accountUpdateList.addAll(balanceNegativeList);
		}
		
		liabProjtDao.saveAccountUpdates(accountUpdateList);
	    }
	}
	
	private void setAccountCostDTOAuditVlaues(AccountCostDTO accountCostDTO,String userId){
	    accountCostDTO.setCrtdDate(new Timestamp(System.currentTimeMillis()));
	    accountCostDTO.setLastUptdDate(new Timestamp(System.currentTimeMillis()));
	    accountCostDTO.setCrtdUser(userId);
	    accountCostDTO.setLastUptdUser(userId);
	}
	

	public ProjectOnLoadVB getMasterData() {
		ProjectOnLoadVB projectOnLoadVB = new ProjectOnLoadVB();
		projectOnLoadVB.setSources(
				lookupService.getDropDownOnLoad(ServiceConstants.EMA_LMS_PROJ_SRC_MSTR, ServiceConstants.PROJ_SRC_CODE,
						ServiceConstants.PROJ_SRC_DESC, ServiceConstants.PROJ_SRC_ID, ServiceConstants.SORT_ORD_NBR));
		projectOnLoadVB.setTypes(lookupService.getDropDownOnLoad(ServiceConstants.EMA_LMS_PROJ_TYPE_MSTR,
				ServiceConstants.PROJ_TYPE_CODE, ServiceConstants.PROJ_TYPE_DESC, ServiceConstants.PROJ_TYPE_ID,
				ServiceConstants.SORT_ORD));
		projectOnLoadVB.setDrivers(lookupService.getDropDownOnLoad(ServiceConstants.EMA_LMS_PROJ_DRIV_MSTR,
				ServiceConstants.PROJ_DRIV_CODE, ServiceConstants.PROJ_DRIV_DESC, ServiceConstants.PROJ_DRIV_ID,
				ServiceConstants.SORT_ORD));
		projectOnLoadVB.setEstimators(lookupService.getDropDownOnLoad(ServiceConstants.EMA_LMS_PROJ_ESTM_MSTR,
				ServiceConstants.PROJ_ESTM_CODE, ServiceConstants.PROJ_ESTM_DESC, ServiceConstants.PROJ_ESTM_ID,
				ServiceConstants.SORT_ORD));
		projectOnLoadVB.setSiteRemManagers(lookupService.getManagers());
		projectOnLoadVB.setRailRoads(lookupService.getDropDownOnLoad(ServiceConstants.EMA_LMS_RAIL_RAOD_MSTR,
				ServiceConstants.RAIL_RAOD_CODE, ServiceConstants.RAIL_RAOD_DESC, ServiceConstants.RAIL_RAOD_ID,
				ServiceConstants.SORT_ORD_NBR));
		projectOnLoadVB.setFederalLeads(
				lookupService.getDropDownOnLoad(ServiceConstants.EMA_LMS_FED_LEAD_MSTR, ServiceConstants.FED_LEAD_CODE,
						ServiceConstants.FED_LEAD_DESC, ServiceConstants.FED_LEAD_ID, ServiceConstants.SORT_ORD_NBR));
		projectOnLoadVB.setBalanceSheets(
				lookupService.getDropDownOnLoad(ServiceConstants.EMA_LMS_BLNC_SHT_MSTR, ServiceConstants.BLNC_SHT_CODE,
						ServiceConstants.BLNC_SHT_DESC, ServiceConstants.BLNC_SHT_ID, ServiceConstants.SORT_ORD_NBR));
		projectOnLoadVB.setSubAccounts(
				lookupService.getDropDownOnLoad(ServiceConstants.EMA_LMS_SUB_ACCT_MSTR, ServiceConstants.SUB_ACCT_CODE,
						ServiceConstants.SUB_ACCT_DESC, ServiceConstants.SUB_ACCT_ID, ServiceConstants.SORT_ORD_NBR));
		projectOnLoadVB.setStates(lookupService.getStates());
		projectOnLoadVB.setCostTypes(lookupService.getDropDownOnLoad(ServiceConstants.EMA_LMS_PROJ_COST_TYPE_MST,
				ServiceConstants.PROJ_COST_TYPE_CODE, ServiceConstants.PROJ_COST_TYPE_DESC,
				ServiceConstants.PROJ_COST_TYPE_ID, ServiceConstants.SORT_ORD_NBR));
		// projectOnLoadVB.setCostSubTypes(lookupService.getDropDownOnLoad(ServiceConstants.EMA_LMS_PROJ_COST_SUBTYPE_MST,
		// ServiceConstants.COST_SUB_TYPE_CODE,
		// ServiceConstants.COST_SUB_TYPE_DESC,
		// ServiceConstants.COST_SUB_TYPE_ID, ServiceConstants.SORT_ORD_NBR));
		List<DropDownInfo> tubeLevelList = lookupDao.getDropDownOnLoadForId(ServiceConstants.EMA_LMS_TUBE_LEVL_MSTR,
				ServiceConstants.TUBE_LEVL_ID, ServiceConstants.TUBE_LEVL_CODE, ServiceConstants.TUBE_LEVL_DESC);

		if (CommonUtils.isNotEmpty(tubeLevelList)) {
			projectOnLoadVB.setTubeLevelList(tubeLevelList);
		}

		List<DropDownInfo> changeReasons = lookupService.getDropDownOnLoadForId(ServiceConstants.EMA_LMS_CHNG_RESN_MSTR,
				ServiceConstants.CHNG_RESN_MSTR_ID, ServiceConstants.CHNG_RESN_CODE, ServiceConstants.CHNG_RESN_DESC);
		if (CommonUtils.isNotEmpty(changeReasons)) {
			projectOnLoadVB.setChangeReasons(changeReasons);
		}

		return projectOnLoadVB;
	}

	@Override
	public ProjectDTO getApprovedProjectDetails(long projectDtlId) {
	    ProjectDTO projectDTO = liabProjtDao.getApprovedProjectDetails(projectDtlId);
	    long projectId = projectDTO.getProjID();

	    if (projectDTO.getActionType().equals(ServiceConstants.ACTION_TYPE_PROJ)
		    && (projectDTO.getAction().equals(ServiceConstants.ACTN_UN_APPORVED)
			    || projectDTO.getAction().equals(ServiceConstants.ACTN_SUBMITTED))) {
		projectDTO.setCurrentCostDTOList(setCosts(liabProjtDao.getCosts(projectId,
			ServiceConstants.ACTION_TYPE_PROJ, ServiceConstants.ACTN_SUBMITTED)));
	    } else {
		projectDTO.setCurrentCostDTOList(setCosts(liabProjtDao.getProjApprovedCosts(projectId)));
		projectDTO.setProposedCostDTOList(
			getProjSubmitCosts(projectId, projectDTO.getActionType(), projectDTO.getAction()));
	    }

	    return projectDTO;
	}
	
	
	@Override
	public ProjectDTO getProjectByProjId(long projectId) {
	    ProjectDTO projectDTO = liabProjtDao.getProjectByProjId(projectId);
	    setProjectCosts(projectDTO);

	    return projectDTO;
	}
	
	
	public void setProjectCosts(ProjectDTO projectDTO) {
	    if (projectDTO.getActionType().equals(ServiceConstants.ACTION_TYPE_PROJ)
		    && (projectDTO.getAction().equals(ServiceConstants.ACTN_UN_APPORVED)
			    || projectDTO.getAction().equals(ServiceConstants.ACTION_PROJECT_PERSIST) 
			    || projectDTO.getAction().equals(ServiceConstants.ACTN_SUBMITTED))) {
		projectDTO.setCurrentCostDTOList(setCosts(liabProjtDao.getProjNoneApprovedCosts(projectDTO.getProjID())));
		projectDTO.setProposedCostDTOList(prepareEmptyCosts());
	    } else {
		projectDTO.setCurrentCostDTOList(setCosts(liabProjtDao.getProjApprovedCosts(projectDTO.getProjID())));
		projectDTO.setProposedCostDTOList(getProjSubmitCosts(projectDTO.getProjID(), projectDTO.getActionType(), projectDTO.getAction()));
	    }
	}
	
	

	/** {@inheritDoc} */

	@Override
	public List<ProjectCostDTO> getProjectCostDetails(long projectID) {
		return setCosts(liabProjtDao.getProjectCostDetails(projectID));
	}

	public List<ProjectCostDTO> getCostsByprojIdAndCostType(long projectID, long costTypeId) {
		return setCosts(liabProjtDao.getCostsByprojIdAndCostType(projectID, costTypeId));
	}

	public List<ProjectCostDTO> getProjApprovedCosts(long projectID) {
		return setCosts(liabProjtDao.getProjApprovedCosts(projectID));
	}

	private List<ProjectCostDTO> setCosts(List<ProjectCostDTO> tempCostsList) {

		List<ProjectCostDTO> finalCostsList = new ArrayList<>(20);
		Map<Long, ProjectCostDTO> costsMap = null;
		long year = Calendar.getInstance().get(Calendar.YEAR);
		if (tempCostsList != null && !tempCostsList.isEmpty()) {

			costsMap = new HashMap<Long, ProjectCostDTO>();
			for (ProjectCostDTO cost : tempCostsList) {
				if (cost.getYear() > 0) {
					costsMap.put(cost.getYear(), cost);
				} else if (isOmmCost(cost) || cost.getCostTypeId() == 3) {
					costsMap.put(cost.getCostTypeId(), cost);
				}
			}
			for (int i = 0; i < 15; i++) {
				if (costsMap.get(year + i) != null) {
					finalCostsList.add(costsMap.get(year + i));
				} else {
					finalCostsList.add(prepareNewCostObject(1, year + i));
				}
			}
			if (costsMap.get((long) 2) != null) {
				finalCostsList.add(costsMap.get((long) 2));
			} else {
				finalCostsList.add(prepareNewCostObject(2, null));
			}
			if (costsMap.get((long) 3) != null) {
				finalCostsList.add(costsMap.get((long) 3));
			} else {
				finalCostsList.add(prepareNewCostObject(3, null));
			}
		} else {
			for (int i = 0; i < 15; i++) {
				finalCostsList.add(prepareNewCostObject(1, year + i));
			}
			finalCostsList.add(prepareNewCostObject(2, null));
			finalCostsList.add(prepareNewCostObject(3, null));
		}
		return finalCostsList;
	}

	public List<ProjectCostDTO> getProjSubmitCosts(long projectID, String actionType, String action) {
		return setCosts(liabProjtDao.getProjNoneApprovedCosts(projectID));
	}

    private List<ProjectCostDTO> prepareEmptyCosts() {
		long year = Calendar.getInstance().get(Calendar.YEAR);
		List<ProjectCostDTO> currentCosts = new ArrayList<>(20);
		for (int i = 0; i < 15; i++) {
			currentCosts.add(prepareNewCostObject(1, year + i));
		}
		currentCosts.add(prepareNewCostObject(2, null));
		currentCosts.add(prepareNewCostObject(3, null));
		return currentCosts;
	}

	public List<ProjectCostVB> getCurrentCosts() {
		List<ProjectCostVB> currentCosts = new ArrayList<>(17);
		long year = Calendar.getInstance().get(Calendar.YEAR);
		for (int i = 0; i < 15; i++) {
			currentCosts.add(prepareNewCostVBObject(1, year + i));
		}
		currentCosts.add(prepareNewCostVBObject(2, null));
		currentCosts.add(prepareNewCostVBObject(3, null));
		return currentCosts;
	}

	private ProjectCostVB prepareNewCostVBObject(long costTypeId, Long year) {
		ProjectCostVB projectCostVB = new ProjectCostVB();
		projectCostVB.setCostTypeId(costTypeId);
		if (costTypeId == 1) {
			projectCostVB.setYear(year);
		} 
		return projectCostVB;
	}

	private ProjectCostDTO prepareNewCostObject(long costTypeId, Long year) {
		ProjectCostDTO projectCostDTO = new ProjectCostDTO();
		projectCostDTO.setCostTypeId(costTypeId);
		if (costTypeId == 1) {
			projectCostDTO.setYear(year);
		}
		return projectCostDTO;
	}

	/*public ProjectDTO saveApproveProject(ProjectDTO inputProjectDTO) {
		return saveOrUpdateProjectDetails(inputProjectDTO);
	}*/

	public ProjectDTO saveProjectDetails(ProjectDTO inputProjectDTO) {
	   // boolean isApproverOrAdmin = autherizationService.canApprove(inputProjectDTO.getCrtdUser());
	    boolean isApproverOrAdmin = false;
	    if (isApproverOrAdmin && (ServiceConstants.ACTION_PROJ_SUBMITTED.equalsIgnoreCase(inputProjectDTO.getInputFrom())
		    || ServiceConstants.ACTION_CHANGE_SUBMITTED.equalsIgnoreCase(inputProjectDTO.getInputFrom()))) {
		
		if(ServiceConstants.ACTION_PROJ_SUBMITTED.equalsIgnoreCase(inputProjectDTO.getInputFrom())){
		    inputProjectDTO.setInputFrom(ServiceConstants.ACTION_PROJ_APPROVED);
		}else if(ServiceConstants.ACTION_CHANGE_SUBMITTED.equalsIgnoreCase(inputProjectDTO.getInputFrom())){
		    inputProjectDTO.setInputFrom(ServiceConstants.ACTION_CHANGE_APPROVED);
		}
	    }
	    //return saveProjectWithCost(inputProjectDTO);
	    
	    if (!(ServiceConstants.ACTION_CHANGE_UN_APPROVED.equalsIgnoreCase(inputProjectDTO.getInputFrom())
		    || ServiceConstants.ACTION_PROJ_UN_APPROVED.equalsIgnoreCase(inputProjectDTO.getInputFrom())
		    || ServiceConstants.ACTION_PROJECT_PERSIST.equalsIgnoreCase(inputProjectDTO.getInputFrom())
		    || ServiceConstants.ACTION_CHANGE_PERSIST.equalsIgnoreCase(inputProjectDTO.getInputFrom()))) {
		inputProjectDTO.setDisaprvCmtDtlId(null);
	    }

	    ProjectDTO projectDTO = saveProject(inputProjectDTO);
	    saveOrUpdateProjectCostDetails(projectDTO);

	    projectDTO.setPreviousAction(projectDTO.getAction());
	    projectDTO.setPreviousActionType(projectDTO.getActionType());
	    sendMail(projectDTO);
	    if (ServiceConstants.ACTION_PROJ_SUBMITTED.equalsIgnoreCase(projectDTO.getInputFrom())) {
		projectDTO.setCurrentCostDTOList(prepareEmptyCosts());
	    }else if (ServiceConstants.ACTION_PROJECT_PERSIST.equalsIgnoreCase(projectDTO.getInputFrom())) {
		projectDTO.setCurrentCostDTOList(setCosts(liabProjtDao.getProjNoneApprovedCosts(projectDTO.getProjID())));
	    }

	    return projectDTO;
	}

	/*private ProjectDTO saveProjectWithCost(ProjectDTO inputProjectDTO) {
	    if (!(ServiceConstants.ACTION_CHANGE_UN_APPROVED.equalsIgnoreCase(inputProjectDTO.getInputFrom())
		    || ServiceConstants.ACTION_PROJ_UN_APPROVED.equalsIgnoreCase(inputProjectDTO.getInputFrom())
		    || ServiceConstants.ACTION_PROJECT_PERSIST.equalsIgnoreCase(inputProjectDTO.getInputFrom())
		    || ServiceConstants.ACTION_CHANGE_PERSIST.equalsIgnoreCase(inputProjectDTO.getInputFrom()))) {
		inputProjectDTO.setDisaprvCmtDtlId(null);
	    }

	    ProjectDTO projectDTO = saveProject(inputProjectDTO);
	    saveOrUpdateProjectCostDetails(projectDTO);

	    projectDTO.setPreviousAction(projectDTO.getAction());
	    projectDTO.setPreviousActionType(projectDTO.getActionType());
	    sendMail(projectDTO);
	    if (ServiceConstants.ACTION_PROJ_SUBMITTED.equalsIgnoreCase(projectDTO.getInputFrom())) {
		projectDTO.setCurrentCostDTOList(prepareEmptyCosts());
	    }else if (ServiceConstants.ACTION_PROJECT_PERSIST.equalsIgnoreCase(projectDTO.getInputFrom())) {
		projectDTO.setCurrentCostDTOList(setCosts(liabProjtDao.getProjNoneApprovedCosts(projectDTO.getProjID())));
	    }

	    return projectDTO;
	}
*/
	@Transactional
	public ProjectDTO saveOrUpdateProjectDetails(ProjectDTO inputProjectDTO) {

	    if (ServiceConstants.ACTION_CHANGE_UN_APPROVED.equalsIgnoreCase(inputProjectDTO.getInputFrom())
		    || ServiceConstants.ACTION_PROJ_UN_APPROVED.equalsIgnoreCase(inputProjectDTO.getInputFrom())) {
		inputProjectDTO.setDisaprvCmtDtlId(saveDisapprove(inputProjectDTO));
	    }else{
		//If action is not project persist or change persist then make previous disapprove comment id as null
		if(!(ServiceConstants.ACTION_PROJECT_PERSIST.equalsIgnoreCase(inputProjectDTO.getInputFrom())
		    || ServiceConstants.ACTION_CHANGE_PERSIST.equalsIgnoreCase(inputProjectDTO.getInputFrom())))
		inputProjectDTO.setDisaprvCmtDtlId(null);
	    }
	    ProjectDTO projectDTO = saveProject(inputProjectDTO);

	    if (!(ServiceConstants.ACTION_PROJ_APPROVED.equalsIgnoreCase(projectDTO.getInputFrom())
		    || ServiceConstants.ACTION_PROJ_UN_APPROVED.equalsIgnoreCase(projectDTO.getInputFrom())
		    || ServiceConstants.ACTION_PROJ_SUBMITTED.equalsIgnoreCase(projectDTO.getInputFrom()))) {
		saveOrUpdateChangeReason(projectDTO);
	    }
	    saveOrUpdateProjectCostDetails(projectDTO);

	    sendMail(projectDTO);
	    if (ServiceConstants.ACTION_PROJ_SUBMITTED.equalsIgnoreCase(projectDTO.getInputFrom())) {
		projectDTO.setCurrentCostDTOList(prepareEmptyCosts());
	    }else if (ServiceConstants.ACTION_PROJECT_PERSIST.equalsIgnoreCase(projectDTO.getInputFrom()) || 
		    ServiceConstants.ACTION_CHANGE_PERSIST.equalsIgnoreCase(projectDTO.getInputFrom())) {
		setProjectCosts(projectDTO);
	    }
	    /*if (ServiceConstants.ACTION_CHANGE_APPROVED.equalsIgnoreCase(projectDTO.getInputFrom())
				|| ServiceConstants.ACTION_CHANGE_UN_APPROVED.equalsIgnoreCase(projectDTO.getInputFrom())) {
			projectDTO.setCurrentCostDTOList(getProjApprovedCosts(projectDTO.getProjID()));
			projectDTO.setProposedCostDTOList(prepareEmptyCostObjects());
		}*/

	    projectDTO.setPreviousAction(projectDTO.getAction());
	    projectDTO.setPreviousActionType(projectDTO.getActionType());
	    return projectDTO;
	}
	
	@Transactional
	public void deleteProject(ProjectDTO projectDTO) {
	    if (ServiceConstants.ACTION_PROJ_DELETED.equalsIgnoreCase(projectDTO.getInputFrom())
		    || ServiceConstants.ACTION_CHANGE_DELETED.equalsIgnoreCase(projectDTO.getInputFrom())) {
		if(ServiceConstants.ACTN_UN_APPORVED.equalsIgnoreCase(projectDTO.getPreviousAction())){
		    projectDTO.setLastUptdDate(new Timestamp(System.currentTimeMillis()));
		    projectDTO.setActFlag(ServiceConstants.STATUS_HISTORY);
		    liabProjtDao.updateProjectDetails(projectDTO);
		
		    projectDTO.setCrtdDate(new Timestamp(System.currentTimeMillis()));
		    projectDTO.setActFlag(ServiceConstants.STATUS_HISTORY);
		    projectDTO.setAction(ServiceConstants.ACTN_DELETED);
		    if (ServiceConstants.ACTION_PROJ_DELETED.equalsIgnoreCase(projectDTO.getInputFrom())) {
			 projectDTO.setActionType(ServiceConstants.ACTION_TYPE_PROJ);
		    }else if (ServiceConstants.ACTION_CHANGE_DELETED.equalsIgnoreCase(projectDTO.getInputFrom())) {
			 projectDTO.setActionType(ServiceConstants.ACTION_TYPE_CHANGE);
		    }
		   
		    liabProjtDao.saveProjectDetails(projectDTO);
		}
		saveOrUpdateProjectCostDetails(projectDTO);
	    }
	}

	private long saveDisapprove(ProjectDTO projectDTO) {
		DisapproveProjDTO disapproveProjDTO = new DisapproveProjDTO();
		disapproveProjDTO.setDisaprvComments(projectDTO.getDisaprvComments());
		disapproveProjDTO.setCrtdUser(projectDTO.getLastUptdUser());
		disapproveProjDTO.setLastUptdUser(projectDTO.getLastUptdUser());
		disapproveProjDTO.setEmpId(projectDTO.getEmpId());
		
		disapproveProjDTO.setCrtdDate(new Timestamp(System.currentTimeMillis()));
		disapproveProjDTO.setLastUptdDate(new Timestamp(System.currentTimeMillis()));
		disapproveProjDTO.setActFlag(ServiceConstants.STATUS_CURRENT);
		return liabProjtDao.saveDisaprvProj(disapproveProjDTO);
	}

	private ProjectDTO saveProject(ProjectDTO projectDTO) {
		// projectDTO.setCrtdDate(new Timestamp(System.currentTimeMillis()));
		projectDTO.setLastUptdDate(new Timestamp(System.currentTimeMillis()));
		if (projectDTO.getProjDtlID() > 0) {// For existing project
			projectDTO.setActFlag(ServiceConstants.STATUS_HISTORY);
			if (projectDTO.isDataChangedFlag()
					|| ServiceConstants.ACTION_PROJ_APPROVED.equalsIgnoreCase(projectDTO.getInputFrom())
					|| ServiceConstants.ACTION_PROJ_UN_APPROVED.equalsIgnoreCase(projectDTO.getInputFrom())
					|| ServiceConstants.ACTION_CHANGE_UN_APPROVED.equalsIgnoreCase(projectDTO.getInputFrom())) {

				boolean isHistoryRequiredFlag = false;

				if (!(ServiceConstants.ACTN_APPORVED.equalsIgnoreCase(projectDTO.getPreviousAction()))) {
					isHistoryRequiredFlag = true;
				}

				if (ServiceConstants.ACTION_PROJECT_PERSIST.equalsIgnoreCase(projectDTO.getInputFrom())
						|| ServiceConstants.ACTION_CHANGE_PERSIST.equalsIgnoreCase(projectDTO.getInputFrom())) {
					// If the record is just saved then there is no change in
					// the action so make the old record to history
					// and create a new record with same action again.
					isHistoryRequiredFlag = true;
				}

				if (isHistoryRequiredFlag) {
					liabProjtDao.updateProjectDetails(projectDTO);
				}

				if (ServiceConstants.ACTION_CHANGE_APPROVED.equalsIgnoreCase(projectDTO.getInputFrom())) {
					// If the status is Change approved then make the previous
					// approved record
					// ( either the "Project Approved :PA" or the "Change
					// Approved :CA" ) to history
					liabProjtDao.updateApprovedProjToHistory(projectDTO);
				}
				return saveProjectToDatabse(projectDTO);
			}
		} else {
			projectDTO.setTubeLvlId(1L);// default tube level Id for submitting
			return saveProjectToDatabse(projectDTO);
		}
		return projectDTO;
	}

	private ProjectDTO saveProjectToDatabse(ProjectDTO projectDTO) {
		projectDTO.setCrtdDate(new Timestamp(System.currentTimeMillis()));
		projectDTO.setActFlag(ServiceConstants.STATUS_CURRENT);
		String currentAction = null;
		String currentActionType = null;
		// Don't prepare actions for just saving the records.
		if (!(ServiceConstants.ACTION_PROJECT_PERSIST.equalsIgnoreCase(projectDTO.getInputFrom())
				|| ServiceConstants.ACTION_CHANGE_PERSIST.equalsIgnoreCase(projectDTO.getInputFrom()))) {
			projectDTO = prepareActions(projectDTO);
		}
		if (projectDTO.getProjID() == 0
				&& (ServiceConstants.ACTION_PROJ_APPROVED.equalsIgnoreCase(projectDTO.getInputFrom())
						|| ServiceConstants.ACTION_PROJ_SUBMITTED.equalsIgnoreCase(projectDTO.getInputFrom()))) {
			long projId = liabProjtDao.saveProjId(projectDTO);
			projectDTO.setProjID(projId);
		}

		if (ServiceConstants.ACTION_PROJECT_PERSIST.equalsIgnoreCase(projectDTO.getInputFrom())
				|| ServiceConstants.ACTION_CHANGE_PERSIST.equalsIgnoreCase(projectDTO.getInputFrom())) {
			// Temporary changes on the project for Action and ActionType as
			// this action and action type are carried to cost also.
			currentAction = projectDTO.getAction();
			currentActionType = projectDTO.getActionType();
			projectDTO.setAction(projectDTO.getPreviousAction());
			projectDTO.setActionType(projectDTO.getPreviousActionType());
		}
		
		if(!(projectDTO.getMinStdgBlncFlag()!=null 
			&& "Y".equalsIgnoreCase(projectDTO.getMinStdgBlncFlag()))){
		    projectDTO.setMinStdBlncAmt(null);
		}
		
		if(!(projectDTO.getReqActgFlag()!=null 
			&& "Y".equalsIgnoreCase(projectDTO.getReqActgFlag()))){
		    projectDTO.setUndergroundStorageTankFlag(null);
		}


		long projDtlId = liabProjtDao.saveProjectDetails(projectDTO);
		projectDTO.setProjDtlID(projDtlId);

		if (currentAction != null) {
			projectDTO.setAction(currentAction);
		}
		if (currentActionType != null) {
			projectDTO.setActionType(currentActionType);
		}

		return projectDTO;
	}

	public void saveOrUpdateChangeReason(ProjectDTO projectDTO) {
		if (projectDTO.getChangeReasonDtlId() != null && projectDTO.getChangeReasonDtlId() > 0) {
			if (projectDTO.isChangeResnDataChangedFlag()) {
				// there is no separate object for change reason, so make use of
				// same
				// project active flag. and reset the active flag data to
				// project
				// after change reason is performed.
				String presentActFlag = projectDTO.getActFlag();
				projectDTO.setActFlag(ServiceConstants.STATUS_HISTORY);
				liabProjtDao.updateChangeReason(projectDTO);
				projectDTO.setActFlag(ServiceConstants.STATUS_CURRENT);
				long changeReasonDtlId = liabProjtDao.saveChangeReason(projectDTO);
				projectDTO.setActFlag(presentActFlag);
				projectDTO.setChangeReasonDtlId(changeReasonDtlId);
			}
		} else {
			if ((projectDTO.getChangeReasonDtlId() == null || projectDTO.getChangeReasonDtlId() == 0)
					&& (projectDTO.getChangeReasonMstrId() != null && projectDTO.getChangeReasonMstrId() > 0)) {
				// there is no separate object for change reason, so make use of
				// same
				// project active flag. and reset the active flag data to
				// project
				// after change reason is performed.
				String presentActFlag = projectDTO.getActFlag();
				projectDTO.setActFlag(ServiceConstants.STATUS_CURRENT);
				long changeReasonDtlId = liabProjtDao.saveChangeReason(projectDTO);
				projectDTO.setChangeReasonDtlId(changeReasonDtlId);
				projectDTO.setActFlag(presentActFlag);
			}
		}
	}

	private ProjectDTO prepareActions(ProjectDTO projectDTO) {

	    // autherizationService.isAutherized(AZMPolicies., action_id,
	    // feature_id, resource_id)
	    String[] actionCodes = LMSUtils.getActionCodes( projectDTO.getInputFrom(), projectDTO.getAction(),
		    projectDTO.getActionType());
	    projectDTO.setActionType(actionCodes[0]);
	    projectDTO.setAction(actionCodes[1]);
	    return projectDTO;
	}

	

	
	public List<ProjectCostDTO> saveOrUpdateProjectCostDetails(ProjectDTO projectDTO) {
		Map<Long, ProjectCostDTO> currentCostsMap = null;
		List<ProjectCostDTO> projCostDTOList = null;
		if (projectDTO.getInputFrom().equals(ServiceConstants.ACTION_PROJ_SUBMITTED)
				|| projectDTO.getInputFrom().equals(ServiceConstants.ACTION_PROJ_APPROVED)
				|| projectDTO.getInputFrom().equals(ServiceConstants.ACTION_PROJECT_PERSIST)
				|| projectDTO.getInputFrom().equals(ServiceConstants.ACTION_PROJ_UN_APPROVED)
				|| projectDTO.getInputFrom().equals(ServiceConstants.ACTION_PROJ_DELETED)) {
			projCostDTOList = projectDTO.getCurrentCostDTOList();
		} else {
			projCostDTOList = projectDTO.getProposedCostDTOList();
		}

		if (projectDTO.getInputFrom().equals(ServiceConstants.ACTION_CHANGE_APPROVED)) {
			currentCostsMap = prepareCurrentCostMap(projectDTO);
		}

		if (LMSUtils.isNotEmpty(projCostDTOList)) {

		    for (ProjectCostDTO projectCostDTO : projCostDTOList) {
			if (projectCostDTO.getCostId() > 0) {
			    updateOldAndSaveNewCost(projectDTO,projectCostDTO,currentCostsMap);
			} else {
			    saveNewCost(projectDTO,projectCostDTO,currentCostsMap);
			}
			projectCostDTO.setDataChangedFlag(false);
		    }
		}
		return projCostDTOList;
	}
	
	private void updateOldAndSaveNewCost(ProjectDTO projectDTO,ProjectCostDTO projectCostDTO,Map<Long, ProjectCostDTO> currentCostsMap){

	    if (projectDTO.getInputFrom().equalsIgnoreCase(ServiceConstants.ACTION_PROJ_SUBMITTED)) {
		if (projectCostDTO.isDataChangedFlag() || 
			ServiceConstants.ACTN_UN_APPORVED.equalsIgnoreCase(projectCostDTO.getPreviousAction())) {
		    // create new records for the submitted with changes
		    updateOldCostAndSaveNewCost(projectDTO, projectCostDTO, ServiceConstants.ACTION_TYPE_PROJ,
			    ServiceConstants.ACTN_SUBMITTED);
		}
	    } else if (projectDTO.getInputFrom().equals(ServiceConstants.ACTION_PROJ_APPROVED)) {
		updateOldCostAndSaveNewCost(projectDTO, projectCostDTO, ServiceConstants.ACTION_TYPE_PROJ,
			ServiceConstants.ACTN_APPORVED);
	    } else if (projectDTO.getInputFrom().equalsIgnoreCase(ServiceConstants.ACTION_PROJ_UN_APPROVED)) {
		projectCostDTO.setDisaprvCmtDtlId(projectDTO.getDisaprvCmtDtlId());
		updateOldCostAndSaveNewCost(projectDTO, projectCostDTO, ServiceConstants.ACTION_TYPE_PROJ,
			ServiceConstants.ACTN_UN_APPORVED);
	    } else if (ServiceConstants.ACTION_CHANGE_SUBMITTED.equalsIgnoreCase(projectDTO.getInputFrom())) {
		if (projectCostDTO.isDataChangedFlag()  ||   ServiceConstants.ACTN_UN_APPORVED.equalsIgnoreCase(projectCostDTO.getPreviousAction())) {
		    if (!ServiceConstants.ACTN_APPORVED.equalsIgnoreCase(projectCostDTO.getPreviousAction())) {
			updateOldCostAndSaveNewCost(projectDTO, projectCostDTO,
				ServiceConstants.ACTION_TYPE_CHANGE, ServiceConstants.ACTN_SUBMITTED);
		    } else {
			saveNewCost(projectDTO, projectCostDTO, ServiceConstants.ACTION_TYPE_CHANGE,
				ServiceConstants.ACTN_SUBMITTED);
		    }
		}
	    } else if (projectDTO.getInputFrom().equalsIgnoreCase(ServiceConstants.ACTION_CHANGE_APPROVED)) {
		if (projectCostDTO.getCost() != null && projectCostDTO.getCost() >= 0) {
		    ProjectCostDTO projectCurrentCostDTO = null;

		    if (projectCostDTO.getYear() > 0) {
			projectCurrentCostDTO = currentCostsMap.get(projectCostDTO.getYear());
		    } else if (isOmmCost(projectCostDTO) || isSystemClosureCost(projectCostDTO)) {
			projectCurrentCostDTO = currentCostsMap.get(projectCostDTO.getCostTypeId());
		    }

		    if (projectCurrentCostDTO != null) {
			updateOnlyCostToHistory(projectDTO, projectCurrentCostDTO);
		    }

		    updateOldCostAndSaveNewCost(projectDTO, projectCostDTO, ServiceConstants.ACTION_TYPE_CHANGE,
			    ServiceConstants.ACTN_APPORVED);
		}
	    } else if (projectDTO.getInputFrom().equalsIgnoreCase(ServiceConstants.ACTION_CHANGE_UN_APPROVED)) {
		projectCostDTO.setDisaprvCmtDtlId(projectDTO.getDisaprvCmtDtlId());
		if (!ServiceConstants.ACTN_APPORVED.equalsIgnoreCase(projectCostDTO.getPreviousAction())) {
		    // If there is any "Project Approved PA" or "Change
		    // Approved CA" record then don't make that record
		    // to history.
		    updateOldCostAndSaveNewCost(projectDTO, projectCostDTO, ServiceConstants.ACTION_TYPE_CHANGE,
			    ServiceConstants.ACTN_UN_APPORVED);
		} else {
		    saveNewCost(projectDTO, projectCostDTO, ServiceConstants.ACTION_TYPE_CHANGE,
			    ServiceConstants.ACTN_UN_APPORVED);
		}
	    } else if (projectCostDTO.isDataChangedFlag() && 
		    (ServiceConstants.ACTION_PROJECT_PERSIST .equalsIgnoreCase(projectDTO.getInputFrom())
			    || ServiceConstants.ACTION_CHANGE_PERSIST.equalsIgnoreCase(projectDTO.getInputFrom()))) {
		updateOldCostAndSaveNewCost(projectDTO, projectCostDTO, projectCostDTO.getPreviousActionType(),
			projectCostDTO.getPreviousAction());
	    }else if (
		    (ServiceConstants.ACTION_PROJ_DELETED .equalsIgnoreCase(projectDTO.getInputFrom())
			    || ServiceConstants.ACTION_CHANGE_DELETED.equalsIgnoreCase(projectDTO.getInputFrom()))) {
		
		if(ServiceConstants.ACTN_UN_APPORVED.equalsIgnoreCase(projectCostDTO.getPreviousAction())){
		    if(ServiceConstants.ACTION_PROJ_DELETED .equalsIgnoreCase(projectDTO.getInputFrom())){
			updateOldCostAndSaveNewCost(projectDTO, projectCostDTO,  ServiceConstants.ACTION_TYPE_PROJ,
				ServiceConstants.ACTN_DELETED);
		    }else{
			updateOldCostAndSaveNewCost(projectDTO, projectCostDTO,  ServiceConstants.ACTION_TYPE_CHANGE,
				ServiceConstants.ACTN_DELETED);
		    }
		}
	
	    }

	}
	
	private void saveNewCost(ProjectDTO projectDTO,ProjectCostDTO projectCostDTO,Map<Long, ProjectCostDTO> currentCostsMap){

	    String inputAction = projectDTO.getInputFrom();
	    if (projectCostDTO.getCost() != null && projectCostDTO.getCost() >= 0) {
		projectCostDTO.setDisaprvCmtDtlId(projectDTO.getDisaprvCmtDtlId());
		if (ServiceConstants.ACTION_PROJ_SUBMITTED.equalsIgnoreCase(inputAction)) {
		    saveNewCost(projectDTO, projectCostDTO, ServiceConstants.ACTION_TYPE_PROJ,ServiceConstants.ACTN_SUBMITTED);
		} else if (ServiceConstants.ACTION_PROJ_APPROVED.equalsIgnoreCase(inputAction)) {
		    saveNewCost(projectDTO, projectCostDTO, ServiceConstants.ACTION_TYPE_PROJ,	ServiceConstants.ACTN_APPORVED);
		} 
		else  if( ServiceConstants.ACTION_PROJ_UN_APPROVED.equalsIgnoreCase(inputAction)){
		    saveNewCost(projectDTO,projectCostDTO,  ServiceConstants.ACTION_TYPE_PROJ,  ServiceConstants.ACTN_UN_APPORVED);
		}
		else if (ServiceConstants.ACTION_CHANGE_SUBMITTED.equalsIgnoreCase(inputAction)) {
		    if (projectCostDTO.isDataChangedFlag()) {
			saveNewCost(projectDTO, projectCostDTO, ServiceConstants.ACTION_TYPE_CHANGE,ServiceConstants.ACTN_SUBMITTED);
		    }
		} else if (ServiceConstants.ACTION_CHANGE_APPROVED.equalsIgnoreCase(inputAction)) {
		    if (projectCostDTO.getCost() != null && projectCostDTO.getCost() >= 0) {
			ProjectCostDTO projectCurrentCostDTO = null;

			if (projectCostDTO.getYear() > 0) {
			    projectCurrentCostDTO = currentCostsMap.get(projectCostDTO.getYear());
			} else if (isOmmCost(projectCostDTO) || isSystemClosureCost(projectCostDTO)) {
			    projectCurrentCostDTO = currentCostsMap.get(projectCostDTO.getCostTypeId());
			}

			if (projectCurrentCostDTO != null) {// Make the
			    /* previous  approved  cost to  history*/
			    updateOnlyCostToHistory(projectDTO, projectCurrentCostDTO);
			}
			saveNewCost(projectDTO, projectCostDTO, ServiceConstants.ACTION_TYPE_CHANGE,ServiceConstants.ACTN_APPORVED);
		    }
		} else if (ServiceConstants.ACTION_CHANGE_UN_APPROVED.equalsIgnoreCase(inputAction) && projectCostDTO.getCost() >= 0) {
		    projectCostDTO.setDisaprvCmtDtlId(projectDTO.getDisaprvCmtDtlId());
		    saveNewCost(projectDTO, projectCostDTO, ServiceConstants.ACTION_TYPE_CHANGE,ServiceConstants.ACTN_UN_APPORVED);
		} else if (ServiceConstants.ACTION_PROJECT_PERSIST.equalsIgnoreCase(inputAction) && projectCostDTO.getCost() >=0) {
		    saveNewCost(projectDTO, projectCostDTO, ServiceConstants.ACTION_TYPE_PROJ,ServiceConstants.ACTN_SUBMITTED);
		}else if (ServiceConstants.ACTION_CHANGE_PERSIST.equalsIgnoreCase(inputAction) && projectCostDTO.getCost() >=0) {
		    saveNewCost(projectDTO, projectCostDTO, ServiceConstants.ACTION_TYPE_CHANGE,ServiceConstants.ACTN_SUBMITTED);
		}
	    }
	}

	private boolean isOmmCost(ProjectCostDTO projectCostDTO) {
		return projectCostDTO.getCostTypeId() == 2;
	}

	private boolean isSystemClosureCost(ProjectCostDTO projectCostDTO) {
		return projectCostDTO.getCostTypeId() == 3;
	}

	private Map<Long, ProjectCostDTO> prepareCurrentCostMap(ProjectDTO projectDTO) {
		Map<Long, ProjectCostDTO> currentCostsMap = null;

		currentCostsMap = new HashMap<Long, ProjectCostDTO>(17);
		for (ProjectCostDTO cost : projectDTO.getCurrentCostDTOList()) {
			if (cost.getYear() > 0 && cost.getCostTypeId() == 1) {
				currentCostsMap.put(cost.getYear(), cost);
			} else if (isOmmCost(cost) || cost.getCostTypeId() == 3) {
				currentCostsMap.put(cost.getCostTypeId(), cost);
			}
		}
		return currentCostsMap;
	}

	private void updateOnlyCostToHistory(ProjectDTO projectDTO, ProjectCostDTO projectCostDTO) {
		setLastUpdatedValues(projectDTO, projectCostDTO);
		projectCostDTO.setActFlag(ServiceConstants.STATUS_HISTORY);
		liabProjtDao.updateProjectCostDetails(projectCostDTO);
	}

	private void updateOldCostAndSaveNewCost(ProjectDTO projectDTO, ProjectCostDTO projectCostDTO, String actionType,
			String action) {
		updateOnlyCostToHistory(projectDTO, projectCostDTO);
		if(projectCostDTO.getCost()!=null && projectCostDTO.getCost() >= 0){
		    saveNewCostToDatabase(projectDTO, projectCostDTO, actionType, action);
		}
	}

	private void saveNewCost(ProjectDTO projectDTO, ProjectCostDTO projectCostDTO, String actionType, String action) {
		// LMSUtils.setUserDetails(projectCostDTO,projectDTO.getLastUptdUser());
	    if(projectCostDTO.getCost()!=null && projectCostDTO.getCost() >= 0){
		setLastUpdatedValues(projectDTO, projectCostDTO);
		saveNewCostToDatabase(projectDTO, projectCostDTO, actionType, action);
	    }
		
	}

	private void saveNewCostToDatabase(ProjectDTO projectDTO, ProjectCostDTO projectCostDTO, String actionType,
			String action) {
		long costDtlId = 0;
		if (projectDTO.getChangeReasonDtlId() != null && projectDTO.getChangeReasonDtlId() > 0) {
			projectCostDTO.setChangeReasonDtlId(projectDTO.getChangeReasonDtlId());
		}
		projectCostDTO.setActionType(actionType);
		projectCostDTO.setAction(action);
		projectCostDTO.setCrtdDate(new Timestamp(System.currentTimeMillis()));
		projectCostDTO.setCrtdUser(projectDTO.getCrtdUser());
		projectCostDTO.setActFlag(ServiceConstants.STATUS_CURRENT);
		if(ServiceConstants.ACTN_DELETED.equalsIgnoreCase(action)){
		    projectCostDTO.setActFlag(ServiceConstants.STATUS_HISTORY);
		}
		projectCostDTO.setEmpId(projectDTO.getEmpId());
		if (ServiceConstants.ACTION_PROJ_UN_APPROVED.equalsIgnoreCase(projectDTO.getInputFrom())
				|| ServiceConstants.ACTION_CHANGE_UN_APPROVED.equalsIgnoreCase(projectDTO.getInputFrom())) {
			if (projectDTO.getDisaprvCmtDtlId() != null && projectDTO.getDisaprvCmtDtlId() > 0) {
				projectCostDTO.setDisaprvCmtDtlId(projectDTO.getDisaprvCmtDtlId());
			}
		}else if ( !(projectDTO.getInputFrom().equals(ServiceConstants.ACTION_PROJECT_PERSIST)
			|| projectDTO.getInputFrom().equals(ServiceConstants.ACTION_CHANGE_PERSIST))) {
		    projectCostDTO.setDisaprvCmtDtlId(projectDTO.getDisaprvCmtDtlId());
		}

		costDtlId = liabProjtDao.saveProjectCostDetails(projectCostDTO);
		projectCostDTO.setCostId(costDtlId);

		projectCostDTO.setPreviousAction(projectCostDTO.getAction());
		projectCostDTO.setPreviousActionType(projectCostDTO.getActionType());
	}

	private void setLastUpdatedValues(ProjectDTO projectDTO, ProjectCostDTO projectCostDTO) {
		projectCostDTO.setLastUptdUser(projectDTO.getLastUptdUser());
		projectCostDTO.setCrtdUser(projectDTO.getLastUptdUser());
		projectCostDTO.setLastUptdDate(new Timestamp(System.currentTimeMillis()));
		projectCostDTO.setProjID(projectDTO.getProjID());
		projectCostDTO.setEmpId(projectDTO.getEmpId());
	}

	/**
	 * This method is used to prepare ProjectCostDTO for OMM and System Closure
	 */
	/*
	 * private ProjectCostDTO prepareCostDetailsType(ProjectCostDTO
	 * projectCostDTO){
	 * if(projectCostDTO.getCostSubType().equalsIgnoreCase(ServiceConstants.
	 * OMM_COST_TYPE_DESC)){
	 * projectCostDTO.setOprnAndMaintCost(projectCostDTO.getCost());
	 * projectCostDTO.setCost(0.0d); } else
	 * if(projectCostDTO.getCostSubType().equalsIgnoreCase(ServiceConstants.
	 * SYS_COST_TYPE_DESC)){
	 * projectCostDTO.setSysClosureCost(projectCostDTO.getCost());
	 * projectCostDTO.setCost(0.0d); } return projectCostDTO; }
	 */
	/** {@inheritDoc} */
	@Override
	public void sendMail(ProjectDTO projectDTO) {

	    boolean isApproverOrAdmin = autherizationService.canApprove(projectDTO.getCrtdUser());
	    if (!(isApproverOrAdmin && (ServiceConstants.ACTION_PROJ_SUBMITTED.equalsIgnoreCase(projectDTO.getInputFrom())
		    || ServiceConstants.ACTION_CHANGE_SUBMITTED.equalsIgnoreCase(projectDTO.getInputFrom())))) {
		if (ServiceConstants.ACTION_PROJ_SUBMITTED.equalsIgnoreCase(projectDTO.getInputFrom())
			|| ServiceConstants.ACTION_PROJ_APPROVED.equalsIgnoreCase(projectDTO.getInputFrom())
			|| ServiceConstants.ACTION_CHANGE_SUBMITTED.equalsIgnoreCase(projectDTO.getInputFrom())
			|| ServiceConstants.ACTION_CHANGE_APPROVED.equalsIgnoreCase(projectDTO.getInputFrom())
			|| ServiceConstants.ACTION_PROJ_UN_APPROVED.equalsIgnoreCase(projectDTO.getInputFrom())
			|| ServiceConstants.ACTION_CHANGE_UN_APPROVED.equalsIgnoreCase(projectDTO.getInputFrom())) {
		    final StringBuilder mailSubject = new StringBuilder();
		    StringBuilder messageBody = null;
	

		    String URLHead = LMSUtils.getPageURL(projectDTO);
		    String fromAddress = LMSUtils.LMS_MAIL;
		    List<String> toArrList = new ArrayList<String>();

		    String lastSubmittedUserId = null;

		    try {
			if (ServiceConstants.ACTION_PROJ_SUBMITTED.equalsIgnoreCase(projectDTO.getInputFrom())
				|| ServiceConstants.ACTION_CHANGE_SUBMITTED.equalsIgnoreCase(projectDTO.getInputFrom())) {
			    toArrList=groupMembers.getGroupMembers(GroupType.APPROVER.getValue());
			} else if (ServiceConstants.ACTION_PROJ_APPROVED.equalsIgnoreCase(projectDTO.getInputFrom())
				|| ServiceConstants.ACTION_PROJ_UN_APPROVED.equalsIgnoreCase(projectDTO.getInputFrom())) {
			    // Prepare From who submitted the project
			    lastSubmittedUserId = getLastPersonSubmitted(projectDTO.getProjID());
			    if (lastSubmittedUserId == null) {
				lastSubmittedUserId = projectDTO.getLastUptdUser();
			    }
			    toArrList.add(lastSubmittedUserId);

			    if (ServiceConstants.ACTION_PROJ_APPROVED.equalsIgnoreCase(projectDTO.getInputFrom())) {
				sendMailToFinanceTeam(projectDTO, lastSubmittedUserId, toArrList);
			    }
			} else if (ServiceConstants.ACTION_CHANGE_APPROVED.equalsIgnoreCase(projectDTO.getInputFrom())
				|| ServiceConstants.ACTION_CHANGE_UN_APPROVED.equalsIgnoreCase(projectDTO.getInputFrom())) {
			    String projectUpdatedByUserId = getLastPersonProjChangeSubmitted(projectDTO.getProjID());
			    String costUpdatedByUserId = getLastPersonCostChangeSubmitted(projectDTO.getProjID());
			    if (projectUpdatedByUserId != null && costUpdatedByUserId != null) {
				if (costUpdatedByUserId.equalsIgnoreCase(projectUpdatedByUserId)) {
				    toArrList.add(projectUpdatedByUserId);
				} else {
				    toArrList.add(projectUpdatedByUserId);
				    toArrList.add(costUpdatedByUserId);
				}
			    } else if (projectUpdatedByUserId != null && costUpdatedByUserId == null) {
				toArrList.add(projectUpdatedByUserId);
			    } else if (projectUpdatedByUserId == null && costUpdatedByUserId != null) {
				toArrList.add(costUpdatedByUserId);
			    }
			}

			mailSubject.append(ActionInputType.getSubjectByCode(projectDTO.getInputFrom()));
			messageBody = prepareMessageLinkWithConent(URLHead, projectDTO);

			// *** Sending Mail **
			SendMailDTO sendMailVO = new SendMailDTO();
			sendMailVO.setFromAddress(fromAddress);
			sendMailVO.setToAddressLst(toArrList);

			sendMailVO.setSubject(mailSubject.toString());
			sendMailVO.setBodyContent(messageBody.toString());
			emailService.sendEmailNotification(sendMailVO);
		    } catch (Exception e) {
			logger.error("Error occured while sending an Error email.", e);
		    }
		}
	    }
	}

	private String getLastPersonSubmitted(long projID) {
		return liabProjtDao.getLastSubmittedProjUser(projID);
	}

	private String getLastPersonProjChangeSubmitted(long projID) {
		return liabProjtDao.getLastChangeSubmittedProjUser(projID);
	}

	private String getLastPersonCostChangeSubmitted(long projID) {
		return liabProjtDao.getLastChangeSubmittedCostUser(projID);
	}

	public void sendMailToFinanceTeam(ProjectDTO projectDTO, String userId, List<String> ccArrList) {
		final StringBuilder mailSubject = new StringBuilder();
		StringBuilder messageBody = null;
		String fromAddress = userId;
		ccArrList.add(userId);
		List<String> toArrList = new ArrayList<String>(1);
		toArrList.add(LMSUtils.SAP_TO_MAIL);
		try {
			mailSubject.append(ActionInputType.getSubjectByCode(projectDTO.getInputFrom()));
			messageBody = prepareMessageBodyForFinanceTeam(projectDTO, userId);
			SendMailDTO sendMailVO = new SendMailDTO();
			sendMailVO.setFromAddress(fromAddress);
			sendMailVO.setToAddressLst(toArrList);
			sendMailVO.setCcAddressLst(ccArrList);
			sendMailVO.setSubject(mailSubject.toString());
			sendMailVO.setBodyContent(messageBody.toString());
			emailService.sendEmailNotification(sendMailVO);
		} catch (Exception e) {
			logger.error("Error occured while sending an Error email.", e);
		}
	}

	@Override
	public ProjectDTO saveDisapprvProj(DisapproveProjDTO disapproveProjDTO,ProjectDTO projectDTO) {
		disapproveProjDTO.setCrtdDate(new Timestamp(System.currentTimeMillis()));
		disapproveProjDTO.setLastUptdDate(new Timestamp(System.currentTimeMillis()));
		disapproveProjDTO.setActFlag(ServiceConstants.STATUS_CURRENT);
		projectDTO.setDisaprvCmtDtlId(liabProjtDao.saveDisaprvProj(disapproveProjDTO));
		return saveProjectDetails(projectDTO);
	}

	private StringBuilder prepareMessageLinkWithConent(String URLHead, ProjectDTO projectDTO) {
	    final StringBuilder messageBody = new StringBuilder();
		messageBody.append(prepareMessageBodyBegining(projectDTO.getInputFrom()));
		//messageBody.append(ServiceConstants.BREAK_LINE);
		messageBody.append("<html> <body><p><a href='");
		messageBody.append(URLHead);
		messageBody.append(projectDTO.getProjID());
		if (ServiceConstants.ACTION_PROJ_APPROVED.equalsIgnoreCase(projectDTO.getInputFrom())
				|| ServiceConstants.ACTION_CHANGE_APPROVED.equalsIgnoreCase(projectDTO.getInputFrom())) {
			messageBody.append("'>View project</a></p>");
		} else {
			messageBody.append("'>Review the project</a></p>");
		}
		messageBody.append(ServiceConstants.BREAK_LINE);
		messageBody.append(prepareMessageBodyConent(projectDTO));
		return messageBody;
	}

	private StringBuilder prepareMessageBodyBegining(String action) {
		final StringBuilder messageBody = new StringBuilder();

		if (ServiceConstants.ACTION_PROJ_SUBMITTED.equalsIgnoreCase(action)) {
			messageBody.append(
					"<p>A new liability project has been created. The project must be approved or disapproved.</p>");
		} else if (ServiceConstants.ACTION_CHANGE_SUBMITTED.equalsIgnoreCase(action)) {
			messageBody.append(
					"<p>A new liability project change has been submitted. The project must be approved or disapproved.</p>");
		} else if (ServiceConstants.ACTION_PROJ_APPROVED.equalsIgnoreCase(action)) {
			messageBody.append("<p>The new project created has been approved. </p>");
		} else if (ServiceConstants.ACTION_PROJ_UN_APPROVED.equalsIgnoreCase(action)) {
			messageBody.append("<p>A new liability project has been disapproved. </p>");
		} else if (ServiceConstants.ACTION_CHANGE_APPROVED.equalsIgnoreCase(action)) {
			messageBody.append("<p>A new liability project change has been approved. </p>");
		} else if (ServiceConstants.ACTION_CHANGE_UN_APPROVED.equalsIgnoreCase(action)) {
			messageBody.append("<p>A liability project change has been disapproved.</p>");
		}

		return messageBody;
	}

	private StringBuilder prepareMessageBodyConent(ProjectDTO projectDTO) {
		final StringBuilder messageBody = new StringBuilder();
		 String name= projectDTO.getEmpId()!=null?getEmployeeDetails.getEmployeeName(projectDTO.getEmpId()):"";
		if (ServiceConstants.ACTION_CHANGE_UN_APPROVED.equalsIgnoreCase(projectDTO.getInputFrom())) {
			messageBody.append("<p><b>Disapproved By: </b>");
			messageBody.append(name);
			messageBody.append("</p>");

			messageBody.append("<p><b>Disapproval Reason: </b>");
			messageBody.append(projectDTO.getDisaprvComments());
			messageBody.append("</p>");
		}

		messageBody.append("<p><b>Project Name: </b>");
		messageBody.append(projectDTO.getProjectName());
		messageBody.append("</p>");
		messageBody.append("<p><b>Location:</b> ");
		messageBody.append(projectDTO.getCity());
		messageBody.append(", ");
		messageBody.append(projectDTO.getState());
		messageBody.append("</p>");
		messageBody.append("<p><b>Project Description:</b> ");
		messageBody.append(projectDTO.getProjOthDesc());
		messageBody.append("</p>");

		if (ServiceConstants.ACTION_CHANGE_SUBMITTED.equalsIgnoreCase(projectDTO.getInputFrom())
				|| ServiceConstants.ACTION_CHANGE_APPROVED.equalsIgnoreCase(projectDTO.getInputFrom())
				|| ServiceConstants.ACTION_CHANGE_UN_APPROVED.equalsIgnoreCase(projectDTO.getInputFrom())) {
			messageBody.append("<p><b>Change Type:</b> ");
			messageBody.append(projectDTO.getChangeType());
			messageBody.append("</p>");

			messageBody.append("<p><b>Proposed Tube Level:</b> ");
			messageBody.append(projectDTO.getTubeLvlId());
			messageBody.append("</p>");

			messageBody.append("<p><b>Planned Costs Change:</b> ");
			messageBody.append(prepareChangedCosts(projectDTO));
			messageBody.append("</p>");

		}
		messageBody.append("<p><b>Created on: </b>");
		messageBody.append(WebDateUtil.getDisplayformat(projectDTO.getProjectDate()));
		messageBody.append("</p>");
		messageBody.append("<p><b>Created by: </b>");
		messageBody.append(name);
		messageBody.append("</p>");
		messageBody.append("</body></html> ");
		return messageBody;
	}

	private String prepareChangedCosts(ProjectDTO projectDTO) {
		List<ProjectCostDTO> projCostDTOList = projectDTO.getProposedCostDTOList();
		StringBuffer changedCosts = new StringBuffer();

		if (LMSUtils.isNotEmpty(projCostDTOList)) {
		    //int i = 0;
		    for (ProjectCostDTO projectCostDTO : projCostDTOList) {
			if (projectCostDTO.getCost() != null && projectCostDTO.getCost() >= 0) {
			    changedCosts.append("<br>");
			    if (projectCostDTO.getYear() > 0) {
				changedCosts.append(" Year: ").append(projectCostDTO.getYear()).append(", Cost Value: ")
				.append(LMSUtils.getCostAppendedToTwoDecimal(projectCostDTO.getCost())).append("<br>");
			    } else if (isOmmCost(projectCostDTO)) {
				changedCosts.append(" OMM Cost").append(" Cost Value: ").append(LMSUtils.getCostAppendedToTwoDecimal(projectCostDTO.getCost()))
				.append("<br>");
			    } else if (isSystemClosureCost(projectCostDTO)) {
				changedCosts.append(" System Closure Cost").append(", Cost Value: ")
				.append(LMSUtils.getCostAppendedToTwoDecimal(projectCostDTO.getCost())).append("<br>");
			    }
			}
		    }
		}
		return changedCosts.toString();
	}

	private StringBuilder prepareMessageBodyForFinanceTeam(ProjectDTO projectDTO, String userId) {
		final StringBuilder messageBody = new StringBuilder();
		messageBody.append("Please provide account for this new Site Rem project <br><br>");
		messageBody.append("<p><b>Name of the site: </b>");
		messageBody.append(projectDTO.getProjectName());
		messageBody.append("</p>");
		messageBody.append("<p><b>Date of the incident: </b>");
		messageBody.append(WebDateUtil.getDisplayformat(projectDTO.getProjectDate()));
		messageBody.append("</p>");
		messageBody.append("<p><b>Operation or non-operating:</b> ");
		messageBody.append(LMSUtils.getTesNoValues(projectDTO.getOperStatFlag()));
		messageBody.append("</p>");
		messageBody.append("<p><b>Description of the site:</b> ");
		messageBody.append(projectDTO.getProjOthDesc());
		messageBody.append("</p>");
		messageBody.append("<p><b>Location:</b> ");
		messageBody.append(projectDTO.getCity());
		messageBody.append(", ");
		messageBody.append(projectDTO.getState());
		messageBody.append("</p>");
		messageBody.append("<p><b>Any internal UPRR labor:</b> ");
		messageBody.append(LMSUtils.getTesNoValues(projectDTO.getIntUprrLaborFlag()));
		messageBody.append("</p>");
		messageBody.append("<p><b>Track Time: </b>");
		messageBody.append(LMSUtils.getTesNoValues(projectDTO.getTrackTimeFlag()));
		messageBody.append("</p>");
		messageBody.append("<p><b>Telecomms: </b>");
		messageBody.append(LMSUtils.getTesNoValues(projectDTO.getTelecomFlag()));
		messageBody.append("</p>");
		messageBody.append("</body></html> ");
		return messageBody;
	}

	

}
