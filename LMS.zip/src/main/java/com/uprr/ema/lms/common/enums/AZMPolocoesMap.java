package com.uprr.ema.lms.common.enums;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public enum AZMPolocoesMap {

	PROJECT_SUBMIT_URL("submitProjDtls",Arrays.asList(AZMPolicies.PROJECT_Aprv,AZMPolicies.PROJECT_Create)),
	PROJECT_APRV_URL("approveProjDtls",Arrays.asList(AZMPolicies.PROJECT_Aprv)),
	PROJECT_DIS_APRV_URL("disAprvProjDtls",Arrays.asList(AZMPolicies.PROJECT_Dprv)),
	PROJECT_UPDT_URL("",Arrays.asList(AZMPolicies.PROJECT_Update,AZMPolicies.PROJECT_Aprv)),
	
	PROJECT_CHNG_SUBMIT_URL("submitProjChngDtls",Arrays.asList(AZMPolicies.PROJECT_CHANGE_Aprv,AZMPolicies.PROJECT_CHANGE_Create)),
	PROJECT_CHANGE_APRV_URL("approveProjChngDtls",Arrays.asList(AZMPolicies.PROJECT_CHANGE_Aprv)),
	PROJECT_CHANGE_DIS_APRV_URL("disAprvProjChngDtls",Arrays.asList(AZMPolicies.PROJECT_CHANGE_Dprv)),
	PROJECT_CHANGE_UPDT_URL("",Arrays.asList(AZMPolicies.PROJECT_CHANGE_Update,AZMPolicies.PROJECT_CHANGE_Aprv)),
	
	PROJECT_VIEW_URL("viewProjDtls",Arrays.asList(AZMPolicies.PROJECT_SUMMERIES_View));
	
	private String url;
	private List<AZMPolicies> additionalPolicies;
	private static Map<String,List<AZMPolicies>> urlPoliciesMap;
	
	private AZMPolocoesMap(String url,List<AZMPolicies> additionalPolicies){
		this.url=url;
		this.additionalPolicies=additionalPolicies;
	}
	
	 private static void initializeMapping() {
		 urlPoliciesMap = new HashMap<String, List<AZMPolicies>>();
	        for (AZMPolocoesMap s : AZMPolocoesMap.values()) {
	        	urlPoliciesMap.put(s.url, s.additionalPolicies);
	        }
	   }
	 
	 public static List<AZMPolicies> getPolicieByUrl(String url) {
	        if (urlPoliciesMap == null) {
	            initializeMapping();
	        }
	        if (urlPoliciesMap.containsKey(url)) {
	            return urlPoliciesMap.get(url);
	        }
	        return null;
	    }
}
