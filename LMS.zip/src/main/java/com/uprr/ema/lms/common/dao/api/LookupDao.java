package com.uprr.ema.lms.common.dao.api;

import java.util.List;

import com.uprr.ema.lms.common.dto.DropDownInfo;
import com.uprr.ema.lms.common.dto.ManagerDTO;
import com.uprr.ema.lms.searchproject.dto.ProjectSearchCriteriaDTO;
import com.uprr.ema.lms.searchproject.dto.SearchDTO;

public interface LookupDao {
	 /**
     * This is used to get the master data based on the inputs given like 
     * table name, 
     * master data table  column which is having code,
     * master data table  column which is having description
     * 
     * @param tableName
     * @param code
     * @param desc
     * @return
     * @
     */
    public List<DropDownInfo> getDropDownOnLoad(String tableName, String code, String desc);
    /**
     * This is used to get the master data based on the inputs given like 
     * table name, 
     * master data table  column which is having code,
     * master data table  column which is having description
     * 
     * @param tableName
     * @param code
     * @param desc
     * @param masterId
     * @param sortOrdNbr
     * @return
     * @
     */
    public List<DropDownInfo> getDropDownOnLoad(String tableName, String code, String desc,String masterId,String sortOrdNbr);
	/**
	 * Used to retrieve all Siterem managers.
	 * @return List<ManagerDTO>
	 * @
	 */
	
	public List<ManagerDTO> getManagers() ;
	/**
	 * Used to retrieve all states
	 * @return List<DropDownInfo>
	 * @
	 */
	public List<DropDownInfo> getStates();
    /**
     *   * This is used to get the master data based on the inputs given like 
     * table name, 
     * master data table  column which is having code,
     * master data table  column which is having alternate code,
     * master data table  column which is having description
     * @param tableName
     * @param code/masterID
     * @param alternateCode
     * @param desc
     * @return
     * @
     */
    public List<DropDownInfo> getDropDownOnLoad(String tableName, String code, 
	    String alternateCode, String desc) ;

    /**
     This is used to get the master data based on the inputs given like 
     * table name, 
     * master data table  column ID which is having ID,
     *  master data table  column which is having code,
     * master data table  column which is having description
     * @param tableName
     * @param codeId
     * @param code
     * @param desc
     * @return
     * @
     */
    public List<DropDownInfo> getDropDownOnLoadForId(String tableName,
	    String codeId, String code, String desc) ;
    
    /**
	 * This method will return one record based on whereId
	 * @param dropDownInfo 
	 * @return DropDownInfo
	 * @
	 */
	public DropDownInfo getDataById(DropDownInfo dropDownInfo) ;
	/**
	 * Get the DropDownInfo entire object based on the masterId for the given tableName
	 * @param masterId
	 * @param tableName
	 * @return
	 * @
	 */
	//public DropDownInfo getDropDownInfoByMstrId(long masterId,String tableName) ;
	
	public DropDownInfo getDropDownInfoByCode(String tableName,String masterIdColumn, String codeColumn,String descprtionColumn,String codeValue)  ;

	List<DropDownInfo> getDropDownOnLoadOrderBy(String tableName, String code, String alternateCode, String desc,
			String orderBy);
	
	/**
	 * To get the master data based on the order by one of the column mentioned in the argument(orderByColumn) of method
	 * @param tableName
	 * @param id
	 * @param code
	 * @param desc
	 * @param orderByColumn
	 * @return
	 */
	public List<DropDownInfo> getDropDownsBySortOrder(String tableName, String id, 
		String code, String desc, String orderByColumn);
	
	/**
	 * <p> Get Desription From Master Table based on Its Master Code </p>
	 */
	public String getDescription(String tableName,String masterCodeColumnName,String masterCode);
	
	/**
	 * <p>Get All the project names which strats with given @param </p>
	 * @param projectName
	 * @return List<DropDownInfo>
	 */
	public List<DropDownInfo> getProjectNames(String tableName, String code, String desc,String projectName);
	
}
