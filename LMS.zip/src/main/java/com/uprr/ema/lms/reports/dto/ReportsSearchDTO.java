package com.uprr.ema.lms.reports.dto;

import java.io.Serializable;

import com.uprr.ema.lms.common.dto.BaseDTO;

public class ReportsSearchDTO extends BaseDTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
}
