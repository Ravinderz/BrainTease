package com.uprr.ema.lms.common.util;

import java.io.IOException;
import java.net.NoRouteToHostException;
import java.net.UnknownHostException;

import org.apache.commons.httpclient.HttpMethod;
import org.apache.commons.httpclient.HttpMethodRetryHandler;
import org.apache.commons.httpclient.NoHttpResponseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RetryHandler implements HttpMethodRetryHandler {
	private int retryCount = 0;
	private final int maxRetries = 10;
	private static Logger logger = LoggerFactory.getLogger(RetryHandler.class.getName());
	
	public RetryHandler() {
		//Auto-generated constructor stub
	}
	
	public boolean retryMethod(final HttpMethod method, final IOException exception, int executionCount) {
		Boolean status = null;
		// Do not retry if over max retry count
		if (executionCount >= maxRetries) {
			logger.error("HTTP Retry-Max Retries Exceeded");
			status = false;
		}
		
		// Don't Retry if unknown host
		if (status == null && exception instanceof UnknownHostException) {
			logger.error("HTTP Retry-UnknownHost");
			retryCount++;
            try {
                Thread.sleep(2000);
            }
            catch (InterruptedException e) {
            	logger.error(e.toString());
            }
            status = true;
		}
		
		// Retry if the server dropped connection on us
		if (status == null && exception instanceof NoHttpResponseException) {
			
			logger.error("HTTP Retry-NoHttpResponse");
			retryCount++;
			try {
				Thread.sleep(2000);
			}
			catch (InterruptedException e) {
				logger.error(e.toString());
			}
			status = true;
		}
		
		// Retry if route not found		
		if (status == null && exception instanceof NoRouteToHostException) {
			logger.error("HTTP Retry-NoRouteToHost");
			retryCount++;
			try {
				Thread.sleep(2000);
			}
			catch (InterruptedException e) {
				logger.error(e.toString());
			}
			status = true;
		}
		
		if (status == null && !method.isRequestSent()) {
			// Retry if the request has not been sent fully or
			// if it's OK to retry methods that have been sent
			logger.info("HTTP Retry-RequestNotSent");
			retryCount++;
			try {
				Thread.sleep(2000);
			}
			catch (InterruptedException e) {
				logger.error(e.toString());
			}
			status = true;
		}

		if(status == null) {
			status = false;
		}
		
		return status;
	}

	public int getRetryCount() {
		return retryCount;
	}
	
	public long getRetrySleepTime() {
		return retryCount*2000;
	}
}
