package com.uprr.ema.lms.common.service.util;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormat;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.util.IOUtils;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.uprr.ema.lms.common.enums.StyleAttribute;

public class XlsxBuilder {

    /**
     * Underlined workbook.
     */
    private Workbook workbook;
    /**
     * Current sheet.
     */
    private Sheet sheet = null;
    /**
	 * @return the workbook
	 */
	public Workbook getWorkbook() {
		return workbook;
	}
	/**
	 * @param workbook the workbook to set
	 */
	public void setWorkbook(Workbook workbook) {
		this.workbook = workbook;
	}
	/**
	 * @return the sheet
	 */
	public Sheet getSheet() {
		return sheet;
	}
	/**
	 * @param sheet the sheet to set
	 */
	public void setSheet(Sheet sheet) {
		this.sheet = sheet;
	}
	/**
     * Current row.
     */
    private Row row = null;
    /**
     * Next row index.
     */
    private int nextRowIdx = 0;
    /**
     * Style attributes for row.
     */
    private Set<StyleAttribute> rowStyleAttributes;
    /**
     * Next column index.
     */
    private int nextColumnIdx = 0;
    private Map<Set<StyleAttribute>, CellStyle> styleBank = new HashMap<Set<StyleAttribute>, CellStyle>();
    /**
     * Creates new instance.
     */
    public XlsxBuilder() {
        workbook = new XSSFWorkbook();
    }
    /**
     * Starts sheet.
     *
     * @param name sheet name
     * @return this instance
     */
    public XlsxBuilder startSheet(String name) {
        sheet = workbook.createSheet(name);
        nextRowIdx = 0;
        nextColumnIdx = 0;
        rowStyleAttributes = new HashSet<StyleAttribute>();
        return this;
    }
    
    public XlsxBuilder startBlankSheet(String name) {
        sheet = workbook.createSheet(name);
        sheet.setDisplayGridlines(false);
        nextRowIdx = 0;
        nextColumnIdx = 0;
        rowStyleAttributes = new HashSet<StyleAttribute>();
        return this;
    }
    /**
     * Sets auto sizing columns.
     *
     * @param idx column index, starting from 0
     * @return this instance
     */
    public XlsxBuilder setAutoSizeColumn(int idx) {
        sheet.autoSizeColumn(idx);
        return this;
    }
    /**
     * Sets column size.
     *
     * @param idx column index, starting from 0
     * @param m number of 'M' standard characters to use for size calculation
     * @return this instance
     */
    public XlsxBuilder setColumnSize(int idx, int m) {
        sheet.setColumnWidth(idx, (m + 1) * 256);
        return this;
    }
    /**
     * Starts new row.
     *
     * @return this instance
     */
    public XlsxBuilder startRow() {
        row = sheet.createRow(nextRowIdx);
        nextRowIdx = nextRowIdx + 1;
        nextColumnIdx = 0;
        rowStyleAttributes = new HashSet<StyleAttribute>();
        return this;
    }
    
    public XlsxBuilder startRecordTitleRow() {
    	nextRowIdx = 1;
        row = sheet.createRow(nextRowIdx);
        nextRowIdx = 4;
        nextColumnIdx = 0;
        rowStyleAttributes = new HashSet<StyleAttribute>();
        return this;
    }
    
    
    /**
     * Sets row top border as thin.
     *
     * @return this instance
     */
    public XlsxBuilder setRowThinTopBorder() {
        row.setRowStyle(getCellStyle(StyleAttribute.THIN_TOP_BORDER));
        rowStyleAttributes.add(StyleAttribute.THIN_TOP_BORDER);
        return this;
    }
    /**
     * Sets row top border as thick.
     *
     * @return this instance
     * must be called before inserting columns
     */
    public XlsxBuilder setRowThickTopBorder() {
        row.setRowStyle(getCellStyle(StyleAttribute.THICK_TOP_BORDER));
        rowStyleAttributes.add(StyleAttribute.THICK_TOP_BORDER);
        return this;
    }
    /**
     * Sets row bottom border as thin.
     *
     * @return this instance
     * must be called before inserting columns
     */
    public XlsxBuilder setRowThinBottomBorder() {
        row.setRowStyle(getCellStyle(StyleAttribute.THIN_BOTTOM_BORDER));
        rowStyleAttributes.add(StyleAttribute.THIN_BOTTOM_BORDER);
        return this;
    }
    /**
     * Sets row bottom border as thick.
     *
     * @return this instance
     * must be called before inserting columns
     */
    public XlsxBuilder setRowThickBottomBorder() {
        row.setRowStyle(getCellStyle(StyleAttribute.THICK_BOTTOM_BORDER));
        rowStyleAttributes.add(StyleAttribute.THICK_BOTTOM_BORDER);
        return this;
    }
    /**
     * Sets row height to capture the title.
     *
     * @return this instance
     * must be called before inserting columns
     */
    public XlsxBuilder setRowTitleHeight() {
        row.setHeightInPoints(30);
        return this;
    }
    /**
     * Adds title column.
     *
     * @param text text
     * @return this instance
     */
    public XlsxBuilder addTitleTextColumn(String text,String reportType) {
    	Cell cell = null;
    	CellStyle style = getCellStyle(StyleAttribute.TITLE_SIZE, StyleAttribute.BOLD,StyleAttribute.THIN_RIGHT_BORDER,StyleAttribute.THIN_LEFT_BORDER,StyleAttribute.THIN_BOTTOM_BORDER,StyleAttribute.THIN_TOP_BORDER);
    	if(reportType.equalsIgnoreCase("sitesource")){
    		cell = row.createCell(nextColumnIdx+1);	
    		style = getCellStyle(StyleAttribute.SITE_SOURCE_HEADER);
    	}else{
    		cell = row.createCell(nextColumnIdx);
    	}

        cell.setCellStyle(style);
        cell.setCellValue(StringUtils.stripToEmpty(text));
        nextColumnIdx = nextColumnIdx + 1;
        return this;
    }
    
    public XlsxBuilder addSimpleHeaderColumn(String text) {
    	Cell cell = null;
    	CellStyle style = getCellStyle(StyleAttribute.SIMPLE_ARIAL_8);
   		cell = row.createCell(nextColumnIdx);	
        cell.setCellStyle(style);
        cell.setCellValue(StringUtils.stripToEmpty(text));
        nextColumnIdx = nextColumnIdx + 1;
        return this;
    }
    
    public XlsxBuilder addSimpleBoldHeaderColumn(String text) {
    	Cell cell = null;
    	CellStyle style = getCellStyle(StyleAttribute.SIMPLE_ARIAL_8,StyleAttribute.BOLD,StyleAttribute.THIN_RIGHT_BORDER,StyleAttribute.THIN_LEFT_BORDER,StyleAttribute.THIN_BOTTOM_BORDER,StyleAttribute.THIN_TOP_BORDER);
   		cell = row.createCell(nextColumnIdx);	
        cell.setCellStyle(style);
        cell.setCellValue(StringUtils.stripToEmpty(text));
        nextColumnIdx = nextColumnIdx + 1;
        return this;
    }
    
    
    public XlsxBuilder addRightAlignedTitleTextColumn(String text,String reportType) {
    	Cell cell = null;
    	CellStyle style = getCellStyle(StyleAttribute.TITLE_SIZE, StyleAttribute.BOLD,StyleAttribute.THIN_RIGHT_BORDER,StyleAttribute.THIN_LEFT_BORDER,StyleAttribute.THIN_BOTTOM_BORDER,StyleAttribute.THIN_TOP_BORDER);
    	if(reportType.equalsIgnoreCase("sitesource")){
    		cell = row.createCell(nextColumnIdx+1);	
    		style = getCellStyle(StyleAttribute.SITE_SOURCE_HEADER,StyleAttribute.ALIGN_RIGHT);
    	}else{
    		cell = row.createCell(nextColumnIdx);
    	}

        cell.setCellStyle(style);
        cell.setCellValue(StringUtils.stripToEmpty(text));
        nextColumnIdx = nextColumnIdx + 1;
        return this;
    }
    
    public XlsxBuilder addTitleFormulaColumn(String text,String reportType,String alignment) {
    	Cell cell = null;
    	CellStyle style = getCellStyle(StyleAttribute.TITLE_SIZE, StyleAttribute.BOLD,StyleAttribute.THIN_RIGHT_BORDER,StyleAttribute.THIN_LEFT_BORDER,StyleAttribute.THIN_BOTTOM_BORDER,StyleAttribute.THIN_TOP_BORDER);
    	if(reportType.equalsIgnoreCase("sitesource")){
    		cell = row.createCell(nextColumnIdx+1);	
    		if(alignment.equalsIgnoreCase("ALIGN_RIGHT")){
    			style = getCellStyle(StyleAttribute.SITE_SOURCE_HEADER,StyleAttribute.ALIGN_RIGHT);	
    		}else{
    			style = getCellStyle(StyleAttribute.SITE_SOURCE_FORMULA_HEADER,StyleAttribute.ALIGN_LEFT);
    		}
    		
    	}else{
    		cell = row.createCell(nextColumnIdx);
    	}

        cell.setCellStyle(style);
        cell.setCellType(HSSFCell.CELL_TYPE_FORMULA);
        cell.setCellFormula(text);
        //cell.setCellValue(StringUtils.stripToEmpty(text)); 
        nextColumnIdx = nextColumnIdx + 1;
        return this;
    }
    
    public XlsxBuilder addTitleFormulaWithDoubleValueColumn(String text,String reportType,String alignment) {
    	Cell cell = null;
    	CellStyle style = null;
    	if(reportType.equalsIgnoreCase("sitesource")){
    		cell = row.createCell(nextColumnIdx+1);	
    		if(alignment.equalsIgnoreCase("ALIGN_RIGHT")){
    			style = getCellStyle(StyleAttribute.SITE_SOURCE_HEADER,StyleAttribute.DOUBLE_VALUE,StyleAttribute.ALIGN_RIGHT);	
    		}else{
    			style = getCellStyle(StyleAttribute.SITE_SOURCE_FORMULA_HEADER,StyleAttribute.ALIGN_LEFT);
    		}
    		
    	}else{
    		cell = row.createCell(nextColumnIdx);
    	}

        cell.setCellStyle(style);
        cell.setCellType(HSSFCell.CELL_TYPE_FORMULA);
        cell.setCellFormula(text);
        nextColumnIdx = nextColumnIdx + 1;
        return this;
    }
    
    public XlsxBuilder addFormulaWithDoubleColumn(String text) {
        Cell cell = row.createCell(nextColumnIdx);
        CellStyle style = getCellStyle(StyleAttribute.DOUBLE_VALUE);
        //cell.setCellValue(StringUtils.stripToEmpty(text));
        cell.setCellStyle(style);
        cell.setCellType(HSSFCell.CELL_TYPE_FORMULA);
        cell.setCellFormula(text);
        nextColumnIdx = nextColumnIdx + 1;
        return this;
    }
    
    
    public XlsxBuilder addMainRowTextColumn(String text) {
    	Cell cell = row.createCell(nextColumnIdx);
    	CellStyle style = getCellStyle(StyleAttribute.SITE_SOURCE_MAIN_HEADER,StyleAttribute.THIN_RIGHT_BORDER,StyleAttribute.THIN_LEFT_BORDER,StyleAttribute.THIN_BOTTOM_BORDER,StyleAttribute.THIN_TOP_BORDER);
        cell.setCellStyle(style);
        cell.setCellValue(StringUtils.stripToEmpty(text));
        nextColumnIdx = nextColumnIdx + 1;
        return this;
    }
    
    public XlsxBuilder addReportHeaderTextColumn(String text,String reportType) {
    	Cell cell = null;
    	if(reportType.equalsIgnoreCase("BPPD")){
    		sheet.addMergedRegion(new CellRangeAddress(1,1,0,7));
    		cell = row.createCell(nextColumnIdx);
    		
    	}else if(reportType.equalsIgnoreCase("sitesource")){
    		cell = row.createCell(nextColumnIdx+1);
    	}
        
        CellStyle style = getCellStyle(StyleAttribute.RECORD_TITLE_SIZE, StyleAttribute.BOLD);
        cell.setCellStyle(style);
        cell.setCellValue(StringUtils.stripToEmpty(text));
        nextColumnIdx = nextColumnIdx + 1;
        return this;
    }
    
    public XlsxBuilder addBppdDataHeaderTextColumn(String text) {
        Cell cell = row.createCell(nextColumnIdx);
        CellStyle style = getCellStyle(StyleAttribute.BPPD_DATA_HEADER_TITLE,StyleAttribute.THIN_RIGHT_BORDER,StyleAttribute.THIN_LEFT_BORDER,StyleAttribute.THIN_BOTTOM_BORDER,StyleAttribute.THIN_TOP_BORDER);
        cell.setCellStyle(style);
        cell.setCellValue(StringUtils.stripToEmpty(text));
        nextColumnIdx = nextColumnIdx + 1;
        return this;
    }
    
    public XlsxBuilder addSiteSourceDataHeaderTextColumn(String text) {
        Cell cell = row.createCell(nextColumnIdx+1);
        CellStyle style = getCellStyle(StyleAttribute.RECORD_TITLE_SIZE,StyleAttribute.THIN_RIGHT_BORDER,StyleAttribute.THIN_LEFT_BORDER,StyleAttribute.THIN_BOTTOM_BORDER,StyleAttribute.THIN_TOP_BORDER);
        cell.setCellStyle(style);
        cell.setCellValue(StringUtils.stripToEmpty(text));
        nextColumnIdx = nextColumnIdx + 1;
        return this;
    }
    
    /**
     * Adds simple left aligned text.
     *
     * @param text text
     * @return this instance
     */
    public XlsxBuilder addTextLeftAlignedColumn(String text) {
        Cell cell = row.createCell(nextColumnIdx);
        CellStyle style = getCellStyle(StyleAttribute.ALIGN_LEFT);
        cell.setCellStyle(style);
        cell.setCellValue(StringUtils.stripToEmpty(text));
        nextColumnIdx = nextColumnIdx + 1;
        return this;
    }
    
    public XlsxBuilder addDoubleColumn(double text) {
        Cell cell = row.createCell(nextColumnIdx);
        CellStyle style = getCellStyle(StyleAttribute.ALIGN_RIGHT,StyleAttribute.DOUBLE_VALUE);
        cell.setCellStyle(style);
        //cell.setCellValue(StringUtils.stripToEmpty(text));
        cell.setCellValue(text);
        nextColumnIdx = nextColumnIdx + 1;
        return this;
    }
    
    public XlsxBuilder addGreyedOutColumn(String text) {
        Cell cell = row.createCell(nextColumnIdx);
        CellStyle style = getCellStyle(StyleAttribute.GREYOUT);
        cell.setCellStyle(style);
        nextColumnIdx = nextColumnIdx + 1;
        return this;
    }
    
    public XlsxBuilder addTextLeftAlignedColumnWithBordersAndDataFormat(String text,String dataType,String reportType) {
        Cell cell = row.createCell(nextColumnIdx);
        DataFormat format = workbook.createDataFormat();
        CellStyle style = getCellStyle(StyleAttribute.ALIGN_LEFT,StyleAttribute.THIN_RIGHT_BORDER,StyleAttribute.THIN_LEFT_BORDER,StyleAttribute.THIN_BOTTOM_BORDER,StyleAttribute.THIN_TOP_BORDER);
        if(reportType.equalsIgnoreCase("MonthlySpend")){
        	style = getCellStyle(StyleAttribute.SITE_SOURCE_HEADER,StyleAttribute.ALIGN_LEFT,StyleAttribute.THIN_RIGHT_BORDER,StyleAttribute.THIN_LEFT_BORDER,StyleAttribute.THIN_BOTTOM_BORDER,StyleAttribute.THIN_TOP_BORDER);
        }else{
        	style = getCellStyle(StyleAttribute.ALIGN_LEFT,StyleAttribute.THIN_RIGHT_BORDER,StyleAttribute.THIN_LEFT_BORDER,StyleAttribute.THIN_BOTTOM_BORDER,StyleAttribute.THIN_TOP_BORDER);	
        }
        
        if(dataType.equalsIgnoreCase("Number")){
        	style.setDataFormat(format.getFormat("0"));
        }else if(dataType.equalsIgnoreCase("Decimal")){
        	style.setDataFormat(format.getFormat("0.00"));
        }
        cell.setCellStyle(style);
        cell.setCellValue(StringUtils.stripToEmpty(text));
        nextColumnIdx = nextColumnIdx + 1;
        return this;
    }
    
    /**
     * Adds simple left aligned text.
     *
     * @param text text
     * @return this instance
     */
    public XlsxBuilder addTextLeftAlignedColumnWithBorders(String text) {
        Cell cell = row.createCell(nextColumnIdx);
        CellStyle style = getCellStyle(StyleAttribute.ALIGN_LEFT,StyleAttribute.THIN_RIGHT_BORDER,StyleAttribute.THIN_LEFT_BORDER,StyleAttribute.THIN_BOTTOM_BORDER,StyleAttribute.THIN_TOP_BORDER);
        cell.setCellStyle(style);
        cell.setCellValue(StringUtils.stripToEmpty(text));
        nextColumnIdx = nextColumnIdx + 1;
        return this;
    }
    /**
     * Adds simple center aligned text.
     *
     * @param text text
     * @return this instance
     */
    public XlsxBuilder addTextCenterAlignedColumn(String text) {
        Cell cell = row.createCell(nextColumnIdx);
        CellStyle style = getCellStyle(StyleAttribute.ALIGN_CENTER);
        cell.setCellStyle(style);
        cell.setCellValue(StringUtils.stripToEmpty(text));
        nextColumnIdx = nextColumnIdx + 1;
        return this;
    }
    /**
     * Adds simple center aligned text.
     *
     * @param val value
     * @return this instance
     */
    public XlsxBuilder addDoubleCenterAlignedColumn(double val) {
        Cell cell = row.createCell(nextColumnIdx);
        CellStyle style = getCellStyle(StyleAttribute.ALIGN_CENTER);
        cell.setCellStyle(style);
        cell.setCellValue(val);
        nextColumnIdx = nextColumnIdx + 1;
        return this;
    }
    /**
     * Adds bold left aligned text.
     *
     * @param text text
     * @return this instance
     */
    public XlsxBuilder addBoldTextLeftAlignedColumn(String text) {
        Cell cell = row.createCell(nextColumnIdx);
        CellStyle style = getCellStyle(StyleAttribute.ALIGN_LEFT, StyleAttribute.BOLD);
        cell.setCellStyle(style);
        cell.setCellValue(StringUtils.stripToEmpty(text));
        nextColumnIdx = nextColumnIdx + 1;
        return this;
    }
    /**
     * Adds bold center aligned text.
     *
     * @param text text
     * @return this instance
     */
    public XlsxBuilder addBoldTextCenterAlignedColumn(String text) {
        Cell cell = row.createCell(nextColumnIdx);
        CellStyle style = getCellStyle(StyleAttribute.ALIGN_CENTER, StyleAttribute.BOLD);
        cell.setCellStyle(style);
        cell.setCellValue(StringUtils.stripToEmpty(text));
        nextColumnIdx = nextColumnIdx + 1;
        return this;
    }
    /**
     * Builds the result object.
     * Object cannot be reused after calling this method.
     *
     * @return created object
     */
    public byte[] build() {
        ByteArrayOutputStream bos = null;
        try {
            bos = new ByteArrayOutputStream();
            workbook.write(bos);
            bos.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        } finally {
            IOUtils.closeQuietly(bos);
        }
        return bos.toByteArray();
    }
    /**
     * To Set Filter
     */
    public XlsxBuilder setFilter(int fisrtRow,int lastRow,int firstColumn,int lastColumn){
    	 CellRangeAddress ca = new CellRangeAddress(fisrtRow, lastRow,
		    		sheet.getRow(0).getFirstCellNum(),
		    		sheet.getRow(0).getLastCellNum()-1);
    	 			sheet.setAutoFilter(ca);
    	 			
    	 			return this;
    }
    /**
     * Returns cell style.
     *
     * @param attrs attributes
     * @return cell style
     */
    private CellStyle getCellStyle(StyleAttribute... attrs) {
        Set<StyleAttribute> allattrs = new HashSet<StyleAttribute>();
        allattrs.addAll(rowStyleAttributes);
        allattrs.addAll(Arrays.asList(attrs));
        if (styleBank.containsKey(allattrs)) {
            return styleBank.get(allattrs);
        }
        CellStyle style = workbook.createCellStyle();
        Font font = workbook.createFont();
        style.setFont(font);
        style.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
        for (StyleAttribute attr : allattrs) {
            if (attr.equals(StyleAttribute.TITLE_SIZE)) {
                font.setFontHeightInPoints((short) 12);
                style.setFillForegroundColor(IndexedColors.LIGHT_YELLOW.index);
                style.setFillPattern(CellStyle.SOLID_FOREGROUND);
            }else if(attr.equals(StyleAttribute.RECORD_TITLE_SIZE)){
            	 font.setFontHeightInPoints((short) 14);
            	 font.setFontName("ARIAL");
            }else if(attr.equals(StyleAttribute.GREYOUT)){
            	style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.index);
                style.setFillPattern(CellStyle.SOLID_FOREGROUND);
            }else if(attr.equals(StyleAttribute.BPPD_DATA_HEADER_TITLE)){
            	font.setFontHeightInPoints((short) 10);
            	font.setFontName("ARIAL");
            	style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.index);
                style.setFillPattern(CellStyle.SOLID_FOREGROUND);
            }else if(attr.equals(StyleAttribute.SITE_SOURCE_HEADER)){
            	font.setFontHeightInPoints((short) 8);
            	font.setFontName("Arial");
            }else if(attr.equals(StyleAttribute.SITE_SOURCE_FORMULA_HEADER)){
            	font.setFontHeightInPoints((short) 8);
            	font.setFontName("Arial");
            	font.setColor(HSSFColor.RED.index);
            }else if(attr.equals(StyleAttribute.SITE_SOURCE_MAIN_HEADER)){
            	font.setFontHeightInPoints((short) 8);
            	font.setFontName("Arial");
            	style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.index);
                style.setFillPattern(CellStyle.SOLID_FOREGROUND);
            }
            else if (attr.equals(StyleAttribute.BOLD)) {
                font.setBoldweight(Font.BOLDWEIGHT_BOLD);
            }
            else if (attr.equals(StyleAttribute.THIN_TOP_BORDER)) {
                style.setBorderTop(CellStyle.BORDER_THIN);
            }else if (attr.equals(StyleAttribute.THIN_RIGHT_BORDER)) {
                style.setBorderRight(CellStyle.BORDER_THIN);
            }else if (attr.equals(StyleAttribute.THIN_LEFT_BORDER)) {
                style.setBorderLeft(CellStyle.BORDER_THIN);
            }
            else if (attr.equals(StyleAttribute.THIN_BOTTOM_BORDER)) {
                style.setBorderBottom(CellStyle.BORDER_THIN);
            }
            else if (attr.equals(StyleAttribute.THICK_TOP_BORDER)) {
                style.setBorderTop(CellStyle.BORDER_THICK);
            }
            else if (attr.equals(StyleAttribute.THICK_BOTTOM_BORDER)) {
                style.setBorderBottom(CellStyle.BORDER_THICK);
            }
            else if (attr.equals(StyleAttribute.ALIGN_LEFT)) {
                style.setAlignment(CellStyle.ALIGN_LEFT);
            }
            else if (attr.equals(StyleAttribute.ALIGN_CENTER)) {
                style.setAlignment(CellStyle.ALIGN_CENTER);
            }
            else if(attr.equals(StyleAttribute.SIMPLE_ARIAL_8)){
            	font.setFontHeightInPoints((short) 8);
            	font.setFontName("Arial");
            }
            else if (attr.equals(StyleAttribute.ALIGN_RIGHT)) {
                style.setAlignment(CellStyle.ALIGN_RIGHT);
            } else if (attr.equals(StyleAttribute.DOUBLE_VALUE)) {
            	DataFormat format = workbook.createDataFormat();
                style.setDataFormat(format.getFormat("_(\"$\"* #,##0_);_(\"$\"* (#,##0);_(\"$\"* \"-\"??_);_(@_)"));
                font.setFontHeightInPoints((short) 8);
            	font.setFontName("Arial");
                
            }
            
            else {
                throw new RuntimeException("unknown cell style attribute: " + attr);
            }
        }
        //style.setFont(font);
        styleBank.put(allattrs, style);
        return style;
    }
    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }
   
   
}
