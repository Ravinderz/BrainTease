package com.uprr.ema.lms.liabilityProject.vb;

import java.io.Serializable;

public class ProjectCostVB implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long costId;
	private long projID;
	private Long costTypeId;
	private Long costSubTypeId;
	private Long changeReasonDtlId;
	private long year;
	private Double cost;
	private Double oprnAndMaintCost;
	private Double sysClosureCost;
	private String costType;
	private String costSubType;
	private String action;
	private String actionType;
	private String previousAction;
	private String previousActionType;
	private String actFlag;
	private String crtdUser;
	private String lastUptdUser;
	private String crtdDate;
	private String lastUptdDate;
	private boolean dataChangedFlag;
	private Long disaprvCmtDtlId;
	private String empId;
	/**
	 * @return the costId
	 */
	public long getCostId() {
	    return costId;
	}
	/**
	 * @param costId the costId to set
	 */
	public void setCostId(long costId) {
	    this.costId = costId;
	}
	/**
	 * @return the projID
	 */
	public long getProjID() {
	    return projID;
	}
	/**
	 * @param projID the projID to set
	 */
	public void setProjID(long projID) {
	    this.projID = projID;
	}
	/**
	 * @return the costTypeId
	 */
	public Long getCostTypeId() {
	    return costTypeId;
	}
	/**
	 * @param costTypeId the costTypeId to set
	 */
	public void setCostTypeId(Long costTypeId) {
	    this.costTypeId = costTypeId;
	}
	/**
	 * @return the costSubTypeId
	 */
	public Long getCostSubTypeId() {
	    return costSubTypeId;
	}
	/**
	 * @param costSubTypeId the costSubTypeId to set
	 */
	public void setCostSubTypeId(Long costSubTypeId) {
	    this.costSubTypeId = costSubTypeId;
	}
	/**
	 * @return the year
	 */
	public long getYear() {
	    return year;
	}
	/**
	 * @param year the year to set
	 */
	public void setYear(long year) {
	    this.year = year;
	}

	
	/**
	 * @return the cost
	 */
	public Double getCost() {
	    return cost;
	}
	/**
	 * @param cost the cost to set
	 */
	public void setCost(Double cost) {
	    this.cost = cost;
	}
	/**
	 * @return the oprnAndMaintCost
	 */
	public Double getOprnAndMaintCost() {
	    return oprnAndMaintCost;
	}
	/**
	 * @param oprnAndMaintCost the oprnAndMaintCost to set
	 */
	public void setOprnAndMaintCost(Double oprnAndMaintCost) {
	    this.oprnAndMaintCost = oprnAndMaintCost;
	}
	/**
	 * @return the sysClosureCost
	 */
	public Double getSysClosureCost() {
	    return sysClosureCost;
	}
	/**
	 * @param sysClosureCost the sysClosureCost to set
	 */
	public void setSysClosureCost(Double sysClosureCost) {
	    this.sysClosureCost = sysClosureCost;
	}
	/**
	 * @return the costType
	 */
	public String getCostType() {
	    return costType;
	}
	/**
	 * @param costType the costType to set
	 */
	public void setCostType(String costType) {
	    this.costType = costType;
	}
	/**
	 * @return the costSubType
	 */
	public String getCostSubType() {
	    return costSubType;
	}
	/**
	 * @param costSubType the costSubType to set
	 */
	public void setCostSubType(String costSubType) {
	    this.costSubType = costSubType;
	}
	/**
	 * @return the actFlag
	 */
	public String getActFlag() {
	    return actFlag;
	}
	/**
	 * @param actFlag the actFlag to set
	 */
	public void setActFlag(String actFlag) {
	    this.actFlag = actFlag;
	}
	/**
	 * @return the crtdUser
	 */
	public String getCrtdUser() {
	    return crtdUser;
	}
	/**
	 * @param crtdUser the crtdUser to set
	 */
	public void setCrtdUser(String crtdUser) {
	    this.crtdUser = crtdUser;
	}
	/**
	 * @return the lastUptdUser
	 */
	public String getLastUptdUser() {
	    return lastUptdUser;
	}
	/**
	 * @param lastUptdUser the lastUptdUser to set
	 */
	public void setLastUptdUser(String lastUptdUser) {
	    this.lastUptdUser = lastUptdUser;
	}
	/**
	 * @return the crtdDate
	 */
	public String getCrtdDate() {
	    return crtdDate;
	}
	/**
	 * @param crtdDate the crtdDate to set
	 */
	public void setCrtdDate(String crtdDate) {
	    this.crtdDate = crtdDate;
	}
	/**
	 * @return the lastUptdDate
	 */
	public String getLastUptdDate() {
	    return lastUptdDate;
	}
	/**
	 * @param lastUptdDate the lastUptdDate to set
	 */
	public void setLastUptdDate(String lastUptdDate) {
	    this.lastUptdDate = lastUptdDate;
	}
	
	/**
	 * @return the dataChangedFlag
	 */
	public boolean isDataChangedFlag() {
	    return dataChangedFlag;
	}
	/**
	 * @param dataChangedFlag the dataChangedFlag to set
	 */
	public void setDataChangedFlag(boolean dataChangedFlag) {
	    this.dataChangedFlag = dataChangedFlag;
	}
	/**
	 * @return the action
	 */
	public String getAction() {
	    return action;
	}
	/**
	 * @param action the action to set
	 */
	public void setAction(String action) {
	    this.action = action;
	}
	/**
	 * @return the actionType
	 */
	public String getActionType() {
	    return actionType;
	}
	/**
	 * @param actionType the actionType to set
	 */
	public void setActionType(String actionType) {
	    this.actionType = actionType;
	}
	/**
	 * @return the changeReasonDtlId
	 */
	public Long getChangeReasonDtlId() {
	    return changeReasonDtlId;
	}
	/**
	 * @param changeReasonDtlId the changeReasonDtlId to set
	 */
	public void setChangeReasonDtlId(Long changeReasonDtlId) {
	    this.changeReasonDtlId = changeReasonDtlId;
	}
	/**
	 * @return the previousAction
	 */
	public String getPreviousAction() {
	    return previousAction;
	}
	/**
	 * @param previousAction the previousAction to set
	 */
	public void setPreviousAction(String previousAction) {
	    this.previousAction = previousAction;
	}
	/**
	 * @return the previousActionType
	 */
	public String getPreviousActionType() {
	    return previousActionType;
	}
	/**
	 * @param previousActionType the previousActionType to set
	 */
	public void setPreviousActionType(String previousActionType) {
	    this.previousActionType = previousActionType;
	}
	/**
	 * @return the disaprvCmtDtlId
	 */
	public Long getDisaprvCmtDtlId() {
	    return disaprvCmtDtlId;
	}
	/**
	 * @param disaprvCmtDtlId the disaprvCmtDtlId to set
	 */
	public void setDisaprvCmtDtlId(Long disaprvCmtDtlId) {
	    this.disaprvCmtDtlId = disaprvCmtDtlId;
	}
	public String getEmpId() {
	    return empId;
	}
	public void setEmpId(String empId) {
	    this.empId = empId;
	}

}
