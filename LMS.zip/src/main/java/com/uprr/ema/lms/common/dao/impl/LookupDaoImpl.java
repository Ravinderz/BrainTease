package com.uprr.ema.lms.common.dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Repository;

import com.uprr.ema.lms.common.dao.api.LookupDao;
import com.uprr.ema.lms.common.dto.DropDownInfo;
import com.uprr.ema.lms.common.dto.ManagerDTO;
import com.uprr.ema.lms.searchproject.dto.ProjectSearchCriteriaDTO;
import com.uprr.ema.lms.searchproject.dto.SearchDTO;

@Repository("lookupDao")
public class LookupDaoImpl extends OracleDaoImpl implements LookupDao {

	/**
	 * {@inheritDoc}
	 */
	@Override
	public List<DropDownInfo> getDropDownOnLoad(String tableName, String code,
			String desc,String masterId,String sortOrdNbr )  {
		StringBuilder query = null;
		try {
			query = new StringBuilder();
			query.append("select distinct TRIM(" + code + ") as code, TRIM(" + desc
					+ ") as description," + masterId + " as codeId,"+ sortOrdNbr +" as orderbyNum FROM " + tableName
					+ " where 1=1 and "+ code +"  is not null and ACT_FLAG = 'C' order by " + sortOrdNbr);
			return (ArrayList<DropDownInfo>) getNamedParamResultsList(
					query.toString(), DropDownInfo.class);
		} finally {
			query = null;
		}
	}
	/**
	 * {@inheritDoc}
	 */
	@Override
	public List<ManagerDTO> getManagers() {
		StringBuffer query = null;
	    ArrayList<ManagerDTO> dataList = null;
	    try {
			query = new StringBuffer();
			query.append("Select PROJ_MGR_ID  as managerId ,PROJ_MGR_FIR_NAME as firstName,PROJ_MGR_MIDL_NAME as middleName, PROJ_MGR_LAST_NAME as lastName ,PROJ_MGR_FIR_NAME ||NVL2 (PROJ_MGR_MIDL_NAME,' '||TRIM( PROJ_MGR_MIDL_NAME),'') || NVL2 (PROJ_MGR_LAST_NAME,' '||TRIM(PROJ_MGR_LAST_NAME),'') AS fullName,PROJ_MGR_LDAP_ID as userId,PROJ_MGR_EMPL_ID as employeeId from EMA_LMS_PROJ_MGR_MSTR  M WHERE  UPPER(M.ACT_FLAG) = 'C'  ORDER BY SORT_ORD ");
			dataList = (ArrayList<ManagerDTO>) getNamedParamResultsList(query.toString(),ManagerDTO.class);
	    } finally {
			query = null;
		}
	    
	    return dataList;
	}
	/**
	 * {@inheritDoc}
	 */
	@Override
	public List<DropDownInfo> getStates()  {
		
		StringBuffer query = null;
		ArrayList<DropDownInfo> dataList = null;
		try {
			query = new StringBuffer();
			query.append("Select ST_CODE as code,ST_DESC as description from EMA_LMS_ST_MSTR WHERE ACT_FLAG = 'C' ORDER BY description");
			dataList = (ArrayList<DropDownInfo>) getNamedParamResultsList(query.toString(),DropDownInfo.class);
		} finally {
			query = null;
		}
		
		return dataList;
	}
	
	public Map<String,Object> getMapOfDropDowns(String tableName, String code,
		String desc,String masterId)  {
	    StringBuilder query = null;
	    try {
		query = new StringBuilder();
		query.append("SELECT DISTINCT "+masterId+" , TRIM(" + code + ") FROM " + tableName + " WHERE    "+ code +"  IS NOT NULL AND ACT_FLAG ='C'");
		return (Map<String,Object>) getJdbcTemplate().queryForMap(query.toString());
	    } finally {
		query = null;
	    }
	}
	
	/*@Override
	public DropDownInfo getDropDownInfoByMstrId(long masterId,String tableName)  {
	    String query = null;
	    if(tableName.equalsIgnoreCase(ServiceConstants.MAIL_AUDT_TYPE_MSTR)){
		query = "SELECT AUD_TYPE_ID codeId, AUD_TYPE_CODE code, AUD_TYPE_DESC description FROM EMA_SITE_AUD_TYPE_MSTR A WHERE A.AUD_TYPE_ID = ?";
	    }
	    return (DropDownInfo)getNamedParamResultObject(query, new Object[] { masterId }, DropDownInfo.class);
	}
	*/
	
	public DropDownInfo getDropDownInfoByCode(String tableName,String masterIdColumn, String codeColumn,String descprtionColumn,String codeValue)  {
	    StringBuilder query = new StringBuilder("");
	    query.append("select ").append(masterIdColumn).append(" as codeId, TRIM(").append(codeColumn).append( ") as code, TRIM(").append(descprtionColumn)
	    .append(") as description from ").append(tableName).append(" WHERE ACT_FLAG = 'C' AND ").append(codeColumn).append(" = ?");
	    return (DropDownInfo) getNamedParamResultObject(query.toString(), new Object[] { codeValue }, DropDownInfo.class);
	}
	
	/**
	 * {@inheritDoc}
	 */
	/*public List<DropDownInfo> getDropDownOnLoadForId(String tableName, 
		String codeId, String code, String desc)  {
	    StringBuilder query = null;
	    try {
		query = new StringBuilder();
		query.append("select distinct TRIM(" + codeId + ") as codeId,TRIM(" + code + ") as code, TRIM(" + desc
			+ ") as description from " + tableName
			+ " where 1=1 and "+ code +"  is not null and ACT_FLAG = 'C' order by description");
		return (ArrayList<DropDownInfo>) getNamedParamResultsList(
			query.toString(), DropDownInfo.class);
	    } finally {
		query = null;
	    }
	}
	*/
	
	public List<DropDownInfo> getDropDownOnLoadForId(String tableName, 
		String codeIdCoumn, String codeColumn, String descColumn)  {
	    StringBuilder query = null;
	    try {
		query = new StringBuilder();
		query.append("SELECT DISTINCT ")
		.append( codeIdCoumn)
		.append(" AS codeId,TRIM(" )
		.append(codeColumn)
		.append(") AS code, TRIM(" )
		.append( descColumn)
		.append(") AS description FROM " )
		.append( tableName)
		.append(" where ")
		.append(codeColumn)
		.append("  IS NOT NULL AND ACT_FLAG = 'C' ORDER BY ")
		.append(" description ");
		return (ArrayList<DropDownInfo>) getNamedParamResultsList(
			query.toString(), DropDownInfo.class);
	    } finally {
		query = null;
	    }
	}
	
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public List<DropDownInfo> getDropDownOnLoad(String tableName, String code, String alternateCode, String desc)
			 {
		StringBuilder query = null;
		try {
			query = new StringBuilder();
			query.append("select distinct TRIM(" + code + ") as code, TRIM(" + alternateCode + ") as alternateCode, TRIM(" + desc
					+ ") as description from " + tableName
					+ " where 1=1 and "+ code +"  is not null and " + alternateCode +"  is not null and ACT_FLAG = 'C' order by description ");
			return (ArrayList<DropDownInfo>) getNamedParamResultsList(
					query.toString(), DropDownInfo.class);
		} finally {
			query = null;
		}
	}
	
	@Override
	public List<DropDownInfo> getDropDownOnLoadOrderBy(String tableName, String code, String alternateCode, String desc, String orderBy)
			 {
		StringBuilder query = null;
		try {
			query = new StringBuilder();
			query.append("select distinct TRIM(" + code + ") as code, TRIM(" + alternateCode + ") as alternateCode, TRIM(" + desc
					+ ") as description , "+ orderBy +" as parentCode from " + tableName
					+ " where 1=1 and "+ code +"  is not null and " + alternateCode +"  is not null and ACT_FLAG = 'C' order by  parentCode asc");
			return (ArrayList<DropDownInfo>) getNamedParamResultsList(
					query.toString(), DropDownInfo.class);
		} finally {
			query = null;
		}
	}
	
	
	@Override
	public List<DropDownInfo> getDropDownsBySortOrder(String tableName, String id, 
		String code, String desc, String orderByColumn)
	{
	    StringBuilder query = null;
	    try {
		query = new StringBuilder();
		query.append("SELECT DISTINCT TRIM(").append(id).append(") AS code, TRIM(").append(code).append(") AS alternateCode, TRIM(")
		.append(desc).append(") AS description ,").append(orderByColumn).append(" AS orderbyNum FROM ").append(tableName)
		.append(" WHERE ").append(id).append(" IS NOT NULL AND ").append(code).append(" IS NOT NULL AND ACT_FLAG = 'C' ORDER BY ")
		.append(orderByColumn);
		return (ArrayList<DropDownInfo>) getNamedParamResultsList(query.toString(), DropDownInfo.class);
	    } finally {
		query = null;
	    }
	}

	/**
	 * {@inheritDoc}}
	 */
	@Override
	public DropDownInfo getDataById(DropDownInfo dropDownInfo)  {
		StringBuilder query = null;
		try {
			query = new StringBuilder();
			query.append("select distinct TRIM(" + dropDownInfo.getCode() + ") as code, TRIM("
					+ dropDownInfo.getAlternateCode() + ") as alternateCode from " + dropDownInfo.getTableName()
					+ " where 1=1 and " + dropDownInfo.getCode() + " = " + dropDownInfo.getCodeId()+" and ACT_FLAG = 'C' order by REQD_WORK_DESC");			
			return (DropDownInfo) getNamedParamResultObject(query.toString(),null, DropDownInfo.class);
		} finally {
			query = null;
		}
	}

	

	@Override
	public String getDescription(String tableName,String masterCodeColumnName,String masterCode){
		 StringBuffer query = null;
	      String  description = "";
	        try {
	            query = new StringBuffer();
	            query.append("Select prop_insp_desc from "+tableName+" where "+masterCodeColumnName+" = '"+masterCode+"'");
	            description = (String)getNamedParamResultObject(query.toString(),null,String.class);
	        }
	        finally {
	            query = null;
	        }
	        return description;
	}
	@Override
	public List<DropDownInfo> getDropDownOnLoad(String tableName, String code, String desc) {

		StringBuilder query = null;
		try {
			query = new StringBuilder();
			query.append("select distinct TRIM(" + code + ") as code,  TRIM(" + desc
					+ ") as description from " + tableName
					+ " where 1=1 and "+ code +"  is not null and  ACT_FLAG = 'C' order by description ");
			return (ArrayList<DropDownInfo>) getNamedParamResultsList(
					query.toString(), DropDownInfo.class);
		} finally {
			query = null;
		}
	
	}

	@Override
	public List<DropDownInfo> getProjectNames(String tableName, String code, String desc,String projectName){
		StringBuilder query = null;
		try {
			query = new StringBuilder();
			query.append("select distinct TRIM(" + code + ") as code,  TRIM(" + desc
					+ ") as description from " + tableName
					+ " where 1=1 and upper("+ desc +")  like (upper('"+projectName+"%'))  and  ACT_FLAG = 'C'");
			return (ArrayList<DropDownInfo>) getNamedParamResultsList(
					query.toString(), DropDownInfo.class);
		} finally {
			query = null;
		}
	}
	
	
	
		
	

}
