package com.uprr.ema.lms.common.service.api;

import com.uprr.ema.lms.xmf.employeesummary.ResponseType;

public interface IGetEmployeeDetails {

	String PERSON_GET_SERVICE_NAME = "person/find-cached-employee-summary/1.0";
	String PERSON_GET_NAMESPACE = "http://services.www.up.com/" + PERSON_GET_SERVICE_NAME;
	public String getEmployeeName(String empId); 
}
