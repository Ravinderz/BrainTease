package com.uprr.ema.lms.reports.dto;

import com.uprr.ema.lms.common.dto.SearchCriteriaDTO;

public class LCRRprtSearchCriteriaDTO extends SearchCriteriaDTO {
private static final long serialVersionUID = 1L;

private String month;
private String year;
/**
 * @return the month
 */
public String getMonth() {
	return month;
}
/**
 * @param month the month to set
 */
public void setMonth(String month) {
	this.month = month;
}
/**
 * @return the year
 */
public String getYear() {
	return year;
}
/**
 * @param year the year to set
 */
public void setYear(String year) {
	this.year = year;
}
/* (non-Javadoc)
 * @see java.lang.Object#toString()
 */
@Override
public String toString() {
	return "LCRReportsSearchCriteriaDTO [month=" + month + ", year=" + year + "]";
}
}
