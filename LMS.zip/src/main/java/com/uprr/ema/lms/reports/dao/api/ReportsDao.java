package com.uprr.ema.lms.reports.dao.api;

import java.util.List;
import java.util.Set;

import com.uprr.ema.lms.liabilityProject.dto.AccountCostDTO;
import com.uprr.ema.lms.reports.dto.BusinessPrepPlanDTO;
import com.uprr.ema.lms.reports.dto.LCRRprtChartDTO;
import com.uprr.ema.lms.reports.dto.LCRRprtDTO;
import com.uprr.ema.lms.reports.dto.MonthlySpendDTO;
import com.uprr.ema.lms.reports.dto.SiteSourceDTO;

public interface ReportsDao {
    public List<AccountCostDTO> getAccountData(String startRange,String endRange,String netwrokNumbers);
    /*public List<SearchDTO> getSearchResultThroughPagination(ProjectSearchCriteriaDTO projectSearchCriteriaDTO);
	public List<SearchDTO> getExcelReport(ProjectSearchCriteriaDTO projectSearchCriteriaDTO);
	public int getSearchResultRowCount(ProjectSearchCriteriaDTO projectSearchCriteriaDTO);
	public List<DropDownInfo> getProjectNames() ;*/
    public List<BusinessPrepPlanDTO> getBusinessPrepPlanData(String startRange,String endRange);
    public List<SiteSourceDTO> getPerYearSpendingData(Set<String> networkNumberSet,String endRange);
    public List<BusinessPrepPlanDTO> getspentAmount(String spentAmountYear);
    public List<MonthlySpendDTO> getMonthlySpendDataFromTeradata(Set<String> networkNumberSet,String startRange,String endRange);
    public List<LCRRprtChartDTO> getActualExpenditureData(String month,String year);
}
