package com.uprr.ema.lms.common.enums;

public enum StyleAttribute {
	/**
     * Thin top border.
     */
    THIN_TOP_BORDER,
    /**
     * Thin bottom border.
     */
    THIN_BOTTOM_BORDER,
    /**
     * Thick top border.
     */
    THICK_TOP_BORDER,
    /**
     * Thick bottom border.
     */
    THICK_BOTTOM_BORDER,
    
    RECORD_TITLE_SIZE,
    
    GREYOUT,
    
    DOUBLE_VALUE,
    
    BPPD_DATA_HEADER_TITLE,
    
    SITE_SOURCE_HEADER,
    
    SITE_SOURCE_FORMULA_HEADER,
    
    SITE_SOURCE_MAIN_HEADER,
    
    SIMPLE_ARIAL_8,
    
    /**
     * Title font size.
     */
    TITLE_SIZE,
    /**
     * Bold font.
     */
    BOLD,
    /**
     * Left alignment.
     */
    ALIGN_LEFT,
    
    ALIGN_RIGHT,
    /**
     * Center alignment.
     */
    ALIGN_CENTER,
    /**
     * Yellow BG color
     * 
     */
    YELLOW_BG_COLOR,
    /**
     * Thin Right border.
     */
    THIN_RIGHT_BORDER,
    /**
     * Thin Left border.
     */
    THIN_LEFT_BORDER
}
