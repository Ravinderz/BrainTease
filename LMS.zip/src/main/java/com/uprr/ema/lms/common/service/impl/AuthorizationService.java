package com.uprr.ema.lms.common.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uprr.app.azm.common.AzmRequest;
import com.uprr.app.azm.common.AzmSecurityUtils;
import com.uprr.app.azm.common.EvaluationBuilderFactory;
import com.uprr.ema.lms.common.enums.AZMPolicies;
import com.uprr.ema.lms.common.service.api.IAuthorizationService;

@Service
public class AuthorizationService  implements IAuthorizationService{

	@Autowired
	private AzmSecurityUtils azmSecurityUtils;
	@Override
	public boolean canSearchProject(String userId) {
		boolean isAuthorized = false;
		EvaluationBuilderFactory.EvaluationBuilder eb = EvaluationBuilderFactory.newEvaluation("User-authorized-to-initiate-workstation-evaluation-process");
		eb.addSubject("subject-id", userId);
		eb.addAction("action-id", "create");
		eb.addResource("resource-id", "environmental-liabilities");
		eb.addResource("feature-id", "project");
		AzmRequest authDto = new AzmRequest(eb.build());
		if(azmSecurityUtils.isAuthorized(authDto)) {
			isAuthorized = true;
		}
		return isAuthorized;
	}
	
	@Override
	public boolean canApprove(String userId) {
		boolean isAuthorized = false;
		EvaluationBuilderFactory.EvaluationBuilder eb = EvaluationBuilderFactory.newEvaluation("User-authorized-to-initiate-workstation-evaluation-process");
		eb.addSubject("subject-id", userId);
		eb.addAction("action-id", "approve");
		eb.addResource("resource-id", "environmental-liabilities");
		eb.addResource("feature-id", "project-update");
		AzmRequest authDto = new AzmRequest(eb.build());
		if(azmSecurityUtils.isAuthorized(authDto)) {
			isAuthorized = true;
		}
		return isAuthorized;
	}
	
	@Override
	public boolean canUpdateProject(String userId) {
		boolean isAuthorized = false;
		EvaluationBuilderFactory.EvaluationBuilder eb = EvaluationBuilderFactory.newEvaluation("User-authorized-to-initiate-workstation-evaluation-process");
		eb.addResource("resource-id", "environmental-liabilities");
		eb.addSubject("subject-id", userId);
		eb.addResource("feature-id", "project-update");
		eb.addAction("action-id", "update");
		AzmRequest authDto = new AzmRequest(eb.build());
		if(azmSecurityUtils.isAuthorized(authDto)) {
			isAuthorized = true;
		}
		return isAuthorized;
	}
	
	
	@Override
	public boolean canViewSummary(String userId) {
	    boolean isAuthorized = false;
	    EvaluationBuilderFactory.EvaluationBuilder eb = EvaluationBuilderFactory.newEvaluation("User-authorized-to-initiate-workstation-evaluation-process");
	    eb.addSubject("subject-id", userId);
	    eb.addResource("resource-id", "environmental-liabilities");
	    eb.addResource("feature-id", "project-summaries");
	    eb.addAction("action-id", "view");
	    AzmRequest authDto = new AzmRequest(eb.build());
	    if(azmSecurityUtils.isAuthorized(authDto)) {
		isAuthorized = true;
	    }
	    return isAuthorized;
	}
	/**
	 * 
	 */
	@Override
	public boolean isAutherized(String userId,String action_id,String feature_id,String resource_id) {

		boolean isAuthorized = false;
		EvaluationBuilderFactory.EvaluationBuilder eb = EvaluationBuilderFactory.newEvaluation("User-authorized-to-initiate-workstation-evaluation-process");
		eb.addSubject("subject-id", userId);
		eb.addAction("action-id", action_id);
		eb.addResource("feature-id", feature_id);
		eb.addResource("resource-id", resource_id);
		AzmRequest authDto = new AzmRequest(eb.build());
		if(azmSecurityUtils.isAuthorized(authDto)) {
			isAuthorized = true;
		}
		return isAuthorized;
	
	}
	
	

}
