package com.uprr.ema.lms.common;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LmsLogger {

	   // Default
	   private static final long serialVersionUID = 1L;

	   private transient Logger log;

	   private LmsLogger(String name) {
	      log = LoggerFactory.getLogger(name);
	   }

	   public static LmsLogger getLogger(Class<? extends Object> clazz) {
	      return new LmsLogger(clazz.getName());
	   }

	   public static LmsLogger getLogger(String name) {
	      return new LmsLogger(name);
	   }

	   public void writeMethodEntry(String methodName) {
		   log.info("Entered Method: " + methodName);
	   }

	   public void writeMethodExit(String methodName) {
	      log.info("Exit Method: " + methodName);
	   }

	   public void writeInfoMsg(String msgType, String msgDetails) {
		   log.info(msgType + ": " + msgDetails);
	   }
	   
	   
	   public void debug(String message) {
		   log.debug(message);
	   }
	   
	   public void debug(Throwable throwable, String methodName, Object[] methodParameters) {
		   log.info("Error Message: " + throwable.getMessage());
		   log.debug(getNonFatalMessage(throwable, methodName, methodParameters).toString());
	   }
	   
	   
	   public void info(String message) {
	      log.info(message);
	   }
	   
	   public void info(Throwable throwable, String methodName, Object[] methodParameters) {
		   log.info("Error Message: " + throwable.getMessage());
		   log.info(getNonFatalMessage(throwable, methodName, methodParameters).toString());
	   }


	   public void warn(String message) {
	      log.warn(message);
	   }

	   public void warn(Throwable throwable, String methodName, Object[] methodParameters) {
		   log.info("Error Message: " + throwable.getMessage());
		   log.warn(getNonFatalMessage(throwable, methodName, methodParameters).toString());
	   }

	   
	   public void error(String message) {
		   log.error(message);
	   }
	   
	   
	   /**
		 * @param throwable
		 * @param methodName
		 * @param methodParameters
		 */
	   public void error(Throwable throwable, String methodName, Object[] methodParameters) {
		   log.error(getNonFatalMessage(throwable, methodName, methodParameters).toString(),throwable);
	   }
	   
	   /**
		 * @param message
		 * @param throwable
		 */
	   public void error(String message, Throwable throwable) {
		   log.error("Exception cause:- ", throwable);
	   }
		   
	   public void error(String message, String methodName, Object[] methodParameters) {
		   StringBuffer errorMsgStr = new StringBuffer();
		   if (message != null) {
			   errorMsgStr.append("Exception:: ").append(message);
		   } 
		   if(methodName!=null){
			   errorMsgStr.append("Method:: ").append(methodName);
		   }
		   if(methodParameters!=null){
			   errorMsgStr.append("Parameters:: ").append(methodName);
			   for (Object param : methodParameters) {
				   errorMsgStr.append(param + ", ");
			   }
			   errorMsgStr.setCharAt(errorMsgStr.length() - 1, ' ');
		   }
		   log.error(errorMsgStr.toString());

	   }
	   
	   public void errorWithQryAndParams(String message, String methodName, Object[] methodParameters) {
	       StringBuffer errorMsgStr = new StringBuffer();
	       if (message != null) {
		   errorMsgStr.append("Exception:: ").append(message);
	       } 
	       if(methodName!=null){
		   errorMsgStr.append("Method:: ").append(methodName);
	       }
	       if(methodParameters!=null){
		   errorMsgStr.append("Parameters:: ").append(methodName);
		   if(methodParameters!=null && methodParameters.length>0){
		       String sql = (String) methodParameters[0];
		       errorMsgStr.append("query:").append(sql).append(",Actual Parameters:");

		       if(methodParameters.length>1){
			   Object[] params = (Object[]) methodParameters[1];
			   if(params!=null && params.length>0){
			       for (Object param : params) {
				   errorMsgStr.append(param + ", ");
			       }
			   }
		       }

		   }
		   errorMsgStr.setCharAt(errorMsgStr.length() - 1, ' ');
	       }
	       log.error(errorMsgStr.toString());

	}
	   
	   /*public void fatal(String message,Throwable throwable) {
		   log.info("Error Message: " + throwable.getMessage());
		   log.
	   }
	   
	   public void fatal(Throwable throwable, String methodName, Object[] methodParameters) {
		   log.info("Error Message: " + throwable.getMessage());
		   log.fatal(getNonFatalMessage(throwable, methodName, methodParameters).toString(),throwable);
	   }

	 public void fatal(Throwable throwable, String methodName, Object[] methodParameters) {
	      log.info("Error Message: " + throwable.getMessage());
	      log.fatal(getFatalMessage(throwable, methodName, methodParameters));
	   }*/

	  
	   private StringBuffer getNonFatalMessage(Throwable throwable, String methodName, Object[] methodParameters) {
	      return getExceptionDetails(throwable).append(getMethodParametersLog(methodName, methodParameters));
	   }

	   private StringBuffer getFatalMessage(Throwable throwable, String methodName, Object[] methodParameters) {
	      return getFatalLogDetails(throwable).append(getMethodParametersLog(methodName, methodParameters));
	   }

	   private StringBuffer getMethodParametersLog(String methodName, Object[] methodParameters) {
	      StringBuffer errorMsgStr = new StringBuffer();
	      if (methodParameters == null) {
	         errorMsgStr.append("Method Parameter are not available for method ");
	      } else {
	         errorMsgStr.append("Param List :" + methodName + "\n");
	         for (Object param : methodParameters) {
	            errorMsgStr.append(param + ", ");
	         }
	         errorMsgStr.setCharAt(errorMsgStr.length() - 1, ' ');
	      }
	      return errorMsgStr;
	   }

	   private StringBuffer getExceptionDetails(Throwable throwable) {
	      StringBuffer errorMsgStr = new StringBuffer();
	      if (throwable != null) {
	    	 errorMsgStr.append(" Exception: " + throwable+ "\n");
	    	 errorMsgStr.append(" RootCause: " + ExceptionUtils.getRootCause(throwable)+ "\n");
	    	 errorMsgStr.append(" ExceptionClass : " + throwable.getClass().getName() + "\n");
	         errorMsgStr.append(" ErrorMessage : " + throwable.getMessage() + "\n");
	      } else {
	         errorMsgStr.append("The exception trace is not available because it was not logged \n");
	      }
	      return errorMsgStr;
	   }
	   
	   private StringBuffer getFatalLogDetails(Throwable throwable) {
		      StringBuffer errorMsgStr = getExceptionDetails(throwable);
		      if (throwable != null) {
		         StackTraceElement[] stackTraceArray = throwable.getStackTrace();
		         int lineNbr = 1;
		         for (StackTraceElement stackTraceElement : stackTraceArray) {
		            errorMsgStr.append(", TraceLineNbr : " + lineNbr++ +" Class : "
		                  + stackTraceElement.getClassName() + " Method : "
		                  + stackTraceElement.getMethodName() + " SourceLineNbr : "
		                  + stackTraceElement.getLineNumber() + "\n");
		         }
		      }
		      return errorMsgStr;
		   }
}
