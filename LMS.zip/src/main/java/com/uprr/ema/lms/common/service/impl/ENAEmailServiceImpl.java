package com.uprr.ema.lms.common.service.impl;

import java.util.ArrayList;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jms.JmsException;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.stereotype.Service;

import com.uprr.ema.lms.common.dto.SendMailDTO;
import com.uprr.ema.lms.common.service.api.IENAEmailService;
import com.uprr.ema.lms.common.service.util.LMSUtils;


@Service
public class ENAEmailServiceImpl implements MessageCreator, IENAEmailService {
	
	private static final Logger LOGGER = Logger.getLogger(ENAEmailServiceImpl.class);

	@Autowired
	@Qualifier("jmsTemplate")
	private JmsTemplate jmsTemplate;
	
	private String emailMessageString;

	@Override
	public void sendEmailNotification(SendMailDTO sendMailVO) throws JmsException{
		if (sendMailVO.getToAddressLst()==null) {
			// min of 1 recipient
			LOGGER.info("Sending ENA Notification -- To Address cannot be empty.");
		}
		if (StringUtils.isBlank(sendMailVO.getBodyContent())) {
			LOGGER.info("Sending ENA Notification -- Message body cannot be empty.");
		}
		
		if(!(LMSUtils.getEnvironment()!=null && "prod".equalsIgnoreCase(LMSUtils.getEnvironment()))){
		  /*  ArrayList<String> toList = new ArrayList<String>(5);
		   
		    toList.add("xprk803");
		    toList.add("xprk480");
		    toList.add("xprk481");
		    
		    sendMailVO.setToAddressLst(toList);
		    sendMailVO.setCcAddressLst(toList);*/
		}
		
		String xmlStrongString = sendMailVO.toXMLStrong();
		this.emailMessageString = xmlStrongString;
		LOGGER.info("Email Request XML:- "+this.emailMessageString);	
		jmsTemplate.send(jmsTemplate.getDefaultDestination(), this);
	}

	/**
	 * Create Text Message.
	 * 
	 * @param session
	 * @return Message 
	 */
	public Message createMessage(Session session) throws JMSException{
		LOGGER.info("Entered createMessage() method:- "+ this.emailMessageString);
		return session.createTextMessage(this.emailMessageString);
	}

	

	/**
	 * @return
	 */
	public String getEmailMessageString() {
		return emailMessageString;
	}

	/**
	 * @param emailMessageString
	 */
	public void setEmailMessageString(String emailMessageString) {
		this.emailMessageString = emailMessageString;
	}

	
}