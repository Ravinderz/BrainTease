package com.uprr.ema.lms.searchproject.service.api;

import java.util.List;
import java.util.Set;

import com.uprr.ema.lms.common.dto.DropDownInfo;
import com.uprr.ema.lms.reports.dto.BusinessPrepPlanDTO;
import com.uprr.ema.lms.searchproject.dto.LEWBReportDto;
import com.uprr.ema.lms.searchproject.dto.ProjectSearchCriteriaDTO;
import com.uprr.ema.lms.searchproject.dto.SearchDTO;
import com.uprr.ema.lms.searchproject.vb.SearchOnloadVB;

public interface ProjectSearchService {

	/**
	 * <p>This method will load all drop downs data</p>
	 * 
	 * @return {@link SearchOnloadVB}
	 */
	public SearchOnloadVB getOnloadData(String userId);
	
	public List<DropDownInfo> getProjectNames(String projectNames);
	public int getSearchResultRowCount(ProjectSearchCriteriaDTO projectSearchCriteriaDTO);
	public List<SearchDTO> getSearchResultThroughPagination(ProjectSearchCriteriaDTO projectSearchCriteriaDTO);
	public List<SearchDTO> getExcelReport(ProjectSearchCriteriaDTO projectSearchCriteriaDTO);

	public List<LEWBReportDto> geLEWBtExcelReport(String fromdate, String toDate);

	public List<LEWBReportDto> getReasonChnage(Integer projectId);

	public List<LEWBReportDto> getCostsData(Integer projectId);

	public List<LEWBReportDto> getBeginingOfYearData(Integer projectId, String year);

	public List<BusinessPrepPlanDTO> getspentAmount(String spentAmountYear);

	public List<LEWBReportDto> getProjectIds(Set<String> networkNumberSet);

	public List<LEWBReportDto> getOmmCostsData(Integer projectId);

	public List<LEWBReportDto> getliabilityEstimateAmount(String liabiltyQueryString, Integer projectId);
	
	
	
	
}
