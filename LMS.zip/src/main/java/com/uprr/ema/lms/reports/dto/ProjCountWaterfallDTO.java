package com.uprr.ema.lms.reports.dto;

public class ProjCountWaterfallDTO {

	private int beginningProjCount;
	private int closedSites;
	private int newSites;
	private String yr;
	
	public int getBeginningProjCount() {
		return beginningProjCount;
	}
	public void setBeginningProjCount(int beginningProjCount) {
		this.beginningProjCount = beginningProjCount;
	}
	public int getClosedSites() {
		return closedSites;
	}
	public void setClosedSites(int closedSites) {
		this.closedSites = closedSites;
	}
	public int getNewSites() {
		return newSites;
	}
	public void setNewSites(int newSites) {
		this.newSites = newSites;
	}
	
	public String getYr() {
		return yr;
	}
	public void setYr(String yr) {
		this.yr = yr;
	}
	public ProjCountWaterfallDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ProjCountWaterfallDTO(int beginningProjCount, int closedSites, int newSites, String yr) {
		super();
		this.beginningProjCount = beginningProjCount;
		this.closedSites = closedSites;
		this.newSites = newSites;
		this.yr = yr;
	}
	@Override
	public String toString() {
		return "ProjCountWaterfallDTO [beginningProjCount=" + beginningProjCount + ", closedSites=" + closedSites
				+ ", newSites=" + newSites + ", yr=" + yr + "]";
	}
	
	
	
	
	
	
}
