package com.uprr.ema.lms.common.service.api;

import java.io.IOException;

import org.springframework.web.multipart.MultipartFile;

public interface IDocumentService {

	public String uploadDocument(MultipartFile file) throws IOException;
	
	public byte[] downloadDocument(String guid);
	
}
