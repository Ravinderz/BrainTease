package com.uprr.ema.lms.searchproject.dto;

import com.uprr.ema.lms.common.dto.SearchCriteriaDTO;

public class ProjectSearchCriteriaDTO extends SearchCriteriaDTO {
private static final long serialVersionUID = 1L;
	
	private SearchDTO projectSearchCriteria;

	/**
	 * @return the projectSearchCriteria
	 */
	public SearchDTO getProjectSearchCriteria() {
		return projectSearchCriteria;
	}

	/**
	 * @param projectSearchCriteria the projectSearchCriteria to set
	 */
	public void setProjectSearchCriteria(SearchDTO projectSearchCriteria) {
		this.projectSearchCriteria = projectSearchCriteria;
	}

	/**
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}


	
	
	

}
