package com.uprr.ema.lms.jmsconfig;

import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.uprr.ema.lms.common.constant.JMSPropertyKeyConstants;
import com.uprr.ema.lms.common.util.CyberArkPoolPasswordUtil;
@Component
@PropertySource(value = { "classpath:environment/lms_${uprr.implementation.environment}.properties", "classpath:common/common.properties","classpath:common/lms.properties" })
public abstract class JNDIConfig {
	@Autowired
	public Environment environment;

	protected Properties jndiEnvironment;
	protected CyberArkPoolPasswordUtil jmsPasswordBean;

	public Properties getJndiEnvironment() {
		if (jndiEnvironment == null) {
			jndiEnvironment = new Properties();
			jndiEnvironment.put(JMSPropertyKeyConstants.JAVA_NAMING_FACTORY_INITIAL, environment.getProperty("ENA_JMS_INITIAL_FACTORY_CONTEXT"));
			jndiEnvironment.put(JMSPropertyKeyConstants.JAVA_NAMING_PROVIDER_URL, environment.getProperty("JMS_JNDI_PROVIDER_URL"));
			jndiEnvironment.put(JMSPropertyKeyConstants.JAVA_NAMING_SECURITY_PRINCIPAL, environment.getProperty("ENA_JMS_USER_NAME"));
			jndiEnvironment.put(JMSPropertyKeyConstants.JAVA_NAMING_SECURITY_CREDENTIALS, getJMSPasswordBean().getPasswordFromCyberArk());
			jndiEnvironment.put(JMSPropertyKeyConstants.JAVA_NAMING_REFERRAL, environment.getProperty("ENA_JMS_CONTEXT_REFERRAL"));
		}
		return jndiEnvironment;
	}

	public CyberArkPoolPasswordUtil getJMSPasswordBean() {
		if (jmsPasswordBean == null) {
			jmsPasswordBean = new CyberArkPoolPasswordUtil();
			jmsPasswordBean.setAppTLA(environment.getProperty("application.tla"));
			jmsPasswordBean.setInstance(environment.getProperty("JMS_INSTANCE"));
			jmsPasswordBean.setType(environment.getProperty("JMS_TYPE"));
			jmsPasswordBean.setRunEnv(environment.getProperty("uprr.implementation.environment"));
			jmsPasswordBean.setAppID(environment.getProperty("ENA_JMS_USER_NAME"));
			jmsPasswordBean.setLocalEnvPassword(environment.getProperty("JMS_LOCAL_PASSWORD"));
		}
		return jmsPasswordBean;
	}

	public Environment getEnvironment() {
		return environment;
	}

	public void setEnvironment(Environment environment) {
		this.environment = environment;
	}

}
