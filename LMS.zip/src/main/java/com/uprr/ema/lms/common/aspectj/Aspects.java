package com.uprr.ema.lms.common.aspectj;

import org.aspectj.lang.annotation.Pointcut;

public abstract class Aspects {

	@Pointcut("within(@org.springframework.stereotype.Controller *)")
	public void controllerBean() {
	}

	@Pointcut("within(@org.springframework.stereotype.Service *)")
	public void service() {
	}

	@Pointcut("within(@org.springframework.stereotype.Repository *)")
	public void dAO() {
	}

	@Pointcut("within(@org.springframework.stereotype.Component *)")
	public void helper() {
	}

	@Pointcut("execution(* com.uprr.ema.lms..*(..))")
	public void methodPointcut() {
	}
}
