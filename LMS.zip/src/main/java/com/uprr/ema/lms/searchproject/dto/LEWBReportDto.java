package com.uprr.ema.lms.searchproject.dto;

import java.io.Serializable;
import java.util.Date;

import com.uprr.ema.lms.common.dto.BaseDTO;

public class LEWBReportDto extends BaseDTO implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private Integer projectId;
	
	
	private Date reviewedDate;
	
	private String projectName;
	
	private String liabilityEstimate;
	
	private String npv;
	
	private String uprrAllocation;
	
	private String financialAssurance;
	
	private String DTList;
	
	private String costRecovery;
	
	private Date closedMonth;
	
	private String federalLead;
	
	private String fifteenYearRule;
	
	private String estimator;
	
	private Integer projectLevel;
	
	private String changeReasonDesc;
	
	private String costId;
	
	private String cost;
	
	private String year;
	
	private String actFlag;
	
	private String actionCode;
	
	private String actionTypeCode;
	
	private String costTypeId;
	
	private Date beginingOfYearDate;
	
	private String balanceSheetDesc;
	
	private String subAccountCode;
	
	private String accountNumberData;
	
	private String operatingStatus;
	
	private String state;
	
	private String city;
	
	private String mangerName;
	
	private Double liabilityEstimateAmount;
	
	private Date projectDate;
	
	public Date getProjectDate() {
		return projectDate;
	}

	public void setProjectDate(Date projectDate) {
		this.projectDate = projectDate;
	}

	public Double getLiabilityEstimateAmount() {
		return liabilityEstimateAmount;
	}

	public void setLiabilityEstimateAmount(Double liabilityEstimateAmount) {
		this.liabilityEstimateAmount = liabilityEstimateAmount;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getMangerName() {
		return mangerName;
	}

	public void setMangerName(String mangerName) {
		this.mangerName = mangerName;
	}

	public String getRailRoad() {
		return railRoad;
	}

	public void setRailRoad(String railRoad) {
		this.railRoad = railRoad;
	}


	private String railRoad;
	
	public String getOperatingStatus() {
		return operatingStatus;
	}

	public void setOperatingStatus(String operatingStatus) {
		this.operatingStatus = operatingStatus;
	}

	public String getBalanceSheetDesc() {
		return balanceSheetDesc;
	}

	public void setBalanceSheetDesc(String balanceSheetDesc) {
		this.balanceSheetDesc = balanceSheetDesc;
	}

	public String getSubAccountCode() {
		return subAccountCode;
	}

	public void setSubAccountCode(String subAccountCode) {
		this.subAccountCode = subAccountCode;
	}

	public String getAccountNumberData() {
		return accountNumberData;
	}

	public void setAccountNumberData(String accountNumberData) {
		this.accountNumberData = accountNumberData;
	}

	public Date getBeginingOfYearDate() {
		return beginingOfYearDate;
	}

	public void setBeginingOfYearDate(Date beginingOfYearDate) {
		this.beginingOfYearDate = beginingOfYearDate;
	}

	public String getCostTypeId() {
		return costTypeId;
	}

	public void setCostTypeId(String costTypeId) {
		this.costTypeId = costTypeId;
	}

	public String getCostId() {
		return costId;
	}

	public void setCostId(String costId) {
		this.costId = costId;
	}

	public String getCost() {
		return cost;
	}

	public void setCost(String cost) {
		this.cost = cost;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public String getActFlag() {
		return actFlag;
	}

	public void setActFlag(String actFlag) {
		this.actFlag = actFlag;
	}

	public String getActionCode() {
		return actionCode;
	}

	public void setActionCode(String actionCode) {
		this.actionCode = actionCode;
	}

	public String getActionTypeCode() {
		return actionTypeCode;
	}

	public void setActionTypeCode(String actionTypeCode) {
		this.actionTypeCode = actionTypeCode;
	}

	public String getChangeReasonDesc() {
		return changeReasonDesc;
	}

	public void setChangeReasonDesc(String changeReasonDesc) {
		this.changeReasonDesc = changeReasonDesc;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

public Date getReviewedDate() {
	return reviewedDate;
}

public void setReviewedDate(Date reviewedDate) {
	this.reviewedDate = reviewedDate;
}

public String getProjectName() {
	return projectName;
}

public void setProjectName(String projectName) {
	this.projectName = projectName;
}

public String getLiabilityEstimate() {
	return liabilityEstimate;
}

public void setLiabilityEstimate(String liabilityEstimate) {
	this.liabilityEstimate = liabilityEstimate;
}

public String getNpv() {
	return npv;
}

public void setNpv(String npv) {
	this.npv = npv;
}

public String getUprrAllocation() {
	return uprrAllocation;
}

public void setUprrAllocation(String uprrAllocation) {
	this.uprrAllocation = uprrAllocation;
}

public String getFinancialAssurance() {
	return financialAssurance;
}

public void setFinancialAssurance(String financialAssurance) {
	this.financialAssurance = financialAssurance;
}

public String getDTList() {
	return DTList;
}

public void setDTList(String dTList) {
	DTList = dTList;
}

public String getCostRecovery() {
	return costRecovery;
}

public void setCostRecovery(String costRecovery) {
	this.costRecovery = costRecovery;
}

public Date getClosedMonth() {
	return closedMonth;
}

public void setClosedMonth(Date closedMonth) {
	this.closedMonth = closedMonth;
}

public String getFederalLead() {
	return federalLead;
}

public void setFederalLead(String federalLead) {
	this.federalLead = federalLead;
}

public String getFifteenYearRule() {
	return fifteenYearRule;
}

public void setFifteenYearRule(String fifteenYearRule) {
	this.fifteenYearRule = fifteenYearRule;
}

public String getEstimator() {
	return estimator;
}

public void setEstimator(String estimator) {
	this.estimator = estimator;
}

public Integer getProjectLevel() {
	return projectLevel;
}

public void setProjectLevel(Integer projectLevel) {
	this.projectLevel = projectLevel;
}





public Integer getProjectId() {
	return projectId;
}

public void setProjectId(Integer projectId) {
	this.projectId = projectId;
}

public LEWBReportDto() {
	super();
	// TODO Auto-generated constructor stub
}


public LEWBReportDto(String projectName, String liabilityEstimate, String npv, String uprrAllocation, String financialAssurance,
		String DTList, String costRecovery, String federalLead, String fifteenYearRule,String estimator,Integer projectLevel,Integer projectId) {
	super();
	this.projectName = projectName;
	this.liabilityEstimate = liabilityEstimate;
	this.npv = npv;
	this.uprrAllocation = uprrAllocation;
	this.financialAssurance = financialAssurance;
	this.DTList = DTList;
	this.costRecovery = costRecovery;
	this.federalLead = federalLead;

	this.estimator = estimator;
	this.projectLevel = projectLevel;
	this.projectId = projectId;
}

}
