package com.uprr.ema.lms.searchproject.vb;

import java.util.List;

import com.uprr.ema.lms.common.vb.SearchCriteriaVB;

public class SearchCriteriaResponse<T> extends SearchCriteriaVB {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private List<T> searchDataList;

	/**
	 * @return the searchDataList
	 */
	public List<T> getSearchDataList() {
		return searchDataList;
	}

	/**
	 * @param searchDataList the searchDataList to set
	 */
	public void setSearchDataList(List<T> searchDataList) {
		this.searchDataList = searchDataList;
	}
	
	
}
