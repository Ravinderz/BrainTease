/**
 * This file is used to declare all the constants related to Service layer of the application.
 */
package com.uprr.ema.lms.common.service.util;

public class ServiceConstants {

    
    public static final String LMS_APP_USER_ID = "DEMA001";

    public static final String ROLE_ADMIN = "EMA-LMS-ADMIN";
    public static final String ROLE_APPROVER = "EMA-LMS-APPROVER";
    public static final String ROLE_MANAGER = "EMA-LMS-MANAGER";
    public static final String ROLE_VIEW = "EMA-LMS-VIEW";

    // Source table constants
    public static final String EMA_LMS_PROJ_SRC_MSTR = "EMA_LMS_PROJ_SRC_MSTR";
    public static final String PROJ_SRC_ID = "PROJ_SRC_ID";
    public static final String PROJ_SRC_CODE = "PROJ_SRC_CODE";
    public static final String PROJ_SRC_DESC = "PROJ_SRC_DESC";
    public static final String SORT_ORD_NBR = "SORT_ORD_NBR";


    public static final String EMA_LMS_CHNG_RESN_MSTR = "EMA_LMS_CHNG_RESN_MSTR";
    public static final String CHNG_RESN_MSTR_ID = "CHNG_RESN_ID";
    public static final String CHNG_RESN_CODE = "CHNG_RESN_CODE";
    public static final String CHNG_RESN_DESC = "CHNG_RESN_DESC";
    public static final String CHNG_RESN_SORT_ORD_NBR = "SORT_ORD_NBR";

    //Types table constants
    public static final String EMA_LMS_PROJ_TYPE_MSTR = "EMA_LMS_PROJ_TYPE_MSTR";
    public static final String PROJ_TYPE_ID = "PROJ_TYPE_ID";
    public static final String PROJ_TYPE_CODE = "PROJ_TYPE_CODE";
    public static final String PROJ_TYPE_DESC = "PROJ_TYPE_DESC";
    public static final String SORT_ORD = "SORT_ORD";

    //Driver table constants
    public static final String EMA_LMS_PROJ_DRIV_MSTR = "EMA_LMS_PROJ_DRIV_MSTR";
    public static final String PROJ_DRIV_ID = "PROJ_DRIV_ID";
    public static final String PROJ_DRIV_CODE = "PROJ_DRIV_CODE";
    public static final String PROJ_DRIV_DESC = "PROJ_DRIV_DESC";

    //Cost type table constants
    public static final String EMA_LMS_PROJ_COST_TYPE_MST = "EMA_LMS_PROJ_COST_TYPE_MST";
    public static final String PROJ_COST_TYPE_ID = "COST_TYPE_ID";
    public static final String PROJ_COST_TYPE_CODE = "COST_TYPE_CODE";
    public static final String PROJ_COST_TYPE_DESC = "COST_TYPE_DESC";
    public static final String CURRENT_COST_TYPE_CODE = "CRNT";
    public static final String PROPOSED_COST_TYPE_CODE = "PROP";


    public static final String EMA_LMS_PROJ_COST_SUBTYPE_MST = "ema_lms_proj_cost_type_mst";
    public static final String COST_SUB_TYPE_ID = "COST_SUB_TYPE_ID";
    public static final String COST_SUB_TYPE_CODE = "COST_SUB_TYPE_CODE";
    public static final String COST_SUB_TYPE_DESC = "COST_SUB_TYPE_DESC";
    public static final String YEAR_COST_TYPE_CODE = "YEAR";
    public static final String OMM_COST_TYPE_CODE = "OMM";
    public static final String SYS_COST_TYPE_CODE = "SYS";

    public static final String YEAR_COST_TYPE_DESC= "Year";
    public static final String OMM_COST_TYPE_DESC = "OMM Costs";
    public static final String SYS_COST_TYPE_DESC = "System Closure Costs";

    //Estimator table constants
    public static final String EMA_LMS_PROJ_ESTM_MSTR = "EMA_LMS_PROJ_ESTM_MSTR";
    public static final String PROJ_ESTM_ID = "PROJ_ESTM_ID";
    public static final String PROJ_ESTM_CODE = "PROJ_ESTM_CODE";
    public static final String PROJ_ESTM_DESC = "PROJ_ESTM_DESC";

    //SiteRem Managers table constants
    public static final String EMA_LMS_PROJ_MGR_MSTR = "EMA_LMS_PROJ_MGR_MSTR";
    public static final String PROJ_MGR_ID = "PROJ_MGR_ID";
    public static final String PROJ_MGR_LDAP_ID = "PROJ_MGR_LDAP_ID";
    public static final String PROJ_MGR_FIR_NAME = "PROJ_MGR_FIR_NAME";
    public static final String PROJ_MGR_MIDL_NAME = "PROJ_MGR_MIDL_NAME";
    public static final String PROJ_MGR_LAST_NAME = "PROJ_MGR_LAST_NAME";
    public static final String PROJ_MGR_EMPL_ID = "PROJ_MGR_EMPL_ID";

    //Railroad table constants
    public static final String EMA_LMS_RAIL_RAOD_MSTR = "EMA_LMS_RAIL_RAOD_MSTR";
    public static final String RAIL_RAOD_ID = "RAIL_RAOD_ID";
    public static final String RAIL_RAOD_CODE = "RAIL_RAOD_CODE";
    public static final String RAIL_RAOD_DESC = "RAIL_RAOD_DESC";

    //Federal Leads table constants
    public static final String EMA_LMS_FED_LEAD_MSTR = "EMA_LMS_FED_LEAD_MSTR";
    public static final String FED_LEAD_ID = "FED_LEAD_ID";
    public static final String FED_LEAD_CODE = "FED_LEAD_CODE";
    public static final String FED_LEAD_DESC = "FED_LEAD_DESC";

    //Balance Sheet table constants
    public static final String EMA_LMS_BLNC_SHT_MSTR = "EMA_LMS_BLNC_SHT_MSTR";
    public static final String BLNC_SHT_ID = "BLNC_SHT_ID";
    public static final String BLNC_SHT_CODE = "BLNC_SHT_CODE";
    public static final String BLNC_SHT_DESC = "BLNC_SHT_DESC";

    //Sub Accounts table constants
    public static final String EMA_LMS_SUB_ACCT_MSTR = "EMA_LMS_SUB_ACCT_MSTR";
    public static final String SUB_ACCT_ID = "SUB_ACCT_ID";
    public static final String SUB_ACCT_CODE = "SUB_ACCT_CODE";
    public static final String SUB_ACCT_DESC = "SUB_ACCT_DESC";

    // LMS Project Status Master
    public static final String EMA_LMS_PROJ_STAT_MSTR="EMA_LMS_PROJ_STAT_MSTR";
    public static final String EMA_LMS_PROJ_STAT_MSTR_ID="PROJ_STAT_ID";
    public static final String PROJ_STAT_CODE="PROJ_STAT_CODE";
    public static final String PROJ_STAT_DESC="PROJ_STAT_DESC";
    public static final String PROJ_STAT_CODE_VALUE="APRV";

    // LMS Action Master
    public static final String EMA_LMS_PROJ_ACTN_MSTR="EMA_LMS_PROJ_ACTN_MSTR";
    public static final String ACTN_CODE="ACTN_CODE";
    public static final String ACTN_DESC="ACTN_DESC";
    //public static final String SORT_ORD_NBR ="SORT_ORD_NBR";

    public static final String STATUS_HISTORY = "H";
    public static final String STATUS_CURRENT ="C";

    public static final String  BREAK_LINE = "<br />";

    // LMS TUBE LEVEL MAster Table 
    public static final String EMA_LMS_TUBE_LEVL_MSTR="EMA_LMS_TUBE_LEVL_MSTR";
    public static final String TUBE_LEVL_ID="TUBE_LEVL_ID";
    public static final String TUBE_LEVL_CODE="TUBE_LEVL_CODE";
    public static final String TUBE_LEVL_DESC="TUBE_LEVL_DESC";

    // LMS Project Names Table 
    public static final String EMA_LMS_PROJ="EMA_LMS_PROJ_DTL";
    public static final String PROJ_ID="PROJ_DTL_ID";
    public static final String PROJ_NAME="PROJ_NAME";

    public static final String ACTN_SUBMITTED = "S";
    public static final String ACTN_APPORVED = "A";
    public static final String ACTN_UN_APPORVED = "U";
    public static final String ACTN_DELETED = "D";

    public static final String ACTION_TYPE_PROJ ="P";
    public static final String ACTION_TYPE_CHANGE ="C";

    public static final String ACTION_PROJ_SUBMITTED ="PS";
    public static final String ACTION_PROJ_APPROVED="PA";
    public static final String ACTION_PROJ_UN_APPROVED="PU";
    public static final String ACTION_PROJ_DELETED="PD";
    public static final String ACTION_CHANGE_SUBMITTED ="CS";
    public static final String ACTION_CHANGE_APPROVED ="CA";
    public static final String ACTION_CHANGE_UN_APPROVED ="CU";
    public static final String ACTION_PROJECT_PERSIST ="PP";
    public static final String ACTION_CHANGE_PERSIST ="CP";
    public static final String ACTION_CHANGE_DELETED ="CD";
    //public static final String ACTION_CHANGE_APPROVED ="CA";






    /*public static final String STATUS_DELETE ="D";
    public static final String STATUS_INACTIVE ="I";
    public static final String EMPTY="";
    // Environment and URL related
    public static final String UP_ENV = "uprr.implementation.environment";
    public static final String WIN_ENV = "win";

    public static  String LOCAL_HOST_NAME = "http://localhost:8080";
    public static  String DEV_HOST_NAME = "http://xdev.home.www.uprr.com";
    public static  String TEST_HOST_NAME = "http://xtest.home.www.uprr.com";
    public static  String PROD_HOST_NAME = "http://home.www.uprr.com";
    //css file path
    public static String HMM_EMA_UPRR_IMG_PATH ="/resources/UPRR.jpg";
    public static String HMM_EMA_CSS_FILE_PATH ="/src/main/resources/UPRR.jpg";
    public static String CUT_DATA_POP_UP_CSS_FILE_PATH ="/resources/css/cutdatapopupstyle.css";

    public static final String  EMA_FROM_MAIL_ADDRESS = "EMA";

    public static final String  HTML_CONTENT_TYPE = "text/html";
    public static final int  THREE = 3;
    public static final String  PDF_CONTENT_TYPE = "application/x-pdf";
    public static final String EMA_RPT_FILE_NAME = "EMATestReport";
    public static final String TO_ADDRESS_PRD = "EMA_SITEREM_TECH_SUPPORT@up.com";

    public static final int EXCP_COUNT = 3;
    public static final String YES = "Y";
    public static final String NO = "N";
    public static final String ZERO = "0";
    public static final String DOBULE_ZERO = "00";

    public static final String CURRENT="C";
    public static final String DELINQUENT="D";

    public static String Context_Path = "/ema_hmm"; 

    public static final String PROPERTY_STATUS_CURRENT = "C";
    public static final String PROPERTY_STATUS_HISTORY = "H";

    public static final String EMA_SITE_GROUP_MASTER="EMA_SITE_GRP_MSTR";
    public static final String GROUP_SHORT="GRP_SHRT_DESC";
    public static final String GROUP_DESC="GRP_DESC";
    public static final String GROUP_ALTERNATECODE = "EMA_SITE_GRP_MSTR_ID";
    public static final String CNTRL_MEAS_REMD_STAT_MSTR="EMA_SITE_CTRL_MSUR_RMDY_MS";
    public static final String CNTRL_MEAS_REMD_STAT_CODE="EMA_SITE_CTRL_MSUR_RMDY_MS_ID";
    public static final String CNTRL_MEAS_REMD_STAT_DESC="CTRL_MSUR_DESC";
    public static final String CNTRL_MEAS_REMD_STAT_ALT_CODE="CTRL_MSUR_CODE";
    public static final String LESE_MNG_IMPC_MSTR="EMA_SITE_LESE_MNGD_MSTR";
    public static final String LESE_MNG_IMPC_STAT_CODE="EMA_SITE_LESE_MNGD_MSTR_ID";
    public static final String LESE_MNG_IMPC_STAT_DESC="LESE_MNGD_IMPC_DESC";
    public static final String LESE_MNG_IMPC_STAT_ALT_CODE="LESE_MNGD_IMPC_CODE";
    public static final String LIAB_REDC_REMD_STAT_MSTR="EMA_SITE_LIAB_RMDY_MSTR";
    public static final String LIAB_REDC_REMD_STAT_CODE="EMA_SITE_LIAB_RMDY_MSTR_ID";
    public static final String LIAB_REDC_REMD_STAT_DESC="LIAB_RDTN_DESC";
    public static final String LIAB_REDC_REMD_STAT_ALT_CODE="LIAB_RDTN_CODE";
    public static final String SOIL_AND_GRND_STAT_MSTR="EMA_SITE_SOIL_WATR_MSTR";
    public static final String SOIL_AND_GRND_ASMT_STAT_CODE="EMA_SITE_SOIL_WATR_MSTR_ID";
    public static final String SOIL_AND_GRND_ASMT_STAT_DESC="SOIL_AND_WATR_DESC";
    public static final String SOIL_AND_GRND_ASMT_STAT_ALT_CODE="SOIL_AND_WATR_CODE";
    public static final String SITE_RMDT_MILEST_STAT_MSTR="EMA_SITE_MGMT_MLST_MSTR";
    public static final String MGMT_MILEST_STAT_CODE="EMA_SITE_MGMT_MLST_MSTR_ID";
    public static final String MGMT_MILEST_STAT_DESC="MGMT_MLST_DESC";
    public static final String MGMT_MILEST_STAT_ALT_CODE="MGMT_MLST_CODE";
    public static final String EMA_SITE_CUSTOMER_NAME_TABLE="EMA_SITE_PROP_CUST_DTL";
    public static final String EMA_SITE_CUSTOMER_NAME_CODE="CUST_NAME";
    //Constants used for state master data
    public static final String EMA_HMM_LKUP_ST = "EMA_HMM_LKUP_ST";
    public static final String ST_CODE = "ST_CODE";
    public static final String ST_DESC = "ST_DESC";
    public static final String INS_TYPE_MSTR = "ema_site_lse_insp_type_mstr";
    public static final String INS_TYPE_MSTR_CODE = "ema_site_lse_insp_type_mstr_Id";
    public static final String INS_TYPE_MSTR_DESC = "lse_insp_type_desc";

    public static final String SORT_ORDR_NBR = "SORT_ORD_NBR";



    //SiteRem Status and Work flow 
    public static final String STATUS_SDS_NEW="SDN";
    public static final String STATUS_SDS_INCOMPLETE="SDI";
    public static final String STATUS_PI_NOT_STARTED="PIS";
    public static final String STATUS_PI_IN_PROGRESS="PIP";
    public static final String STATUS_PI_INCOMPLETE="PIC";
    public static final String STATUS_PI_SGSA="PIG";
    public static final String STATUS_CR_SUBMITED="CSU";
    public static final String STATUS_CR_STEERING_COMMITEE_REVIEW="SCR";
    public static final String STATUS_CR_STEERING_COMMITEE_APPROVED="APR";
    public static final String STATUS_CR_NO_FURTHER_ACTION="NFA";
    public static final String STATUS_CR_CLOSED="CRC";
    public static final String STATUS_ADMIN_DROPED="ADM";
    public static final String STATUS_DOC_PM_REVIEW="DPR";
    public static final String STATUS_INS_PM_REVIEW="IPR";

    public static final String STATUS_CMR_COMPLETE="CMP";
    public static final String STATUS_LRM_COMPLETE="CMP";
    public static final String STATUS_SGA_COMPLETE="CMP";
    public static final String STATUS_LMI_COMPLETE="CMP";
    public static final String STATUS_SRM_COMPLETE="CMP";


    //Workflow
    public static final String WORKFLOW_SDS="YNN";
    public static final String WORKFLOW_SDS_PI="YYN";
    public static final String WORKFLOW_SDS_PI_CR="YYY";
    public static final String WORKFLOW_SDS_CR="YNY";
    public static final String WORKFLOW_PI="NYN";
    public static final String WORKFLOW_PI_CR="NYY";
    public static final String WORKFLOW_CR="NNY";
    public static final String WORKFLOW_ONRAMP="NNN";

    //Mail Notification Constats
    public static final String SURVEY_TASK = " Property is submitted for Inspection";
    public static final String SURVEY_COMMENTS = "Property is submitted for Inspection";
    public static final String MAIL_TYPE_DR_SUBMIT = "DR_SUBMIT";
    public static final String MAIL_TYPE_INSP_SUBMIT = "INSP_SUBMIT";
    public static final String MAIL_TYPE_EPRO_CHANGE = "EPRO_CHANGE";
    public static final String MAIL_TYPE_SUBMIT = "SUBMIT";

    //Insoection status details 
    public static final String PROP_INSP_DTL = "ema_site_prop_dtl";
    public static final String DOC_REVW_SBMT_DATE = "DOC_REVW_SBMT_DATE";
    public static final String INSP_SBMT_DATE = "INSP_SBMT_DATE";
    public static final String SOIL_GRND_WATR_ASMT_SBMT_DATE = "SOIL_GRND_WATR_ASMT_SBMT_DATE";

    //Constants used for sitedatasurvey(documentReviewtab) dropdown values
    public static final String EMA_SITE_PROP_USE_CLAS_MSTR = "EMA_SITE_PROP_USE_CLAS_MSTR";
    public static final String EMA_SITE_PROP_USE_CLAS_MSTR_ID = "EMA_SITE_PROP_USE_CLAS_MSTR_ID";
    public static final String PROP_USE_CLAS_DESC = "PROP_USE_CLAS_DESC";
    public static final String PROP_USE_CLAS_RISK = "PROP_USE_CLAS_RSK_LEVL_VALU";
    public static final String EMA_SITE_CUR_LSE_FORM_MSTR = "EMA_SITE_CUR_LSE_FORM_MSTR";
    public static final String EMA_SITE_CUR_LSE_FORM_MSTR_ID = "EMA_SITE_CUR_LSE_FORM_MSTR_ID";
    public static final String CUR_LSE_FORM_DESC = "CUR_LSE_FORM_DESC";
    public static final String EMA_SITE_INS_RQMT_MSTR = "EMA_SITE_INS_RQMT_MSTR";
    public static final String EMA_SITE_INS_RQMT_MSTR_ID = "EMA_SITE_INS_RQMT_MSTR_ID";
    public static final String INS_RQMT_DESC = "INS_RQMT_DESC";


    public static final String SITE_LSE_TYPE_MSTR = "EMA_SITE_LSE_MAP_TYPE_MSTR";
    public static final String SITE_LSE_TYPE_MSTR_ID = "EMA_SITE_LSE_MAP_TYPE_MSTR_ID";
    public static final String SITE_LSE_TYPE_MSTR_DESC = "LSE_MAP_TYPE_DESC";


    public static final String ST_FNDG_PGMS_MSTR = "EMA_SITE_ST_FNDG_PGMS_MSTR";
    public static final String ST_FNDG_PGMS_MSTR_ID = "EMA_SITE_ST_FNDG_PGMS_MSTR_ID";
    public static final String ST_FNDG_PGMS_MSTR_DESC = "PGM_NAME";

    public static final String EMA_SITE_LSE_READ_MSTR = "EMA_SITE_LSE_READ_MSTR";
    public static final String EMA_SITE_LSE_READ_MSTR_ID = "EMA_SITE_LSE_READ_MSTR_ID";
    public static final String EMA_SITE_LSE_READ_MSTR_DESC = "LSE_READ_DESC";


    public static final String EMA_SITE_LSE_PURP_MSTR = "EMA_SITE_LSE_PURP_MSTR";
    public static final String EMA_SITE_LSE_PURP_MSTR_ID = "EMA_SITE_LSE_PURP_MSTR_ID";
    public static final String EMA_SITE_LSE_PURP_MSTR_CODE = "LSE_PURP_CODE";
    public static final String EMA_SITE_LSE_PURP_MSTR_DESC = "LSE_PURP_DESC";

    public static final String EMA_SITE_AUD_FREQ_MSTR = "EMA_SITE_AUD_FREQ_MSTR";
    public static final String EMA_SITE_AUD_FREQ_MSTR_ID = "EMA_SITE_AUD_FREQ_MSTR_ID";
    public static final String EMA_SITE_AUD_FREQ_MSTR_CODE = "AUD_FREQ_CODE";
    public static final String EMA_SITE_AUD_FREQ_MSTR_DESC = "AUD_FREQ_DESC";

    public static final String EMA_SITE_WELL_USE_MSTR = "EMA_SITE_WELL_USE_MSTR";
    public static final String EMA_SITE_WELL_USE_MSTR_ID = "EMA_SITE_WELL_USE_MSTR_ID";
    public static final String EMA_SITE_WELL_USE_MSTR_CODE = "WELL_USE_CODE";
    public static final String EMA_SITE_WELL_USE_MSTR_DESC = "WELL_USE_DESC";

    public static final String EMA_SITE_FAC_POT_WATR_MSTR = "EMA_SITE_FAC_PRTB_TYPE_MSTR";
    public static final String EMA_SITE_FAC_POT_WATR_MSTR_ID = "EMA_SITE_FAC_PRTB_MSTR_ID";
    public static final String POT_WATR_CODE = "EMA_SITE_FAC_PRTB_MSTR_CODE";
    public static final String POT_WATR_DESC = "EMA_SITE_FAC_PRTB_MSTR_DESC";

    public static final String EMA_SITE_COND_PROC_MSTR = "EMA_SITE_COND_PROC_MSTR";
    public static final String EMA_SITE_COND_PROC_MSTR_ID = "EMA_SITE_COND_PROC_MSTR_ID";
    public static final String EMA_SITE_COND_PROC_MSTR_CODE = "COND_PROC_CODE";
    public static final String EMA_SITE_COND_PROC_MSTR_DESC = "COND_PROC_DESC";


    public static final String EMA_SITE_HZRD_SBSN_MSTR = "EMA_SITE_HZRD_SBSN_MSTR";
    public static final String EMA_SITE_HZRD_SBSN_MSTR_ID = "EMA_SITE_HZRD_SBSN_MSTR_ID";
    public static final String EMA_SITE_HZRD_SBSN_MSTR_CODE = "HZRD_SBSN_CODE";
    public static final String EMA_SITE_HZRD_SBSN_MSTR_DESC = "HZRD_SBSN_DESC";

    public static final String EMA_SITE_PRDC_WAST_MSTR = "EMA_SITE_PRDC_WAST_MSTR";
    public static final String EMA_SITE_PRDC_WAST_MSTR_ID = "EMA_SITE_PRDC_WAST_MSTR_ID";
    public static final String EMA_SITE_PRDC_WAST_MSTR_CODE = "PRDC_WAST_CODE";
    public static final String EMA_SITE_PRDC_WAST_MSTR_DESC = "PRDC_WAST_DESC";

    public static final String EMA_SITE_TANK_CONT_MSTR = "EMA_SITE_TANK_CONT_MSTR";
    public static final String EMA_SITE_TANK_CONT_MSTR_ID = "EMA_SITE_TANK_CONT_MSTR_ID";
    public static final String EMA_SITE_TANK_CONT_MSTR_CODE = "STRG_TANK_CONT_CODE";
    public static final String EMA_SITE_TANK_CONT_MSTR_DESC = "STRG_TANK_CONT_DESC";





    public static final String SAVE_MODE = "save";
    public static final String COMM_SAVE_MODE = "comitteesave";
    public static final String SUBMIT_MODE = "submit";
    public static final String PRIMARY_CONTACT = "P";
    public static final String SECONDARY_CONTACT = "S";

    public static final String LAND_USE_PROCESS_TABLE =  "EMA_SITE_LAND_USE_RESP_DTL";
    public static final String LAND_USE_HRD_SUB_TABLE =  "EMA_SITE_HZRD_RESP_DTL";
    public static final String LAND_USE_PRD_WASTE_TABLE =  "EMA_SITE_PRDC_WAST_RESP_DTL";
    public static final String LAND_USE_UG_TANK_TABLE =  "EMA_SITE_BURD_TANK_RESP_DTL";
    public static final String LAND_USE_AG_TANK_TABLE =  "EMA_SITE_ABOV_GRND_TANK_DTL";
    public static final String EMA_SITE_PROP_USE_DTL =  "EMA_SITE_PROP_USE_DTL";
    public static final String EMA_SITE_PREV_PROP_USE_DTL =  "EMA_SITE_PREV_PROP_USE_DTL";
    public static final String  EMA_SITE_MATL_AND_STRG_DTL = "EMA_SITE_MATL_AND_STRG_DTL";

    //Batch property constants
    public static final long PROP_INSP_STAT_MAST_ID = 3L;
    public static final long BAT_PROP_SEL_STAT_ID = 7L;
    public static final String LSE_SHORT = "LSE_PURP_CODE";
    public static final String LSE_DESC = "LSE_PURP_DESC";
    public static final String EMA_SITE_LSE_INSP_TYPE_MSTR = "ema_site_lse_insp_type_mstr";
    public static final String INSP_TYPE_MSTR_SHORT = "LSE_INSP_TYPE_CODE";
    public static final String INSP_TYPE_MSTR_DESC = "LSE_INSP_TYPE_DESC";
    public static final String INSP_TYPE_MSTR_ALTERNATE_CODE = "EMA_SITE_LSE_INSP_TYPE_MSTR_ID";
    public static final String EMA_SITE_REQD_WORK_MSTR = "ema_site_reqd_work_mstr";
    public static final String WORK_MSTR_SHORT = "REQD_WORK_CODE";
    public static final String WORK_MSTR_DESC = "REQD_WORK_DESC";
    public static final String WORK_MSTR_ALTERNATECODE ="EMA_SITE_REQD_WORK_MSTR_ID";

    // lesse response constants
    //building and structures
    public static final String EMA_SITE_STRC_TYPE_MSTR = "ema_site_strc_type_mstr";
    public static final String STRUCT_TYPE_SHORT = "ema_site_strc_type_mstr_id";
    public static final String STRUCT_TYPE_DESC = "STRC_TYPE_DESC";
    public static final String STRUCT_TYPE_ALTERNATECODE = "STRC_TYPE_CODE";

    //owner 
    public static final String EMA_SITE_OWN_TYPE_MSTR = "ema_site_own_type_mstr";
    public static final String OWN_TYPE_SHORT = "ema_site_own_type_mstr_id";
    public static final String OWN_TYPE_DESC = "OWN_DESC";
    public static final String OWN_TYPE_ALTERNATECODE = "OWN_CODE";

    //storage and materials
    public static final String EMA_SITE_MATL_AND_STRG_MSTR = "ema_site_matl_and_strg_mstr";
    public static final String STRG_MATL_SHORT = "MATL_AND_STRG_CODE";
    public static final String STRG_MATL_DESC = "MATL_AND_STRG_DESC";
    public static final String EMA_SITE_MATL_AND_STRG_MSTR_ID = "ema_site_matl_and_strg_mstr_id";

    //Inspection status master table constants 
    public static final String EMA_SITE_PROP_INSP_MSTR = "ema_site_prop_insp_mstr";
    public static final String EMA_SITE_PROP_INSP_MSTR_ID = "ema_site_prop_insp_mstr_id";
    public static final String PROP_INSP_CODE = "PROP_INSP_CODE";
    public static final String PROP_INSP_DESC = "PROP_INSP_DESC";

    //property use category
    public static final String EMA_SITE_PROP_USE_DTL_MSTR = "EMA_SITE_PROP_USE_DTL_MSTR dtl INNER JOIN EMA_SITE_PROP_USE_CATG_MSTR catg ON dtl.EMA_SITE_PROP_USE_CATG_MSTR_ID = catg.EMA_SITE_PROP_USE_CATG_MSTR_ID";
    public static final String PROP_USE_CODE = "dtl.PROP_USE_CODE";
    public static final String PROP_USE_DESC = "catg.PROP_USE_CATG_DESC || ' - ' || dtl.PROP_USE_DESC";
    public static final String EMA_SITE_PROP_USE_DTL_MSTR_ID = "EMA_SITE_PROP_USE_DTL_MSTR_ID";

    //tank location
    public static final String EMA_SITE_TANK_LOCA_MSTR = "EMA_SITE_TANK_LOCA_MSTR";
    public static final String STRG_TANK_LOCA_SHORT = "EMA_SITE_TANK_LOCA_MSTR_ID";
    public static final String STRG_TANK_LOCA_DESC = "STRG_TANK_LOCA_DESC";
    public static final String STRG_TANK_LOCA_ALTERNATECODE = "STRG_TANK_LOCA_CODE";

    //other facilities type
    public static final String EMA_SITE_OTH_FAC_TYPE_MSTR = "ema_site_oth_fac_type_mstr";
    public static final String EMA_SITE_OTH_FAC_TYPE_MSTR_SHORT = "ema_site_oth_fac_type_mstr_id";
    public static final String EMA_SITE_OTH_FAC_TYPE_MSTR_DESC = "oth_fac_type_desc";
    public static final String EMA_SITE_OTH_FAC_TYPE_MSTR_CODE = "oth_fac_type_code";
    public static final String EMA_SITE_OTH_FAC_TYPE_MSTR_ID = "EMA_SITE_OTH_FAC_TYPE_MSTR_ID";
    public static String EMA_SITE_OTH_FAC_TYPE_WATER_WELL_CODE_VALUE = "WWL";

    //General waste material type
    public static final String EMA_SITE_GEN_WAST_MATL_MSTR = "ema_site_gen_wast_matl_mstr";
    public static final String EMA_SITE_GEN_WAST_MATL_MSTR_ID = "ema_site_gen_wast_matl_mstr_id";
    public static final String EMA_SITE_GEN_WAST_MATL_MSTR_DESC = "gen_wast_matl_desc";
    public static final String EMA_SITE_GEN_WAST_MATL_MSTR_CODE = "gen_wast_matl_code";

    //Environment and audit frequency 
    public static final String EMA_SITE_ENVR_AUD_FREQ_MSTR = "ema_site_envr_aud_freq_mstr";
    public static final String EMA_SITE_ENVR_AUD_FREQ_MSTR_ID = "ema_site_envr_aud_freq_mstr_id";
    public static final String EMA_SITE_ENVR_AUD_FREQ_MSTR_CODE = "envr_cmpl_aud_freq_code";
    public static final String EMA_SITE_ENVR_AUD_FREQ_MSTR_DESC = "envr_cmpl_aud_freq_desc";

    //Mail Display type master table constants 
    public static final String MAIL_DISPLAY_MSTR = "EMA_SITE_MAIL_DSPL_TYPE_MSTR";
    public static final String MAIL_DISPLAY_CODE = "DSPL_TYPE_CODE";
    public static final String MAIL_DISPLAY_DESC = "DSPL_TYPE_DESC";
    public static final String MAIL_DISPLAY_ID   = "DSPL_TYPE_ID";

    //Mail Audit type master table constants 
    public static final String MAIL_AUDT_TYPE_MSTR = "EMA_SITE_AUD_TYPE_MSTR";
    public static final String MAIL_AUDT_TYPE_CODE = "AUD_TYPE_CODE";
    public static final String MAIL_AUDT_TYPE_DESC = "AUD_TYPE_DESC";
    public static final String MAIL_AUDT_TYPE_ID= "AUD_TYPE_ID";

    public static final String[] DATA_SURVEY_TABLE_LIST= {"EMA_SITE_DOCS_AND_RCDS_DTL","EMA_SITE_LSE_DTL","EMA_SITE_LSE_ID_INFO_DTL","EMA_SITE_LSE_SITE_LOCA_DTL","EMA_SITE_REIM_PGMS_DTL","EMA_SITE_CONS_PROP_USE_DTL","ema_site_rsk_asmt_scor_dtl","ema_site_rsk_scor_dtls"};
    public static final String[] LESE_RESP_TABLE_LIST= {"EMA_SITE_PROP_USE_DTL","EMA_SITE_PREV_PROP_USE_DTL","EMA_SITE_STRC_AND_FAC_DTL","EMA_SITE_STRG_TANK_DTL","EMA_SITE_OTH_FAC_DTL","EMA_SITE_MATL_AND_STRG_DTL","EMA_SITE_GENL_QSTN_DTL","EMA_SITE_GEN_WAST_DTL"};
    public static final String[] INSPECTOR_TABLE_LIST= {"EMA_SITE_LAND_USE_REVW_DTL","EMA_SITE_CTRL_MSUR_QSTN_DTL","EMA_SITE_LAND_USE_RESP_DTL","EMA_SITE_HZRD_RESP_DTL","EMA_SITE_PRDC_WAST_RESP_DTL","EMA_SITE_BURD_TANK_RESP_DTL","EMA_SITE_ABOV_GRND_TANK_DTL","EMA_SITE_DOC_QSTN_DTL","EMA_SITE_INSP_FAC_PRTB_WATR","EMA_SITE_INSP_FAC_WATR_WELL"};
    public static final String[] COMMITTE_TABLE_LIST= {"ema_site_dtl"};
    // LMS TUBE LEVEL MAster Table 
    public static final String EMA_LMS_TUBE_LEVL_MSTR="EMA_LMS_TUBE_LEVL_MSTR";
    public static final String TUBE_LEVL_ID="TUBE_LEVL_ID";
    public static final String TUBE_LEVL_CODE="TUBE_LEVL_CODE";
    public static final String TUBE_LEVL_DESC="TUBE_LEVL_DESC";

    // LMS TUBE LEVEL MAster Table 
    public static final String EMA_LMS_PROJ="EMA_LMS_PROJ";
    public static final String PROJ_ID="PROJ_ID";
    public static final String PROJ_NAME="PROJ_NAME";

     */

}