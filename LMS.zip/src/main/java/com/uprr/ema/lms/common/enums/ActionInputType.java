package com.uprr.ema.lms.common.enums;

import java.util.HashMap;
import java.util.Map;

/**
 * RoleTypeEnum.java
 * This class will maintain all the constants for actions and inputs for project status
 * @author Shubhi Agarwal
 *
 */
public enum ActionInputType {

	PROJECT_SUBMITTED("Project Submitted","PS","create-project","New Liability Project Submitted for Approval"),
	PROJECT_APPROVED("Project Approved","PA","project-summary","New Liability Project Approved"),
	PROJECT_DISAPPROVED("Project Disapproved","PU","create-project","New Liability Project Disapproved"),
	//PROJACT_SAVED("Project Saved","PS","",""),
	CHANGE_SUBMITTED("Change Submitted","CS","update-project","Project Update Submitted"),
	CHANGE_APPROVED("Change Approved","CA","project-summary","Project Update Approved"),
	CHANGE_DISAPPROVED("Change Disapproved","CU","update-project","Project Update Disapproved");
	//CHANGE_SAVED("Change Saved","CS","","");
	
	private String name;
	private String code;
	private String page;
	private String subject;
	private static Map<String, String> pageMap ;
	private static Map<String, String> subjMap ;
	
	private ActionInputType (String name, String code,String page,String subject){
		this.name = name;
		this.code = code;
		this.page=page;
		this.subject=subject;
	}
	
	 private static void initializeMapping() {
		 pageMap = new HashMap<String,String>();
		 subjMap= new HashMap<String,String>();
	        for (ActionInputType s : ActionInputType.values()) {
	        	pageMap.put(s.code, s.page);
	        }
	        for (ActionInputType s : ActionInputType.values()) {
	        	subjMap.put(s.code, s.subject);
	        }
	   }

	 public static String getPageByCode(String code) {
	        if (pageMap == null) {
	            initializeMapping();
	        }
	        if (pageMap.containsKey(code)) {
	            return pageMap.get(code);
	        }
	        return "";
	    }
	 
	 public static String getSubjectByCode(String code) {
	        if (subjMap == null) {
	            initializeMapping();
	        }
	        if (subjMap.containsKey(code)) {
	            return subjMap.get(code);
	        }
	        return "";
	    }
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * @param code the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * @return the page
	 */
	public String getPage() {
		return page;
	}

	/**
	 * @param page the page to set
	 */
	public void setPage(String page) {
		this.page = page;
	}
	
	
}
