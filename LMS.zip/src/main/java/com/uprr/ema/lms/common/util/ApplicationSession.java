package com.uprr.ema.lms.common.util;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;

import com.uprr.ema.lms.common.constant.LmsConstants;
import com.uprr.ema.lms.exception.LmsException;

/**
 * 
 * @author Anil Kumar Manchala
 *
 */
public class ApplicationSession {

	private static final Logger LOGGER = LoggerFactory.getLogger(ApplicationSession.class);
	private String userToken;
	
	public ApplicationSession() {
		//Auto-generated constructor stub
	}
	
	public ApplicationSession(HttpServletRequest servletRequest) {
		setUserToken(servletRequest);
	}
	
	/**
	 * This method sets the userToken in the session and this will be used for FileNet request.	 * 
	 * @param httpRequest
	 * @return
	 */
	private void setUserToken(HttpServletRequest httpRequest) {
		try {
			userToken = getClientToken();
			LOGGER.info("---------->>> userToken(from Client Token): {}", userToken);
			if(StringUtils.isNotEmpty(userToken)) {
				setUserToken(userToken);
			}
		} catch(Exception e) {
			LOGGER.error("A siteminder token could not be generated.", e);
		}
		if(StringUtils.isEmpty(userToken) || (userToken != null && StringUtils.isEmpty(userToken.trim()))) {
			setSessionUserToken(httpRequest);
		}
	}
	
	
	/**
	 * Gets the user token.
	 * @return
	 */
	public String setSessionUserToken(HttpServletRequest httpRequest) {
		Environment environment = CommonUtils.getEnvironment();
		String env = environment.getProperty(LmsConstants.UPRR_IMPLEMENTATION_ENVIRONMENT);

		if("Local".equalsIgnoreCase(env) || "Win".equalsIgnoreCase(env)){
			//SmClient smClient = new SmClient();
			//smClient.authenticate("xmie006", "7u8i9o", null);
			//Need to keep User Token here and we can get this from XDEV or XTEST logs.
			userToken = "";//"TZxkmEL4ZK1TDgeBaFL+Z2IWvYMaq6oh5qCvQJtYV5fG0KSB4b98P76Kp6wVDBb3zq0Nwfi8tn5w80Zg5QNjrW2iIvxdgsFeBQBiZYZCTPF14ft0mHXEldORxBWyG0yEPEcbZlYDlQFjszaC85oYSV78w6F/PbyeNU2I3zHEYhEIOjwOaTEpi1SWEVyL493nkD/o6GYF6hqR2ZDt4KHu9qJ0o4ATAozpAHeqAWp9UWcMm8cSrJVBRDfTWAHfy+bkMCN1/FirwEoj6bnJ+WKvHGzbkevQgxi55rOICjvYxeYTDh2BzejPKFmfq7r0GMoyjE/D0MOdo2UoV9p1vCBbWChyxn3zb89EdDwY93xExGvNG1mt90uC7FptcQGsXLprQYzprkkXiVWALKW9tBXU1H2GAr0TdAPqHmc4S0iOmj2lnI41Yf490OMFtO0eOmSe8KbjvpXVAq6M9fxqVsY25h8EH02TaZLmZ/mWO7VZ7c5EkE7YGvB3vHxBtwLZxAEnJ6eXU94eATvHfYj0eH0r2w0bpX0Wvg7lhCI04VnYjGUtSc5xj+NcQ4ghjsvue3c4joV4gP54Q3Ixi0OXxXVxw/IhjJAuEsnKPoWZdfP/TJtnjTWNY3MDCyjktdj+q0Qkmccq5Ekv4dE6p1INclIy7jrK68SveqdeiCBHYMFLq3p3ZkyIlier4pC0V9QeQQiNJskPr1KEsfzgAucBrGyhDdqmtlfeKoZDzDlcd3ghMEqoqWuN7K08D07q1fPHzMO/vvgzAvHhvDX37g5XH4F3w6T0lwtlLLnQh0n7LajksE387IAegpqPRyWdYGxg2/vCbZGiLcBRv6L8bBI52o5sSV/e5s7pH9+o5XDLEqb3BaxvNVyKPcl7L2W0kFIkXvgsTwGeeNW9Y/9Z5VR94/e/nuyiiIIcHjFjKPW+3TRASV7IwVuTQupRf4h9UTlOWBo6Q7Cf8PlKDz57n96y/JjpculOAaTn3qFnKdG83MywhZ8iD93hMWhnMCIgGmGIpzg0";
		} else {
			extractUserTokenFromRequest(httpRequest);
		}
	  return userToken;
	}

	private void extractUserTokenFromRequest(HttpServletRequest httpRequest) {
		if (httpRequest != null) {
			if ((httpRequest.getRemoteUser() == null || httpRequest.getRemoteUser().trim().length() == 0)
					&& (httpRequest.getUserPrincipal() == null || httpRequest.getUserPrincipal().getName() == null 
					|| httpRequest.getUserPrincipal().getName().trim().length() == 0)) {
				//TODO: Implement to route the Error Page for the Invalid RDT Users.
			} else {
				Cookie[] cookies = httpRequest.getCookies();
				for (int i = 0; i < cookies.length; i++) {
					Cookie cookie = cookies[i];
					if (cookie.getName().equalsIgnoreCase(LmsConstants.USER_SESSION_TOKEN)) {
						userToken = cookie.getValue();
						LOGGER.info("---------->>> userToken: {}",userToken);
					}
				}
			}
		}
	}
	
	/**
	 * Gets the user token.
	 * @return
	 */
	public static String getClientToken() {
		HttpClientLogin httpClient = new HttpClientLogin(10000, 50000);
		HttpResult myHttpResult;
		String smSession = "";
		Environment environment = CommonUtils.getEnvironment();
		String env = environment.getProperty(LmsConstants.UPRR_IMPLEMENTATION_ENVIRONMENT);

		if("Local".equalsIgnoreCase(env) || "Win".equalsIgnoreCase(env)){
			//SmClient smClient = new SmClient();
			//smClient.authenticate("xmie006", "7u8i9o", null);
			//Need to keep User Token here and we can get this from XDEV or XTEST logs.
			smSession = "";//"TZxkmEL4ZK1TDgeBaFL+Z2IWvYMaq6oh5qCvQJtYV5fG0KSB4b98P76Kp6wVDBb3zq0Nwfi8tn5w80Zg5QNjrW2iIvxdgsFeBQBiZYZCTPF14ft0mHXEldORxBWyG0yEPEcbZlYDlQFjszaC85oYSV78w6F/PbyeNU2I3zHEYhEIOjwOaTEpi1SWEVyL493nkD/o6GYF6hqR2ZDt4KHu9qJ0o4ATAozpAHeqAWp9UWcMm8cSrJVBRDfTWAHfy+bkMCN1/FirwEoj6bnJ+WKvHGzbkevQgxi55rOICjvYxeYTDh2BzejPKFmfq7r0GMoyjE/D0MOdo2UoV9p1vCBbWChyxn3zb89EdDwY93xExGvNG1mt90uC7FptcQGsXLprQYzprkkXiVWALKW9tBXU1H2GAr0TdAPqHmc4S0iOmj2lnI41Yf490OMFtO0eOmSe8KbjvpXVAq6M9fxqVsY25h8EH02TaZLmZ/mWO7VZ7c5EkE7YGvB3vHxBtwLZxAEnJ6eXU94eATvHfYj0eH0r2w0bpX0Wvg7lhCI04VnYjGUtSc5xj+NcQ4ghjsvue3c4joV4gP54Q3Ixi0OXxXVxw/IhjJAuEsnKPoWZdfP/TJtnjTWNY3MDCyjktdj+q0Qkmccq5Ekv4dE6p1INclIy7jrK68SveqdeiCBHYMFLq3p3ZkyIlier4pC0V9QeQQiNJskPr1KEsfzgAucBrGyhDdqmtlfeKoZDzDlcd3ghMEqoqWuN7K08D07q1fPHzMO/vvgzAvHhvDX37g5XH4F3w6T0lwtlLLnQh0n7LajksE387IAegpqPRyWdYGxg2/vCbZGiLcBRv6L8bBI52o5sSV/e5s7pH9+o5XDLEqb3BaxvNVyKPcl7L2W0kFIkXvgsTwGeeNW9Y/9Z5VR94/e/nuyiiIIcHjFjKPW+3TRASV7IwVuTQupRf4h9UTlOWBo6Q7Cf8PlKDz57n96y/JjpculOAaTn3qFnKdG83MywhZ8iD93hMWhnMCIgGmGIpzg0";
		}  else {

			try {
				myHttpResult = (HttpResult) httpClient.getSecureUrlSMLogin(getURL(), "drdt999", "y6u7i8");
				smSession = myHttpResult == null ? null :  myHttpResult.getSmSessionValue();
			} catch (LmsException se) {
				LOGGER.error("A siteminder token could not be generated.", se);
			} catch (Exception e) {
				LOGGER.error("A siteminder token could not be generated.",  e);
			} 
			LOGGER.info(">>>>>>>>>>>>>><<<<<<<<<<<<<<<<>>>>>>>>>>>>>>>>>>>>>> Token : {}",  smSession);
		}
		return smSession;
	}
	/**
	 * 
	 * This methods returns current url
	 * 
	 * @return
	 */
	public static String getURL() {
		String hostUrl = CommonUtils.getEnvironment().getProperty("host.url");
		return new StringBuilder("https://").append(hostUrl).append("/rdt-rest/secure/jas").toString();		
	}
	public String getUserToken() {
		return userToken;
	}

	public void setUserToken(String userToken) {
		this.userToken = userToken;
	}

}
