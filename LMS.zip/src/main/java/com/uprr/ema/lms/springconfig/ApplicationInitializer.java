package com.uprr.ema.lms.springconfig;

import javax.servlet.*;

import org.springframework.web.WebApplicationInitializer;
import org.springframework.web.context.ContextLoaderListener;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.filter.DelegatingFilterProxy;
import org.springframework.web.servlet.DispatcherServlet;

/**
 * This class initializes the web application context (the web app equivalent to
 * the "main" class in a standalone app) WebApplicationInitializer classes are
 * detected *automatically* by Spring and may be located anywhere in the
 * classpath. This file should not require modification
 * (except to possibly add/configure filters)
 *
 *************************************************************
 * REQUIRES Java 7, Servlet 3.0 API, and therefore Tomcat 7  *
 *************************************************************
 */
public class ApplicationInitializer implements WebApplicationInitializer {
    /*
     * Missing URL mapping throws an exception that is handled out of the UPALertErrorInterceptor
     * rather than bouncing it back to the Servlet container to throw a 404
     */
    private static final boolean HANDLE_MISSING_HANDLERS_IN_ERROR_INTERCEPTOR = true;
    
    private static final String DISPATCHER_NAME = "emalms";
    /*
     * If this is not a secured service (unusual) remove the /secure from this URL (also update your Gatling examples!)
     */
    private static final String DISPATCHER_MAPPING_URL = "/secure/jas/*";

    @Override
    public void onStartup(ServletContext servletContext) {
        AnnotationConfigWebApplicationContext rootContext = registerAndMapDispatcherServlet(servletContext);
        rootContext.register(MainConfig.class);
    }
    
    protected AnnotationConfigWebApplicationContext registerAndMapDispatcherServlet(ServletContext servletContext) {
        addDelegatedFilter(servletContext, FilterConfig.USER_VALIDATION_FILTER);
                
        // Create the dispatcher servlet's Spring application context
        AnnotationConfigWebApplicationContext dispatcherContext = new AnnotationConfigWebApplicationContext();
        servletContext.addListener(new ContextLoaderListener(dispatcherContext));  //required for the DelegatingFilterProxy
        DispatcherServlet dispServlet = new DispatcherServlet(dispatcherContext);
        dispServlet.setThrowExceptionIfNoHandlerFound(HANDLE_MISSING_HANDLERS_IN_ERROR_INTERCEPTOR);
        final ServletRegistration.Dynamic dispatcher = 
            servletContext.addServlet(DISPATCHER_NAME, dispServlet);
        dispatcher.setLoadOnStartup(1);
        dispatcher.addMapping(DISPATCHER_MAPPING_URL);
        return dispatcherContext;
    }
    
    /**
     * Creates a DelegatingFilterProxy attached to the passedFilterName.
     * Delegated Filters (usually) defined in FilterConfig.java
     * @param servletContext
     * @param filterName the name of the delegated filter that will be used by Spring to find the bean from the context
     */
    protected void addDelegatedFilter(ServletContext servletContext, String filterName) {
        final FilterRegistration.Dynamic delegatedFilter = 
            servletContext.addFilter(filterName, new DelegatingFilterProxy());
        delegatedFilter.addMappingForUrlPatterns(null, true, DISPATCHER_MAPPING_URL);
    }
 }
