package com.uprr.ema.lms.reports.dao.impl;

import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Repository;

import com.uprr.ema.lms.common.dao.impl.OracleDaoImpl;
import com.uprr.ema.lms.common.dto.DocumentDTO;
import com.uprr.ema.lms.common.util.WebDateUtils;
import com.uprr.ema.lms.reports.dao.api.ReportsOracleDao;
import com.uprr.ema.lms.reports.dto.BusinessPrepPlanDTO;
import com.uprr.ema.lms.reports.dto.LCRRprtDTO;
import com.uprr.ema.lms.reports.dto.LCRRprtSearchCriteriaDTO;
import com.uprr.ema.lms.reports.dto.MonthlySpendDTO;
import com.uprr.ema.lms.reports.dto.ProjCountWaterfallDTO;
import com.uprr.ema.lms.reports.dto.SiteSourceDTO;
import com.uprr.ema.lms.reports.service.api.ReportsService;

@Repository
@PropertySource(value={"classpath:reports/reports_sql.properties"})
public class ReportsOracleDaoImpl extends OracleDaoImpl implements ReportsOracleDao{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ReportsOracleDaoImpl.class);
	

	@Autowired
	public Environment environment;
	
	@Autowired
	public ReportsService reportsService;
	
	public List<BusinessPrepPlanDTO> getProjectDetailsBasedOnNetworkId(Set<String> networkNumberSet){
		
		StringBuilder query = new StringBuilder(environment.getProperty("GET_BPPD_DETAILS_FROM_ORACLE"));
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("networkIds", networkNumberSet);
		List<BusinessPrepPlanDTO> oracleList = this.getNamedParamResultsList(query.toString(), parameters,BusinessPrepPlanDTO.class);
		LOGGER.info("oracle list size :: "+oracleList.size());
		return oracleList;
	}

	@Override
	public List<SiteSourceDTO> getSiteSourceProjDetailsBasedOnNetworkId(String date) {
		
		StringBuilder query = new StringBuilder(environment.getProperty("GET_SITE_SOURCE_DETAILS_FROM_ORACLE"));
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("date", date);
		List<SiteSourceDTO> oracleList = this.getNamedParamResultsList(query.toString(),parameters,SiteSourceDTO.class);
		return oracleList;
	}

	@Override
	public List<MonthlySpendDTO> getMonthlySpendDataFromOracle() {
		
		StringBuilder query = new StringBuilder(environment.getProperty("GET_MONTHLY_SPEND_DETAILS_FROM_ORACLE"));
		List<MonthlySpendDTO> monthlySpendOracleList = this.getNamedParamResultsList(query.toString(),MonthlySpendDTO.class);
		return monthlySpendOracleList;
		
	}

	@Override
	public int getBeginningProjCount(String year) {
		StringBuilder query = new StringBuilder(environment.getProperty("GET_BEGINNING_PROJECT_COUNT"));
		String date = Integer.parseInt(year)- 10 +"-01-01";
		int beginningProjCount = this.getCount(query.toString(),new Object[]{date});
		return beginningProjCount;
	}

	@Override
	public List<ProjCountWaterfallDTO> getProjCountWaterfallList(String year) {
		StringBuilder query = new StringBuilder(environment.getProperty("GET_CLOSED_AND_NEW_SITES_COUNT"));
		List<ProjCountWaterfallDTO> list = this.getNamedParamResultsList(query.toString(),new Object[] {Integer.parseInt(year)-10,Integer.parseInt(year)},ProjCountWaterfallDTO.class);
		return list;
	}
	
	/* (non-Javadoc)
	 * @see com.uprr.ema.lms.reports.lcr.dao.api.ReportsOracleDao#getAllProjectLstforSumOfLiabEst(com.uprr.ema.lms.reports.lcr.dto.LCRRprtSearchCriteriaDTO)
	 */
	public List<LCRRprtDTO> getAllProjectLstforSumOfLiabEst(LCRRprtSearchCriteriaDTO lcrRprtSearchCriteria){
		String[] startEndDtOfMonth = WebDateUtils.getFirstLastDayInMMMMddyyyyFormat(lcrRprtSearchCriteria.getMonth(),lcrRprtSearchCriteria.getYear());
		StringBuilder query = new StringBuilder(environment.getProperty("GET_AllPROJ_LIABEST_LCRR_FROM_ORACLE"));
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("stdt", startEndDtOfMonth[0]);
		parameters.addValue("eddt", startEndDtOfMonth[1]);
		List<LCRRprtDTO> lcrRprtDTOList =  this.getNamedParamResultsList(query.toString(),parameters,LCRRprtDTO.class);
		LOGGER.info("lcrRprtDTOList :: "+lcrRprtDTOList);
		return lcrRprtDTOList;
	}
	
	/* (non-Javadoc)
	 * @see com.uprr.ema.lms.reports.lcr.dao.api.ReportsOracleDao#getAllProjectLstforTubelevelGreaterThan6()
	 */
	public List<LCRRprtDTO> getAllProjectLstforTubelevelGreaterThan6(LCRRprtSearchCriteriaDTO lcrRprtSearchCriteria){
		String[] startEndDtOfMonth = WebDateUtils.getFirstLastDayInMMMMddyyyyFormat(lcrRprtSearchCriteria.getMonth(),lcrRprtSearchCriteria.getYear());
		StringBuilder query = new StringBuilder(environment.getProperty("GET_ALL_PRJDTLS_LCRR_TUBLVLGREATERTHAN6"));
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("stdt", startEndDtOfMonth[0]);
		parameters.addValue("plusdaystdt", startEndDtOfMonth[2]);
		List<LCRRprtDTO> lcrRprtDTOList =  this.getNamedParamResultsList(query.toString(),parameters,LCRRprtDTO.class);
		LOGGER.info("lcrRprtDTOList :: "+lcrRprtDTOList);
		return lcrRprtDTOList;
	}
	
	/* (non-Javadoc)
	 * @see com.uprr.ema.lms.reports.lcr.dao.api.ReportsOracleDao#getProjectListIncrsedChngdEstBy10000forMMYYYY(com.uprr.ema.lms.reports.lcr.dto.LCRRprtSearchCriteriaDTO)
	 */
	public List<LCRRprtDTO> getProjectListIncrsedChngdEstBy10000forMMYYYY(LCRRprtSearchCriteriaDTO lcrRprtSearchCriteria){
		String[] startEndDtOfMonth = WebDateUtils.getFirstLastDayInMMMMddyyyyFormat(lcrRprtSearchCriteria.getMonth(),lcrRprtSearchCriteria.getYear());
		StringBuilder query = new StringBuilder(environment.getProperty("GET_PRJCTDTLSFORLCR_ESTCHNGLESSMORETHAN10000_FROM_ORCL"));
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("stdt", startEndDtOfMonth[0]);
		parameters.addValue("eddt", startEndDtOfMonth[1]);
		List<LCRRprtDTO> lcrRprtDTOList =  this.getNamedParamResultsList(query.toString(),parameters,LCRRprtDTO.class);
		LOGGER.info("lcrRprtDTOList :: "+lcrRprtDTOList);
		return lcrRprtDTOList;
	}
	
	
	/* (non-Javadoc)
	 * @see com.uprr.ema.lms.reports.lcr.dao.api.ReportsOracleDao#getNewProjectListforMMYYYY(com.uprr.ema.lms.reports.lcr.dto.LCRRprtSearchCriteriaDTO)
	 */
	public List<LCRRprtDTO> getNewProjectListforMMYYYY(LCRRprtSearchCriteriaDTO lcrRprtSearchCriteria){
		String[] startEndDtOfMonth = WebDateUtils.getFirstLastDayInMMMMddyyyyFormat(lcrRprtSearchCriteria.getMonth(),lcrRprtSearchCriteria.getYear());
		StringBuilder query = new StringBuilder(environment.getProperty("GET_AllNEWPROJDTLS_FORMMYYYY_LCRR_FROM_ORACLE"));
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("stdt", startEndDtOfMonth[0]);
		parameters.addValue("eddt", startEndDtOfMonth[1]);
		List<LCRRprtDTO> lcrRprtDTOList =  this.getNamedParamResultsList(query.toString(),parameters,LCRRprtDTO.class);
		LOGGER.info("lcrRprtDTOList :: "+lcrRprtDTOList);
		return lcrRprtDTOList;
	}
	
	/* (non-Javadoc)
	 * @see com.uprr.ema.lms.reports.dao.api.ReportsOracleDao#getTotalCostPlannedExpndtrForYear(java.lang.String)
	 */
	public Float getTotalCostPlannedExpndtrForYear(String year){
		StringBuilder query = new StringBuilder(environment.getProperty("GET_PLANNEDEXPENDITRE_DATA_FROM_ORACLE"));
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("selectedYear", year); 
		Float beginningProjCount = this.queryForObject(query.toString(), parameters, Float.class);
		return beginningProjCount;
	}

	@Override
	public String saveDoc(DocumentDTO doc) {
		//Write the code to insert the data into the table once the table is created
		System.out.println(doc.toString());
		StringBuilder query = new StringBuilder(environment.getProperty("INSERT_DOC_DETAILS"));
		this.saveOrUpdate(query.toString(), new Object[]{1,doc.getGuid(),doc.getMimeType(),doc.getDocName(),doc.getDocDesc(),doc.getDocDesc(),doc.getDocCmnt(),doc.getActiveFlag(),doc.getDocType(),"","",doc.getSelectedDate()});
		return doc.getGuid();
	}

	@Override
	public DocumentDTO getSavedDoc(String month, String year, String reportType) {
		DocumentDTO dto = new DocumentDTO();
		String date = "01-"+month.substring(0,3).toLowerCase()+"-"+year;
		StringBuilder query = new StringBuilder(environment.getProperty("GET_DOC_DETAILS"));
		dto = (DocumentDTO) this.getNamedParamResultObject(query.toString(), new Object[]{reportType,date},DocumentDTO.class);
		return dto;
	}

	@Override
	public String updateDoc(DocumentDTO doc) {
		System.out.println(doc.toString());
		StringBuilder query = new StringBuilder(environment.getProperty("UPDATE_DOC"));
		this.saveOrUpdate(query.toString(), new Object[]{doc.getDocId()});
		return doc.getGuid();
	}
	
}
