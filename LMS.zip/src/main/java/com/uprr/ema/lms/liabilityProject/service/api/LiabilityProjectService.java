package com.uprr.ema.lms.liabilityProject.service.api;

import java.util.List;

import com.uprr.ema.lms.liabilityProject.dto.AccountCostDTO;
import com.uprr.ema.lms.liabilityProject.dto.DisapproveProjDTO;
import com.uprr.ema.lms.liabilityProject.dto.ProjectCostDTO;
import com.uprr.ema.lms.liabilityProject.dto.ProjectDTO;
import com.uprr.ema.lms.liabilityProject.vb.ProjectOnLoadVB;
/**
 * This interface delegate the request to DAO and response is send back to
 * called method.
 * 
 * The methods in this invoke will invoke the corresponding DAO method to
 * process the request.
 * 
 * @author xprk208
 * 
 */
public interface LiabilityProjectService {

    
    public List<ProjectDTO> getPendignApprovalProjects();
    public List<ProjectDTO> getDisApprovedProjects() ;
    public List<AccountCostDTO> getAccountUpdate();
	/**
	 * This method will fetch all drop down values of Create New project page
	 * @see com.uprr.ema.lms.liabilityProject.service.api.LiabilityProjectService.getLookUpData()
	 * @return ProjectOnLoadVB
	 */
	public ProjectOnLoadVB getLookUpData() ;
	public ProjectOnLoadVB getMasterData();
	/**
     * To save all the project detail values to database.
     * @param ProjectDTO
     * @return long
     * @
     */
	//public ProjectDTO saveOrUpdateProjectDetails(ProjectDTO projectDTO);
	public ProjectDTO saveOrUpdateProjectDetails(ProjectDTO projectDTO);
	public ProjectDTO saveProjectDetails(ProjectDTO projectDTO);
	public void deleteProject(ProjectDTO projectDTO) ;
	/**
     * To save all the project cost detail values to database.
     * @param ProjectCostDTO 
     * @param ActiveUserId 
     * @return long
     * @
     */
	//public List<ProjectCostDTO> saveOrUpdateProjectCostDetails(ProjectDTO projectDTO);
	//public ProjectDTO saveApproveProject(ProjectDTO inputProjectDTO);
	
	/**
     * To send mail to the approver of the project details
     * @param ProjectDTO
     * @return void
     * @
     */
	public void sendMail(ProjectDTO projectDTO);
	/**
     * To get the project details from the database based on project id
     * @param ProjectDTO
     * @return long
     * @
     */
	public ProjectDTO getApprovedProjectDetails(long projectDtlID);
	public ProjectDTO getProjectByProjId(long projectId) ;
	/**
     * To get the project details from the database based on project id
     * @param ProjectCostDTO
     * @return long
     * @
     */
	public List<ProjectCostDTO> getProjectCostDetails(long projectID);
	public List<ProjectCostDTO> getCostsByprojIdAndCostType(long projectID, long costTypeId);
	
	//public List<ProjectCostDTO> getProjSubmitCosts(long projectID);
	
	public List<ProjectCostDTO> getProjApprovedCosts(long projectID);
	public ProjectDTO saveDisapprvProj(DisapproveProjDTO disapproveProjDTO,ProjectDTO projectDTO);
	
	public List<Integer> getUpto15Years();
	
	public void setAccountUpdate(String userId) ;
	
}
