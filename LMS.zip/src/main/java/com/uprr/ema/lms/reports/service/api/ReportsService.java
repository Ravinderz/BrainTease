package com.uprr.ema.lms.reports.service.api;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.web.multipart.MultipartFile;

import com.uprr.ema.lms.liabilityProject.dto.AccountCostDTO;
import com.uprr.ema.lms.reports.dto.LCRRprtSearchCriteriaDTO;
import com.uprr.ema.lms.reports.vb.DocumentVB;

public interface ReportsService {

    void getBppdExcelReport(HttpServletResponse response,String month, String year);
    void getSiteSourceExcelReport(HttpServletResponse response,String month,String year);
    void getMonthlySpendReport(HttpServletResponse response,String month, String year);
    void getQuarterlyAuditBackupReport(HttpServletResponse response,String month, String year);
    List<List<Integer>> getProjectCountWaterfallReport(String month, String year);
    public List<AccountCostDTO> getAccountData(String networkNumbers);
    public void getLCRReport(HttpServletResponse response, LCRRprtSearchCriteriaDTO lcrRprtSearchCriteria);
	String getMonthInNumeric(String month);
	String getlastQuarterMonth(String month);
	public List<List<Float>> generateLCRBarChart(HttpServletResponse response, String month, String year);
	public String archieveLEWBReport(MultipartFile file,String month,String year) throws IOException;
	public DocumentVB downloadLEWBReport(String month,String year);
	public String archieveLCRReport(MultipartFile file,String month,String year) throws IOException;
	public DocumentVB downloadLCRReport(String month,String year);

}
