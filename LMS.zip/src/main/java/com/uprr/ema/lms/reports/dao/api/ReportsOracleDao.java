package com.uprr.ema.lms.reports.dao.api;

import java.util.List;
import java.util.Set;

import com.uprr.ema.lms.common.dto.DocumentDTO;
import com.uprr.ema.lms.reports.dto.BusinessPrepPlanDTO;
import com.uprr.ema.lms.reports.dto.LCRRprtDTO;
import com.uprr.ema.lms.reports.dto.LCRRprtSearchCriteriaDTO;
import com.uprr.ema.lms.reports.dto.MonthlySpendDTO;
import com.uprr.ema.lms.reports.dto.ProjCountWaterfallDTO;
import com.uprr.ema.lms.reports.dto.SiteSourceDTO;

public interface ReportsOracleDao {

	public List<BusinessPrepPlanDTO> getProjectDetailsBasedOnNetworkId(Set<String> networkNumberSet);
	
	public List<SiteSourceDTO> getSiteSourceProjDetailsBasedOnNetworkId(String date);
	
	public List<MonthlySpendDTO> getMonthlySpendDataFromOracle();
	
	public int getBeginningProjCount(String year);
	
	public List<ProjCountWaterfallDTO> getProjCountWaterfallList(String year);
	
	public List<LCRRprtDTO> getAllProjectLstforTubelevelGreaterThan6(LCRRprtSearchCriteriaDTO lcrRprtSearchCriteria);
	
	public List<LCRRprtDTO> getAllProjectLstforSumOfLiabEst(LCRRprtSearchCriteriaDTO lcrRprtSearchCriteria);
	
	public List<LCRRprtDTO> getProjectListIncrsedChngdEstBy10000forMMYYYY(LCRRprtSearchCriteriaDTO lcrRprtSearchCriteria);
	
	public List<LCRRprtDTO> getNewProjectListforMMYYYY(LCRRprtSearchCriteriaDTO lcrRprtSearchCriteria);
	
	public Float getTotalCostPlannedExpndtrForYear(String year);
	
	public String saveDoc(DocumentDTO doc);
	
	public String updateDoc(DocumentDTO doc);
	
	public DocumentDTO getSavedDoc(String month,String year,String reportType);

}
