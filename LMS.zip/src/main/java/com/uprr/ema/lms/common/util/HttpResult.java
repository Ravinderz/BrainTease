package com.uprr.ema.lms.common.util;

import org.apache.commons.httpclient.Cookie;
import org.apache.commons.httpclient.Header;

public class HttpResult {


    private String httpContent="";
    private Exception httpException=null;
    private int httpStatusCode=0;
    private Header[] requestHeaders=null;
    private Header[] responseHeaders =null;
    
    private String serverResponseHeader="";
    private String contentDateHeader="";
    private String serverTypeHeader="";
    private String contentTypeHeader="";
    
    private long startTime=0;
    private long endTime=0;
    
    private String smSessionValue="";
    private Cookie[] cookies=null;
    
    public HttpResult() {
    	/**
    	 * Empty Constructor
    	 */
    }

    public String getHttpContent() {
        return httpContent;
    }
    
    public void setHttpContent(String responseBody) {
        this.httpContent = responseBody;
    }
   

    public Exception getHttpException() {
        return httpException;
    }

    public void setHttpException(Exception httpException) {
        this.httpException = httpException;
    }

    public int getHttpStatusCode() {
        return httpStatusCode;
    }

    public void setHttpStatusCode(int httpStatusCode) {
        this.httpStatusCode = httpStatusCode;
    }

    public Header[] getRequestHeaders() {
        return requestHeaders;
    }

    public void setRequestHeaders(Header[] requestHeaders) {
        this.requestHeaders = requestHeaders;
    }

    public Header[] getResponseHeaders() {
        return responseHeaders;
    }

    public void setResponseHeaders(Header[] responseHeaders) {
        this.responseHeaders = responseHeaders;
    }

    public String getContentDateHeader() {
        return contentDateHeader;
    }

    public void setContentDateHeader(String contentDateHeader) {
        this.contentDateHeader = contentDateHeader;
    }

    public String getContentTypeHeader() {
        return contentTypeHeader;
    }

    public void setContentTypeHeader(String contentTypeHeader) {
        this.contentTypeHeader = contentTypeHeader;
    }

    public String getServerResponseHeader() {
        return serverResponseHeader;
    }

    public void setServerResponseHeader(String serverResponseHeader) {
        this.serverResponseHeader = serverResponseHeader;
    }

    public String getServerTypeHeader() {
        return serverTypeHeader;
    }

    public void setServerTypeHeader(String serverTypeHeader) {
        this.serverTypeHeader = serverTypeHeader;
    }

    public long getEndTime() {
        return endTime;
    }

    public void setEndTime(long endTime) {
        this.endTime = endTime;
    }

    public long getStartTime() {
        return startTime;
    }

    public void setStartTime(long startTime) {
        this.startTime = startTime;
    }

    public String getSmSessionValue() {
        return smSessionValue;
    }

    public void setSmSessionValue(String smSessionValue) {
        this.smSessionValue = smSessionValue;
    }

    public Cookie[] getCookies() {
        return cookies;
    }

    public void setCookies(Cookie[] cookies) {
        this.cookies = cookies;
    }

}
