package com.uprr.ema.lms.common.dto;

import java.lang.reflect.Field;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;

public class BaseDTO {

    private boolean dataChanged;
    private String actFlag;
    private String crtdUser;
    private String lastUptdUser;
    private Date crtdDate;
    private Date lastUptdDate;
    
    /**
	  * Intended only for debugging.
	  *
	  * <P>Here, a generic implementation uses reflection to print
	  * names and values of all fields <em>declared in this class</em>. Note that
	  * superclass fields are left out of this implementation.
	  *
	  * <p>The format of the presentation could be standardized by using
	  * a MessageFormat object with a standard pattern.
	  */
	public String toString(Object obj) {
	    StringBuilder result = new StringBuilder();
	    String newLine = System.getProperty("line.separator");

	    result.append(obj.getClass().getName());
	    result.append(" Object {");
	    result.append(newLine);

	    //determine fields declared in this class only (no fields of superclass)
	    Field[] fields = this.getClass().getDeclaredFields();

	    //print field names paired with their values
	    for (Field field : fields) {	      
	      try {	
	    	  field.setAccessible(true);
	    	  if(field.get(this)!=null && !StringUtils.equalsIgnoreCase(field.getName(), "serialVersionUID")){
		    		result.append("  ");
		    		result.append(field.getName());
			        result.append(": ");			        
			        result.append(field.get(this));
			        result.append(newLine);
		    	}	
	      }
	      catch (IllegalAccessException ex) {
	        System.out.println(ex);
	      }
	     
	    }
	    result.append("}");

	    return result.toString();
	  }

    /**
     * @return the dataChanged
     */
    public boolean isDataChanged() {
        return dataChanged;
    }

    /**
     * @param dataChanged the dataChanged to set
     */
    public void setDataChanged(boolean dataChanged) {
        this.dataChanged = dataChanged;
    }

    /**
     * @return the actFlag
     */
    public String getActFlag() {
        return actFlag;
    }

    /**
     * @param actFlag the actFlag to set
     */
    public void setActFlag(String actFlag) {
        this.actFlag = actFlag;
    }

    /**
     * @return the crtdUser
     */
    public String getCrtdUser() {
        return crtdUser;
    }

    /**
     * @param crtdUser the crtdUser to set
     */
    public void setCrtdUser(String crtdUser) {
        this.crtdUser = crtdUser;
    }

    /**
     * @return the lastUptdUser
     */
    public String getLastUptdUser() {
        return lastUptdUser;
    }

    /**
     * @param lastUptdUser the lastUptdUser to set
     */
    public void setLastUptdUser(String lastUptdUser) {
        this.lastUptdUser = lastUptdUser;
    }

    /**
     * @return the crtdDate
     */
    public Date getCrtdDate() {
        return crtdDate;
    }

    /**
     * @param crtdDate the crtdDate to set
     */
    public void setCrtdDate(Date crtdDate) {
        this.crtdDate = crtdDate;
    }

    /**
     * @return the lastUptdDate
     */
    public Date getLastUptdDate() {
        return lastUptdDate;
    }

    /**
     * @param lastUptdDate the lastUptdDate to set
     */
    public void setLastUptdDate(Date lastUptdDate) {
        this.lastUptdDate = lastUptdDate;
    }
	
    
}
