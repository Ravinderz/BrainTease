package com.uprr.ema.lms.advise;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import com.uprr.ema.lms.common.constant.LmsConstants;
import com.uprr.ema.lms.common.dto.SendMailDTO;
import com.uprr.ema.lms.common.service.api.IENAEmailService;
import com.uprr.ema.lms.common.util.LMSResponseConstants;
import com.uprr.ema.lms.common.vb.StatusDetailsVB;
import com.uprr.ema.lms.exception.ExcelReportException;
import com.uprr.ema.lms.exception.LmsException;

@ControllerAdvice
public class ExceptionControllerAdvice {
	Logger logger = Logger.getLogger(ExceptionControllerAdvice.class);
	private String userName;

	 @Autowired
	 private IENAEmailService emailService;
	 
	 @Autowired
	 public Environment environment;

	/**
	 * @purpose Handles the exceptions of the type CustomExeption
	 * @param request
	 * @param CustomException
	 * @return ResponseVO
	 */
	@ExceptionHandler(LmsException.class)
	public @ResponseBody
	StatusDetailsVB customException(HttpServletRequest request,
			LmsException custmExcep) {
		return prepareReplyStatus(custmExcep,request.getUserPrincipal().getName());
	}
	
	
	

	/**
	 * @purpose Handles all unHandled exceptions and errors
	 * @param request
	 * @param Exception
	 * @return ResponseVO
	 * @throws Exception
	 */
	@ExceptionHandler(Exception.class)
	public @ResponseBody
	StatusDetailsVB exception(HttpServletRequest request, Exception excep)
			 {
		return prepareReplyStatus(excep,request.getUserPrincipal().getName());
	}
	
	/**
	 * @purpose Handles all unHandled exceptions and errors
	 * @param request
	 * @param Exception
	 * @return ResponseVO
	 * @throws Exception
	 */
	@ExceptionHandler(ExcelReportException.class)
	public @ResponseBody
	StatusDetailsVB excelException(HttpServletRequest request,HttpServletResponse response, Exception excep)
			 {
		response.setHeader("code", "2222");
		return prepareReplyStatus(excep,request.getUserPrincipal().getName());
	}
	

	public StatusDetailsVB prepareReplyStatus(Exception exception,String userId ){
		StatusDetailsVB objResponseVO = new StatusDetailsVB();
		objResponseVO.setStatusType(LMSResponseConstants.ERROR_MESSAGE_TYPE);
		objResponseVO.setStatusCode(LMSResponseConstants.FAILURE_CODE);
		sendMail(exception, userId);
		return objResponseVO;
	}
	

	    /**
	     * @param object 
	     * @purpose This method is used for sending a mail.
	     * @param String userId
	     * @param Exception excep
	     * @throws Exception
	     */
	   public void sendMail(Exception excep, String userId) {

		String fromAddress = null;
		StringBuilder subject = null;
		List<String> toArrList = new ArrayList<String>();

		StringBuilder messageText = new StringBuilder();
		final StringBuilder mailSubject = new StringBuilder();
		final StringBuilder exceptnContentString = new StringBuilder();

		try{
		    String strBuildEnv = environment.getProperty(LmsConstants.UPRR_IMPLEMENTATION_ENVIRONMENT);
		    if(strBuildEnv==null ){
			strBuildEnv = LmsConstants.LOCAL_ENV;
		    }
		    fromAddress = LmsConstants.EMA_FROM_MAIL_ADDRESS; 

		    exceptnContentString.append("Dear Customer,");
		    exceptnContentString.append(LmsConstants.BREAK_LINE);
		    exceptnContentString.append("Following exception has" + " occured in Application. ");
		    exceptnContentString.append(LmsConstants.BREAK_LINE);
		    exceptnContentString.append(LmsConstants.BREAK_LINE);

		    exceptnContentString.append(excep);
		    exceptnContentString.append("<html> ");
		    final StackTraceElement[] strStackTraceArray = excep.getStackTrace();
		    for (final StackTraceElement strArray : strStackTraceArray) {
			exceptnContentString.append(LmsConstants.BREAK_LINE);
			exceptnContentString.append("at ");
			exceptnContentString.append(strArray.toString());
		    }

		    exceptnContentString.append(LmsConstants.BREAK_LINE);
		    exceptnContentString.append(LmsConstants.BREAK_LINE);
		    exceptnContentString.append(LmsConstants.BREAK_LINE);
		    exceptnContentString.append("Thanks & Regards");
		    exceptnContentString.append(LmsConstants.BREAK_LINE);
		    exceptnContentString.append("EMA Service Team.");
		    exceptnContentString.append("</html> ");
		    messageText.append(exceptnContentString);

		    //** Added for Mail change based on environment **//*
		    strBuildEnv = strBuildEnv.toUpperCase();
		    subject = new StringBuilder();

		    if ((LmsConstants.DEV_ENV.equalsIgnoreCase(strBuildEnv)) || (LmsConstants.LOCAL_ENV.equalsIgnoreCase(strBuildEnv))|| LmsConstants.WIN_ENV.equalsIgnoreCase(strBuildEnv) || (LmsConstants.TEST_ENV.equalsIgnoreCase(strBuildEnv)) || (LmsConstants.PROD_ENV.equalsIgnoreCase(strBuildEnv))) {
			mailSubject.append("EMA [" + strBuildEnv +"]");
		    }
		    if(userId !=null){
		    mailSubject.append(userId);
		    }
		    mailSubject.append(" ::::::: ");
		    mailSubject.append("ERROR Report");
		    subject.append(mailSubject.toString());

		    if (LmsConstants.LOCAL_ENV.equalsIgnoreCase(strBuildEnv) || LmsConstants.WIN_ENV.equalsIgnoreCase(strBuildEnv)) {
			//toArrList.add(new String("sobilis@upcontractor.up.com"));
			/*toArrList.add(new String("amancha@upcontractor.up.com"));
		    toArrList.add(new String("mrajana@upcontractor.up.com"));*/
			//toArrList.add(new String("nkamini@upcontractor.up.com"));
			toArrList.add(new String("nkamini@upcontractor.up.com"));
		    }
		    else if ((LmsConstants.DEV_ENV.equalsIgnoreCase(strBuildEnv)) || 
			    (LmsConstants.TEST_ENV.equalsIgnoreCase(strBuildEnv))) {

			toArrList.add(new String("sthoefle@up.com"));
			toArrList.add(new String("amancha@upcontractor.up.com"));
			toArrList.add(new String("mpashik@upcontractor.up.com"));
			toArrList.add(new String("nkamini@upcontractor.up.com"));
			toArrList.add(new String("rjagtar@upcontractor.up.com"));
			toArrList.add(new String("bbachu@upcontractor.up.com"));
			toArrList.add(new String("pjoshi02@upcontractor.up.com"));
			

		    }else if (LmsConstants.PROD_ENV.equalsIgnoreCase(strBuildEnv)) {
			toArrList.clear();		
			toArrList.add(new String(LmsConstants.TO_ADDRESS_PRD));
		    }

		    //*** Sending Mail ***//*
		    SendMailDTO sendMailVO = new SendMailDTO();
		    sendMailVO.setFromAddress(fromAddress);
		    sendMailVO.setToAddressLst(toArrList);
		    sendMailVO.setSubject(subject.toString());
		    sendMailVO.setBodyContent(messageText.toString());
		    emailService.sendEmailNotification(sendMailVO);

		}catch(Exception e){
		    logger.error("Error occured while sending an Error email.", e);
		}
	    }

	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @param userName
	 *            the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

}
