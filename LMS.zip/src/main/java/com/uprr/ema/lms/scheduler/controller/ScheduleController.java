package com.uprr.ema.lms.scheduler.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.uprr.azm.shared.mvc.security.authorization.Attribute;
import com.uprr.azm.shared.mvc.security.authorization.Authorize;
import com.uprr.ema.lms.liabilityProject.service.api.LiabilityProjectService;
import com.uprr.ema.lms.scheduler.service.api.SchedulableService;
import com.uprr.ui.shared.user.ActiveUserId;
import com.uprr.ui.shared.user.spring.mvc.ActiveUser;

@RestController
@RequestMapping("/scheduler")
public class ScheduleController {

    @Autowired
    LiabilityProjectService liabilityProjectService;
    

    @Autowired
    SchedulableService schedulableService;

    @RequestMapping(value = "/accountUpdate", method = RequestMethod.GET)
    @ResponseBody
    public void setAccountUpdate(@ActiveUser ActiveUserId user)throws Exception {
	liabilityProjectService.setAccountUpdate(user.getUserId());
    }


    @RequestMapping(value = "/scheduleLEWBMonth", method = RequestMethod.GET)
    @ResponseBody
    @Authorize(
	    actions = {@Attribute(key="action-id", value="approve")},
	    resources = {@Attribute(key="resource-id", value="environmental-liabilities"),@Attribute(key="feature-id", value="project")}
	    )
    public void scheduleLEWBMonth(@ActiveUser ActiveUserId user)throws Exception {
	schedulableService.saveLEWBMonthData(user.getUserId());
    }
    
    @RequestMapping(value = "/scheduleLEWBQuarter", method = RequestMethod.GET)
    @ResponseBody
    @Authorize(
	    actions = {@Attribute(key="action-id", value="approve")},
	    resources = {@Attribute(key="resource-id", value="environmental-liabilities"),@Attribute(key="feature-id", value="project")}
	    )
    public void scheduleLEWBQuarter(@ActiveUser ActiveUserId user){
	schedulableService.saveLEWBQuarterData(user.getUserId());
    }


    @RequestMapping(value = "/scheduleLEWBMonthInQuarter", method = RequestMethod.GET)
    @ResponseBody
    @Authorize(
	    actions = {@Attribute(key="action-id", value="approve")},
	    resources = {@Attribute(key="resource-id", value="environmental-liabilities"),@Attribute(key="feature-id", value="project")}
	    )
    public void scheduleLEWBMonthInQuarter(@ActiveUser ActiveUserId user){
	schedulableService.saveLEWBMonthInQuarterData(user.getUserId());
    }
}

