package com.uprr.ema.lms.reports.helper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class SiteSourceReportMapper<T> implements RowMapper<T> {
	
	int year;
	
	public SiteSourceReportMapper(int year) {
		super();
		this.year = year;
	}

	public SiteSourceReportMapper() {
		super();
		// TODO Auto-generated constructor stub
	}

	public T mapRow(ResultSet arg0, int arg1) throws SQLException {
		SiteSourceReportResultSetExtractor<T> docExtractor = new SiteSourceReportResultSetExtractor<T>(year);
		return docExtractor.extractData(arg0);
	}
}

