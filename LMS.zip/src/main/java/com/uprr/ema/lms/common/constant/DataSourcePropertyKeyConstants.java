package com.uprr.ema.lms.common.constant;

public class DataSourcePropertyKeyConstants {
	
	 public static final String ORACLE_BI_CONNECTION_DB_INSTANCE = "oracleBI.connection.dbInstance";
	 public static final String ORACLE_BI_CONNECTION_DRIVER_CLASS = "oracleBI.connection.driver_class";
	 public static final String ORACLE_BI_PASS_KEY = "oracleBI.connection.localPassword";
	 public static final String ORACLE_BI_USERNAME = "oracleBI.connection.username";
	
	 public static final String ORACLE_CONNECTION_DB2_POOL_LOCAL_PASS_KEY = "oracle.connection.db2Pool_localPassword";
	 public static final String ORACLE_CONNECTION_DB2_POOL_USERNAME = "oracle.connection.db2Pool_username";
	 public static final String ORACLE_CONNECTION_DB2_POOL_DBMS_TYPE = "oracle.connection.db2Pool_dbmsType";
	 public static final String ORACLE_CONNECTION_DB2_POOL_DB_INSTANCE = "oracle.connection.db2Pool_dbInstance";
	 
	 public static final String DB2_POOL_NAME = "db2.pool.name";
	 public static final String ORACLE_CONNECTION_DB2POOL_DRIVER_CLASS = "oracle.connection.db2Pool_driver_class";
	
	 public static final String TERA_DATA_CONNECTION_DB_INSTANCE = "teraData.connection.dbInstance";
	 public static final String TERA_DATA_CONNECTION_DBMS_TYPE = "teraData.connection.dbmsType";
	 public static final String TERA_DATA_CONNECTION_USERNAME = "teraData.connection.username";
	 public static final String TERA_DATA_CONNECTION_LOCAL_PASS_KEY = "teraData.connection.localPassword";
	 
	 public static final String TERADATA_POOL_NAME = "teraData.pool.name";
	 public static final String TERADATA_CONNECTION_DRIVER_CLASS = "teraData.connection.driver_class";
	 
	 public static final String VALIDATION_INTERVAL = "VALIDATION_INTERVAL";
	 public static final String TRUE_PROP = "TRUE_PROP";
	 public static final String VALIDATION_QUERY = "VALIDATION_QUERY";
	 public static final String MIN_IDLE = "MIN_IDLE";
	 public static final String MAX_IDLE = "MAX_IDLE";
	 public static final String MAX_ACTIVE = "MAX_ACTIVE";
	 public static final String INITIAL_SIZE = "INITIAL_SIZE";
	 public static final String MIN_SIZE = "MIN_SIZE";
	 public static final String APPLICATION_TLA = "application.tla";
	
	 public static final String ORACLE_CONNECTION_DRIVER_CLASS = "oracle.connection.driver_class";
	 public static final String ORACLE_CONNECTION_LOCAL_PASS_KEY = "oracle.connection.localPassword";
	 public static final String ORACLE_CONNECTION_USERNAME = "oracle.connection.username";
	 public static final String UPRR_IMPLEMENTATION_ENVIRONMENT = "uprr.implementation.environment";
	 public static final String ORACLE_CONNECTION_DBMS_TYPE = "oracle.connection.dbmsType";
	 public static final String ORACLE_CONNECTION_DB_INSTANCE = "oracle.connection.dbInstance";

	 
	 public static final String SQLSERVER_CONNECTION_USERNAME = "sqlServer.connection.username";
	 public static final String SQLSERVER_CONNECTION_DBINSTANCE = "sqlServer.connection.dbInstance";
	 public static final String SQLSERVER_CONNECTION_LOCALPASS_KEY = "sqlServer.connection.localPassword";
	 public static final String SQL_POOL_NAME = "sql.pool.name";
	 public static final String SQLSERVER_CONNECTION_DRIVER_CLASS = "sqlServer.connection.driver_class";
	 public static final String SQLSERVER_CONNECTION_DBMSTYPE = "sqlServer.connection.dbmsType";
	 public static final String DSNAME = "DSName";

	 
	 
	
	 
}
