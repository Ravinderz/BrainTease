package com.uprr.ema.lms.searchproject.vb;

import com.uprr.ema.lms.common.vb.SearchCriteriaVB;

public class ProjectSearchCriteriaVB extends SearchCriteriaVB {

	private static final long serialVersionUID = 1L;
	
	private SearchVB projectSearchCriteria;

	/**
	 * @return the projectSearchCriteria
	 */
	public SearchVB getProjectSearchCriteria() {
		return projectSearchCriteria;
	}

	/**
	 * @param projectSearchCriteria the projectSearchCriteria to set
	 */
	public void setProjectSearchCriteria(SearchVB projectSearchCriteria) {
		this.projectSearchCriteria = projectSearchCriteria;
	}

	
	
	
}
