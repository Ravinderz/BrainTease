package com.uprr.ema.lms.liabilityProject.vb;

import java.io.Serializable;
import java.util.List;

import com.uprr.ema.lms.common.vb.StatusDetailsVB;

public class ProjectStatusVB extends StatusDetailsVB implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private ProjectVB projectVB;
	List<ProjectVB> projects;
	List<ProjectVB> pendingApprovalProjects;
	List<ProjectVB> disApprovedProjects;

	/**
	 * @return the projectVB
	 */
	public ProjectVB getProjectVB() {
		return projectVB;
	}

	/**
	 * @param projectVB the projectVB to set
	 */
	public void setProjectVB(ProjectVB projectVB) {
		this.projectVB = projectVB;
	}

	/**
	 * @return the projects
	 */
	public List<ProjectVB> getProjects() {
	    return projects;
	}

	/**
	 * @param projects the projects to set
	 */
	public void setProjects(List<ProjectVB> projects) {
	    this.projects = projects;
	}

	public List<ProjectVB> getPendingApprovalProjects() {
	    return pendingApprovalProjects;
	}

	public void setPendingApprovalProjects(List<ProjectVB> pendingApprovalProjects) {
	    this.pendingApprovalProjects = pendingApprovalProjects;
	}

	public List<ProjectVB> getDisApprovedProjects() {
	    return disApprovedProjects;
	}

	public void setDisApprovedProjects(List<ProjectVB> disApprovedProjects) {
	    this.disApprovedProjects = disApprovedProjects;
	}
	
	
	
}
