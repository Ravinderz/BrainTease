package com.uprr.ema.lms.liabilityProject.dto;

import java.io.Serializable;
import java.util.Date;

public class DisapproveProjDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long disaprvComtDtlID;
	private String disaprvComments;
	private String actFlag;
	private String crtdUser;
	private String lastUptdUser;
	private Date crtdDate;
	private Date lastUptdDate;
	private String empId;
	/**
	 * @return the disaprvComtDtlID
	 */
	public long getDisaprvComtDtlID() {
		return disaprvComtDtlID;
	}
	/**
	 * @param disaprvComtDtlID the disaprvComtDtlID to set
	 */
	public void setDisaprvComtDtlID(long disaprvComtDtlID) {
		this.disaprvComtDtlID = disaprvComtDtlID;
	}
	/**
	 * @return the disaprvComments
	 */
	public String getDisaprvComments() {
		return disaprvComments;
	}
	/**
	 * @param disaprvComments the disaprvComments to set
	 */
	public void setDisaprvComments(String disaprvComments) {
		this.disaprvComments = disaprvComments;
	}
	/**
	 * @return the actFlag
	 */
	public String getActFlag() {
		return actFlag;
	}
	/**
	 * @param actFlag the actFlag to set
	 */
	public void setActFlag(String actFlag) {
		this.actFlag = actFlag;
	}
	/**
	 * @return the crtdUser
	 */
	public String getCrtdUser() {
		return crtdUser;
	}
	/**
	 * @param crtdUser the crtdUser to set
	 */
	public void setCrtdUser(String crtdUser) {
		this.crtdUser = crtdUser;
	}
	/**
	 * @return the lastUptdUser
	 */
	public String getLastUptdUser() {
		return lastUptdUser;
	}
	/**
	 * @param lastUptdUser the lastUptdUser to set
	 */
	public void setLastUptdUser(String lastUptdUser) {
		this.lastUptdUser = lastUptdUser;
	}
	/**
	 * @return the crtdDate
	 */
	public Date getCrtdDate() {
		return crtdDate;
	}
	/**
	 * @param crtdDate the crtdDate to set
	 */
	public void setCrtdDate(Date crtdDate) {
		this.crtdDate = crtdDate;
	}
	/**
	 * @return the lastUptdDate
	 */
	public Date getLastUptdDate() {
		return lastUptdDate;
	}
	/**
	 * @param lastUptdDate the lastUptdDate to set
	 */
	public void setLastUptdDate(Date lastUptdDate) {
		this.lastUptdDate = lastUptdDate;
	}
	/**
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	/**
	 * @return the empId
	 */
	public String getEmpId() {
		return empId;
	}
	/**
	 * @param empId the empId to set
	 */
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	
	
}
