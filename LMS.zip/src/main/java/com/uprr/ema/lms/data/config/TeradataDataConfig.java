package com.uprr.ema.lms.data.config;

import org.apache.tomcat.jdbc.pool.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.JdbcTemplate;

import com.uprr.ema.lms.common.constant.DataSourcePropertyKeyConstants;
import com.uprr.ema.lms.common.util.CyberArkPoolPasswordUtil;

@Configuration
public class TeradataDataConfig {

	@Autowired
	Environment environment;

	@Bean(name = "teradataDataSource")
	public DataSource getTeradataDataSource() {
		return new org.apache.tomcat.jdbc.pool.DataSource(getTeradataPoolProperties());
	}

	@Bean(name = "teradataPoolProperties")
	public CyberArkPoolPasswordUtil getTeradataPoolProperties() {
		CyberArkPoolPasswordUtil cyberArkPoolPasswordUtil = new CyberArkPoolPasswordUtil();

		String dbInstance = environment.getProperty("TERADATA_DB_INSTANCE");

		cyberArkPoolPasswordUtil.setAppTLA(environment.getProperty(DataSourcePropertyKeyConstants.APPLICATION_TLA));
		cyberArkPoolPasswordUtil.setInstance(dbInstance);
		cyberArkPoolPasswordUtil.setType(environment.getProperty("TERADATA_DBMS"));
		cyberArkPoolPasswordUtil.setRunEnv(environment.getProperty("uprr.implementation.environment"));
		cyberArkPoolPasswordUtil.setDriverClassName(environment.getProperty("TERADATA_DRIVER_CLASS"));
		cyberArkPoolPasswordUtil.setUrl("jdbc:teradata://" + dbInstance);
		cyberArkPoolPasswordUtil.setAppID(environment.getProperty("TERADATA_DB_USER_NAME"));
		cyberArkPoolPasswordUtil.setLocalEnvPassword(environment.getProperty("TERADATA_DB_LOCAL_PASSWORD"));
		cyberArkPoolPasswordUtil.setInitialSize(Integer.parseInt(environment.getProperty("INITIAL_SIZE")));
		cyberArkPoolPasswordUtil.setMaxActive(Integer.parseInt(environment.getProperty("MAX_ACTIVE")));
		cyberArkPoolPasswordUtil.setMaxIdle(Integer.parseInt(environment.getProperty("MAX_IDLE")));
		cyberArkPoolPasswordUtil.setMinIdle(Integer.parseInt(environment.getProperty("MIN_IDLE")));
		cyberArkPoolPasswordUtil.setValidationQuery(environment.getProperty("VALIDATION_QUERY"));
		cyberArkPoolPasswordUtil.setTestWhileIdle(Boolean.parseBoolean(environment.getProperty("TRUE_PROP")));
		cyberArkPoolPasswordUtil.setValidationInterval(Long.parseLong(environment.getProperty("VALIDATION_INTERVAL")));
		cyberArkPoolPasswordUtil.setAccessToUnderlyingConnectionAllowed(Boolean.parseBoolean(environment.getProperty("TRUE_PROP")));
		return cyberArkPoolPasswordUtil;
	}
	
	@Bean(name="teradataJdbcTemplate")
	public JdbcTemplate jdbcTemplate() {
		JdbcTemplate jdbcTemplate = new JdbcTemplate(getTeradataDataSource());
		//jdbcTemplate.setDataSource(getOracleDataSource());
		return jdbcTemplate;
	}
}
