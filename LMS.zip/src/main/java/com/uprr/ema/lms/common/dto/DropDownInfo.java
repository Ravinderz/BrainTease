package com.uprr.ema.lms.common.dto;

import java.io.Serializable;

public class DropDownInfo implements Serializable {

    // default
    private static final long serialVersionUID = -6520558070592437137L;

    private Long codeId;
    private String code;
    private String description;
    private String descWithCode;
    private String codeWithDescription;
    private String parentCode;
    private Long orderbyNum;

    private String alternateCode;
    private String firstName;
    private String middleName;
    private String lastName;
    private String fullName;
    private String orgnName;
    private String city;
    private String phnNbr;
    private String email;
    private String persSt;
    private String lsePurpCode;
    private String lsePurpDesc;
    private String tableName;
    
    public DropDownInfo() {

    }

    public DropDownInfo(String code) {
	this.code = code;
    }

    public DropDownInfo(String code, String description) {
	this.code = code;
	this.description = description;
    }

    public String getDescription() {
	return description;
    }

    public void setDescription(String description) {
	this.description = description;
    }

    public String getCode() {
	return code;
    }

    public void setCode(String code) {
	this.code = code;
    }

    public String getDescWithCode() {
	return description + "(" + code + ")";
    }

    public String getCodeWithDescription() {
	codeWithDescription = "(" + code + ") " + description;
	return codeWithDescription;
    }

    @Override
    public boolean equals(Object obj) {
	if (obj != null && obj instanceof DropDownInfo) {
	    if (getCode() != null) {
		return getCode().equals(((DropDownInfo) obj).getCode());
	    }
	}
	return false;
    }

    @Override
    public int hashCode() {
	if (code != null) {
	    return code.hashCode();
	} else {
	    return super.hashCode();
	}
    }

    public String getAlternateCode() {
	return alternateCode;
    }

    public void setAlternateCode(String alternateCode) {
	this.alternateCode = alternateCode;
    }

    /**
     * @return the parentCode
     */
    public String getParentCode() {
	return parentCode;
    }

    /**
     * @param parentCode the parentCode to set
     */
    public void setParentCode(String parentCode) {
	this.parentCode = parentCode;
    }

    /**
     * @return the firstName
     */
    public String getFirstName() {
	return firstName;
    }

    /**
     * @param firstName the firstName to set
     */
    public void setFirstName(String firstName) {
	this.firstName = firstName;
    }

    /**
     * @return the middleName
     */
    public String getMiddleName() {
	return middleName;
    }

    /**
     * @param middleName the middleName to set
     */
    public void setMiddleName(String middleName) {
	this.middleName = middleName;
    }

    /**
     * @return the lastName
     */
    public String getLastName() {
	return lastName;
    }

    /**
     * @param lastName the lastName to set
     */
    public void setLastName(String lastName) {
	this.lastName = lastName;
    }

    /**
     * @return the fullName
     */
    public String getFullName() {
	return fullName;
    }

    /**
     * @param fullName the fullName to set
     */
    public void setFullName(String fullName) {
	this.fullName = fullName;
    }

    /**
     * @return the orgnName
     */
    public String getOrgnName() {
	return orgnName;
    }

    /**
     * @param orgnName the orgnName to set
     */
    public void setOrgnName(String orgnName) {
	this.orgnName = orgnName;
    }

    /**
     * @return the city
     */
    public String getCity() {
	return city;
    }

    /**
     * @param city the city to set
     */
    public void setCity(String city) {
	this.city = city;
    }

    /**
     * @return the phnNbr
     */
    public String getPhnNbr() {
	return phnNbr;
    }

    /**
     * @param phnNbr the phnNbr to set
     */
    public void setPhnNbr(String phnNbr) {
	this.phnNbr = phnNbr;
    }

    /**
     * @return the email
     */
    public String getEmail() {
	return email;
    }

    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
	this.email = email;
    }

    /**
     * @return the persSt
     */
    public String getPersSt() {
	return persSt;
    }

    /**
     * @param persSt the persSt to set
     */
    public void setPersSt(String persSt) {
	this.persSt = persSt;
    }

    public String getLsePurpCode() {
	return lsePurpCode;
    }

    public void setLsePurpCode(String lsePurpCode) {
	this.lsePurpCode = lsePurpCode;
    }

    public String getLsePurpDesc() {
	return lsePurpDesc;
    }

    public void setLsePurpDesc(String lsePurpDesc) {
	this.lsePurpDesc = lsePurpDesc;
    }

    public void setDescWithCode(String descWithCode) {
	this.descWithCode = descWithCode;
    }

    /**
     * @return the codeId
     */
    public Long getCodeId() {
        return codeId;
    }

    /**
     * @param codeId the codeId to set
     */
    public void setCodeId(Long codeId) {
        this.codeId = codeId;
    }

	/**
	 * @return the tableName
	 */
	public String getTableName() {
		return tableName;
	}

	/**
	 * @param tableName the tableName to set
	 */
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	/**
	 * @param codeWithDescription the codeWithDescription to set
	 */
	public void setCodeWithDescription(String codeWithDescription) {
		this.codeWithDescription = codeWithDescription;
	}

	public Long getOrderbyNum() {
	    return orderbyNum;
	}

	public void setOrderbyNum(Long orderbyNum) {
	    this.orderbyNum = orderbyNum;
	}


}
