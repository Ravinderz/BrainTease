package com.uprr.ema.lms.searchproject.dao.api;

import java.util.List;
import java.util.Set;

import com.uprr.ema.lms.common.dto.DropDownInfo;
import com.uprr.ema.lms.searchproject.dto.LEWBReportDto;
import com.uprr.ema.lms.searchproject.dto.ProjectSearchCriteriaDTO;
import com.uprr.ema.lms.searchproject.dto.SearchDTO;

public interface ProjectSearchDao {
	public List<SearchDTO> getSearchResultThroughPagination(ProjectSearchCriteriaDTO projectSearchCriteriaDTO);
	public List<SearchDTO> getExcelReport(ProjectSearchCriteriaDTO projectSearchCriteriaDTO);
	public int getSearchResultRowCount(ProjectSearchCriteriaDTO projectSearchCriteriaDTO);
	public List<DropDownInfo> getProjectNames() ;
	public List<LEWBReportDto> geLEWBtExcelReport(String fromdate, String toDate);
	public List<LEWBReportDto> getReasonChnage(Integer projectId);
	public List<LEWBReportDto> getCostsData(Integer projectId);
	public List<LEWBReportDto> getBeginingOfYearData(Integer projectId, String year);
	public List<LEWBReportDto> getspentAmount(Set<String> networkNumberSet);
	public List<LEWBReportDto> getOmmCostsData(Integer projectId);
	public List<LEWBReportDto> getliabilityEstimateAmount(String liabiltyQueryString, Integer projectId);

	
}
