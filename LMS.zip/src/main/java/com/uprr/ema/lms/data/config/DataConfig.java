package com.uprr.ema.lms.data.config;

import org.apache.tomcat.jdbc.pool.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.support.TransactionTemplate;

@Configuration
@PropertySource(value={"classpath:environment/lms_${uprr.implementation.environment}.properties","classpath:common/common.properties"})
@Import({OracleDataConfig.class})
public class DataConfig {

	@Autowired
	DataSource oracleDataSource;

	@Bean
	public PlatformTransactionManager getTransactionManager(){
		return new DataSourceTransactionManager(oracleDataSource);
	}

	@Bean
	
	public TransactionTemplate getTransactionTemplateDefault(){
		TransactionTemplate transactionTemplate = new TransactionTemplate(getTransactionManager());
		transactionTemplate.setPropagationBehavior(Propagation.REQUIRED.value());
		return transactionTemplate;
	}
	
	//need to check this code whether below code works or not. 
	
	/*
	@Bean(name="txInterceptor")
	public TransactionInterceptor getTrasactionIntercptor(){
		
		Properties prop = new Properties();
		prop.put("*save", "PROPAGATION_REQUIRED,-Exception");
		prop.put("save*", "PROPAGATION_REQUIRED,-Exception");
		prop.put("*update", "PROPAGATION_REQUIRED,-Exception");
		prop.put("update*", "PROPAGATION_REQUIRED,-Exception");
		prop.put("*delete", "PROPAGATION_REQUIRED,-Exception");
		prop.put("delete*", "PROPAGATION_REQUIRED,-Exception");
		prop.put("remove*", "PROPAGATION_REQUIRED,-Exception");
		prop.put("*remove", "PROPAGATION_REQUIRED,-Exception");
		prop.put("*submit", "PROPAGATION_REQUIRED,-Exception");
		prop.put("submit*", "PROPAGATION_REQUIRED,-Exception");
		prop.put("*", "PROPAGATION_REQUIRED,readOnly");
		return new TransactionInterceptor(getTransactionManager(),prop);
	}
	
	
	@Bean(name="autoProxyBean")
	public BeanNameAutoProxyCreator getBeanNameAutoProxyCreator(){
		
		BeanNameAutoProxyCreator beanNameProxy = new BeanNameAutoProxyCreator();
		beanNameProxy.setBeanNames("*ServiceImpl");
		beanNameProxy.setInterceptorNames("txInterceptor");
		
		return beanNameProxy;
		
	} 
*/
}
