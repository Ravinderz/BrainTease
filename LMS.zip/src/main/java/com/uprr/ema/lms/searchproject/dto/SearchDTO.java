package com.uprr.ema.lms.searchproject.dto;

import java.io.Serializable;
import java.util.Date;

import com.uprr.ema.lms.common.dto.BaseDTO;

public class SearchDTO extends BaseDTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Integer projectId;
	private long projDtlID;
	private Integer tubeLevelId;
	private Integer projectStatId;
	private Integer projEstmId;
	private Integer projMgrId;
	
	private String projectActnCode;

	private Date createDateFrm;
	private Date createDateTo;
	private Date lastChangeDateFrm;
	private Date lastChangeDateTo;
	private Date projCloseDateFrm;
	private Date projCloseDateTo;
	
	private String projecName;
	private String tubLevelDesc;
	private String projEstDesc;
	private String projMgrDesc;
	private Date creationDate;
	private Date lastChngDate;
	
	
	
	
	/**
	 * @return the projEstDesc
	 */
	public String getProjEstDesc() {
		return projEstDesc;
	}
	/**
	 * @param projEstDesc the projEstDesc to set
	 */
	public void setProjEstDesc(String projEstDesc) {
		this.projEstDesc = projEstDesc;
	}
	/**
	 * @return the projMgrDesc
	 */
	public String getProjMgrDesc() {
		return projMgrDesc;
	}
	/**
	 * @param projMgrDesc the projMgrDesc to set
	 */
	public void setProjMgrDesc(String projMgrDesc) {
		this.projMgrDesc = projMgrDesc;
	}
	/**
	 * @return the projEstmId
	 */
	public Integer getProjEstmId() {
		return projEstmId;
	}
	/**
	 * @param projEstmId the projEstmId to set
	 */
	public void setProjEstmId(Integer projEstmId) {
		this.projEstmId = projEstmId;
	}
	/**
	 * @return the projMgrId
	 */
	public Integer getProjMgrId() {
		return projMgrId;
	}
	/**
	 * @param projMgrId the projMgrId to set
	 */
	public void setProjMgrId(Integer projMgrId) {
		this.projMgrId = projMgrId;
	}
	/**
	 * @return the projectId
	 */
	public Integer getProjectId() {
		return projectId;
	}
	/**
	 * @param projectId the projectId to set
	 */
	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}
	/**
	 * @return the tubeLevelId
	 */
	public Integer getTubeLevelId() {
		return tubeLevelId;
	}
	/**
	 * @param tubeLevelId the tubeLevelId to set
	 */
	public void setTubeLevelId(Integer tubeLevelId) {
		this.tubeLevelId = tubeLevelId;
	}
	/**
	 * @return the projectStatId
	 */
	public Integer getProjectStatId() {
		return projectStatId;
	}
	/**
	 * @param projectStatId the projectStatId to set
	 */
	public void setProjectStatId(Integer projectStatId) {
		this.projectStatId = projectStatId;
	}
	/**
	 * @return the createDateFrm
	 */
	public Date getCreateDateFrm() {
		return createDateFrm;
	}
	/**
	 * @param createDateFrm the createDateFrm to set
	 */
	public void setCreateDateFrm(Date createDateFrm) {
		this.createDateFrm = createDateFrm;
	}
	/**
	 * @return the createDateTo
	 */
	public Date getCreateDateTo() {
		return createDateTo;
	}
	/**
	 * @param createDateTo the createDateTo to set
	 */
	public void setCreateDateTo(Date createDateTo) {
		this.createDateTo = createDateTo;
	}
	/**
	 * @return the lastChangeDateFrm
	 */
	public Date getLastChangeDateFrm() {
		return lastChangeDateFrm;
	}
	/**
	 * @param lastChangeDateFrm the lastChangeDateFrm to set
	 */
	public void setLastChangeDateFrm(Date lastChangeDateFrm) {
		this.lastChangeDateFrm = lastChangeDateFrm;
	}
	/**
	 * @return the lastChangeDateTo
	 */
	public Date getLastChangeDateTo() {
		return lastChangeDateTo;
	}
	/**
	 * @param lastChangeDateTo the lastChangeDateTo to set
	 */
	public void setLastChangeDateTo(Date lastChangeDateTo) {
		this.lastChangeDateTo = lastChangeDateTo;
	}
	/**
	 * @return the projCloseDateFrm
	 */
	public Date getProjCloseDateFrm() {
		return projCloseDateFrm;
	}
	/**
	 * @param projCloseDateFrm the projCloseDateFrm to set
	 */
	public void setProjCloseDateFrm(Date projCloseDateFrm) {
		this.projCloseDateFrm = projCloseDateFrm;
	}
	/**
	 * @return the projCloseDateTo
	 */
	public Date getProjCloseDateTo() {
		return projCloseDateTo;
	}
	/**
	 * @param projCloseDateTo the projCloseDateTo to set
	 */
	public void setProjCloseDateTo(Date projCloseDateTo) {
		this.projCloseDateTo = projCloseDateTo;
	}
	/**
	 * @return the projecName
	 */
	public String getProjecName() {
		return projecName;
	}
	/**
	 * @param projecName the projecName to set
	 */
	public void setProjecName(String projecName) {
		this.projecName = projecName;
	}
	/**
	 * @return the tubLevelDesc
	 */
	public String getTubLevelDesc() {
		return tubLevelDesc;
	}
	/**
	 * @param tubLevelDesc the tubLevelDesc to set
	 */
	public void setTubLevelDesc(String tubLevelDesc) {
		this.tubLevelDesc = tubLevelDesc;
	}
	/**
	 * @return the creationDate
	 */
	public Date getCreationDate() {
		return creationDate;
	}
	/**
	 * @param creationDate the creationDate to set
	 */
	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}
	/**
	 * @return the lastChngDate
	 */
	public Date getLastChngDate() {
		return lastChngDate;
	}
	/**
	 * @param lastChngDate the lastChngDate to set
	 */
	public void setLastChngDate(Date lastChngDate) {
		this.lastChngDate = lastChngDate;
	}
	/**
	 * @return the projectActnCode
	 */
	public String getProjectActnCode() {
		return projectActnCode;
	}
	/**
	 * @param projectActnCode the projectActnCode to set
	 */
	public void setProjectActnCode(String projectActnCode) {
		this.projectActnCode = projectActnCode;
	}
	/**
	 * @return the projDtlID
	 */
	public long getProjDtlID() {
	    return projDtlID;
	}
	/**
	 * @param projDtlID the projDtlID to set
	 */
	public void setProjDtlID(long projDtlID) {
	    this.projDtlID = projDtlID;
	}
	
}
