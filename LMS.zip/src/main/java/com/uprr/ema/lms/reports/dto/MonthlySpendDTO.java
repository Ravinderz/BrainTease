package com.uprr.ema.lms.reports.dto;

import java.util.Objects;

public class MonthlySpendDTO {

	private String projName;
	private String network;
	private String fiscper;
	private String activity;
	private String job;
	private String accountInfo;
	private String docType;
	private String type;
	private String identifier;
	private String desc;
	private String invoiceNumber;
	private String amount;
	
	
	public String getProjName() {
		return projName;
	}
	public void setProjName(String projName) {
		this.projName = projName;
	}
	public String getNetwork() {
		return network;
	}
	public void setNetwork(String network) {
		this.network = network;
	}
	public String getFiscper() {
		return fiscper;
	}
	public void setFiscper(String fiscper) {
		this.fiscper = fiscper;
	}
	public String getActivity() {
		return activity;
	}
	public void setActivity(String activity) {
		this.activity = activity;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public String getAccountInfo() {
		return accountInfo;
	}
	public void setAccountInfo(String accountInfo) {
		this.accountInfo = accountInfo;
	}
	public String getDocType() {
		return docType;
	}
	public void setDocType(String docType) {
		this.docType = docType;
	}
	public String getIdentifier() {
		return identifier;
	}
	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public String getInvoiceNumber() {
		return invoiceNumber;
	}
	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	public MonthlySpendDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public MonthlySpendDTO(String projName, String network, String fiscper, String activity, String job,
			String accountInfo, String docType, String type, String identifier, String desc, String invoiceNumber,
			String amount) {
		super();
		this.projName = projName;
		this.network = network;
		this.fiscper = fiscper;
		this.activity = activity;
		this.job = job;
		this.accountInfo = accountInfo;
		this.docType = docType;
		this.type = type;
		this.identifier = identifier;
		this.desc = desc;
		this.invoiceNumber = invoiceNumber;
		this.amount = amount;
	}
	
	
	@Override
	public String toString() {
		return "MonthlySpendDTO [projName=" + projName + ", network=" + network + ", fiscper=" + fiscper + ", activity="
				+ activity + ", job=" + job + ", accountInfo=" + accountInfo + ", docType=" + docType + ", type=" + type
				+ ", identifier=" + identifier + ", desc=" + desc + ", invoiceNumber=" + invoiceNumber + ", amount="
				+ amount + "]";
	}
	@Override
	public int hashCode() {
		return Objects.hash(network);
	}
	
	
	@Override
	public boolean equals(Object obj) {
		if (obj == this) return true;
        if (!(obj instanceof SiteSourceDTO)) {
            return false;
        }
        MonthlySpendDTO dto = (MonthlySpendDTO) obj;
        return Objects.equals(network, dto.network);
	}
	
	
}
