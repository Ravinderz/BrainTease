package com.uprr.ema.lms.common.util;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.net.URL;
import java.net.URLConnection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.stream.FactoryConfigurationError;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.core.env.Environment;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class CommonUtils {

	private static final String APPLICATION_VND_MS_EXCEL = "application/vnd.ms-excel";
	private static final String CONTENT_DISPOSITION = "Content-disposition";
	
	private static MessageSource messageSource;
	private static ApplicationContext applicationContext;
	private static final Logger LOGGER = LoggerFactory.getLogger(CommonUtils.class);
	static Integer LENTH_OF_AIM_KEY = 27;
	static String PRE_FIX_VALUE_FOR_AIM_KEY = "RDT";
	private CommonUtils() {
		//Auto-generated constructor stub
	}

	@Autowired
	public CommonUtils(ApplicationContext applicationContext, MessageSource messageSource) {

		CommonUtils.applicationContext = applicationContext;
		CommonUtils.messageSource = messageSource;
	}
	protected CommonUtils getInstance(){
		return new CommonUtils();
	}

	/**
	 * @param requestData
	 * @param classType
	 * @return
	 * @throws JAXBException
	 * @throws ParserConfigurationException
	 */
	public static String marshal(Object requestData, Class<?> classType) throws JAXBException {
		String retu = null;
		JAXBContext context = JAXBContext.newInstance(classType);
		Marshaller marshaller = context.createMarshaller();
		marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		marshaller.setProperty(Marshaller.JAXB_FRAGMENT, true);
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		dbf.setNamespaceAware(true);
		Document doc = null;
		try {
			doc = dbf.newDocumentBuilder().newDocument();
		} catch (ParserConfigurationException e) {
			LOGGER.error("Exception while marshalling request data ", e);
		}
		StringWriter writer = new StringWriter();
		if (doc != null) {
			marshaller.marshal(requestData, writer);
			retu = writer.toString();
		}
		return retu;
	}

	/**
	 * @param replyData
	 * @param classType
	 * @return
	 * @throws JAXBException
	 */
	public static Object unmarshal(String replyData, Class<?> classType) throws JAXBException {
		JAXBContext context = JAXBContext.newInstance(classType);
		Unmarshaller unmarshal = context.createUnmarshaller();
		InputSource inputStream = new InputSource();
		inputStream.setCharacterStream(new StringReader(replyData));
		return unmarshal.unmarshal(inputStream);
	}

	public static <T> T unmarshal(final String payload, final String packageName, String schemaPath, Class<T> classType) throws JAXBException, SAXException, IOException, FactoryConfigurationError, XMLStreamException {
		JAXBContext jaxbContext = JAXBContext.newInstance(packageName);
		Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
		javax.xml.stream.XMLStreamReader xmlStreamReader = null;
		SchemaFactory schemaFactory = SchemaFactory.newInstance("http://www.w3.org/2001/XMLSchema"); 
		Schema schema = schemaFactory.newSchema(new File(Thread.currentThread().getContextClassLoader().getResource(schemaPath).getPath())); 
		unmarshaller.setSchema(schema);

		StringReader messageReader = new StringReader(payload);
		javax.xml.validation.Validator validator = schema.newValidator(); 
		Source source = new StreamSource(messageReader); 
		validator.validate(source); 


		XMLInputFactory xmlInputFactory = XMLInputFactory.newInstance();
		xmlInputFactory.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES, false); 
		xmlInputFactory.setProperty(XMLInputFactory.SUPPORT_DTD, false);
		xmlStreamReader = xmlInputFactory.createXMLStreamReader(new StringReader(payload));

		JAXBElement<T> jaxbElement = unmarshaller.unmarshal( xmlStreamReader,classType);
		return jaxbElement.getValue();
	}
	
	/**
	 * To get formated employee Id.
	 * 
	 * @param employeeId
	 * @return
	 */
	public static String getValidEmployeeID(String employeeId) {
		StringBuilder emplId = new StringBuilder("");
		if (employeeId != null && employeeId.trim().length() > 0) {
			emplId = new StringBuilder(employeeId);
			if (emplId.toString().indexOf(",") != -1) {
				emplId = new StringBuilder(emplId.toString().substring(0, emplId.toString().indexOf(",")));
			}
			if (String.valueOf(emplId).length() > 7) {
				emplId = new StringBuilder(emplId.substring(emplId.length() - 7));
			}
		}
		return emplId.toString();
	}

	/**
	 * To get Employee Id as per UPRR standard.
	 * 
	 * @param employeeId
	 * @param size
	 * @return
	 */
	public static String getEmployeeIdAsPerUPRRStandard(String employeeId, int size, String insertChar) {
		StringBuilder empIdStr = new StringBuilder();
		if (employeeId != null && employeeId.trim().length() > 0) {
			empIdStr.append(employeeId.trim());
			int empIdLength = empIdStr.toString().length();
			if (empIdLength > size) {
				empIdStr = new StringBuilder(empIdStr.substring(empIdLength - 7));
			} else if (empIdLength < size) {
				for (int i = 0; i < (size - empIdLength); i++) {
					empIdStr.insert(i, insertChar);
				}
			}
		}
		return empIdStr.length() > 0 ? empIdStr.toString() : "";
	}

	public static String XMLtoString(String resourcePath) throws IOException {
		File xmlFile = new File(resourcePath);
		Reader fileReader = null;
		BufferedReader buffferedReader = null;
		StringBuilder stringBuilder = null;
		try {
			fileReader = new FileReader(xmlFile);
			buffferedReader = new BufferedReader(fileReader);

			stringBuilder = new StringBuilder();
			String line = buffferedReader.readLine();
			while (line != null) {
				stringBuilder.append(line).append("\n");
				line = buffferedReader.readLine();
			}
		} finally {
			if (buffferedReader != null) {
				buffferedReader.close();
			}
			if (fileReader != null) {
				fileReader.close();
			}
		}
		return stringBuilder.toString();
	}

	public static boolean isEmpty(String str) {
		boolean ret = false;
		if (str == null || str.trim().length() == 0) {
			ret = true;
		}
		return ret;
	}

	public static boolean isNotEmpty(String str) {
		return !isEmpty(str);
	}

	public static boolean isNotNull(Object obj) {
		return obj != null;
	}

	public static boolean isNull(Object obj) {
		return obj == null;
	}

	
	/**
	 * Returns a comma separated string from the passed list.
	 *
	 * @param strList
	 *            the str list
	 * @return the comma separed str val
	 */
	public static String getCommaSeparedStrVal(List<String> strList) {
		StringBuilder strBuilder = new StringBuilder(1024); // IEpicConstants.STRING_BUILDER_SIZE);TODO
		if (strList != null) {
			for (int m = 0; m < strList.size(); m++) {
				String key = strList.get(m);
				if (m != 0) {
					strBuilder.append(",");
				}
				strBuilder.append(key);
			}
		}
		return strBuilder.toString();
	}

	/**
	 * Gets a message from messages.properties
	 * 
	 * @param messageKey
	 *            the key of the message
	 * @param args
	 *            any arguments
	 */
	public static String getMessage(String messageKey, Object... args) {
		return messageSource.getMessage(messageKey, args, LocaleContextHolder.getLocale());
	}

	/**
	 * Gets the reference to an application-context bean by Type
	 * 
	 * @param clazz the type of the bean
	 */
	public static <T> T getBean(Class<T> clazz) {
		return applicationContext.getBean(clazz);
	}
	
	/**
	 * Gets the reference to an application-context bean by Name
	 * 
	 * @param name
	 */
	public static Object getBean(String name) {
		return applicationContext.getBean(name);
	}

	/**
	 * 
	 * 
	 * @param value
	 * @return
	 */
	public static String getFullName(String lastName, String firstName, String midilInit) {
		String[] nameArray = { lastName, firstName, midilInit };
		StringBuilder finalName = new StringBuilder();
		for (int i = 0; i < nameArray.length; i++) {
			String val = nameArray[i] == null ? "" : nameArray[i].toUpperCase();
			finalName.append(val);
			if (i == 0 && !"".equals(val)) {
				finalName.append(", ");
			}
			if (i == 1 && !val.equals("")) {
				finalName.append(" ");
			}
		}
		return finalName.toString().toUpperCase();
	}

	

	

	
	

	public static byte[] getByteArrayOfTheGivenFilePath(String fileRelativePath) {
		ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
		try {
			URL url = new URL("http://xdev.home.www.uprr.com" + fileRelativePath);
			URLConnection connection = url.openConnection();
			InputStream inputStream = connection.getInputStream();
			int nextByte;
			while ((nextByte = inputStream.read()) != -1) {
				byteArrayOutputStream.write(nextByte);
			}
			inputStream.close();
			byteArrayOutputStream.close();
		} catch (Exception e) {
			LOGGER.error("Exception inside getByteArrayForTheGivenDocument:- ", e);
		}
		return byteArrayOutputStream.toByteArray();
	}

	

	

	public static String getStringAsCommaSeperated(List<String> list) {
		StringBuilder valueBuilder = new StringBuilder();
		for (String string : list) {
			if (StringUtils.isNotEmpty(string)) {
				valueBuilder.append("'").append(string).append("', ");
			}
		}
		String commaSeperatedString = valueBuilder.toString();
		if (commaSeperatedString.endsWith(", ")) {
			commaSeperatedString = commaSeperatedString.substring(0, commaSeperatedString.length() - 2);
		}
		return commaSeperatedString;
	}

	public static boolean isNotEmpty(Map<String, String> map) {
		return !(map ==null || map.isEmpty());
	}

	public static Environment getEnvironment() {
		return CommonUtils.getBean(Environment.class);
	}
	
	
	
	
	
	/**
	 * To get the page numbers for PAGINATION purpose
	 * 
	 * @param page
	 * @param totalNoOfRecords
	 * @param pageSize
	 * @return
	 */
	public static List<Integer> getPages(Integer page, Integer totalNoOfRecords, Integer pageSize) {
		List<Integer> pages = new ArrayList<Integer>();
		int lastPage = totalNoOfRecords / pageSize;
		if (totalNoOfRecords % pageSize > 0) {
			lastPage += 1;
		}
		if (page < 3) {
			if(page==1){
				for (int i = 1; i <= lastPage && i <= page + 4; i++) {
					pages.add(i);
				}
			}
			else{
				for (int i = 1; i <= lastPage && i <= page + 3; i++) {
					pages.add(i);
				}
			}

		} else if (page == lastPage) {
			int temp = page - 4;
			if (temp < 1) {
				temp = 1;
			}
			for (int i = temp; i <= lastPage && i <= page + 4; i++) {
				pages.add(i);
			}
		} else if (page == lastPage - 1) {
			for (int i = page - 3; i <= lastPage && i <= page + 4; i++) {
				if(i!=0){
					pages.add(i);
				}
			}
		} else {
			for (int i = page - 2; i <= lastPage && i <= page + 2; i++) {
				pages.add(i);
			}
		}
		return pages;
	}

	public static <T> T getValue(ResultSet resultSet, String columnName, Class<T> classType) throws SQLException {
		T instance = null;
		if (isColumnExists(resultSet, columnName) && null != resultSet.getObject(columnName)) {
			instance = classType.cast(resultSet.getObject(columnName));
		}
		return instance;
	}

	public static boolean isColumnExists(ResultSet rs, String columnName) {

		boolean columnExistsFlag = true;
		try {
			rs.findColumn(columnName);
		} catch (Exception exception) {
			columnExistsFlag = false;
		}
		return columnExistsFlag;
	}
	
	public static String getLocation(String... value) {
		StringBuilder location = new StringBuilder();
		for (int i = 0; i < value.length; i++) {
			String val = value[i] == null ? "" : value[i];
			location.append(val);
			if (i == 0 && !val.equals("") && value[1] != null) {
				location.append(", ");
			}
		}
		return location.toString().toUpperCase();
	}
	

	/**
	 * Gets exception details as String
	 * @param throwable
	 * @return
	 */
	public static String getStackTrace(final Throwable throwable) {
		final StringWriter sw = new StringWriter();
		final PrintWriter pw = new PrintWriter(sw, true);
		throwable.printStackTrace(pw);
		return sw.getBuffer().toString();
	}
	
	/**
	 * Concatenate the failure reason of text
	 * @param failureResn
	 */
	public static String concatenateCltnCrtnFailsResn(final String failureResn) {
		String text = "";
		if (StringUtils.isNotEmpty(failureResn)) {
			int count = 0;
			String[] failureResnArray = failureResn.split(",");
			count = failureResnArray == null ? 0 : failureResnArray.length;
			if (count == 1) {
				text = " is invalid/missing.";
			} else if (count > 1) {
				text = " are invalid/missing.";
			}
		}
		return failureResn + text;
	}
	
	/**
	 * Gets list of values from stirng.
	 * @param values
	 * @return
	 */
	public static List<String> getListFromCommaSeperated(String values) {
		List<String> listofValues = new ArrayList<String>();
		if (StringUtils.isNotEmpty(values)) {
			listofValues = Arrays.asList(values.split(","));
		}
		return listofValues;
	}

	public static String notNullString(String string) {
		String notNullString =string;
		if(StringUtils.isEmpty(notNullString)){
			notNullString = "";
		}
		return notNullString; 
	}
	public static String prepareStringtoReqSize(String inputStr, int maxLength, String inputType) {
		StringBuilder formatedStringBuilderObj = new StringBuilder();
		String nullCheckedString = checkStringForNull(inputStr);
		nullCheckedString = nullCheckedString.toUpperCase(); // Convert to Upper
		// Case
		int inputStringSize = nullCheckedString.length();
		if (inputStringSize <= maxLength) {
			formatedStringBuilderObj.append(nullCheckedString);
			for (int count = inputStringSize; count < maxLength; count++) {
				formatedStringBuilderObj.insert(0, inputType);
			}
		} else {
			formatedStringBuilderObj.append(nullCheckedString.substring(inputStringSize - maxLength));
		}
		return formatedStringBuilderObj.toString();
	}
	public static String checkStringForNull(String passedStr) {
		String returnStrVal = "";
		if (passedStr != null) {
			returnStrVal = passedStr.trim();
		}
		return returnStrVal;
	}
	

	public static <T> boolean isNotEmpty(Collection<T> collection) {
		return collection != null && !collection.isEmpty();
	}

	public static <T> boolean isEmpty(Collection<T> collection) {
		return collection == null || collection.isEmpty();
	}
	
	
	

}
