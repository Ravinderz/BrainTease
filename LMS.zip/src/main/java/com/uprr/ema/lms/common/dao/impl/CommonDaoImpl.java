package com.uprr.ema.lms.common.dao.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Repository;

import com.uprr.ema.lms.common.dao.api.CommonDao;

@Repository
public class CommonDaoImpl extends OracleDaoImpl implements CommonDao  {

	@Autowired
	public Environment environment;


}
