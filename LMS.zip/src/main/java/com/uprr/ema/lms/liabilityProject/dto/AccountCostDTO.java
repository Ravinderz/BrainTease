package com.uprr.ema.lms.liabilityProject.dto;

import java.io.Serializable;
import java.util.Date;

public class AccountCostDTO implements Serializable{

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    private long projID;    
    private String projectName;
    private Date projectDate;
    private String projOthDesc;
    private long accountTypeMstrId; 
    private String accountDesc;
    private String actionType;
    private String accountNbrData;
    private String network;
    private Double amount;
    private String crtdUser;
    private String lastUptdUser;
    private Date crtdDate;
    private Date lastUptdDate;

    public long getProjID() {
	return projID;
    }
    public void setProjID(long projID) {
	this.projID = projID;
    }
    public String getProjectName() {
	return projectName;
    }
    public void setProjectName(String projectName) {
	this.projectName = projectName;
    }
    public String getProjOthDesc() {
	return projOthDesc;
    }
    public void setProjOthDesc(String projOthDesc) {
	this.projOthDesc = projOthDesc;
    }
    public String getAccountDesc() {
	return accountDesc;
    }
    public void setAccountDesc(String accountDesc) {
	this.accountDesc = accountDesc;
    }
    public String getActionType() {
	return actionType;
    }
    public void setActionType(String actionType) {
	this.actionType = actionType;
    }
    public String getAccountNbrData() {
	return accountNbrData;
    }
    public void setAccountNbrData(String accountNbrData) {
	this.accountNbrData = accountNbrData;
    }


    public String getNetwork() {
	return network;
    }
    public void setNetwork(String network) {
	this.network = network;
    }

    public Double getAmount() {
	return amount;
    }
    public void setAmount(Double amount) {
	this.amount = amount;
    }
           
    public Date getProjectDate() {
        return projectDate;
    }
    public void setProjectDate(Date projectDate) {
        this.projectDate = projectDate;
    }
    public String getCrtdUser() {
        return crtdUser;
    }
    public void setCrtdUser(String crtdUser) {
        this.crtdUser = crtdUser;
    }
    public String getLastUptdUser() {
        return lastUptdUser;
    }
    public void setLastUptdUser(String lastUptdUser) {
        this.lastUptdUser = lastUptdUser;
    }
    public Date getCrtdDate() {
        return crtdDate;
    }
    public void setCrtdDate(Date crtdDate) {
        this.crtdDate = crtdDate;
    }
    public Date getLastUptdDate() {
        return lastUptdDate;
    }
    public void setLastUptdDate(Date lastUptdDate) {
        this.lastUptdDate = lastUptdDate;
    }
        
    
    public long getAccountTypeMstrId() {
        return accountTypeMstrId;
    }
    public void setAccountTypeMstrId(long accountTypeMstrId) {
        this.accountTypeMstrId = accountTypeMstrId;
    }
    @Override
    public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((accountNbrData == null) ? 0 : accountNbrData.hashCode());
	return result;
    }
    @Override
    public boolean equals(Object obj) {
	if (this == obj)
	    return true;
	if (obj == null)
	    return false;
	if (getClass() != obj.getClass())
	    return false;
	AccountCostDTO other = (AccountCostDTO) obj;

	if(other.accountNbrData!=null && 
		this.accountNbrData!=null && 
		this.accountNbrData.equalsIgnoreCase(other.accountNbrData)){
	    return true;
	}

	return false;
    }


}
