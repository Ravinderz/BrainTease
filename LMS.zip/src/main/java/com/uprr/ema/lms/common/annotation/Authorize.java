package com.uprr.ema.lms.common.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

/**
 * 
 * @author Anil Manchala
 *
 */
@Retention(value=java.lang.annotation.RetentionPolicy.RUNTIME)
@Target(value={java.lang.annotation.ElementType.TYPE,java.lang.annotation.ElementType.METHOD})
@Documented
@Inherited
public @interface Authorize {
	public abstract String[] roles() default "";
}
