package com.uprr.ema.lms.common.enums;

public class DocsServiceNames {

	private enum serviceNameEnum {
		ECHOSERVICE ("/echo"),
		UPLOADSERVICE ("/utility/managed-content/upload-document/1.0"),
		DOWNLAODSERVICE ("/utility/managed-content/download-document/1.0");
		private final String serviceName;
		serviceNameEnum(String serviceName) { this.serviceName = serviceName; }
	};

	public static String getEchoServiceName() {
		return serviceNameEnum.ECHOSERVICE.serviceName;
	}

	public static String getUploadServiceName() {
		return serviceNameEnum.UPLOADSERVICE.serviceName;
	}

	public static String getDownloadServiceName() {
		return serviceNameEnum.DOWNLAODSERVICE.serviceName;
	}

	public static String getOwnerName() {
		return "dema001";
	}

	public static String getAppName() {
		return "EnvironmentalManagementHazmat";
	}

	public static String getEnvironment() {
		return System.getProperty("uprr.implementation.environment");
	}
}
