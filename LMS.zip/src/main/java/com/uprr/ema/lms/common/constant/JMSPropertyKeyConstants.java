package com.uprr.ema.lms.common.constant;

public interface JMSPropertyKeyConstants {

	String JMS_KEYSTORE_LOCATION = "JMS_KEYSTORE_LOCATION";
	String JMS_KEYSTORE_PASS_KEY = "JMS_KEYSTORE_PASSWORD";
	String JMS_CERTIFICATE_ALIAS = "JMS_CERTIFICATE_ALIAS";
	String JMS_PRIVATEKEY_PASS_KEY = "JMS_PRIVATEKEY_PASSWORD";
	String JMS_PERSONDETAILS_SERVICE_NAME = "JMS_PERSONDETAILS_SERVICE_NAME";

	String JAVA_NAMING_SECURITY_PRINCIPAL = "java.naming.security.principal";
	String JAVA_NAMING_PROVIDER_URL = "java.naming.provider.url";
	String JAVA_NAMING_FACTORY_INITIAL = "java.naming.factory.initial";
	String JAVA_NAMING_SECURITY_CREDENTIALS = "java.naming.security.credentials";
	String JAVA_NAMING_REFERRAL = "java.naming.referral";

	String XMF_CLIENT_ID = "XMF_CLIENT_ID";

	String XMF_CF_00 = "XMF_FACTORY";
	

	String LMS_QUEUE = "XMF_REQUEST_QUEUE";
	String ENA_QCF_00="ENA-QCF-00";

}
