package com.uprr.ema.lms.common.dao.util;

import org.apache.commons.lang3.StringEscapeUtils;


public class LmsFortificationUtil {

   /* private final static Codec ORACLE_CODEC = new OracleCodec();

    public static String immuneOracleSQL(String inputQuery){
	String outputQuery;
	outputQuery =  StringEscapeUtils.unescapeJava(ESAPI.encoder().encodeForSQL(ORACLE_CODEC,inputQuery));
	return outputQuery;
    }*/

}
