package com.uprr.ema.lms.reports.dao.impl;

import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Repository;

import com.uprr.ema.lms.common.dao.impl.TeraDataDaoImpl;
import com.uprr.ema.lms.common.util.WebDateUtils;
import com.uprr.ema.lms.liabilityProject.dto.AccountCostDTO;
import com.uprr.ema.lms.reports.dao.api.ReportsDao;
import com.uprr.ema.lms.reports.dto.BusinessPrepPlanDTO;
import com.uprr.ema.lms.reports.dto.LCRRprtChartDTO;
import com.uprr.ema.lms.reports.dto.LCRRprtDTO;
import com.uprr.ema.lms.reports.dto.MonthlySpendDTO;
import com.uprr.ema.lms.reports.dto.SiteSourceDTO;
import com.uprr.ema.lms.reports.helper.SiteSourceReportMapper;

@Repository
@PropertySource(value={"classpath:reports/reports_sql.properties"})
public class ReportsDaoImpl extends TeraDataDaoImpl implements ReportsDao {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ReportsDaoImpl.class);
	
	@Autowired
	public Environment environment;
	
	@Override
	public List<BusinessPrepPlanDTO> getBusinessPrepPlanData(String startRange,String endRange) {
		LOGGER.info("insdie get business dao");
		StringBuilder query = new StringBuilder(environment.getProperty("GET_BPPD_DETAILS_FROM_TERADATA"));
		List<BusinessPrepPlanDTO> list = this.getNamedParamResultsList(query.toString(), new Object[] {startRange,endRange},BusinessPrepPlanDTO.class);
		LOGGER.info("size of list :: "+list.size());
		return list;
	}
	
	
	public List<AccountCostDTO> getAccountData(String startRange,String endRange,String netwrokNumbers) {
	    //String sql_query = "SELECT FIN476.WBSWO AS accountNbrData ,SUM(FIN476.DEB_CRE_LC) AS amount FROM FINDVP00.FINUV476 FIN476 LEFT JOIN FINDVP00.FINUV314 FIN314 ON FIN476.WBS_ELEMT = FIN314.WBS_ELEMT WHERE FIN476.FISCPER >=? and FIN476.FISCPER <=? AND ((FIN314.ACCT='274074') Or (FIN314.ACCT='274084')) AND  FIN476.WBSWO IN (?) GROUP BY 1  having Sum(FIN476.DEB_CRE_LC)  < 0";
	    String sql_query = "SELECT FIN476.WBSWO AS accountNbrData ,SUM(FIN476.DEB_CRE_LC) AS amount FROM FINDVP00.FINUV476 FIN476 LEFT JOIN FINDVP00.FINUV314 FIN314 ON FIN476.WBS_ELEMT = FIN314.WBS_ELEMT WHERE FIN476.FISCPER >=? and FIN476.FISCPER <=? AND ((FIN314.ACCT='274074') Or (FIN314.ACCT='274084')) AND  FIN476.WBSWO IN (?) GROUP BY 1 ";
	    LOGGER.info("inside getAccountData dao");
	    List<AccountCostDTO> list = this.getNamedParamResultsList(sql_query, new Object[] {startRange,endRange,netwrokNumbers},AccountCostDTO.class);
	    LOGGER.info("size of list :: "+list.size());
	    return list;
	}

	@Override
	public List<SiteSourceDTO> getPerYearSpendingData(Set<String> networkNumberSet,String endRange) {
		
		StringBuilder query = new StringBuilder(environment.getProperty("GET_SITE_SOURCE_SPENDING_DATA_SELECT_QUERY_FROM_TERADATA"));
		int year = Integer.parseInt(endRange.substring(0,4));
		int startYear = 2016;
		if(startYear <= year){
			for(;startYear <= year; startYear++){
				query.append(",sum(case when CAST(FIN476.FISCPER AS VARCHAR(4)) = '"+startYear+"' then FIN476.DEB_CRE_LC else 0 end) spendYear"+startYear+" ");
			}
		}
		query.append(environment.getProperty("GET_SITE_SOURCE_SPENDING_DATA_WHERE_CLAUSE_FROM_TERADATA"));
		
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("networkIds", networkNumberSet);
		parameters.addValue("endRange", endRange);
		List<SiteSourceDTO> spendingList = this.getNamedParamResultsListByRowMapper(query.toString(), parameters,new SiteSourceReportMapper<SiteSourceDTO>(year));
		return spendingList;
	}

	@Override
	public List<BusinessPrepPlanDTO> getspentAmount(String queryString) {
		LOGGER.info("insdie get business dao");
		StringBuilder query = new StringBuilder(environment.getProperty("GET_SPENT_DETAILS_FROM_TERADATA"));
		String queryStr=query.toString();
		queryStr+=queryString+" "+"AND ((FIN314.ACCT = '274074') Or (FIN314.ACCT = '274084')) GROUP BY 1, 2 ORDER BY 2, 1";
		MapSqlParameterSource params=new MapSqlParameterSource();
		params.addValue("year", queryString);
		List<BusinessPrepPlanDTO> list = this.getNamedParamResultsList(queryStr,  params,BusinessPrepPlanDTO.class);
		LOGGER.info("size of list :: "+list.size());
		return list;
	}


	@Override
	public List<MonthlySpendDTO> getMonthlySpendDataFromTeradata(Set<String> networkNumberSet,String startRange, String endRange) {
		StringBuilder query = new StringBuilder(environment.getProperty("GET_MONTHLY_SPEND_DETAILS_FROM_TERADATA"));
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("networkIds", networkNumberSet);
		parameters.addValue("endDate", endRange);
		parameters.addValue("startDate", startRange);
		List<MonthlySpendDTO> list = this.getNamedParamResultsList(query.toString(),parameters,MonthlySpendDTO.class);
		return list;
	}
	
	@Override
	public List<LCRRprtChartDTO> getActualExpenditureData(String month,String year){
		String selectedYYYYMMM = WebDateUtils.getMonthYearInYYYYMMMFormat(month, year);
		String firstMonth = year+"001";
		StringBuilder query = new StringBuilder(environment.getProperty("GET_ACTUALEXPENDITRE_DATA_FROM_TERADATA"));
		
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("firstMonth", firstMonth);
		parameters.addValue("selectedMonth", selectedYYYYMMM);
		List<LCRRprtChartDTO> spendingList = this.getNamedParamResultsList(query.toString(), parameters,LCRRprtChartDTO.class);
		return spendingList;
	}
	
	
	
	/*@Autowired
	public Environment environment;
	
	@Override
	public List<SearchDTO> getSearchResultThroughPagination(ProjectSearchCriteriaDTO projectSearchCriteriaDTO){
		//getNamedParameterJdbcTemplate().query("", "", "");
		
		StringBuilder builder = new StringBuilder(environment.getProperty("SEARCH_OUTER_QRY_PREFIX"));
		builder.append(environment.getProperty("PROJECT_SEARCH_QUERY"));
		MapSqlParameterSource params=createCriterias(projectSearchCriteriaDTO, builder);
		builder.append(" order by "+projectSearchCriteriaDTO.getOrderByColumn()+" "+projectSearchCriteriaDTO.getSortingType());
		builder.append(environment.getProperty("SEARCH_OUTER_QRY_SUFFIX"));
		return this.getNamedParamResultsList(builder.toString(), params, SearchDTO.class);
	}

	@Override
	public int getSearchResultRowCount(ProjectSearchCriteriaDTO projectSearchCriteriaDTO) {
		StringBuilder builder = new StringBuilder(environment.getProperty("PROJECT_SEARCH_COUNT_QUERY"));
		final MapSqlParameterSource params =createCriterias(projectSearchCriteriaDTO,builder);
		return getCount(builder.toString(), params);
	}
	
	private final MapSqlParameterSource createCriterias(ProjectSearchCriteriaDTO projectSearchCriteriaDTO,StringBuilder builder){
		final MapSqlParameterSource params = new MapSqlParameterSource();
		params.addValue("startRow", projectSearchCriteriaDTO.getStartIndex());
		params.addValue("endRow", projectSearchCriteriaDTO.getEndIndex());
		if(projectSearchCriteriaDTO.getProjectSearchCriteria()!=null){
			final SearchDTO dto = projectSearchCriteriaDTO.getProjectSearchCriteria();
			if(dto.getProjectId() !=null && dto.getProjectId()>0){
				builder.append(" and prj.proj_dtl_id = :projectId");
				params.addValue("projectId", dto.getProjectId());
			}else if(dto.getProjecName()!=null && !"".equalsIgnoreCase(dto.getProjecName().trim())){
			    builder.append(" and UPPER(prj.PROJ_NAME) LIKE :projecName");
			    params.addValue("projecName", "%"+dto.getProjecName().toUpperCase()+"%");
			}
			
			if(StringUtils.isNoneBlank(dto.getProjectActnCode())){
				builder.append(" and actn.ACTN_CODE=:projectActnCode");
				params.addValue("projectActnCode", dto.getProjectActnCode());
			}
			
			if(dto.getTubeLevelId() !=null && dto.getTubeLevelId()>0){
				builder.append(" and tub.tube_levl_id=:tubeLevelId");
				params.addValue("tubeLevelId", dto.getTubeLevelId());
			}
			
			if(dto.getProjEstmId() !=null && dto.getProjEstmId()>0){
				builder.append(" and est.PROJ_ESTM_ID=:projEstmId");
				params.addValue("projEstmId", dto.getProjEstmId());
			}
			
			if(dto.getProjMgrId() !=null && dto.getProjMgrId()>0){
				builder.append(" and mgr.PROJ_MGR_ID=:projMgrId");
				params.addValue("projMgrId", dto.getProjMgrId());
			}
			
			if(dto.getCreateDateFrm()!=null){
				builder.append(" and TRIM(prj.PROJ_DATE)>=TO_DATE(:createDateFrm, 'MM/DD/YYYY')");
				params.addValue("createDateFrm", WebDateUtil.getDateInMMDDYYYY(dto.getCreateDateFrm()));
			}
			if(dto.getCreateDateTo()!=null){
				builder.append(" and TRIM(prj.PROJ_DATE)<=TO_DATE(:createDateTo, 'MM/DD/YYYY')");
				params.addValue("createDateTo", WebDateUtil.getDateInMMDDYYYY(dto.getCreateDateTo()));
			}
			
			if(dto.getLastChangeDateFrm()!=null){
				builder.append(" and TRIM(prjchg.CHNG_DATE)>=TO_DATE(:lastChangeDateFrm, 'MM/DD/YYYY')");
				params.addValue("lastChangeDateFrm", WebDateUtil.getDateInMMDDYYYY(dto.getLastChangeDateFrm()));
			}
			if(dto.getLastChangeDateTo()!=null){
				builder.append(" and TRIM(prjchg.CHNG_DATE)<=TO_DATE(:lastChangeDateTo, 'MM/DD/YYYY')");
				params.addValue("lastChangeDateTo", WebDateUtil.getDateInMMDDYYYY(dto.getLastChangeDateTo()));
			}
			
			if(dto.getProjCloseDateFrm()!=null){
				builder.append(" and TRIM(prj.PROJ_DATE)>=TO_DATE(:projCloseDateFrm, 'MM/DD/YYYY')");
				params.addValue("projCloseDateFrm", WebDateUtil.getDateInMMDDYYYY(dto.getProjCloseDateFrm()));
			}
			if(dto.getProjCloseDateTo()!=null){
				builder.append(" and TRIM(prj.PROJ_DATE)<=TO_DATE(:projCloseDateTo, 'MM/DD/YYYY')");
				params.addValue("projCloseDateTo", WebDateUtil.getDateInMMDDYYYY(dto.getProjCloseDateTo()));
			}
			
		}
		return params;
		
	}

	@Override
	public List<SearchDTO> getExcelReport(ProjectSearchCriteriaDTO projectSearchCriteriaDTO) {
		StringBuilder builder = new StringBuilder(environment.getProperty("PROJECT_SEARCH_QUERY"));
		MapSqlParameterSource params=createCriterias(projectSearchCriteriaDTO, builder);
		return this.getNamedParamResultsList(builder.toString(), params, SearchDTO.class);
	}
	
	@Override
	public List<DropDownInfo> getProjectNames() {
	    return (List<DropDownInfo>)getNamedParamResultsList(environment.getProperty("PROJECT_SEARCH_NAME_QUERY"), new Object[] { }, DropDownInfo.class);
	}*/
	
	
	
}
