package com.uprr.ema.lms.common.util;

public class LMSResponseConstants {
    public static final String SUCESS_CODE= "1111";
    public static final String FAILURE_CODE= "2222";
    public static final String EXCEPTION_CODE= "6666";
    public static final String VALIDATION_FAILURE_CODE= "7777";
    
    public static final String DUPLICATE_CODE="3333";
    public static final String RECORD_NOTEXIST="4444";
    
    public static final String DUPLICATE_CODE_OUTRCH_LEPC="3001";
    
    
    public static final String RECORD_MORE_EXIST="5555";
    

    public static final String LEPC_NAME_NOTEXIST="4001";
    public static final String LEPC_NAME_EXIST="4002";
    
    public static final String SUCESS_MESSAGE_TYPE = "Sucess";
    public static final String ERROR_MESSAGE_TYPE = "error";
    public static final String INFO_MESSAGE_TYPE = "Info";
    public static final String VALID_MESSAGE_TYPE= "validationError";
    
    public static final String CRTAB_ERROR_MESSAGE= "Steering Committee Recommendation details is updated by another user.Kindly search with inspection number for latest details.";
    public static final String PROPERTY_ERROR_MESSAGE = "Property is not active now.Kindly search with inspection number for latest details.";

}
