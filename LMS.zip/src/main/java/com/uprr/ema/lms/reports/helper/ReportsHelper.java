package com.uprr.ema.lms.reports.helper;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DataFormat;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xwpf.model.XWPFHeaderFooterPolicy;
import org.apache.poi.xwpf.usermodel.ParagraphAlignment;
import org.apache.poi.xwpf.usermodel.UnderlinePatterns;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFFooter;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.uprr.ema.lms.common.service.util.ExcelUtils;
import com.uprr.ema.lms.common.util.WebDateUtils;
import com.uprr.ema.lms.reports.dto.BusinessPrepPlanDTO;
import com.uprr.ema.lms.reports.dto.LCRRprtDTO;
import com.uprr.ema.lms.reports.dto.LCRRprtSearchCriteriaDTO;
import com.uprr.ema.lms.reports.dto.OverAllDataLCRRprtDTO;
import com.uprr.ema.lms.reports.service.api.ReportsService;
import com.uprr.ema.lms.searchproject.dto.LEWBReportDto;
import com.uprr.ema.lms.searchproject.service.api.ProjectSearchService;



@Component
public class ReportsHelper {
	private static final Logger LOGGER = Logger.getLogger(ReportsHelper.class);
	
	 
    @Autowired
    ProjectSearchService projectSearchService;
    
    @Autowired
    ReportsService reportsService;
    
    public static int endYear;
    
    public void getLCRReport(HttpServletResponse response,LCRRprtSearchCriteriaDTO lcrRprtSearchCriteria, OverAllDataLCRRprtDTO overAllDataLCRRprtDTO)throws Exception{
		XWPFDocument document = new XWPFDocument();
		document.getParagraphs();
		
		////////////////////COMMON LCR DOCUMENT FORMAT AT START ONE SECTION////////////////
		if(lcrRprtSearchCriteria != null && overAllDataLCRRprtDTO.getFirstLastDayStrings() != null){
			getCommonLCRDocumentFormatAtStartOne(document, lcrRprtSearchCriteria,overAllDataLCRRprtDTO.getFirstLastDayStrings());
		}
		
		////////////////////ENVIRONMENTAL LIABILITY CALCULATION SECTION////////////////
		getEnvLiabiltyCalculations(document, overAllDataLCRRprtDTO.getTotalLiabilityEstAmt(), overAllDataLCRRprtDTO.getTotalLiabilityEstChanged(), overAllDataLCRRprtDTO.getTotalLiabilityEstChangedForQrtr());
		
		////////////////////COMMON LCR DOCUMENT FORMAT AT START TWO SECTION////////////////
		getCommonLCRDocumentFormatAtStartTwo(document);
		
		////////////////////NEW PROJECTS SECTION////////////////
		if(overAllDataLCRRprtDTO.getLcrRptDTOAllNewProjectLst() != null && !overAllDataLCRRprtDTO.getLcrRptDTOAllNewProjectLst().isEmpty()){
			getParagraphNewProjectsProposedDetails(document,overAllDataLCRRprtDTO.getLcrRptDTOAllNewProjectLst());
		}
		
		////////////////////PROPOSED LIABILITY INCREASES TO EXISTING PROJECTS////////////////
		if(overAllDataLCRRprtDTO.getLcrRprtDTOLstofLst() != null && !overAllDataLCRRprtDTO.getLcrRprtDTOLstofLst().isEmpty()){
			getParagraphProposedLibEstIncreasing(document,overAllDataLCRRprtDTO.getLcrRprtDTOLstofLst().get(0));
		}
		
		////////////////////PROPOSED LIABILITY DECREASES TO EXISTING PROJECTS////////////////
		if(overAllDataLCRRprtDTO.getLcrRprtDTOLstofLst() != null && !overAllDataLCRRprtDTO.getLcrRprtDTOLstofLst().isEmpty()){
			getParagraphProposedLibEstDecreasing(document,overAllDataLCRRprtDTO.getLcrRprtDTOLstofLst().get(1));
		}
		
		////////////////////SITE REMEDIATION PROJECTS REACHING LEVEL 7 CLOSURE////////////////
		if(overAllDataLCRRprtDTO.getLcrRptDTOAllPrjctLstforTubeLevelGrtrThanSix() != null && !overAllDataLCRRprtDTO.getLcrRptDTOAllPrjctLstforTubeLevelGrtrThanSix().isEmpty()){
			getSiteRemidProjectLstTubeLvlGrtrThanSix(document,overAllDataLCRRprtDTO.getLcrRptDTOAllPrjctLstforTubeLevelGrtrThanSix());
		}
		
		////////////////////CREATE HEADER START////////////////// 
		lcrCreateFooter(document);
				
		response.setHeader("Content-Disposition", "inline; filename=" + "Projects Report.docx");
		response.setContentType("application/msword");
		ServletOutputStream outputStream = response.getOutputStream();
		response.setCharacterEncoding("UTF-8");
		
		document.write(outputStream);
		outputStream.flush();
	}

	private void lcrCreateFooter(XWPFDocument document) throws IOException {
		XWPFHeaderFooterPolicy headerFooterPolicy = document.getHeaderFooterPolicy();
		if (headerFooterPolicy == null) {
			headerFooterPolicy = document.createHeaderFooterPolicy();
		}
		
		XWPFFooter footer = headerFooterPolicy.createFooter(XWPFHeaderFooterPolicy.DEFAULT);
		XWPFParagraph paragraphFooter = document.createParagraph();
		
		XWPFRun runFooter = paragraphFooter.createRun();
		paragraphFooter = footer.getParagraphArray(0);
		if (paragraphFooter == null) {
			paragraphFooter = footer.createParagraph();
		}
		paragraphFooter.setAlignment(ParagraphAlignment.CENTER);
		runFooter = paragraphFooter.createRun();
		runFooter.setText("PRIVILEGED AND CONFIDENTIAL");
		runFooter.addBreak();
		runFooter.setText("PREPARED AT THE REQUEST OF LEGAL COUNSEL ");
		runFooter = paragraphFooter.createRun();
		runFooter.addBreak();
		runFooter.setText("Page ");
		paragraphFooter.getCTP().addNewFldSimple().setInstr("PAGE \\* MERGEFORMAT");
	}
	
	public void getCommonLCRDocumentFormatAtStartOne(XWPFDocument document,LCRRprtSearchCriteriaDTO lcrRprtSearchCriteria, String[] firstLastDayStrings) {
		XWPFParagraph paragraph = document.createParagraph();
		paragraph.setAlignment(ParagraphAlignment.CENTER);
		XWPFRun run = paragraph.createRun();
		run.setBold(true);
		run.setFontSize(10);
		run.setFontFamily("Arial");
		run.setText("UPRR ENVIRONMENTAL SITE REMEDIATION GROUP");
		run.addBreak();
		run.setText("LIABILITY CHANGE REPORT");
		run.addBreak();
		if(!StringUtils.isEmpty(lcrRprtSearchCriteria.getMonth()) && !StringUtils.isEmpty(lcrRprtSearchCriteria.getYear())){
			run.setText(lcrRprtSearchCriteria.getMonth().toUpperCase() + " " + lcrRprtSearchCriteria.getYear());
		}
		
		XWPFParagraph paragraph1 = document.createParagraph();
		XWPFRun run1 = paragraph1.createRun();
		run1.setBold(false);
		run1.setFontSize(10);
		run1.setFontFamily("Arial");
		run1.setText("This report summarizes proposed changes to Union Pacific Railroad Company�s (�UPRR�) environmental liability recognized from ");
		if(!StringUtils.isEmpty(firstLastDayStrings[0]) && !StringUtils.isEmpty(firstLastDayStrings[1])){
			run1.setText(firstLastDayStrings[0] + " through " + firstLastDayStrings[1]);
		}
		
	}
	
	public void getCommonLCRDocumentFormatAtStartTwo(XWPFDocument document) {
		XWPFParagraph paragraph4 = document.createParagraph();
		XWPFRun run4 = paragraph4.createRun();
		run4.setBold(true);
		run4.setUnderline(UnderlinePatterns.SINGLE);
		run4.setFontSize(10);
		run4.setFontFamily("Arial");
		run4.setText("EXPEDITURES AGAINST THE ENVIRONMENTAL RESERVE");
		
		XWPFParagraph paragraph5 = document.createParagraph();
		XWPFRun run5 = paragraph5.createRun();
		run5.setBold(false);
		run5.setFontSize(10);
		run5.setFontFamily("Arial");
		run5.setText("The chart below summarizes the year to date expenditures against planned expenditures to the environmental reserve.");
	}
	
	public void getEnvLiabiltyCalculations(XWPFDocument document, Integer totalLiabilityEstAmt,Integer totalLiabilityEstChanged, Integer totalLiabilityEstChangedForQrtr) {
		XWPFParagraph paragraph2 = document.createParagraph();
		XWPFRun run2 = paragraph2.createRun();
		run2.setBold(true);
		run2.setUnderline(UnderlinePatterns.SINGLE);
		run2.setFontSize(10);
		run2.setFontFamily("Arial");
		run2.setText("ENVIRONMENTAL LIABILITY");
		XWPFParagraph paragraph3 = document.createParagraph();
		XWPFRun run3 = paragraph3.createRun();
		run3.setBold(false);
		run3.setFontSize(10);
		run3.setFontFamily("Arial");
		run3.setText("The proposed environmental liability is $" + String.format("%,d", totalLiabilityEstAmt));
		run3.addBreak();
		run3.addBreak();
		run3.setText("This proposes a change in environmental liability of $"+ String.format("%,d", totalLiabilityEstChanged));
		run3.addBreak();
		run3.addBreak();
		run3.setText("The quarterly change to date is $" + String.format("%,d", totalLiabilityEstChangedForQrtr));
	}
	
	public void getParagraphNewProjectsProposedDetails(XWPFDocument document,List<LCRRprtDTO> lCRRptDTOAllNewProjectLst){
		XWPFParagraph paragraph6 = document.createParagraph();
		XWPFRun run6 = paragraph6.createRun();
		run6.setBold(true);
		run6.setUnderline(UnderlinePatterns.SINGLE);
		run6.setFontSize(10);
		run6.setFontFamily("Arial");
		run6.setText("NEW PROJECTS");
		
		XWPFParagraph paragraph7 = document.createParagraph();
		XWPFRun run7 = paragraph7.createRun();
		run7.setBold(false);
		run7.setFontSize(10);
		run7.setFontFamily("Arial");
		run7.setText("This review identified the following new sites:");
		
		createNewProposedProjectList(document, lCRRptDTOAllNewProjectLst);
	}

	private void createNewProposedProjectList(XWPFDocument document, List<LCRRprtDTO> lCRRptDTOAllNewProjectLst) {
		for (LCRRprtDTO lcrRprtDTO: lCRRptDTOAllNewProjectLst) {
			int recordCount = lCRRptDTOAllNewProjectLst.indexOf(lcrRprtDTO) + 1;
			XWPFParagraph paragraphNewProjTitle = document.createParagraph();
			paragraphNewProjTitle.setSpacingAfter(0);
			paragraphNewProjTitle.setSpacingBefore(0);
			paragraphNewProjTitle.setSpacingBeforeLines(2);
			XWPFRun runNewProjTitle = paragraphNewProjTitle.createRun();
			runNewProjTitle.setBold(true);
			runNewProjTitle.setFontSize(10);
			runNewProjTitle.setFontFamily("Arial");
			runNewProjTitle.setText(recordCount + ".   " + lcrRprtDTO.getCity() + ", " + lcrRprtDTO.getState() + " - " + lcrRprtDTO.getProjectName());
		
			Integer absoluteValueOFTotalLiabEstAmt = Math.abs(lcrRprtDTO.getTotalLiabEstAmt() !=null ? lcrRprtDTO.getTotalLiabEstAmt() : 0);
			if(absoluteValueOFTotalLiabEstAmt!=null && absoluteValueOFTotalLiabEstAmt>0 ){
				XWPFParagraph subparaNewProjTitle0 = document.createParagraph();
				subparaNewProjTitle0.setSpacingAfter(0);
				subparaNewProjTitle0.setSpacingBefore(0);
				XWPFRun subRunNewProjTitle0 = subparaNewProjTitle0.createRun();
				subRunNewProjTitle0.setBold(false);
				subRunNewProjTitle0.setFontSize(10);
				subRunNewProjTitle0.setFontFamily("Arial");
				subRunNewProjTitle0.addTab();
				subRunNewProjTitle0.setText(absoluteValueOFTotalLiabEstAmt!=null ?  "a. Liability Estimate Changed: $" +String.format("%,d", absoluteValueOFTotalLiabEstAmt) : "a. Liability Estimate Changed: $0");
			}
			
			XWPFParagraph subparaNewProjTitle1 = document.createParagraph();
			subparaNewProjTitle1.setSpacingAfter(0);
			subparaNewProjTitle1.setSpacingBefore(0);
			XWPFRun subRunNewProjTitle1 = subparaNewProjTitle1.createRun();
			subRunNewProjTitle1.setBold(false);
			subRunNewProjTitle1.setFontSize(10);
			subRunNewProjTitle1.setFontFamily("Arial");
			subRunNewProjTitle1.addTab();
			if(absoluteValueOFTotalLiabEstAmt!=null && absoluteValueOFTotalLiabEstAmt>0){
				subRunNewProjTitle1.setText(lcrRprtDTO.getChangeReasonDesc()!=null ?  "b. Liability Estimating Rule:" +lcrRprtDTO.getChangeReasonDesc() : "b. Liability Estimating Rule:");
			}else{
				subRunNewProjTitle1.setText(lcrRprtDTO.getChangeReasonDesc()!=null ?  "a. Liability Estimating Rule:" +lcrRprtDTO.getChangeReasonDesc() : "a. Liability Estimating Rule:");
			}
		
			XWPFParagraph subparaNewProjTitle2 = document.createParagraph();
			subparaNewProjTitle2.setSpacingAfter(0);
			subparaNewProjTitle2.setSpacingBefore(0);
			XWPFRun subRunNewProjTitle2 = subparaNewProjTitle2.createRun();
			subRunNewProjTitle2.setBold(false);
			subRunNewProjTitle2.setFontSize(10);
			subRunNewProjTitle2.setFontFamily("Arial");
			subRunNewProjTitle2.addTab();
			if(absoluteValueOFTotalLiabEstAmt != null && absoluteValueOFTotalLiabEstAmt>0){
				subRunNewProjTitle2.setText("c. Background: " +lcrRprtDTO.getProjOthDesc());
			}else{
				subRunNewProjTitle2.setText("b. Background: " +lcrRprtDTO.getProjOthDesc());
			}
			
			if(absoluteValueOFTotalLiabEstAmt != null && absoluteValueOFTotalLiabEstAmt>0){
				XWPFParagraph subparaNewProjTitle3 = document.createParagraph();
				subparaNewProjTitle3.setSpacingAfter(0);
				subparaNewProjTitle3.setSpacingBefore(0);
				XWPFRun subRunNewProjTitle3 = subparaNewProjTitle3.createRun();
				subRunNewProjTitle3.setBold(false);
				subRunNewProjTitle3.setFontSize(10);
				subRunNewProjTitle3.setFontFamily("Arial");
				subRunNewProjTitle3.addTab();
				subRunNewProjTitle3.setText(lcrRprtDTO.getChangeReasonComment()!=null ?  "d. Change Detail:" +lcrRprtDTO.getChangeReasonComment() : "d.	Change Detail:");
				subRunNewProjTitle3.addBreak();
			}
		}
	}
		
	public void getParagraphProposedLibEstIncreasing(XWPFDocument document,List<LCRRprtDTO> lCRRprtDTOLst){
		boolean decreaseFlag = false;
		Collections.sort(lCRRprtDTOLst, Collections.reverseOrder());
		XWPFParagraph paragraph10 = document.createParagraph();
		XWPFRun run10 = paragraph10.createRun();
		run10.setBold(true);
		run10.setUnderline(UnderlinePatterns.SINGLE);
		run10.setFontSize(10);
		run10.setFontFamily("Arial");
		run10.setText("PROPOSED LIABILITY INCREASES TO EXISTING PROJECTS");
		
		XWPFParagraph paragraph11 = document.createParagraph();
		XWPFRun runparagraph11 = paragraph11.createRun();
		runparagraph11.setBold(false);
		runparagraph11.setFontSize(10);
		runparagraph11.setFontFamily("Arial");
		runparagraph11.setText("The paragraphs below provide a narrative of proposed changes to existing projects that increased environmental liability estimates greater than or equal to $10,000.");
		
		for (LCRRprtDTO lcrRprtDTO: lCRRprtDTOLst) {
			int recordCount = lCRRprtDTOLst.indexOf(lcrRprtDTO) + 1;
			writeDecreasesAndIncreasesSection(document, lcrRprtDTO, recordCount, decreaseFlag);
		}
	}
	
	public void getParagraphProposedLibEstDecreasing(XWPFDocument document,List<LCRRprtDTO> lCRRprtDTOLst){
		boolean decreaseFlag = true;
		Collections.sort(lCRRprtDTOLst);
		XWPFParagraph paragraph11 = document.createParagraph();
		XWPFRun run11 = paragraph11.createRun();
		run11.setBold(true);
		run11.setUnderline(UnderlinePatterns.SINGLE);
		run11.setFontSize(10);
		run11.setFontFamily("Arial");
		run11.setText("PROPOSED LIABILITY DECREASES TO EXISTING PROJECTS");
		
		XWPFParagraph paragraph111 = document.createParagraph();
		XWPFRun runparagraph111 = paragraph111.createRun();
		runparagraph111.setBold(false);
		runparagraph111.setFontSize(10);
		runparagraph111.setFontFamily("Arial");
		runparagraph111.setText("The paragraphs below provide a narrative of proposed changes to existing projects that decreased environmental liability estimates greater than or equal to $10,000.");
		
		for (LCRRprtDTO lcrRprtDTO: lCRRprtDTOLst) {
			int recordCount = lCRRprtDTOLst.indexOf(lcrRprtDTO) + 1;
			writeDecreasesAndIncreasesSection(document, lcrRprtDTO, recordCount, decreaseFlag);
		}
	}

	private void writeDecreasesAndIncreasesSection(XWPFDocument document, LCRRprtDTO lcrRprtDTO, int recordCount, boolean decreaseFlag) {
		XWPFParagraph paragraph8 = document.createParagraph();
		paragraph8.setSpacingAfter(0);
		paragraph8.setSpacingBefore(0);
		paragraph8.setSpacingBeforeLines(2);
		XWPFRun run8 = paragraph8.createRun();
		run8.setBold(true);
		run8.setFontSize(10);
		run8.setFontFamily("Arial");
		run8.setText(recordCount + ".   " + lcrRprtDTO.getCity() + ", " + lcrRprtDTO.getState() + " - " + lcrRprtDTO.getProjectName());

		XWPFParagraph subParagraph2 = document.createParagraph();
		subParagraph2.setSpacingAfter(0);
		subParagraph2.setSpacingBefore(0);
		XWPFRun subRun2 = subParagraph2.createRun();
		subRun2.setBold(false);
		subRun2.setFontSize(10);
		subRun2.setFontFamily("Arial");
		subRun2.addTab();
		if(decreaseFlag){
			Integer absValChangedLiabEstAmt = Math.abs(lcrRprtDTO.getChangedLiabilityEstimate() !=null ? lcrRprtDTO.getChangedLiabilityEstimate() : 0);
			subRun2.setText(absValChangedLiabEstAmt!=null ? "a. Liability Estimate Changed: $(" + String.format("%,d", absValChangedLiabEstAmt)+")" : "a. Liability Estimate Changed: $0");
		} else {
			subRun2.setText("a. Liability Estimate Changed: $" + String.format("%,d", lcrRprtDTO.getChangedLiabilityEstimate()));
		}

		XWPFParagraph subParagraph3 = document.createParagraph();
		subParagraph3.setSpacingAfter(0);
		subParagraph3.setSpacingBefore(0);
		XWPFRun subRun3 = subParagraph3.createRun();
		subRun3.setBold(false);
		subRun3.setFontSize(10);
		subRun3.setFontFamily("Arial");
		subRun3.addTab();
		subRun3.setText(lcrRprtDTO.getChangeReasonComment()!=null ?  "b. Liability Estimating Rule:" + lcrRprtDTO.getChangeReasonComment() : "b. Liability Estimating Rule:");

		XWPFParagraph subParagraph4 = document.createParagraph();
		subParagraph4.setSpacingAfter(0);
		subParagraph4.setSpacingBefore(0);
		XWPFRun subRun4 = subParagraph4.createRun();
		subRun4.setBold(false);
		subRun4.setFontSize(10);
		subRun4.setFontFamily("Arial");
		subRun4.addTab();
		subRun4.setText("c. Background: "+lcrRprtDTO.getProjOthDesc());

		XWPFParagraph subParagraph5 = document.createParagraph();
		subParagraph5.setSpacingAfter(0);
		subParagraph5.setSpacingBefore(0);
		XWPFRun subRun5 = subParagraph5.createRun();
		subRun5.setBold(false);
		subRun5.setFontSize(10);
		subRun5.setFontFamily("Arial");
		subRun5.addTab();
		subRun5.setText(lcrRprtDTO.getChangeReasonComment()!=null ?  "d.	Change Detail: " + lcrRprtDTO.getChangeReasonComment() : "d.	Change Detail:");
		subRun5.addBreak();
	}
	
	public void getSiteRemidProjectLstTubeLvlGrtrThanSix(XWPFDocument document,List<LCRRprtDTO> lCRRptDTOAllPrjctLstforTLSix){
		XWPFParagraph paragraph12 = document.createParagraph();
		XWPFRun run12 = paragraph12.createRun();
		run12.setBold(true);
		run12.setUnderline(UnderlinePatterns.SINGLE);
		run12.setFontSize(10);
		run12.setFontFamily("Arial");
		run12.setText("SITE REMEDIATION PROJECTS REACHING LEVEL 7 CLOSURE");
		
		XWPFParagraph paragraph13 = document.createParagraph();
		paragraph13.setSpacingAfter(0);
		paragraph13.setSpacingBefore(0);
		XWPFRun run13 = paragraph13.createRun();
		run13.setBold(false);
		run13.setFontSize(10);
		run13.setFontFamily("Arial");
		run13.setText("The status of the projects listed below progressed to closure.");
		run13.addBreak();
		
		for (LCRRprtDTO lcrRprtDTOProjctTLSix: lCRRptDTOAllPrjctLstforTLSix) {
			int recordCount = lCRRptDTOAllPrjctLstforTLSix.indexOf(lcrRprtDTOProjctTLSix) + 1;
			XWPFParagraph paragraph8 = document.createParagraph();
			paragraph8.setSpacingAfter(0);
			paragraph8.setSpacingBefore(0);
			paragraph8.setSpacingBeforeLines(2);
			XWPFRun run8 = paragraph8.createRun();
			run8.setBold(true);
			run8.setFontSize(10);
			run8.setFontFamily("Arial");
			run8.setText(recordCount + ".   " + lcrRprtDTOProjctTLSix.getCity() + ", " + lcrRprtDTOProjctTLSix.getState() + " - " + lcrRprtDTOProjctTLSix.getProjectName());
		}
	}

	public void generateLewbReort(HttpServletResponse response, String month, String year,String reportType) {
	try
		{
		List<String[]> list = new ArrayList<>();
    	
    	Sheet sheet = ExcelUtils.generateExcel("Liability Estimating Workbook Report", list);
    	 sheet.getWorkbook().setSheetName(0, "Study");
    	response.setHeader("Content-Disposition", "inline; filename="+ "Liability Estimating Workbook Report");
		response.setContentType("application/vnd.ms-excel");
		ServletOutputStream outputStream = response.getOutputStream();
		response.setCharacterEncoding("UTF-8");
		Row row = sheet.createRow((short) 0);
        Cell cell = row.createCell((short) 0);
		final CellStyle style = sheet.getWorkbook().createCellStyle();
		final Font font = sheet.getWorkbook().createFont();
		font.setBold(true);
		font.setColor(IndexedColors.RED.getIndex());
		font.setFontHeightInPoints((short)15);
		style.setFont(font);
		style.setShrinkToFit(false);
		cell.setCellStyle(style);
		cell.setCellValue("PRIVILEGED AND CONFIDENTIAL WORK PRODUCT PREPARED AT THE REQUEST OF LEGAL COUNSEL");
		sheet.addMergedRegion(CellRangeAddress.valueOf("A1:H1"));
		
		Row row1 = sheet.createRow((short) 1);
        Cell cell1 = row1.createCell((short) 0);
		final CellStyle style1 = sheet.getWorkbook().createCellStyle();
		final Font font1 = sheet.getWorkbook().createFont();
		font1.setBold(true);
		font1.setColor(IndexedColors.BLACK.getIndex());
		font1.setFontHeightInPoints((short)15);
		style1.setFont(font1);
		style1.setShrinkToFit(false);
		cell1.setCellStyle(style1);
		cell1.setCellValue(" ENVIRONMENTAL LIABILITY ESTIMATING WORKBOOK");
		sheet.addMergedRegion(CellRangeAddress.valueOf("A2:H2"));
		
		Row row2 = sheet.createRow((short) 2);
        Cell cell2 = row2.createCell((short) 0);
		final CellStyle style2 = sheet.getWorkbook().createCellStyle();
		final Font font2 = sheet.getWorkbook().createFont();
		font2.setBold(true);
		font2.setColor(IndexedColors.BLACK.getIndex());
		font2.setFontHeightInPoints((short)15);
		style2.setFont(font2);
		style2.setShrinkToFit(false);
		cell2.setCellStyle(style2);
		String quarter=getlastQuarterNumber(month);
		cell2.setCellValue(""+quarter+" QUARTER "+year+" - Draft ");
		sheet.addMergedRegion(CellRangeAddress.valueOf("A3:H3"));
		
		
		int fistYear=Integer.parseInt(year)+1;
		int secondear=Integer.parseInt(year)+2;
		int thirdYear=Integer.parseInt(year)+3;
		int fourthYear=Integer.parseInt(year)+4;
		int fifthYear=Integer.parseInt(year)+5;
		int sixtYear=Integer.parseInt(year)+6;
		int seventhyear=Integer.parseInt(year)+7;
		int eigthYear=Integer.parseInt(year)+8;
		int ningthYear=Integer.parseInt(year)+9;
		int tenthYear=Integer.parseInt(year)+10;
		int eleventhyear=Integer.parseInt(year)+11;
		int twelethYear=Integer.parseInt(year)+12;
		int thirteenthYear=Integer.parseInt(year)+13;
		int fourteenthYear=Integer.parseInt(year)+14;
		int fifteenthyear=Integer.parseInt(year)+15;
		

	/* spent amount from jan to selected month */
		
		List<LEWBReportDto> searchDtoList=	getExcelDataFromDb(month,year);
		
		int rowCount=11;
		
		List<BusinessPrepPlanDTO> spentInAmount=	new ArrayList<BusinessPrepPlanDTO>();
		String monthinNumeric=reportsService.getMonthInNumeric(month);
		String queryString1=" "+"BETWEEN '"+year+"001' AND '"+year+""+monthinNumeric+"'";
		spentInAmount=spentAmount(queryString1);
		Map<String,Double> spentInAmountMap=new HashMap<String,Double>();
		if(spentInAmount!=null && spentInAmount.size()>0)
		{
			spentInAmountMap=getamountMap(spentInAmount);
		}
		
	
		
		
		/*  spent amount upto last quarter */
		
		List<BusinessPrepPlanDTO> spentToLastQuater=	new ArrayList<BusinessPrepPlanDTO>();
		String lastQuarterMonth=reportsService.getlastQuarterMonth(month);
		String lastQuarterMonthInNumberic="";
		String lastQuarterMonthInString="";
		if(lastQuarterMonth.contains("##"))
		{
			lastQuarterMonthInNumberic=lastQuarterMonth.split("##")[0];
			lastQuarterMonthInString=lastQuarterMonth.split("##")[1];
		}
		int lastQuarterYear=0;
		if(lastQuarterMonthInNumberic.equalsIgnoreCase("012")){
			lastQuarterYear=Integer.parseInt(year)-1;
		}
		else
		{
			lastQuarterYear=Integer.parseInt(year);
		}
		String lastQuarterYearstr=lastQuarterYear+"";
		String queryString2="<='"+lastQuarterYearstr+""+lastQuarterMonthInNumberic+"'";
		spentToLastQuater=spentAmount(queryString2);
		Map<String,Double> spentToLastQuaterMap=new HashMap<String,Double>();
		if(spentToLastQuater!=null && spentToLastQuater.size()>0)
		{
			spentToLastQuaterMap=getamountMap(spentToLastQuater);
		}
		 
		
		
		
		/* spent amount upto selected month */
		
		List<BusinessPrepPlanDTO> spentToLastSelectedMonth=	new ArrayList<BusinessPrepPlanDTO>();
		String monthinNumeric1=reportsService.getMonthInNumeric(month);
		String queryString3="<='"+year+""+monthinNumeric1+"'";
		spentToLastSelectedMonth=spentAmount(queryString3);
		Map<String,Double> spentToLastSelMonthMap=new HashMap<String,Double>();
		if(spentToLastSelectedMonth!=null && spentToLastSelectedMonth.size()>0)
		{
			spentToLastSelMonthMap=getamountMap(spentToLastSelectedMonth);
		}
		
		
		
		/* spent amount upto last audit cycle */
		
		List<BusinessPrepPlanDTO> spentToLastAuditCycle=new ArrayList<BusinessPrepPlanDTO>();
		String lastAuditCycleMonthInNumberic="";
		String lastAuditCycleMonthInStr="";
		int lastAuditCycleYear=0;
		if(month.equalsIgnoreCase("January") || month.equalsIgnoreCase("February") || month.equalsIgnoreCase("march"))
		{
			lastAuditCycleMonthInNumberic="003";
			lastAuditCycleMonthInStr="March";
			lastAuditCycleYear=Integer.parseInt(year)-1;
		}
		else
		{
			lastAuditCycleMonthInNumberic="003";
			lastAuditCycleMonthInStr="March";
			lastAuditCycleYear=Integer.parseInt(year);
		}
		String lastAuditCycleYearInString=lastAuditCycleYear+"";
		
		String queryString4="<='"+lastAuditCycleYearInString+""+lastAuditCycleMonthInNumberic+"'";
		spentToLastAuditCycle=spentAmount(queryString4);
		
		Map<String,Double> spentToLastAuditCycleMap=new HashMap<String,Double>();
		if(spentToLastAuditCycle!=null && spentToLastAuditCycle.size()>0)
		{
			spentToLastAuditCycleMap=getamountMap(spentToLastAuditCycle);
		}
		
		
	
		
		
		/*Set<String> networkNumberSet = reportsService.getDistinctValues(spentInAmount);
		List<LEWBReportDto> projectIds=projectSearchService.getProjectIds(networkNumberSet);*/
		String quarterNumber=getlastQuarterNumber(month);
		List<String> headerListfirstQuarter=getHeaderArray(quarterNumber,month,year,"false");
		List<String> headerListSecondQuarter=getHeaderArray(headerListfirstQuarter.get(0),month,year,headerListfirstQuarter.get(5));
		List<String> headerListThirdQuarter=getHeaderArray(headerListSecondQuarter.get(0),month,year,headerListSecondQuarter.get(5));
		List<String> headerListFourthQuarter=getHeaderArray(headerListThirdQuarter.get(0),month,year,headerListThirdQuarter.get(5));
		List<String> headerListfifthQuarter=getHeaderArray(headerListFourthQuarter.get(0),month,year,headerListFourthQuarter.get(5));
		
		
		
		String[] excelHeader = { "Reviewed", "Project", "Liability Estimate", "NPV", "UPRR Allocation",
				"Financial Assuarnce", "D & T List", "Cost Recovery", "Project Level", "Month Closed", "Federal Lead", "15-year Rule", "Estimator",
				"Quarterly Liability Change", "Reason for last change", ""+year+" Plan", ""+year+" BOY Plan", "Change in "+year+" Plan",
				"Spent in "+year+" ("+month+" Close)", ""+year+" Remaining Liability",""+fistYear+" plan",""+secondear+" plan",""+thirdYear+" plan",
						""+fourthYear+" plan",""+fifthYear+" plan",""+sixtYear+" plan",""+seventhyear+" plan",""+eigthYear+" plan",
						""+ningthYear+" plan",""+tenthYear+" plan",""+eleventhyear+" plan",""+twelethYear+" plan",""+thirteenthYear+" plan",
						""+fourteenthYear+" plan",""+fifteenthyear+" plan","OMM Costs","System Cloure Costs","BOY Date","Operating Status","Balance Sheet","Sub Account","CN",
								"Liability Estimate Ending Previous Quarter","Spent to "+lastQuarterMonthInString+"-"+lastQuarterYearstr+" Close","Spent to "+month+"-"+year+" Close","Liability Estimate Ending Previous Audit Committee Cycle (June-"+lastAuditCycleYearInString+")",
								"Spent to End of Previous Audit Committee Cycle (June-"+lastAuditCycleYearInString+")","Manager","St","City","RR","Listed Date","Last Paid Date","Remove",
								"Site Closed for 12-Months","No Spending for 12-Months","No Liability change in 12 months","Liability Estimate = 0",
								headerListfirstQuarter.get(1),headerListfirstQuarter.get(2),"Reason",headerListfirstQuarter.get(3),"Reason",headerListfirstQuarter.get(4),"Reason",
								headerListSecondQuarter.get(1),headerListSecondQuarter.get(2),"Reason",headerListSecondQuarter.get(3),"Reason",headerListSecondQuarter.get(4),"Reason",
								headerListThirdQuarter.get(1),headerListThirdQuarter.get(2),"Reason",headerListThirdQuarter.get(3),"Reason",headerListThirdQuarter.get(4),"Reason",
								headerListFourthQuarter.get(1),headerListFourthQuarter.get(2),"Reason",headerListFourthQuarter.get(3),"Reason",headerListFourthQuarter.get(4),"Reason",
								headerListfifthQuarter.get(1),headerListfifthQuarter.get(2),"Reason",headerListfifthQuarter.get(3),"Reason",headerListfifthQuarter.get(4),"Reason","Past 12 Month Change in Liability"};
		
		if(reportType.equalsIgnoreCase("QuarterlyAuditBackup")){
		String[] quarterlyReportHeader = {"Reviewed", "Project", "Liability Estimate", "NPV", "UPRR Allocation",
				"Financial Assuarnce", "D & T List", "Cost Recovery", "Project Level", "Month Closed", "Federal Lead", "15-year Rule", "Estimator",
				"Quarterly Liability Change", "Reason for last change", ""+year+" Plan", ""+year+" BOY Plan", "Change in "+year+" Plan",
				"Spent in "+year+" ("+month+" Close)", ""+year+" Remaining Liability",""+fistYear+" plan",""+secondear+" plan",""+thirdYear+" plan",
						""+fourthYear+" plan",""+fifthYear+" plan",""+sixtYear+" plan",""+seventhyear+" plan",""+eigthYear+" plan",
						""+ningthYear+" plan",""+tenthYear+" plan",""+eleventhyear+" plan",""+twelethYear+" plan",""+thirteenthYear+" plan",
						""+fourteenthYear+" plan",""+fifteenthyear+" plan","OMM Costs","System Cloure Costs","BOY Date","Operating Status","Balance Sheet","Sub Account","CN",
								"Liability Estimate Ending Previous Quarter","Spent to "+lastQuarterMonthInString+"-"+lastQuarterYearstr+" Close","Spent to "+month+"-"+year+" Close","Liability Estimate Ending Previous Audit Committee Cycle (June-"+lastAuditCycleYearInString+")",
								"Spent to End of Previous Audit Committee Cycle (June-"+lastAuditCycleYearInString+")","Manager","St","City","RR","Listed Date","Last Paid Date","Remove",
								"Site Closed for 12-Months","No Spending for 12-Months","No Liability change in 12 months","Liability Estimate = 0",
								headerListfirstQuarter.get(1),headerListfirstQuarter.get(2),"Reason",headerListfirstQuarter.get(3),"Reason",headerListfirstQuarter.get(4),"Reason",
								headerListSecondQuarter.get(1),headerListSecondQuarter.get(2),"Reason",headerListSecondQuarter.get(3),"Reason",headerListSecondQuarter.get(4),"Reason",
								headerListThirdQuarter.get(1),headerListThirdQuarter.get(2),"Reason",headerListThirdQuarter.get(3),"Reason",headerListThirdQuarter.get(4),"Reason",
								headerListFourthQuarter.get(1),headerListFourthQuarter.get(2),"Reason",headerListFourthQuarter.get(3),"Reason",headerListFourthQuarter.get(4),"Reason",
								headerListfifthQuarter.get(1),headerListfifthQuarter.get(2),"Reason",headerListfifthQuarter.get(3),"Reason",headerListfifthQuarter.get(4),"Reason","Past 12 Month Change in Liability",
								"Quarterly Change","Spend","Increase","Decrease"};
		
		
		excelHeader = quarterlyReportHeader;
		}
		
		createHeaderRow(sheet,excelHeader);
		generateLEWBHeaders(sheet,excelHeader,searchDtoList.size()+11,month,year);
		int maxCol = 0;
		for(LEWBReportDto obj:searchDtoList)
			
		{
		    	
		    		String[] rowDataArray = new String[60];
		            
		    		if(obj.getReviewedDate()!=null)
		    		{
		    			SimpleDateFormat dateFormat = new SimpleDateFormat(
			                    "MM-dd-yyyy");
			            String stringDate = dateFormat.format(obj.getReviewedDate());
			            
		    			rowDataArray[0]=stringDate;
		    		}
		    		else 
		    		{
		    			rowDataArray[0]="";
		    		}
		    		if(obj.getProjectName()!=null)
		    		{
		    			
		    			rowDataArray[1]=obj.getProjectName();
		    		}
		    		else
		    		{
		    			rowDataArray[1]="";
		    			
		    		}
		    			//rowDataArray[2]=""; //liability Estimate
		    			
		    			
		    			
		    		if(obj.getNpv()!=null)
		    		{
		    			
		    			if(obj.getNpv().equalsIgnoreCase("Y"))
		    			{
		    				
		    				rowDataArray[3]="NPV";
		    			}
		    			else
		    			{
		    				rowDataArray[3]="";
		    			}
		    			
		    		}
		    		else
		    		{
		    			rowDataArray[3]="";
		    		}
		    		
		    		if(obj.getUprrAllocation()!=null)
		    		{
		    			rowDataArray[4]=obj.getUprrAllocation();
		    		}
		    		else
		    		{
		    			rowDataArray[4]="";
		    		}
		    		
		    		if(obj.getFinancialAssurance()!=null)
		    		{
		    			rowDataArray[5]=obj.getFinancialAssurance();
		    		}
		    		else 
		    		{
		    			rowDataArray[5]="";
		    		}
		    		if(obj.getDTList()!=null)
		    		{
		    			rowDataArray[6]=obj.getDTList();
		    		}
		    		else 
		    		{
		    			rowDataArray[6]="";
		    		}
		    		if(obj.getCostRecovery()!=null)
		    		{
		    			rowDataArray[7]=obj.getCostRecovery();
		    		}
		    		else
		    		{
		    			rowDataArray[7]="";
		    		}
		    		if(obj.getProjectLevel()!=null)
		    		{
		    			rowDataArray[8]=obj.getProjectLevel().toString();
		    		}
		    		else
		    		{
		    			rowDataArray[8]="";
		    		}
		    		if(obj.getClosedMonth()!=null)
		    		{
		    			SimpleDateFormat dateFormat = new SimpleDateFormat(
			                    "MM-dd-yyyy");
			            String stringDate = dateFormat.format(obj.getClosedMonth());
			            
		    			rowDataArray[9]=stringDate;
		    		}
		    		else
		    		{
		    			rowDataArray[9]="";
		    		}
		    		if(obj.getFederalLead()!=null)
		    		{
		    			rowDataArray[10]=obj.getFederalLead();
		    		}
		    		else
		    		{
		    			rowDataArray[10]="";
		    		}
		    		
		    		if(obj.getFifteenYearRule()!=null)
		    		{
		    			rowDataArray[11]=obj.getFifteenYearRule();
		    		}
		    		else
		    		{
		    			rowDataArray[11]="";
		    		}
		    		if(obj.getEstimator()!=null)
		    		{
		    			rowDataArray[12]=obj.getEstimator();
		    		}
		    		else
		    		{
		    			rowDataArray[12]="";
		    		}
		    		
		    		if(obj.getOperatingStatus()!=null)
		    		{
		    			rowDataArray[38]=obj.getOperatingStatus();
		    		}
		    		else
		    		{
		    			rowDataArray[38]="";
		    		}
		    		
		    		if(obj.getBalanceSheetDesc()!=null)
		    		{
		    			rowDataArray[39]=obj.getBalanceSheetDesc();
		    		}
		    		else
		    		{
		    			rowDataArray[39]="";
		    		}
		    		
		    		if(obj.getSubAccountCode()!=null)
		    		{
		    			rowDataArray[40]=obj.getSubAccountCode();
		    		}
		    		else
		    		{
		    			rowDataArray[40]="";
		    		}
		    		
		    		if(obj.getAccountNumberData()!=null)
		    		{
		    			rowDataArray[41]=obj.getAccountNumberData();
		    		}
		    		else
		    		{
		    			rowDataArray[41]="";
		    		}
		    		
		    		if(obj.getMangerName()!=null)
		    		{
		    			rowDataArray[47]=obj.getMangerName();
		    		}
		    		else
		    		{
		    			rowDataArray[47]="";
		    		}
		    		
		    		if(obj.getState()!=null)
		    		{
		    			rowDataArray[48]=obj.getState();
		    		}
		    		else
		    		{
		    			rowDataArray[48]="";
		    		}
		    		
		    		if(obj.getCity()!=null)
		    		{
		    			rowDataArray[49]=obj.getCity();
		    		}
		    		else
		    		{
		    			rowDataArray[49]="";
		    		}
		    		
		    		if(obj.getRailRoad()!=null)
		    		{
		    			rowDataArray[50]=obj.getRailRoad();
		    		}
		    		else
		    		{
		    			rowDataArray[50]="";
		    		}
		    		
		    		if(obj.getProjectId()!=null)
		    		{
		    			String lastDate=getDateInNumeric(lastQuarterMonthInString);
		    			String liabiltyQueryString=" "+"between  to_date(('"+lastQuarterMonthInString+"-01-"+lastQuarterYearstr+"'),'Mon-DD-YYYY') and to_date(('"+lastQuarterMonthInString+"-"+lastDate+"-"+lastQuarterYearstr+"'),'Mon-DD-YYYY')";
		    			List<LEWBReportDto> liabilityEstimateEndingPreviousQyarter=liabilityEstimateAmount(liabiltyQueryString,obj.getProjectId());
		    			Double liabilitycost=0.0;;
		    			for(LEWBReportDto liability:liabilityEstimateEndingPreviousQyarter){
		    				liabilitycost+=liability.getLiabilityEstimateAmount();
		    			}
		    			
		    			rowDataArray[42]=liabilitycost.toString();
		    			
		    			String lastDate1=getDateInNumeric(lastAuditCycleMonthInStr);
		    			String liabiltyQueryString1=" "+"<= to_date(('"+lastAuditCycleMonthInStr+"-"+lastDate1+"-"+lastAuditCycleYear+"'),'MM-DD-YYYY')";
		    			List<LEWBReportDto> liabilityEstimatePreviousAudit=liabilityEstimateAmount(liabiltyQueryString1,obj.getProjectId());
		    			Double previousAuditCycleliabilitycost=0.0;;
		    			for(LEWBReportDto liability:liabilityEstimatePreviousAudit){
		    				previousAuditCycleliabilitycost+=liability.getLiabilityEstimateAmount();
		    			}
		    			
		    			rowDataArray[45]=previousAuditCycleliabilitycost.toString();
		    			
		    		}
		    		
		    		if(obj.getProjectDate()!=null)
		    		{
		    			SimpleDateFormat dateFormat = new SimpleDateFormat(
			                    "MM-dd-yyyy");
			            String stringDate = dateFormat.format(obj.getProjectDate());
						
		    			rowDataArray[51]=stringDate;
		    		}
		    		else
		    		{
		    			rowDataArray[51]="";
		    		}
		    		
		    		List<LEWBReportDto> costsData=	getCostsData(obj.getProjectId());
		    		List<LEWBReportDto> beginingOfYearData=	new ArrayList<LEWBReportDto>();
		    		beginingOfYearData=getBeginingOfYearData(obj.getProjectId(),year);
		    		List<LEWBReportDto> ommCostsData=getOmmCostsData(obj.getProjectId());
		    		
		    		
		    		if (rowCount > 0) 
			    	{
			    		final Row currentRow = sheet.createRow(rowCount);
			    		int j = 0;
		    			for (; j < rowDataArray.length; j++) 
		    			{
			    				final Cell datacell = currentRow.createCell(j);
			    				datacell.setCellValue(rowDataArray[j]);
			    				
			    				if(j!=0 && j!=1 && j==15 && j!=3 && j!=3 && j!=4 && j!=5 && j!=6 && j!=7 && j!=9 && j!=10 && j!=11 && j!=12 && j!=14 && j!=37 && j!=38 && j!=39 && j!=47 && j!=48 && j!=49 && j!=50 && j!=51 && j!=52 && j!=53) 
			    				{
			    					datacell.setCellType(Cell.CELL_TYPE_NUMERIC);
			    				}
			    				
			    				sheet.autoSizeColumn(j);
			    				
			    				CellStyle datastyle = sheet.getWorkbook().createCellStyle();
			    				//style.setFillForegroundColor(IndexedColors.YELLOW.getIndex());
			    				 //style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			    				if(j!=1 && j!=2  && j!=13 && j!=14 && j!=17 && j!=19 && j!=34 && j!=38 && j!=39 && j!=40 && j!=41 && j!=47 && j!=48 && j!=49 && j!=50  && j!=51)
			    				{
			    					datastyle.setFillForegroundColor(HSSFColor.LIGHT_YELLOW.index);
				    				datastyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
			    				}
			    				
			    				datastyle.setBorderTop((short) 1); // single line border
			    				datastyle.setBorderBottom((short) 1);
			    				datastyle.setBorderLeft((short) 1);
			    				 //cellStyle.setLeftBorderColor(IndexedColors.GREEN.getIndex());
			    				datastyle.setBorderRight((short) 1);
			    				
		    					int currentRowNumber=currentRow.getRowNum()+1;
			    				if(j==2)
			    				{
			    					//String strFormula= environment.getProperty(LmsConstants.LIABILITY_ESTIMATE);
			    					//String strFormula=LmsConstants.LIABILITY_ESTIMATE;
			    					//String strFormula1="IF(A2=\"TEST\",1,2)";
			    					
			    					currentRow.getCell(j).setCellType(CellType.FORMULA);
			    					currentRow.getCell(j).setCellFormula("IF($D"+currentRowNumber+"=\"NPV\",(NPV($D$6,$T"+currentRowNumber+":$AI"+currentRowNumber+")),(SUM($T"+currentRowNumber+":$AI"+currentRowNumber+")))*$E"+currentRowNumber+"");
			    				}
			    				
			    				if(j==13)
			    				{
			    					
			    					//String quarterlyLiabilityChangeFormula=LmsConstants.QUARTERLY_LIABILTY_CHANGE;
			    					//String strFormula1="IF(A2=\"TEST\",1,2)";
			    					currentRow.getCell(j).setCellType(CellType.FORMULA);
			    					currentRow.getCell(j).setCellFormula("(C"+currentRowNumber+"-AQ"+currentRowNumber+")+(AS"+currentRowNumber+"-AR"+currentRowNumber+")*E"+currentRowNumber+"");
			    				}
			    				
			    				if(j==14)
			    				{
			    					
			    					List<LEWBReportDto> reasonChange=	getReasonChnage(obj.getProjectId());
			    					if(reasonChange!=null && reasonChange.size()>0){
			    						datacell.setCellValue(reasonChange.get(0).getChangeReasonDesc());
			    					}
			    					else
			    					{
			    						datacell.setCellValue("");
			    					}
			    				}
			    				
			    				if(j==15)
			    				{
			    					
				    				for(LEWBReportDto data:costsData)	
				    				{
				    					if(data.getYear()!=null && !data.getYear().isEmpty() && year.equalsIgnoreCase(data.getYear()))
				    					{
				    						if(data.getCost()!=null && !data.getCost().isEmpty())
				    						{
				    							datacell.setCellValue(data.getCost());
				    						}
				    						
				    						else
				    						{
				    							datacell.setCellValue("");
				    						}
				    						
				    					}
				    						
				    				}
				    				
			    				}
			    				if(j==16)
			    				{
			    					if(beginingOfYearData.size()>0 && beginingOfYearData.get(0).getCost()!=null && !beginingOfYearData.get(0).getCost().isEmpty())
			    					{
			    						datacell.setCellValue(beginingOfYearData.get(0).getCost());
			    					}
			    					
			    					else
			    					{
			    						datacell.setCellValue("");
			    					}
			    					
			    				}
			    					
			    				
			    				
			    				if(j==17)
			    				{
			    					currentRow.getCell(j).setCellType(CellType.FORMULA);
			    					currentRow.getCell(j).setCellFormula("P"+currentRowNumber+"-Q"+currentRowNumber+"");
				    				
			    				}
			    				
			    				if(j==18)
			    				{
			    					if(spentInAmountMap.size()>0)
			    					{
				    				 Double spentInCost=spentInAmountMap.get(obj.getAccountNumberData());
				    				 
					    					if(spentInCost!=null)
					    					{
					    						datacell.setCellValue(spentInCost);
					    					}
					    					
					    					else
					    					{
					    						datacell.setCellValue("");
					    					}
			    					}
			    					else
			    					{
			    							datacell.setCellValue("");
			    					}
			    					
			    					
			    				}
			    				
			    				if(j==19)
			    				{
			    					
			    					//String currentYearRemainingLiability=LmsConstants.CURRENT_YEAR_REMAINING_LIABILITY;
			    					//String strFormula1="IF(A2=\"TEST\",1,2)";
			    					currentRow.getCell(j).setCellType(CellType.FORMULA);
			    					currentRow.getCell(j).setCellFormula("P"+currentRowNumber+"-S"+currentRowNumber+"");
				    				
			    				}
			    				
			    				if(j==20)
			    				{
			    					
				    				for(LEWBReportDto data:costsData)	
				    				{
				    					if(data.getYear()!=null && !data.getYear().isEmpty() && fistYear==Integer.parseInt(data.getYear()))
				    					{
				    						if(data.getCost()!=null && !data.getCost().isEmpty())
				    						{
				    							datacell.setCellValue(data.getCost());
				    						}
				    						
				    						else
				    						{
				    							datacell.setCellValue("");
				    						}
				    						
				    					}
				    						
				    				}
				    				
			    				}
			    				if(j==21)
			    				{
			    					
				    				for(LEWBReportDto data:costsData)	
				    				{
				    					if(data.getYear()!=null && !data.getYear().isEmpty() && secondear==Integer.parseInt(data.getYear()))
				    					{
				    						if(data.getCost()!=null && !data.getCost().isEmpty())
				    						{
				    							datacell.setCellValue(data.getCost());
				    						}
				    						
				    						else
				    						{
				    							datacell.setCellValue("");
				    						}
				    						
				    					}
				    						
				    				}
				    				
			    				}
			    				if(j==22)
			    				{
			    					
				    				for(LEWBReportDto data:costsData)	
				    				{
				    					if(data.getYear()!=null && !data.getYear().isEmpty() && thirdYear==Integer.parseInt(data.getYear()))
				    					{
				    						if(data.getCost()!=null && !data.getCost().isEmpty())
				    						{
				    							datacell.setCellValue(data.getCost());
				    						}
				    						
				    						else
				    						{
				    							datacell.setCellValue("");
				    						}
				    						
				    					}
				    						
				    				}
				    				
			    				}
			    				
			    				if(j==23)
			    				{
			    					
				    				for(LEWBReportDto data:costsData)	
				    				{
				    					if(data.getYear()!=null && !data.getYear().isEmpty() && fourthYear==Integer.parseInt(data.getYear()))
				    					{
				    						if(data.getCost()!=null && !data.getCost().isEmpty())
				    						{
				    							datacell.setCellValue(data.getCost());
				    						}
				    						
				    						else
				    						{
				    							datacell.setCellValue("");
				    						}
				    						
				    					}
				    						
				    				}
				    				
			    				}
			    				
			    				if(j==24)
			    				{
			    					
				    				for(LEWBReportDto data:costsData)	
				    				{
				    					if(data.getYear()!=null && !data.getYear().isEmpty() && fifthYear==Integer.parseInt(data.getYear()))
				    					{
				    						if(data.getCost()!=null && !data.getCost().isEmpty())
				    						{
				    							datacell.setCellValue(data.getCost());
				    						}
				    						
				    						else
				    						{
				    							datacell.setCellValue("");
				    						}
				    						
				    					}
				    						
				    				}
				    				
			    				}
			    				
			    				if(j==25)
			    				{
			    					
				    				for(LEWBReportDto data:costsData)	
				    				{
				    					if(data.getYear()!=null && !data.getYear().isEmpty() && sixtYear==Integer.parseInt(data.getYear()))
				    					{
				    						if(data.getCost()!=null && !data.getCost().isEmpty())
				    						{
				    							datacell.setCellValue(data.getCost());
				    						}
				    						
				    						else
				    						{
				    							datacell.setCellValue("");
				    						}
				    						
				    					}
				    						
				    				}
				    				
			    				}
			    				
			    				if(j==26)
			    				{
			    					
				    				for(LEWBReportDto data:costsData)	
				    				{
				    					if(data.getYear()!=null && !data.getYear().isEmpty() && seventhyear==Integer.parseInt(data.getYear()))
				    					{
				    						if(data.getCost()!=null && !data.getCost().isEmpty())
				    						{
				    							datacell.setCellValue(data.getCost());
				    						}
				    						
				    						else
				    						{
				    							datacell.setCellValue("");
				    						}
				    						
				    					}
				    						
				    				}
				    				
			    				}
			    				
			    				if(j==26)
			    				{
			    					
				    				for(LEWBReportDto data:costsData)	
				    				{
				    					if(data.getYear()!=null && !data.getYear().isEmpty() && eigthYear==Integer.parseInt(data.getYear()))
				    					{
				    						if(data.getCost()!=null && !data.getCost().isEmpty())
				    						{
				    							datacell.setCellValue(data.getCost());
				    						}
				    						
				    						else
				    						{
				    							datacell.setCellValue("");
				    						}
				    						
				    					}
				    						
				    				}
				    				
			    				}
			    				
			    				if(j==27)
			    				{
			    					
				    				for(LEWBReportDto data:costsData)	
				    				{
				    					if(data.getYear()!=null && !data.getYear().isEmpty() && ningthYear==Integer.parseInt(data.getYear()))
				    					{
				    						if(data.getCost()!=null && !data.getCost().isEmpty())
				    						{
				    							datacell.setCellValue(data.getCost());
				    						}
				    						
				    						else
				    						{
				    							datacell.setCellValue("");
				    						}
				    						
				    					}
				    						
				    				}
				    				
			    				}
			    				
			    				if(j==28)
			    				{
			    					
				    				for(LEWBReportDto data:costsData)	
				    				{
				    					if(data.getYear()!=null && !data.getYear().isEmpty() && tenthYear==Integer.parseInt(data.getYear()))
				    					{
				    						if(data.getCost()!=null && !data.getCost().isEmpty())
				    						{
				    							datacell.setCellValue(data.getCost());
				    						}
				    						
				    						else
				    						{
				    							datacell.setCellValue("");
				    						}
				    						
				    					}
				    						
				    				}
				    				
			    				}
			    				
			    				if(j==29)
			    				{
			    					
				    				for(LEWBReportDto data:costsData)	
				    				{
				    					if(data.getYear()!=null && !data.getYear().isEmpty() && eleventhyear==Integer.parseInt(data.getYear()))
				    					{
				    						if(data.getCost()!=null && !data.getCost().isEmpty())
				    						{
				    							datacell.setCellValue(data.getCost());
				    						}
				    						
				    						else
				    						{
				    							datacell.setCellValue("");
				    						}
				    						
				    					}
				    						
				    				}
				    				
			    				}
			    				
			    				if(j==30)
			    				{
			    					
				    				for(LEWBReportDto data:costsData)	
				    				{
				    					if(data.getYear()!=null && !data.getYear().isEmpty() && twelethYear==Integer.parseInt(data.getYear()))
				    					{
				    						if(data.getCost()!=null && !data.getCost().isEmpty())
				    						{
				    							datacell.setCellValue(data.getCost());
				    						}
				    						
				    						else
				    						{
				    							datacell.setCellValue("");
				    						}
				    						
				    					}
				    						
				    				}
				    				
			    				}
			    				
			    				if(j==31)
			    				{
			    					
				    				for(LEWBReportDto data:costsData)	
				    				{
				    					if(data.getYear()!=null && !data.getYear().isEmpty() && thirteenthYear==Integer.parseInt(data.getYear()))
				    					{
				    						if(data.getCost()!=null && !data.getCost().isEmpty())
				    						{
				    							datacell.setCellValue(data.getCost());
				    						}
				    						
				    						else
				    						{
				    							datacell.setCellValue("");
				    						}
				    						
				    					}
				    						
				    				}
				    				
			    				}
			    				
			    				if(j==32)
			    				{
			    					
				    				for(LEWBReportDto data:costsData)	
				    				{
				    					if(data.getYear()!=null && !data.getYear().isEmpty() && fourteenthYear==Integer.parseInt(data.getYear()))
				    					{
				    						if(data.getCost()!=null && !data.getCost().isEmpty())
				    						{
				    							datacell.setCellValue(data.getCost());
				    						}
				    						
				    						else
				    						{
				    							datacell.setCellValue("");
				    						}
				    						
				    					}
				    						
				    				}
				    				
			    				}
			    				
			    				if(j==33)
			    				{
			    					
				    				for(LEWBReportDto data:costsData)	
				    				{
				    					if(data.getYear()!=null && !data.getYear().isEmpty() && fourteenthYear==Integer.parseInt(data.getYear()))
				    					{
				    						if(data.getCost()!=null && !data.getCost().isEmpty())
				    						{
				    							datacell.setCellValue(data.getCost());
				    						}
				    						
				    						else
				    						{
				    							datacell.setCellValue("");
				    						}
				    						
				    					}
				    						
				    				}
				    				
			    				}
			    				
			    				if(j==34)
			    				{
			    					
				    				for(LEWBReportDto data:costsData)	
				    				{
				    					if(data.getYear()!=null && !data.getYear().isEmpty() && fifteenthyear==Integer.parseInt(data.getYear()))
				    					{
				    						if(data.getCost()!=null && !data.getCost().isEmpty())
				    						{
				    							datacell.setCellValue(data.getCost());
				    						}
				    						
				    						else
				    						{
				    							datacell.setCellValue("");
				    						}
				    						
				    					}
				    						
				    				}
				    				
			    				}
			    				
			    				if(j==35)
			    				{
			    					
				    				for(LEWBReportDto data:ommCostsData)	
				    				{
				    					if(data.getCostTypeId()!=null && data.getCostTypeId().equalsIgnoreCase("2"))
				    					{
				    						datacell.setCellValue(data.getCost());
				    					}
				    					else
				    					{
				    						datacell.setCellValue("");
				    					}
				    				}
				    				
			    				}
			    				
			    				if(j==36)
			    				{
			    					
				    				for(LEWBReportDto data:ommCostsData)	
				    				{
				    					if(data.getCostTypeId()!=null && data.getCostTypeId().equalsIgnoreCase("3"))
				    					{
				    						datacell.setCellValue(data.getCost());
				    					}
				    					else
				    					{
				    						datacell.setCellValue("");
				    					}
				    				}
				    				
			    				}
			    				
			    				if(j==37)
			    				{
			    					if(beginingOfYearData.size()>0 && beginingOfYearData.get(0).getBeginingOfYearDate()!=null)
			    					{
			    						SimpleDateFormat dateFormat = new SimpleDateFormat(
			    			                    "MM-dd-yyyy");
			    			            String stringDate = dateFormat.format(beginingOfYearData.get(0).getBeginingOfYearDate());
			    						datacell.setCellValue(stringDate);
			    					}
			    					
			    					else
			    					{
			    						datacell.setCellValue("");
			    					}
			    					
			    				}
			    				

			    				
			    				
			    				
			    				if(j==43)
			    				{
			    					
			    					if(spentToLastQuaterMap.size()>0)
			    					{
				    				 Double spentToCost=spentToLastQuaterMap.get(obj.getAccountNumberData());
				    				 
					    					if(spentToCost!=null)
					    					{
					    						datacell.setCellValue(spentToCost);
					    					}
					    					
					    					else
					    					{
					    						datacell.setCellValue("");
					    					}
			    					}
			    					else
			    					{
			    							datacell.setCellValue("");
			    					}
			    				}
			    				
			    				
			    				if(j==44)
			    				{
			    					
			    					if(spentToLastSelMonthMap.size()>0)
			    					{
				    				 Double spentTolastMonthCost=spentToLastSelMonthMap.get(obj.getAccountNumberData());
				    				 
					    					if(spentTolastMonthCost!=null)
					    					{
					    						datacell.setCellValue(spentTolastMonthCost);
					    					}
					    					
					    					else
					    					{
					    						datacell.setCellValue("");
					    					}
			    					}
			    					else
			    					{
			    							datacell.setCellValue("");
			    					}
			    				}
			    				
			    				if(j==46)
			    				{
			    					
			    					if(spentToLastAuditCycleMap.size()>0)
			    					{
				    				 Double spentTolastAuditCost=spentToLastAuditCycleMap.get(obj.getAccountNumberData());
				    				 
					    					if(spentTolastAuditCost!=null)
					    					{
					    						datacell.setCellValue(spentTolastAuditCost);
					    					}
					    					
					    					else
					    					{
					    						datacell.setCellValue("");
					    					}
			    					}
			    					else
			    					{
			    							datacell.setCellValue("");
			    					}
			    				}
			    				
			    				if(j==53)
			    				{
			    					
			    					currentRow.getCell(j).setCellType(CellType.FORMULA);
			    					currentRow.getCell(j).setCellFormula("IF(BC"+currentRowNumber+"+BD"+currentRowNumber+"+BE"+currentRowNumber+"+BF"+currentRowNumber+"=4,\"Yes\",\"No\")");
			    				}
			    				
			    				if(j==54)
			    				{
			    					
			    					currentRow.getCell(j).setCellType(CellType.FORMULA);
			    					currentRow.getCell(j).setCellFormula("IF(J"+currentRowNumber+"=0,0,IF(J"+currentRowNumber+"<(TODAY()-365),1,0))");
			    				}
			    				
			    				if(j==55)
			    				{
			    					
			    					currentRow.getCell(j).setCellType(CellType.FORMULA);
			    					currentRow.getCell(j).setCellFormula("IF((TODAY()-BA"+currentRowNumber+">365),1,0)");
			    				}
			    				
			    				if(j==56)
			    				{
			    					
			    					currentRow.getCell(j).setCellType(CellType.FORMULA);
			    					currentRow.getCell(j).setCellFormula("IF(SUBTOTAL(4,$BJ"+currentRowNumber+":$CJ"+currentRowNumber+")=0,IF(SUBTOTAL(5,$BJ"+currentRowNumber+":$CJ"+currentRowNumber+")=0,1,0),0)");
			    				}
			    				
			    				if(j==57)
			    				{
			    					
			    					currentRow.getCell(j).setCellType(CellType.FORMULA);
			    					currentRow.getCell(j).setCellFormula("IF(C"+currentRowNumber+"=0,1,0)");
			    				}
			    				
			    				if(j==93)
			    				{
			    					
			    					currentRow.getCell(j).setCellType(CellType.FORMULA);
			    					currentRow.getCell(j).setCellFormula("SUM(BL"+currentRowNumber+":CL"+currentRowNumber+")");
			    				}
			    				
			    				currentRow.getCell(j).setCellStyle(datastyle);
			    				
		    			}
		    			maxCol = j;
			    			
			    	}
		    					
		    		rowCount++;	
		 }
		
		if(reportType.equalsIgnoreCase("QuarterlyAuditBackup")){
			sheet = generateQuarterlyAuditBackupColumns(maxCol,sheet,searchDtoList.size());
		}
    	
    	
        sheet.getWorkbook().write(outputStream);
		outputStream.flush();
	}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	

	
	public Sheet generateQuarterlyAuditBackupColumns(int startIndex,Sheet sheet,int recordCount){
		int rowIndex = 11;
		final Workbook workbook = sheet.getWorkbook();
		LOGGER.info("StartINdex :: "+startIndex);
		LOGGER.info("recordCount :: "+recordCount);
		for(int i = 0 ;i < recordCount;i++){
			final Row currentRow = sheet.getRow(rowIndex);
			int col = 1;
			for (int index = startIndex; index < startIndex+4; index++) 
			{
    				final Cell cell = currentRow.createCell(index);
    				 CellStyle style = workbook.createCellStyle();
    				 DataFormat format = workbook.createDataFormat();
    				 Font font = workbook.createFont();
    	             style.setDataFormat(format.getFormat("_(\"$\"* #,##0_);_(\"$\"* (#,##0);_(\"$\"* \"-\"??_);_(@_)"));
    	             font.setFontHeightInPoints((short) 8);
    	             font.setFontName("Arial");
    	             style.setFont(font);
    	             cell.setCellStyle(style);
    	             cell.setCellType(HSSFCell.CELL_TYPE_FORMULA);
    	             cell.setCellFormula(getQuarterlyBackupFormulaes(col, rowIndex+1));
    	             LOGGER.info("index :: "+index);
    	             LOGGER.info("col :: "+col);
    	             col++;
    	             
			}
			rowIndex++;
		}
		
		return sheet;
	}
	
	public String getQuarterlyBackupFormulaes(int col,int row){
		String formula = "";
		switch(col){
			case 1: formula = "C"+row+"-AR"+row;
					break;
			case 2: formula = "AT"+row+"-AS"+row;
					break;
			case 3: formula = "IF(CJ"+row+">0,CJ"+row+",0)+IF(CK"+row+">0,CK"+row+",0)+IF(CM"+row+">0,CM"+row+",0)+IF(CO"+row+">0,CO"+row+",0)";
					break;
			case 4: formula = "IF(CJ"+row+"<0,CJ"+row+",0)+IF(CK"+row+"<0,CK"+row+",0)+IF(CM"+row+"<0,CM"+row+",0)+IF(CO"+row+"<0,CO"+row+",0)";
					break;
		}
		LOGGER.info("Formula :: "+formula);
		return formula;
	}

	

	

	
	

	private String getlastQuarterNumber(String month) {
		String numericMonth = "00";
		switch(month){
			case "January":
				numericMonth = "1st";
				break;
			case "February":
				numericMonth = "1st";
				break;
			case "March":
				numericMonth = "1st";
				break;
			case "April":
				numericMonth = "2nd";
				break;	
			case "May":
				numericMonth = "2nd";
				break;
			case "June":
				numericMonth = "2nd";
				break;
			case "July":
				numericMonth = "3rd";
				break;
			case "August":
				numericMonth = "3rd";
				break;
			case "September":
				numericMonth = "3rd";
				break;
			case "October":
				numericMonth = "4th";
				break;	
			case "November":
				numericMonth = "4th";
				break;	
			case "December":
				numericMonth = "4th";
				break;		
		}
		return numericMonth;
	}

private List<String> getHeaderArray(String quarterNumber, String month, String year,String yearFlag) {
		

		List<String> headerList = new ArrayList<String>();
		int prev=Integer.parseInt(year)-1;
		switch(quarterNumber){
			case "1st":
				headerList.add("2nd");
				headerList.add("15-Year Rule- 1st qtr");
				if(yearFlag.equalsIgnoreCase("false"))
				{
					headerList.add("January-"+prev+"");
					headerList.add("February-"+prev+"");
					headerList.add("March-"+prev+"");
					headerList.add("false");
				}
				else
				{
					headerList.add("January-"+year+"");
					headerList.add("February-"+year+"");
					headerList.add("March-"+year+"");
					headerList.add("true");
				}
				break;
			case "2nd":
				headerList.add("3rd");
				headerList.add("15-Year Rule- 2nd qtr");
				
				if(yearFlag.equalsIgnoreCase("false"))
				{
					headerList.add("April-"+prev+"");
					headerList.add("May-"+prev+"");
					headerList.add("June-"+prev+"");
					headerList.add("false");
				}
				else
				{
					headerList.add("April-"+year+"");
					headerList.add("May-"+year+"");
					headerList.add("June--"+year+"");
					headerList.add("true");
				}
				
				break;
			case "3rd":
				headerList.add("4th");
				headerList.add("15-Year Rule- 3rd qtr");
				
				if(yearFlag.equalsIgnoreCase("false"))
				{
					headerList.add("July-"+prev+"");
					headerList.add("August-"+prev+"");
					headerList.add("September-"+prev+"");
					headerList.add("false");
				}
				else
				{
					headerList.add("July-"+year+"");
					headerList.add("August"+year+"");
					headerList.add("September--"+year+"");
					headerList.add("true");
				}
				
				break;
			case "4th":
				headerList.add("1st");
				headerList.add("15-Year Rule- 4th qtr");
				
				if(yearFlag.equalsIgnoreCase("false"))
				{
					headerList.add("October-"+prev+"");
					headerList.add("November-"+prev+"");
					headerList.add("December-"+prev+"");
					headerList.add("true");
				}
				else
				{
					headerList.add("October-"+year+"");
					headerList.add("November"+year+"");
					headerList.add("December--"+year+"");
					headerList.add("true");
				}
				break;	
					
		}
		return headerList;
	
	}

	private static void createHeaderRow(final Sheet sheet, final String[] rowContent) {
		
		final Workbook workbook = sheet.getWorkbook();
		
		final Row hiddenRow = sheet.createRow((short)9);
		CellStyle hiddenstyle = workbook.createCellStyle();
		hiddenstyle.setHidden(true);
		hiddenRow.setRowStyle(hiddenstyle);
		hiddenRow.setZeroHeight(true);
		Map<Integer,Boolean> bordersMap = getMapForRow11Borders();
		Map<Integer,Boolean> redFontColorMap = getRedFontColorHeadingsMap();
		Map<Integer,Boolean> rotationMap = getTextRotationMap();
		final Row headerRow = sheet.createRow((short) 10);
		CellStyle headerStyle = workbook.createCellStyle();
		
		headerRow.setHeight((short)1700);
		for (int i = 0; i < rowContent.length; i++) {
			final Cell cell = headerRow.createCell(i);
			final CellStyle style = workbook.createCellStyle();
			final Font font = workbook.createFont();
			font.setFontHeightInPoints((short) 8);
            font.setFontName("Arial");
            style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
            style.setFillPattern(CellStyle.SOLID_FOREGROUND);
            if(bordersMap.containsKey(i)){
            	style.setBorderRight(CellStyle.BORDER_THIN);
            }
            if(redFontColorMap.containsKey(i)){
            	font.setColor(IndexedColors.RED.index);
            }
            
            if(rotationMap.containsKey(i)){
            	style.setRotation((short)90);
            	style.setAlignment(HorizontalAlignment.CENTER);
            	style.setVerticalAlignment(VerticalAlignment.CENTER);
            	
            }
			style.setFont(font);
			//headerRow.setRowStyle(style);
			style.setShrinkToFit(false);
			cell.setCellStyle(style);
			cell.setCellValue(rowContent[i]);
			if(rotationMap.containsKey(i)){
				sheet.setColumnWidth(i, 100 * 256);
			}
			sheet.autoSizeColumn(i);
		}
	}
	
	public static Map<Integer,Boolean> getTextRotationMap(){
		Map<Integer,Boolean> rotationMap = new HashMap<>();
		rotationMap.put(0, true);
		rotationMap.put(3, true);
		rotationMap.put(4, true);
		rotationMap.put(5, true);
		rotationMap.put(6, true);
		rotationMap.put(7, true);
		rotationMap.put(8, true);
		rotationMap.put(11, true);
		rotationMap.put(12, true);
		for(int i = 47; i < 94; i++){
			rotationMap.put(i, true);	
		}
		return rotationMap;
	}
	
	public static Map<Integer,Boolean> getRedFontColorHeadingsMap(){
		Map<Integer,Boolean> redMap = new HashMap<>();
		redMap.put(0, true);
		redMap.put(8, true);
		redMap.put(9, true);
		redMap.put(10, true);
		redMap.put(11, true);
		redMap.put(12, true);
		redMap.put(14, true);
		redMap.put(15, true);
		redMap.put(18, true);
		redMap.put(20, true);
		redMap.put(21, true);
		redMap.put(22, true);
		redMap.put(23, true);
		redMap.put(24, true);
		redMap.put(25, true);
		redMap.put(26, true);
		redMap.put(27, true);
		redMap.put(28, true);
		redMap.put(29, true);
		redMap.put(30, true);
		redMap.put(31, true);
		redMap.put(32, true);
		redMap.put(33, true);
		redMap.put(35, true);
		redMap.put(36, true);
		redMap.put(42, true);
		redMap.put(43, true);
		redMap.put(44, true);
		redMap.put(45, true);
		redMap.put(46, true);
		return redMap;
	}
	
	public static Map<Integer,Boolean> getMapForRow11Borders(){
		Map<Integer,Boolean> bordersMap = new HashMap<>();
		bordersMap.put(2, true);
		bordersMap.put(19, true);
		bordersMap.put(34, true);
		bordersMap.put(37, true);
		bordersMap.put(41, true);
		bordersMap.put(42, true);
		bordersMap.put(43, true);
		bordersMap.put(44, true);
		bordersMap.put(45, true);
		bordersMap.put(46, true);
		bordersMap.put(51, true);
		bordersMap.put(57, true);
		bordersMap.put(58, true);
		bordersMap.put(60, true);
		bordersMap.put(62, true);
		bordersMap.put(64, true);
		bordersMap.put(65, true);
		bordersMap.put(67, true);
		bordersMap.put(69, true);
		bordersMap.put(71, true);
		bordersMap.put(72, true);
		bordersMap.put(74, true);
		bordersMap.put(76, true);
		bordersMap.put(78, true);
		bordersMap.put(79, true);
		bordersMap.put(81, true);
		bordersMap.put(83, true);
		bordersMap.put(85, true);
		bordersMap.put(86, true);
		bordersMap.put(88, true);
		bordersMap.put(90, true);
		bordersMap.put(92, true);
		bordersMap.put(93, true);
		return bordersMap;
	}
  
    public List<LEWBReportDto> getExcelDataFromDb(String month, String year)throws Exception{
	
    	String date=getDateInNumeric(month);
		String fromdate=""+month+"-01-"+year+"";
		String toDate=""+month+"-"+date+"-"+year+"";
		final List<LEWBReportDto> searchDtoList = this.projectSearchService
				.geLEWBtExcelReport(fromdate,toDate);
	
		LOGGER.info("searchdto list size is"+searchDtoList.size());
		return searchDtoList;
	//	Sheet sheet=exportDataToExcel(searchDtoList);
		//write(response,sheet, "Projects Report.xls");
		
	}
    
    public List<LEWBReportDto> getReasonChnage(Integer projectId)throws Exception{
    	
		final List<LEWBReportDto> reasonChnage = this.projectSearchService
				.getReasonChnage(projectId);
		LOGGER.info("searchdto list size is"+reasonChnage.size());
		return reasonChnage;
	//	Sheet sheet=exportDataToExcel(searchDtoList);
		//write(response,sheet, "Projects Report.xls");
		
	}
    
    private List<LEWBReportDto> getCostsData(Integer projectId) {
		// TODO Auto-generated method stub
    	final List<LEWBReportDto> costsDatafromdb = this.projectSearchService
				.getCostsData(projectId);
		LOGGER.info("searchdto list size is"+costsDatafromdb.size());
		return costsDatafromdb;
	}
    
    private List<LEWBReportDto> getBeginingOfYearData(Integer projectId, String year) {
    	final List<LEWBReportDto> costsDatafromdb = this.projectSearchService
				.getBeginingOfYearData(projectId,year);
		LOGGER.info("searchdto list size is"+costsDatafromdb.size());
		return costsDatafromdb;
	}
    
    public String getQuartersBasedOnQuarter(String selectedQuarter,int year){
    	String quarter = "";
    	switch(selectedQuarter){
    		
    	case "1st":
    		quarter = "4th Quarter "+ (year-1);
    		break;
	    case "2nd":
			quarter = "1st Quarter "+ year;
			break;
		case "3rd":
			quarter = "2nd Quarter "+ year;
			break;
		case "4th":
			quarter = "3rd Quarter "+ year;
			break;
    	}
    	
    	return quarter;
    }
    
    public void generateLEWBHeaders(final Sheet sheet,String[] excelHeader,int rowCount,String month,String year){
    	List<String[]> headersList = new ArrayList<>(10);
    	
    	String row9Formula = "COUNTIF(I12:I"+rowCount+",\"<7\")";
    	
    	String selectedQuarter = getlastQuarterNumber(month)+" Quarter "+year;
    	String quarterHeading = getQuartersBasedOnQuarter(selectedQuarter.split(" ")[0],Integer.parseInt(selectedQuarter.split(" ")[2]));
    	String quarterHeading1 = getQuartersBasedOnQuarter(quarterHeading.split(" ")[0],Integer.parseInt(quarterHeading.split(" ")[2]));
    	String quarterHeading2 = getQuartersBasedOnQuarter(quarterHeading1.split(" ")[0],Integer.parseInt(quarterHeading1.split(" ")[2]));
    	String quarterHeading3 = getQuartersBasedOnQuarter(quarterHeading2.split(" ")[0],Integer.parseInt(quarterHeading2.split(" ")[2]));
    	
    	String[] row6 = {"","","NPV Rate =","0%"};
    	String[] row7 = {generateFormulaHeaders("row7", rowCount)};
    	String[] row8 = {generateFormulaHeaders("row8", rowCount)};
    	
    	String[] row9 = {"",row9Formula,"Active Site Count","Discounts","","Basis of Estimate","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","15 Year Accrual","","","Account","","","","Quaterly Change Data","","","Audit Committee Data","","EPIC Data Reference","","","","","EPIC Data Reference","","","","","",quarterHeading3,"","","","","","",quarterHeading2,"","","","","","",quarterHeading1,"","","","","","",quarterHeading ,"","","","","","",selectedQuarter,"","","","","","",""};
    	
    	headersList.add(row6);
    	headersList.add(row7);
    	headersList.add(row8);
    	headersList.add(row9);
    	
    	short index = 5;
    	for(String[] rowContent : headersList){
    		final Row headerRow = sheet.createRow(index);
    		final Workbook workbook = sheet.getWorkbook();
    		
    		for (int i = 0; i < rowContent.length; i++) {
    			
    			if(rowContent[i].contains("#")){
    				int j = 0;
    				for(String content : rowContent[i].split("#")){
    					final Cell cell = headerRow.createCell(j);
    	    			final CellStyle style = workbook.createCellStyle();
    	    			final Font font = workbook.createFont();
    					DataFormat format = workbook.createDataFormat();
    	                font.setFontHeightInPoints((short) 8);
    	            	font.setFontName("Arial");
     	                style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
     	                style.setFillPattern(CellStyle.SOLID_FOREGROUND);
     	                if(content.contains("SUBTOTAL(3") || content.contains("COUNTA")){
     	                	style.setAlignment(CellStyle.ALIGN_RIGHT);
     	                }else{
     	                	style.setDataFormat(format.getFormat("_(\"$\"* #,##0_);_(\"$\"* (#,##0);_(\"$\"* \"-\"??_);_(@_)"));
     	                }
     	                
    	            	style.setFont(font);
    	            	if(index == 6){
    	            		 style.setBorderTop(CellStyle.BORDER_THIN);
    	            	}else if (index == 7){
    	            		 style.setBorderBottom(CellStyle.BORDER_THIN);
    	            	}
    	            	
    	            	cell.setCellStyle(style);
    	            	if(content.length() > 4 && j > 0){
    	            		cell.setCellType(HSSFCell.CELL_TYPE_FORMULA);
        	                cell.setCellFormula(content);	
    	            	}else{
    	            		cell.setCellValue(content);
    	            	}
    	                
    	    			//sheet.autoSizeColumn(j);
    	    			j++;
    				}
    			}else{
    				final Cell cell = headerRow.createCell(i);
        			final CellStyle style = workbook.createCellStyle();
        			final Font font = workbook.createFont();
        			font.setFontHeightInPoints((short) 8);
    	            font.setFontName("Arial");
    	            if(index == 5){
    	            	if(rowContent[i].length() > 1){
    	            		style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
            	            style.setFillPattern(CellStyle.SOLID_FOREGROUND);	
    	            	}
    	            }else{
    	            	if(index == 8){
    	            		style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
            	            style.setFillPattern(CellStyle.SOLID_FOREGROUND);	
            	            style.setBorderTop(CellStyle.BORDER_THIN);
            	            style.setBorderBottom(CellStyle.BORDER_THIN);
            	            if(rowContent[i].length() > 1){
            	            	style.setBorderLeft(CellStyle.BORDER_THIN);
            	            }
    	            	}
    	            		
    	            }
        			style.setFont(font);
        			style.setShrinkToFit(false);
        			cell.setCellStyle(style);
        			if(index == 8 && i == 1){
        				cell.setCellType(HSSFCell.CELL_TYPE_FORMULA);
    	                cell.setCellFormula(rowContent[i]);	
	            	}else{
	            		cell.setCellValue(rowContent[i]);	
	            	}
        			
        			sheet.autoSizeColumn(i);
    			}
    			
    		}
    		index++;
    	}
		
    }
    
    public String generateFormulaHeaders(String row,int listCount){
    	char[] alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".toCharArray();
    	String formulaHeader = "";
    	String formula = "";
    	String currentLetter = "A";
    	String nextLetter = "B";
    	int colLength = 94;
    	int outerIndex = 0;
    	int innerIndex = 0;
    	boolean skipFirstIndex = true;
    	Map<Integer,String> emptyMap = generateEmptyMap();
    	
    	for(int i = 0; i < colLength; i++){
    		if(emptyMap.containsKey(i)){
    			formula = " ";
    		}else{
    			if(nextLetter.length() == 1){
    				if(skipFirstIndex){
    					if(row.equalsIgnoreCase("row7"))
    						formula = "Subtotals =";
    					else if(row.equalsIgnoreCase("row8")){
    						formula = " ";
    					}
    					skipFirstIndex = false;
    				}else{
    					if(i == 1 || i == 5 || i == 6 || i == 7 || i == 10 || i == 11 || i == 12 ){
    						if(row.equalsIgnoreCase("row7")){
    							formula = formula + "SUBTOTAL(3,"+Character.toString(alphabet[innerIndex])+"12:"+Character.toString(alphabet[innerIndex])+listCount+")";
    						}
        					else if(row.equalsIgnoreCase("row8")){
        						formula = formula + "COUNTA("+Character.toString(alphabet[innerIndex])+"12:"+Character.toString(alphabet[innerIndex])+listCount+")";
        					}
    						
    					}else{
    						if(row.equalsIgnoreCase("row7")){
    							formula = formula + "SUBTOTAL(9,"+Character.toString(alphabet[innerIndex])+"12:"+Character.toString(alphabet[innerIndex])+listCount+")";
    						}
        					else if(row.equalsIgnoreCase("row8")){
        						formula = formula + "SUM("+Character.toString(alphabet[innerIndex])+"12:"+Character.toString(alphabet[innerIndex])+listCount+")";
        					}
    						
                			currentLetter = Character.toString(alphabet[innerIndex]);
                			if(innerIndex+1 > 25){
                				nextLetter = Character.toString(alphabet[outerIndex]) + Character.toString(alphabet[innerIndex]);
                			}	
    					}
    				}
        			
        		}else{
        			if(row.equalsIgnoreCase("row7")){
        				formula = formula + "SUBTOTAL(9,"+Character.toString(alphabet[outerIndex]) + Character.toString(alphabet[innerIndex])+"12:"+Character.toString(alphabet[outerIndex]) + Character.toString(alphabet[innerIndex])+listCount+")";
					}
					else if(row.equalsIgnoreCase("row8")){
						formula = formula + "SUM("+Character.toString(alphabet[outerIndex]) + Character.toString(alphabet[innerIndex])+"12:"+Character.toString(alphabet[outerIndex]) + Character.toString(alphabet[innerIndex])+listCount+")";
					}
        			
        			currentLetter = Character.toString(alphabet[outerIndex]) + Character.toString(alphabet[innerIndex]);
        		}
    		}
    		innerIndex++;
    		if(innerIndex > 25){
    			innerIndex = 0;
    			if(currentLetter.length() > 1 ){
    				outerIndex++;
    			}
    		}
    		
    		if(i+1 == colLength){
    			formulaHeader = formulaHeader + formula;
    		}else{
    			formulaHeader = formulaHeader + formula +"#";
    		}
    		
    		formula = "";
    		
    	}
    		
    	
    	
		return formulaHeader;
    	
    }
    
    public Map<Integer,String> generateEmptyMap(){
    	Map<Integer,String> emptyMap = new HashMap<>();
    	emptyMap.put(4, "");
    	emptyMap.put(8, "");
    	emptyMap.put(9, "");
    	emptyMap.put(37, "");
    	emptyMap.put(38, "");
    	emptyMap.put(39, "");
    	emptyMap.put(40, "");
    	emptyMap.put(41, "");
    	emptyMap.put(47, "");
    	emptyMap.put(48, "");
    	emptyMap.put(49, "");
    	emptyMap.put(50, "");
    	emptyMap.put(51, "");
    	emptyMap.put(52, "");
    	emptyMap.put(53, "");
    	emptyMap.put(54, "");
    	emptyMap.put(55, "");
    	emptyMap.put(56, "");
    	emptyMap.put(57, "");
    	emptyMap.put(60, "");
    	emptyMap.put(62, "");
    	emptyMap.put(64, "");
    	emptyMap.put(67, "");
    	emptyMap.put(69, "");
    	emptyMap.put(71, "");
    	emptyMap.put(74, "");
    	emptyMap.put(76, "");
    	emptyMap.put(78, "");
    	emptyMap.put(81, "");
    	emptyMap.put(83, "");
    	emptyMap.put(85, "");
    	emptyMap.put(88, "");
    	emptyMap.put(90, "");
    	emptyMap.put(92, "");
    	
    	return emptyMap;
    }
    
    public static String getDateInNumeric(String month){
		String numericMonth = "00";
		switch(month){
			case "January":
				numericMonth = "31";
				break;
			case "February":
				numericMonth = "28";
				break;
			case "March":
				numericMonth = "31";
				break;
			case "April":
				numericMonth = "30";
				break;	
			case "May":
				numericMonth = "31";
				break;
			case "June":
				numericMonth = "30";
				break;
			case "July":
				numericMonth = "31";
				break;
			case "August":
				numericMonth = "31";
				break;
			case "September":
				numericMonth = "30";
				break;
			case "October":
				numericMonth = "31";
				break;	
			case "November":
				numericMonth = "30";
				break;	
			case "December":
				numericMonth = "31";
				break;		
		}
		return numericMonth;
	}
    
    private List<BusinessPrepPlanDTO> spentAmount(String queryString) {
    	
    	List<BusinessPrepPlanDTO> teradataList = projectSearchService.getspentAmount(queryString);
		return teradataList;
	}
    
    private List<LEWBReportDto> getOmmCostsData(Integer projectId) {
    	final List<LEWBReportDto> ommCostdata = this.projectSearchService
				.getOmmCostsData(projectId);
		LOGGER.info("searchdto list size is"+ommCostdata.size());
		return ommCostdata;
	}
    
    private Map<String, Double> getamountMap(List<BusinessPrepPlanDTO> spentInAmount) {
		// TODO Auto-generated method stub
    	Map<String, Double> spentInAmountMap=new HashMap<String, Double>();
    	List<String> networkIds=new ArrayList<String>();
    	for(BusinessPrepPlanDTO businessPrepPlanDTO:spentInAmount){
    		if(networkIds.contains(businessPrepPlanDTO.getNetwork()))
    		{
    			Double d=spentInAmountMap.get(businessPrepPlanDTO.getNetwork());
    			d=d+Double.parseDouble(businessPrepPlanDTO.getAmount());
    			spentInAmountMap.put(businessPrepPlanDTO.getNetwork(), d);
    		}
    		else
    		{
    			spentInAmountMap.put(businessPrepPlanDTO.getNetwork(), Double.parseDouble(businessPrepPlanDTO.getAmount()));
        		networkIds.add(businessPrepPlanDTO.getNetwork());
    		}
    		
    		
    	}
		return spentInAmountMap;
	}
    
    private List<LEWBReportDto> liabilityEstimateAmount(String liabiltyQueryString, Integer projectId) {
    	final List<LEWBReportDto> liabilityEstimatesData = this.projectSearchService
				.getliabilityEstimateAmount(liabiltyQueryString,projectId);
    	LOGGER.info("searchdto list size is"+liabilityEstimatesData.size());
		return liabilityEstimatesData;	
		}
    
    

}
