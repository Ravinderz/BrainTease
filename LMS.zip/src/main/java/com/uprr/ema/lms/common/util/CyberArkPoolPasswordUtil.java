package com.uprr.ema.lms.common.util;

import java.util.List;

import org.apache.tomcat.jdbc.pool.PoolProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.uprr.app.iae.cyberark.client.CyberArkClient;
import com.uprr.app.iae.cyberark.client.dto.CyberArkPasswordRequestDTO;
import com.uprr.app.iae.cyberark.client.dto.CyberArkPasswordResponseDTO;
import com.uprr.ema.lms.common.constant.LmsConstants;
import com.uprr.ema.lms.common.enums.EnvironmentType;

public class CyberArkPoolPasswordUtil extends PoolProperties { 
	private static final long serialVersionUID = 4518945943615732572L;
	private static final Logger LOGGER = LoggerFactory.getLogger(CyberArkPoolPasswordUtil.class);  
	
	private  String appTLA;
	private  String appID;
	private  String type;
	private String instance;
	private  String runEnv;
	private String localEnvPassword;
	public CyberArkPoolPasswordUtil() {
		//Auto-generated constructor stub
	}
	
	/**
	 *This method is used to get the password from CyberArk
	 * 
	 * @return
	 */
	public String getPasswordFromCyberArk() {
		String response = null;
		if (isValidEnv()) {
			/*if(System.getProperty(LmsConstants.UPRR_IMPLEMENTATION_ENVIRONMENT).equalsIgnoreCase("dev") && getType().equalsIgnoreCase("teradata")){
				response = getLocalEnvPassword();
			}else{*/
				String password = null;
				CyberArkPasswordResponseDTO passwordDetails = null;
				try {
					CyberArkPasswordRequestDTO cyberArkPasswordRequest = new CyberArkPasswordRequestDTO();
					cyberArkPasswordRequest.setEnvironment(getRunEnv());
					cyberArkPasswordRequest.setSystem(getType()); 
					cyberArkPasswordRequest.setTla(getAppTLA());
					cyberArkPasswordRequest.setApplicationId(getAppID());
					cyberArkPasswordRequest.setResource(getInstance()); 
					CyberArkClient cyberArkClientObj = new CyberArkClient();
					passwordDetails = cyberArkClientObj.getPassword(cyberArkPasswordRequest);
					if(passwordDetails != null) {
						password = passwordDetails.getPassword();
					}
					LOGGER.info("Password Retrieval Successful for the instance : {0} ",getInstance());
					System.out.println("Password Retrieval Successful for the instance : "+getInstance());
				} catch (Exception exception) {
					LOGGER.error("Error occurred while retrieving the Password from CyberArk for the instance :{} with the exception {}",getInstance(), exception);
				}	
				response = password;
			/*}*/
		}
		else {		
			response = getLocalEnvPassword();
		}
		return response;
		
	}
	
	/**
	 * This method checks logged in users environment.
	 * 
	 * @return the boolean
	 */
	public static Boolean isValidEnv() {
		boolean isValidEnv = false;
		String envProperty = System.getProperty(LmsConstants.UPRR_IMPLEMENTATION_ENVIRONMENT);
		List<String> envLst = EnvironmentType.getListOfEnvironemnts();
		if (envLst.contains(envProperty)) {
			isValidEnv = true;
		}
		return isValidEnv;
	}	
	
	/**
	 * @return the appTLA
	 */
	public String getAppTLA() {
		return appTLA;
	}
	/**
	 * @param appTLA the appTLA to set
	 */
	public void setAppTLA(String appTLA) {
		this.appTLA = appTLA;
	}
	/**
	 * @return the appID
	 */
	public String getAppID() {
		return appID;
	}
	/**
	 * @param appID the appID to set
	 */
	public void setAppID(String appID) {
		this.appID = appID;
	}
	
	/**
	 * @return the instance
	 */
	public String getInstance() {
		return instance;
	}

	/**
	 * @param instance the instance to set
	 */
	public void setInstance(String instance) {
		this.instance = instance;
	}

	/**
	 * @return the localEnvPassword
	 */
	public String getLocalEnvPassword() {
		return localEnvPassword;
	}

	/**
	 * @param localEnvPassword the localEnvPassword to set
	 */
	public void setLocalEnvPassword(String localEnvPassword) {
		this.localEnvPassword = localEnvPassword;
	}
	
	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return the runEnv
	 */
	public String getRunEnv() {
		return runEnv;
	}
	/**
	 * @param runEnv the runEnv to set
	 */
	public void setRunEnv(String runEnv) {
		this.runEnv = runEnv;
	}
	@Override
	public boolean isJmxEnabled() {
		return false;
	}

	@Override
	public boolean isPoolSweeperEnabled() {
		return true;
	}

	@Override
	public String getUsername() {
		return getAppID();
	}

	@Override
	public String getPassword() {
		return getPasswordFromCyberArk();
	}
}
