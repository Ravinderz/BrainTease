package com.uprr.ema.lms.springconfig;

import org.springframework.context.annotation.Bean;

import com.uprr.ui.shared.user.spring.mvc.UserValidationFilter;

/**
 * This configuration file contains ServletFilters 
 * that will be used by the DelegatingFilterProxy in the ApplicationInitializer
 * Note the bean name given each filter must match the name of the filter in the application context 
 */
public class FilterConfig {
    
    public static final String USER_VALIDATION_FILTER = "userValidationFilter";
    
    @Bean(name=USER_VALIDATION_FILTER)
    public UserValidationFilter createUserValidationFilter() {
        return new UserValidationFilter();
    }
}
