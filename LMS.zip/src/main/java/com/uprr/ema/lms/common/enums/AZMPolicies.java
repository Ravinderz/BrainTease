package com.uprr.ema.lms.common.enums;

/**
 * All Enum Constructers declared as per below Naming Covention
 * <Feature-Id>_<Action_id>
 * @author xprk481
 *
 */
public enum AZMPolicies {
	
	PROJECT_Create("create","project","environmental-liabilities","S","P"),PROJECT_Aprv("approve","project","environmental-liabilities","A","P"),PROJECT_Dprv("disapprove","project","environmental-liabilities","U","P"),PROJECT_Update("update","project","environmental-liabilities","S","P"),
	PROJECT_CHANGE_Aprv("approve","project-update","environmental-liabilities","A","C"),PROJECT_CHANGE_Dprv("disapprove","project-update","environmental-liabilities","U","C"),PROJECT_CHANGE_Create("create","project-update","environmental-liabilities","S","C"),PROJECT_CHANGE_Update("update","project-update","environmental-liabilities","S","C"),
	PROJECT_SUMMERIES_View("view","project-summaries","environmental-liabilities","",""),
	WORKBOOK_Archive("archive","workbook","environmental-liabilities","",""),
	LESS_SENSITIVE_REPORTS_View("view","less-sensitive-reports","environmental-liabilities","",""),
	SENSITIVE_REPORTS_View("view","sensitive-reports","environmental-liabilities","",""),
	MASTER_TABLE_DATA_Add("add","master-table-data","environmental-liabilities","",""),MASTER_TABLE_DATA_Update("update","master-table-data","environmental-liabilities","","");
	
	private String feature_id;
	private String resource_id;
	private String action_id;
	private String action_code;
	private String action_type_code;
	
	AZMPolicies(final String action_id,final String feature_id,final String resource_id,final String action_code,final String action_type_code){
		//this.subject_id=subject_id;
		this.action_id=action_id;
		this.feature_id=feature_id;
		this.resource_id=resource_id;
		this.action_code=action_code;
		this.action_type_code=action_type_code;
	}


	/**
	 * @return the feature_id
	 */
	public String getFeature_id() {
		return feature_id;
	}

	/**
	 * @param feature_id the feature_id to set
	 */
	public void setFeature_id(String feature_id) {
		this.feature_id = feature_id;
	}

	/**
	 * @return the resource_id
	 */
	public String getResource_id() {
		return resource_id;
	}

	/**
	 * @param resource_id the resource_id to set
	 */
	public void setResource_id(String resource_id) {
		this.resource_id = resource_id;
	}

	/**
	 * @return the action_id
	 */
	public String getAction_id() {
		return action_id;
	}

	/**
	 * @param action_id the action_id to set
	 */
	public void setAction_id(String action_id) {
		this.action_id = action_id;
	}


	/**
	 * @return the action_code
	 */
	public String getAction_code() {
		return action_code;
	}


	/**
	 * @param action_code the action_code to set
	 */
	public void setAction_code(String action_code) {
		this.action_code = action_code;
	}


	/**
	 * @return the action_type_code
	 */
	public String getAction_type_code() {
		return action_type_code;
	}


	/**
	 * @param action_type_code the action_type_code to set
	 */
	public void setAction_type_code(String action_type_code) {
		this.action_type_code = action_type_code;
	}
	

}
