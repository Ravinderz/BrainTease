package com.uprr.ema.lms.reports.dto;

import java.util.List;
import java.util.Objects;

public class SiteSourceDTO {

	private int num;
	private String projName;
	private String railRoadCode;
	private String projSrcDesc;
	private String state;
	private String projStartDate;
	private String projClosedDate;
	private String spendYear;
	private String amount;
	private String network;
	private List<String> spendingPerYear;
	private String fifteenYrRule;
	private String totalUpSpending;
	private String totalPreMergerSpending;
	private String totalProjectSpending;
	private String QuarterELC;
	private String totalCommittedCost;
	
	
	public int getNum() {
		return num;
	}
	public String getSpendYear() {
		return spendYear;
	}
	public void setSpendYear(String spendYear) {
		this.spendYear = spendYear;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getNetwork() {
		return network;
	}
	public void setNetwork(String network) {
		this.network = network;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getProjName() {
		return projName;
	}
	public void setProjName(String projName) {
		this.projName = projName;
	}
	public String getRailRoadCode() {
		return railRoadCode;
	}
	public void setRailRoadCode(String railRoadCode) {
		this.railRoadCode = railRoadCode;
	}
	public String getProjSrcDesc() {
		return projSrcDesc;
	}
	public void setProjSrcDesc(String projSrcDesc) {
		this.projSrcDesc = projSrcDesc;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getProjStartDate() {
		return projStartDate;
	}
	public void setProjStartDate(String projStartDate) {
		this.projStartDate = projStartDate;
	}
	public String getProjClosedDate() {
		return projClosedDate;
	}
	public void setProjClosedDate(String projClosedDate) {
		this.projClosedDate = projClosedDate;
	}

	public String getFifteenYrRule() {
		return fifteenYrRule;
	}
	public void setFifteenYrRule(String fifteenYrRule) {
		this.fifteenYrRule = fifteenYrRule;
	}
	public List<String> getSpendingPerYear() {
		return spendingPerYear;
	}
	public void setSpendingPerYear(List<String> spendingPerYear) {
		this.spendingPerYear = spendingPerYear;
	}
	
	public String getTotalUpSpending() {
		return totalUpSpending;
	}
	public void setTotalUpSpending(String totalUpSpending) {
		this.totalUpSpending = totalUpSpending;
	}
	public String getTotalPreMergerSpending() {
		return totalPreMergerSpending;
	}
	public void setTotalPreMergerSpending(String totalPreMergerSpending) {
		this.totalPreMergerSpending = totalPreMergerSpending;
	}
	public String getTotalProjectSpending() {
		return totalProjectSpending;
	}
	public void setTotalProjectSpending(String totalProjectSpending) {
		this.totalProjectSpending = totalProjectSpending;
	}
	public String getQuarterELC() {
		return QuarterELC;
	}
	public void setQuarterELC(String quarterELC) {
		QuarterELC = quarterELC;
	}
	public String getTotalCommittedCost() {
		return totalCommittedCost;
	}
	public void setTotalCommittedCost(String totalCommittedCost) {
		this.totalCommittedCost = totalCommittedCost;
	}
	public SiteSourceDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	@Override
	public String toString() {
		return "SiteSourceDTO [num=" + num + ", projName=" + projName + ", railRoadCode=" + railRoadCode
				+ ", projSrcDesc=" + projSrcDesc + ", state=" + state + ", projStartDate=" + projStartDate
				+ ", projClosedDate=" + projClosedDate + ", spendYear=" + spendYear + ", amount=" + amount
				+ ", network=" + network + ", spendingPerYear=" + spendingPerYear + ", fifteenYrRule=" + fifteenYrRule
				+ ", totalUpSpending=" + totalUpSpending + ", totalPreMergerSpending=" + totalPreMergerSpending
				+ ", totalProjectSpending=" + totalProjectSpending + ", QuarterELC=" + QuarterELC
				+ ", totalCommittedCost=" + totalCommittedCost + "]";
	}

	public SiteSourceDTO(int num, String projName, String railRoadCode, String projSrcDesc, String state,
			String projStartDate, String projClosedDate, String spendYear, String amount, String network,
			List<String> spendingPerYear, String fifteenYrRule, String totalUpSpending, String totalPreMergerSpending,
			String totalProjectSpending, String quarterELC, String totalCommittedCost) {
		super();
		this.num = num;
		this.projName = projName;
		this.railRoadCode = railRoadCode;
		this.projSrcDesc = projSrcDesc;
		this.state = state;
		this.projStartDate = projStartDate;
		this.projClosedDate = projClosedDate;
		this.spendYear = spendYear;
		this.amount = amount;
		this.network = network;
		this.spendingPerYear = spendingPerYear;
		this.fifteenYrRule = fifteenYrRule;
		this.totalUpSpending = totalUpSpending;
		this.totalPreMergerSpending = totalPreMergerSpending;
		this.totalProjectSpending = totalProjectSpending;
		QuarterELC = quarterELC;
		this.totalCommittedCost = totalCommittedCost;
	}
/*	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((network == null) ? 0 : network.hashCode());
		return result;
		
	}
	
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SiteSourceDTO other = (SiteSourceDTO) obj;
		if (network == null) {
			if (other.network != null)
				return false;
		} else if (!network.equals(other.network))
			return false;
		return true;
	}*/
	
	//Above JDK 7 we can generate hashcode and equals using Objects class
	@Override
	public int hashCode() {
		return Objects.hash(network);
	}
	
	
	@Override
	public boolean equals(Object obj) {
		if (obj == this) return true;
        if (!(obj instanceof SiteSourceDTO)) {
            return false;
        }
        SiteSourceDTO dto = (SiteSourceDTO) obj;
        return Objects.equals(network, dto.network);
	}
	
	
}
