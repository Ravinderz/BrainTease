package com.uprr.ema.lms.springconfig;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.scheduling.annotation.EnableScheduling;

import com.uprr.ema.lms.data.config.DataConfig;
import com.uprr.ema.lms.email.ENAConfig;
import com.uprr.ema.lms.springconfig.common.MVCConfig;
import com.uprr.ema.lms.springconfig.trn.ServiceConfig;

/**
 * This is the hub "Main" config, the first configuration file triggered by the ApplicationInitializer 
 */
@Configuration
@EnableScheduling 
@Import({ PropertyConfig.class, ServiceConfig.class, MVCConfig.class, FilterConfig.class, DataConfig.class,AspectJConfig.class,ENAConfig.class })
public class MainConfig {
}
