package com.uprr.ema.lms.common.service.impl;

import java.io.IOException;
import java.util.Arrays;
import java.util.Map;

import javax.annotation.Resource;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.uprr.app.doc.utility_managed_content_upload_document_1_0.dto.UtilityManagedContentUploadDocumentRequest;
import com.uprr.ema.lms.common.enums.DocsServiceNames;
import com.uprr.ema.lms.common.service.api.IDocumentService;
import com.uprr.enterprise.client.auth.spring.interceptor.EsbClientRestTemplateCustomizer;
import com.uprr.enterprise.security.credential.simple.SimpleCredentialProvider;
import com.uprr.enterprise.shared.components.credential.cyberark.CyberArkCredentialProvider;

@Service
@PropertySource("classpath:common/common.properties")
public class DocumentServiceImpl implements IDocumentService{
	
	@Value("${esb2.url}")
	private String esbUrl;
	
	@Resource(name = "appCredentialProvider")
	private CyberArkCredentialProvider appCredentialProvider;

	@Override
	public String uploadDocument(MultipartFile file) throws IOException{
		RestTemplate restTemplate = createRestTemplate();
		final String fileName = file.getOriginalFilename();
		
		UtilityManagedContentUploadDocumentRequest request = new UtilityManagedContentUploadDocumentRequest();
		request.setApplication(DocsServiceNames.getAppName());
		request.setMimeType("text/plain");
		request.setOwner(DocsServiceNames.getOwnerName());
		//request.setRetentionExpiration(UTCDateTime.createAmbiguousUTCDateTime(2019, 12,12,12,12,12, TimeZoneEnum.AMERICA_CHICAGO));
		request.setFileName(fileName);
		ByteArrayResource fileAsResource = new ByteArrayResource(file.getBytes()) {
			@Override
			public String getFilename() {
					return fileName;
				}
		};
		MultiValueMap<String, Object> map = new LinkedMultiValueMap<>();
		ObjectMapper mapper = new ObjectMapper();
		map.add("properties", mapper.writeValueAsString(request));
		map.add("file", fileAsResource);
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.MULTIPART_FORM_DATA);
		HttpEntity<MultiValueMap<String, Object>> requestHttpEntity = new HttpEntity<>(map, headers);
		System.out.println(this.esbUrl);
		System.out.println(DocsServiceNames.getUploadServiceName());
		ResponseEntity<String> response = restTemplate.exchange(this.esbUrl+DocsServiceNames.getUploadServiceName(), HttpMethod.POST, requestHttpEntity, String.class);
		String body = response.getBody();
		System.out.println(body);
		JSONObject jsonObj = new JSONObject(body.substring(0, body.length()).trim());
		Map<String, Object> docMap = jsonObj.toMap();
		Map<String, Object> valueMap = (Map<String, Object>) docMap.get("document-identifiers");
		String guid = ((String)valueMap.get("document-id"));
		return guid;
	}

	@Override
	public byte[] downloadDocument(String guid) {
		RestTemplate restTemplate = createRestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_OCTET_STREAM));
		HttpEntity<String> entity = new HttpEntity<>(headers);
		final StringBuilder uri = new StringBuilder(this.esbUrl+DocsServiceNames.getDownloadServiceName()+"?document-identifier=").append(guid.trim());
		ResponseEntity<byte[]> response = restTemplate.exchange(uri.toString(), HttpMethod.GET, entity, byte[].class);
		byte[] file = response.getBody();
		return file;
	}
	
	public RestTemplate createRestTemplate() {
		//SimpleCredentialProvider scp = new SimpleCredentialProvider(appCredentialProvider.getPrincipal(), appCredentialProvider.getPassword());
		SimpleCredentialProvider scp = new SimpleCredentialProvider("d00047f","Hoce6fsNLcwECii");
		System.setProperty("uprr.implementation.environment","dev");
		EsbClientRestTemplateCustomizer customizer = new EsbClientRestTemplateCustomizer(scp);
		
    	RestTemplate restTemplate = new RestTemplate();
        customizer.customize(restTemplate);
		return restTemplate;
	}

}
