package com.uprr.ema.lms.springconfig.common;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.env.Environment;
import org.springframework.format.FormatterRegistrar;
import org.springframework.format.support.FormattingConversionService;
import org.springframework.format.support.FormattingConversionServiceFactoryBean;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.multipart.MultipartResolver;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport;
import org.springframework.web.servlet.mvc.WebContentInterceptor;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.uprr.app.azm.cache.AzmCache;
import com.uprr.app.azm.common.AuthorizationService;
import com.uprr.app.azm.common.AzmSecurityUtils;
import com.uprr.app.azm.common.CacheableSecurityUtils;
import com.uprr.app.azm.common.RestAuthorizationService;
import com.uprr.app.azm.jcs.JcsAzmCache;
import com.uprr.azm.shared.mvc.security.authorization.AuthorizationInterceptor;
import com.uprr.azm.shared.mvc.security.authorization.AuthorizationManager;
import com.uprr.azm.shared.mvc.security.authorization.impl.AzmAuthorizationManager;
import com.uprr.ema.lms.common.enums.DocsServiceNames;
import com.uprr.ema.lms.controller.UPAlertErrorInterceptor;
import com.uprr.enterprise.datetime.jackson2.serialization.UTCDateTimeCoreModule2;
import com.uprr.enterprise.datetime.springmvc.UTCDateTimeFormatterRegistrar;
import com.uprr.enterprise.i18n.UPRRTranslator;
import com.uprr.enterprise.shared.components.credential.configuration.model.vo.ConfigurationVO;
import com.uprr.enterprise.shared.components.credential.cyberark.CyberArkCredentialProvider;
import com.uprr.ui.shared.user.spring.mvc.ActiveUserHandlerMethodArgumentResolver;

@ComponentScan("com.uprr.ema.lms")
@EnableTransactionManagement
@PropertySource(value = { "classpath:environment/lms_${uprr.implementation.environment}.properties", "classpath:common/lms.properties" })
@Configuration
public class MVCConfig extends WebMvcConfigurationSupport {
	
	 @Autowired
	  private Environment env;
	 
	  @Value("${rest.hostname}")
	  private String restHostname;
	 
	  @Value("${rest.service.url}")
	  private String restServiceUrl;
	 
	  @Value("${azm.cache.timeout}")
	  private String cacheTimeout;
	 
	  @Bean
	  public AuthorizationService azmService() {
	    RestAuthorizationService azmService = new RestAuthorizationService(restHostname, restServiceUrl);
	    return azmService;
	  }
	 
	  @Bean
	  public AzmSecurityUtils azmSecurityUtils() {
	    CacheableSecurityUtils azmSecurityUtils = new CacheableSecurityUtils(azmService(), buildAzmCache());
	    return azmSecurityUtils ;
	  }
	

	@Bean(name = "azmCache")
	public AzmCache buildAzmCache() {
		AzmCache azmCache = new JcsAzmCache(Long.parseLong(cacheTimeout));
		return azmCache;
	}
	
	 @Bean
	  public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
	     return new PropertySourcesPlaceholderConfigurer();
	  }
	 
	  @Bean
	  public AuthorizationManager authorizationManager() {
	    return new AzmAuthorizationManager(azmSecurityUtils());
	  }
    /**
     * Creates a default error handler for all controllers.
     * @param translator is declared in the I18NConfig class
     */
    @Bean 
    public UPAlertErrorInterceptor createUPAlertErrorInterceptor(UPRRTranslator translator) {
        return new UPAlertErrorInterceptor(translator);
    }

    /**
     * Adds the ArgumentResolver that allows @ActiveUser annotation  
     * to inject the ActiveUserId in Controller methods.
     */
    @Override
    public void addArgumentResolvers(final List<HandlerMethodArgumentResolver> argumentResolvers) {
      argumentResolvers.add(new ActiveUserHandlerMethodArgumentResolver());
      super.addArgumentResolvers(argumentResolvers);
    }
    
    /**
     * Disabling client side caching for proper REST call handling
     */
    @Override
    public void addInterceptors(final InterceptorRegistry registry) {
      registry.addInterceptor(buildWebContentInterceptor());
      registry.addInterceptor(new AuthorizationInterceptor(authorizationManager())); //Simple Site minder Related
      super.addInterceptors(registry);
    }
    
    private HandlerInterceptor buildWebContentInterceptor() {
      final WebContentInterceptor interceptor = new WebContentInterceptor();
      interceptor.setCacheSeconds(0);
      return interceptor;
    }
    
    /**
     * Adds uprr-date-time Jackson converters
     */
    @Override
    public void configureMessageConverters(final List<HttpMessageConverter<?>> converters) {
      converters.add(jsonConverter());    
      super.addDefaultHttpMessageConverters(converters); // enables other defaults to continue to function
    }  
     
    @Bean
    public MappingJackson2HttpMessageConverter jsonConverter() {
      final MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
      final ObjectMapper mapper = new ObjectMapper().registerModule(new UTCDateTimeCoreModule2());
      converter.setObjectMapper(mapper);
      return converter;
    }
    
    @Override
    public FormattingConversionService mvcConversionService() {
      return getConversionService().getObject();
    }

    /**
     * Adds uprr-date-time formatters
     */
    @Bean
    public FormattingConversionServiceFactoryBean getConversionService() {
      final FormattingConversionServiceFactoryBean fb = new FormattingConversionServiceFactoryBean();
      final Set<FormatterRegistrar> formatterRegistrars = new HashSet<FormatterRegistrar>();
      formatterRegistrars.add(new UTCDateTimeFormatterRegistrar());
      fb.setFormatterRegistrars(formatterRegistrars);
      return fb;
    }
    
    @Bean
    public MultipartResolver multipartResolver(){
    	return new CommonsMultipartResolver();
    }
    
    @Bean(name = "cyberArkConfiguration")
	public com.uprr.enterprise.shared.components.credential.configuration.model.Configuration configuration(@Value("${esb.app.id}") String esbAppId) {
	    ConfigurationVO configuration = new ConfigurationVO();
	    configuration.setSystem("Enterprise-Software-Credentials");
	    configuration.setApplicationId(esbAppId);
	    configuration.setEnvironment("dev");//(DocsServiceNames.getEnvironment());
	    configuration.setResource("");
	    configuration.setTla("EMA");
	    return configuration;
	}

	@Bean(name = "appCredentialProvider")
	public CyberArkCredentialProvider credentialProvider(@Qualifier(value = "cyberArkConfiguration") com.uprr.enterprise.shared.components.credential.configuration.model.Configuration config) {
		 return new CyberArkCredentialProvider(config);
	}

}
