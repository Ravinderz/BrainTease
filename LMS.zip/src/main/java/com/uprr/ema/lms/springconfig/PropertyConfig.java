package com.uprr.ema.lms.springconfig;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
/**
 * Autowired settings from the properties files.
 * To use, Autowire this PropertiesConfig in other Spring COnfig files and reference the type variables directly. 
 * see: http://go.up.com/springconfig
 */
@Configuration
@PropertySource({"classpath:default.properties"} //add any other referenced properties files here...
                 )
public class PropertyConfig {

  @Bean
  public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
    return new PropertySourcesPlaceholderConfigurer();
  }

}
