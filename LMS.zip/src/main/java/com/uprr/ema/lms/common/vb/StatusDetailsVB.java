package com.uprr.ema.lms.common.vb;

import java.util.List;

import com.uprr.ema.lms.common.dto.DropDownInfo;

public class StatusDetailsVB {
	private String statusCode;
    private String statusDesc;
    private String statusType;	
    private long recordCount;
    private List<DropDownInfo> dropDownList;
	/**
	 * @return the statusCode
	 */
	public String getStatusCode() {
		return statusCode;
	}
	/**
	 * @param statusCode the statusCode to set
	 */
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	/**
	 * @return the statusDesc
	 */
	public String getStatusDesc() {
		return statusDesc;
	}
	/**
	 * @param statusDesc the statusDesc to set
	 */
	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}
	/**
	 * @return the statusType
	 */
	public String getStatusType() {
		return statusType;
	}
	/**
	 * @param statusType the statusType to set
	 */
	public void setStatusType(String statusType) {
		this.statusType = statusType;
	}
	/**
	 * @return the recordCount
	 */
	public long getRecordCount() {
		return recordCount;
	}
	/**
	 * @param recordCount the recordCount to set
	 */
	public void setRecordCount(long recordCount) {
		this.recordCount = recordCount;
	}
	/**
	 * @return the dropDownList
	 */
	public List<DropDownInfo> getDropDownList() {
		return dropDownList;
	}
	/**
	 * @param dropDownList the dropDownList to set
	 */
	public void setDropDownList(List<DropDownInfo> dropDownList) {
		this.dropDownList = dropDownList;
	}
    
    
}
