package com.uprr.ema.lms.common.util;

import java.io.IOException;

import org.apache.commons.httpclient.Cookie;
import org.apache.commons.httpclient.Header;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.HttpState;
import org.apache.commons.httpclient.URI;
import org.apache.commons.httpclient.URIException;
import org.apache.commons.httpclient.cookie.CookiePolicy;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.params.HttpMethodParams;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.uprr.ema.lms.exception.LmsException;

public class HttpClientLogin {


	private static final Logger LOGGER = LoggerFactory.getLogger(HttpClientLogin.class);
	private int httpConnectTimeout = 100;
	private int httpReadTimeout = 5000;

	/**
	 * Constructor
	 * 
	 * @param nHttpConnectTimeout int
	 * @param nHttpReadTimeout int
	 */
	public HttpClientLogin(int nHttpConnectTimeout, int nHttpReadTimeout) {
		httpConnectTimeout = nHttpConnectTimeout;
		httpReadTimeout = nHttpReadTimeout;
	}

	public HttpClientLogin(){
		httpConnectTimeout = 10000;
		httpReadTimeout = 50000;
	}
	/**
	 * THIS DOESN'T WORK  
	 * Gets a SiteMinder protected URL. Expects that you have already logged in and are passing a valid smSession cookie
	 * and user name.
	 *  
	 * @param url String
	 * @param smSessionValue String
	 * @param cookies Cookie[]
	 * @return HttpResult
	 * @throws IOException 
	 */
	public HttpResult getSecureUrl(String url, String smSessionValue, Cookie[] cookies) throws IOException {
		// Create initial HTTP State
		HttpState initialState = new HttpState();

		// Add cookies to state
		for (int i = 0; i < cookies.length; i++) {            
			LOGGER.debug("Add cookie name: '{}':'{}'",cookies[i].getName(),cookies[i].getValue());
			LOGGER.debug(" cookie domain='{}'; path ='{}';version='{}'",cookies[i].getDomain(), cookies[i].getPath(), cookies[i].getVersion());

			Cookie newCookie = new Cookie(cookies[i].getDomain(), cookies[i].getName(), cookies[i].getValue(),cookies[i].getPath(), cookies[i].getExpiryDate(), cookies[i].getSecure());
			initialState.addCookie(newCookie);
		}

		// Create SMSESSION Cookie and add to state
		Cookie smSessionCookie = new Cookie(".uprr.com", "SMSESSION", smSessionValue,"/", null, false);
		initialState.addCookie(smSessionCookie);

		// Create Result & Client Object
		HttpResult httpResult = new HttpResult();
		HttpClient httpclient = createHttpClient();

		// Set initial state
		httpclient.setState(initialState);

		// Make initial HTTP GET
		GetMethod getMethod = createGetMethod(url);

		// Add Headers
		getMethod.setRequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; Union Pacific Corporate Image; .NET CLR 1.1.4322; .NET CLR 2.0.50727; Union Pacific Corporate Image)");

		httpResult = executeGet(httpclient, getMethod);


		// Release Connection
		getMethod.releaseConnection();

		return httpResult;
	}

	/**
	 * Gets a SiteMinder protected URL. Expects that you have already logged in and are passing a valid smSession cookie
	 * and user name.
	 * 
	 * @param url String url to retrieve
	 * @param smSessionValue String SMSession cookie value
	 * @return HttpResult
	 * @throws IOException 
	 */
	public HttpResult getSecureUrl(String url,String smSessionValue) throws IOException {   
		// Create initial HTTP State
		HttpState initialState = new HttpState();

		// Create SMSESSION Cookie and add to state
		Cookie smSessionCookie = new Cookie(".uprr.com", "SMSESSION", smSessionValue,"/", null, false);
		initialState.addCookie(smSessionCookie);

		// Create Result & Client Object
		HttpResult httpResult = new HttpResult();
		HttpClient httpclient = createHttpClient();

		// Set initial state
		httpclient.setState(initialState);

		// Make initial HTTP GET
		GetMethod getMethod = createGetMethod(url);

		// Add Headers
		getMethod.setRequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; Union Pacific Corporate Image; .NET CLR 1.1.4322; .NET CLR 2.0.50727; Union Pacific Corporate Image)");
		httpResult = executeGet(httpclient, getMethod);


		// Release Connection
		getMethod.releaseConnection();

		return httpResult;
	}

	/**
	 * Given a url, user name, and password this method will log in to SiteMinder and return the content
	 * of the url
	 * 
	 * @param url String URL to retrieve
	 * @param userName String
	 * @param password String
	 * @return HttpResult
	 * @throws IOException 
	 */
	public HttpResult getSecureUrlSMLogin(String url,String userName, String password) throws LmsException {

		try{
			HttpResult httpResult = new HttpResult();
			HttpClient client = createHttpClient();
			// Make initial HTTP GET
			GetMethod getMethod = createGetMethod(url);
			httpResult = executeGet(client, getMethod);

			// Build Login URL based off redirect in first request
			String finalURL = buildLoginURL(getMethod);

			// Post to login page
			PostMethod postMethod = createPostMethod(finalURL);
			postMethod.addParameter("USER", userName);
			postMethod.addParameter("PASSWORD",password);
			postMethod.addParameter("target", url);
			postMethod.addParameter("smauthreason","0");
			httpResult = executePost(client, postMethod);


			// Get the redirect header
			String redirectLocation = null;
			Header locationHeader = postMethod.getResponseHeader("Location");
			if (locationHeader == null) {
				LOGGER.debug("Location Header null");
			} else {
				redirectLocation = locationHeader.getValue();
			}

			// Make HTTP GET to target page
			getMethod = createGetMethod(redirectLocation);
			httpResult = executeGet(client, getMethod);

			// Close Connection
			getMethod.releaseConnection();
			postMethod.releaseConnection();

			return httpResult;
		}catch(Exception e){
			LOGGER.error("Exception Occured while getting session",e);
			throw new LmsException(e);
		}
	}

	private String buildLoginURL(GetMethod getMethod) {
		String urlPath="";
		String host="";
		String queryString="";
		String finalURL = "";
		try {
			URI currURI = getMethod.getURI();
			urlPath = currURI.getPath();
			host = currURI.getHost();
			queryString = currURI.getQuery();
			finalURL = new StringBuilder("https://").append(host)
							.append(urlPath).append("?")
							.append(queryString).toString();
		}
		catch (URIException urie) {
			LOGGER.error("Exception ::",urie);
		}
		return finalURL;
	}

	

	/**
	 * Creates an HttpClient object with default values
	 * 
	 * @return HttpClient
	 */
	public HttpClient createHttpClient() {
		HttpClient client = null;
		try{
			client = new HttpClient();
			client.getHttpConnectionManager().getParams().setConnectionTimeout(httpConnectTimeout);
			client.getHttpConnectionManager().getParams().setSoTimeout(httpReadTimeout);
			client.getHttpConnectionManager().getParams().setTcpNoDelay(true);
			client.getParams().setCookiePolicy(CookiePolicy.BROWSER_COMPATIBILITY);
		}catch(Exception e){
			LOGGER.error("Exception has Occured while getting HttpClient Object", e);
		}
		return client;
	}


	/**
	 * Creates an HTTP Post Method Object with default parameters
	 * 
	 * @param url String
	 * @return PostMethod
	 */
	public PostMethod createPostMethod(String url) {
		PostMethod postMethod = null;

		try {
			postMethod = new PostMethod(url);
		}
		catch (IllegalStateException ise) {
			LOGGER.error("Http error connecting to '{}' Error: '{}'",url, ise.toString());
		}

		postMethod.setRequestHeader("User-Agent","HttpClientExample Browser");
		postMethod.getParams().setCookiePolicy(CookiePolicy.BROWSER_COMPATIBILITY);

		// Set the class for handling retries
		RetryHandler myRetryHandler = new RetryHandler();
		postMethod.getParams().setParameter(HttpMethodParams.RETRY_HANDLER, myRetryHandler);

		return postMethod;
	}


	/**
	 * Creates an HTTP Get Method Object with default parameters
	 * 
	 * @param url String
	 * @return GetMethod
	 */
	public GetMethod createGetMethod(String url) {
		GetMethod getMethod = null;

		try {
			getMethod = new GetMethod(url);
		}
		catch (IllegalStateException ise) {
			LOGGER.error("Http error connecting to '{}' Error: '{}'",url, ise.toString());
		}

		getMethod.setRequestHeader("User-Agent","HttpClientExample Browser");
		getMethod.setFollowRedirects(true);
		getMethod.getParams().setCookiePolicy(CookiePolicy.BROWSER_COMPATIBILITY);

		// Set the class for handling retries
		RetryHandler myRetryHandler = new RetryHandler();
		getMethod.getParams().setParameter(HttpMethodParams.RETRY_HANDLER, myRetryHandler);

		return getMethod;
	}


	/**
	 * Executes an HTTP Post Method with default parameters
	 * 
	 * @param client HttpClient
	 * @param postMethod PostMethod
	 * @return HttpResult
	 */
	public HttpResult executePost(HttpClient client, PostMethod postMethod) {
		HttpResult httpResult = new HttpResult();

		try {
			client.executeMethod(postMethod);
			// Set HttpResult Object
			if (postMethod.getStatusCode()>=200) {
				httpResult.setHttpContent(postMethod.getResponseBodyAsString());
				httpResult.setRequestHeaders(postMethod.getRequestHeaders());
				httpResult.setHttpStatusCode(postMethod.getStatusCode());
				httpResult.setResponseHeaders(postMethod.getResponseHeaders());

				Header[] responseHeader = postMethod.getResponseHeaders();
				for (int i=0; i<responseHeader.length; i++) {
					LOGGER.debug("Response Header: '{}':'{}'",responseHeader[i].getName(),responseHeader[i].getValue());
				}

				setCookieValueInHTTPResult(client, httpResult);
			}
		} 
		catch (HttpException he) {
			LOGGER.error("Http error connecting to '{} ' Error: {}" ,postMethod.getPath(), he);
			httpResult.setHttpException(he);
		} 
		catch (IOException ioe){
			LOGGER.error("Unable to connect to to '{}' Error: {}",postMethod.getPath(), ioe);
			httpResult.setHttpException(ioe);
		}
		catch (IllegalArgumentException iae) {
			LOGGER.error("Unable to connect to '{}, Error : {}",postMethod.getPath(), iae);
			httpResult.setHttpException(iae);
		}

		return httpResult;
	}

	private void setCookieValueInHTTPResult(HttpClient client, HttpResult httpResult) {
		Cookie[] cookies = client.getState().getCookies();
		httpResult.setCookies(cookies);
		for (int i = 0; i < cookies.length; i++) {
			LOGGER.debug("Post Cookie: '{}':'{}' ", cookies[i].getName(), cookies[i].getValue());
			setSMSessionValue(httpResult, cookies, i);
		}
	}


	/**
	 * Executes an HTTP Get Method with default parameters
	 * 
	 * @param client HttpClient
	 * @param getMethod GetMethod
	 * @return HttpResult
	 * @throws IOException 
	 */
	public HttpResult executeGet(HttpClient client, GetMethod getMethod) throws IOException {
		HttpResult httpResult = new HttpResult();

		try {

			client.executeMethod(getMethod);
			// Set HttpResult Object
			if (getMethod.getStatusCode()>=200) {
				httpResult.setHttpContent(getMethod.getResponseBodyAsString());
				httpResult.setRequestHeaders(getMethod.getRequestHeaders());
				httpResult.setHttpStatusCode(getMethod.getStatusCode());
				httpResult.setResponseHeaders(getMethod.getResponseHeaders());

				Header[] responseHeader = getMethod.getResponseHeaders();
				for (int i=0; i<responseHeader.length; i++) {
					LOGGER.debug("Response Header: '{}':'{}'",responseHeader[i].getName(),responseHeader[i].getValue());
				}

				// Set SMSESSION in httpResult
				Cookie[] cookies = client.getState().getCookies();
				httpResult.setCookies(cookies);
				for (int i = 0; i < cookies.length; i++) {
					setSMSessionValue(httpResult, cookies, i);
				}
			}
		} 
		catch (HttpException he) {
			LOGGER.error("Http error connecting to '{} ' Error: {}",getMethod.getPath(),he.toString());
			httpResult.setHttpException(he);
		} 
		catch (IOException ioe){
			LOGGER.error("Unable to connect to '{} ' Error: {}", getMethod.getPath(),ioe.toString());            
			httpResult.setHttpException(ioe);
			throw ioe;
		}
		catch (Exception iae) {
			LOGGER.error("Unable to connect to '{} ' Error: {}",getMethod.getPath(),iae.toString());
			httpResult.setHttpException(iae);
		}

		return httpResult;
	}

	private void setSMSessionValue(HttpResult httpResult, Cookie[] cookies,	int index) {
		if (cookies[index].getName().compareToIgnoreCase("SMSESSION")==0) {
			LOGGER.debug("smcookie name - '{}':'{}'", cookies[index].getName(),cookies[index].getValue());
			LOGGER.debug("smcookie domain - '{}'; path - '{}'", cookies[index].getDomain(),cookies[index].getPath());
			httpResult.setSmSessionValue(cookies[index].getValue());
		}
	}

}
