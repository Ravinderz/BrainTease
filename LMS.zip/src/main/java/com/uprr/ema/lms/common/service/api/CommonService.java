package com.uprr.ema.lms.common.service.api;


public interface CommonService {
	/**
     * To get the project status details
     * @param project Id
     * @return ProjectStatusDetailsDTO
     * @
     */
}
