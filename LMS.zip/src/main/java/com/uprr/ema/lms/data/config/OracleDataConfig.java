package com.uprr.ema.lms.data.config;




import org.apache.tomcat.jdbc.pool.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.JdbcTemplate;

import com.uprr.ema.lms.common.constant.DataSourcePropertyKeyConstants;
import com.uprr.ema.lms.common.util.CyberArkPoolPasswordUtil;

@Configuration
public class OracleDataConfig {
	
	@Autowired
	Environment environment;
	
	@Bean(name="oracleDataSource")
	@Primary
	public DataSource getOracleDataSource(){
		return new DataSource(getOraclePoolProperties());
	}
	
	@Bean(name="oraclePoolProperties")
	public CyberArkPoolPasswordUtil getOraclePoolProperties(){
		CyberArkPoolPasswordUtil cyberArkPoolPasswordUtil = new CyberArkPoolPasswordUtil();

		String dbInstance = environment.getProperty(DataSourcePropertyKeyConstants.ORACLE_CONNECTION_DB_INSTANCE);

		cyberArkPoolPasswordUtil.setAppTLA(environment.getProperty(DataSourcePropertyKeyConstants.APPLICATION_TLA));
		cyberArkPoolPasswordUtil.setInstance(dbInstance);
		cyberArkPoolPasswordUtil.setType(environment.getProperty(DataSourcePropertyKeyConstants.ORACLE_CONNECTION_DBMS_TYPE));
		cyberArkPoolPasswordUtil.setRunEnv(environment.getProperty(DataSourcePropertyKeyConstants.UPRR_IMPLEMENTATION_ENVIRONMENT));
		cyberArkPoolPasswordUtil.setDriverClassName(environment.getProperty(DataSourcePropertyKeyConstants.ORACLE_CONNECTION_DRIVER_CLASS));
		cyberArkPoolPasswordUtil.setUrl("jdbc:oracle:thin:@"+dbInstance+".oracle.uprr.com:1521:"+dbInstance);
		cyberArkPoolPasswordUtil.setAppID(environment.getProperty(DataSourcePropertyKeyConstants.ORACLE_CONNECTION_USERNAME));
		cyberArkPoolPasswordUtil.setLocalEnvPassword(environment.getProperty(DataSourcePropertyKeyConstants.ORACLE_CONNECTION_LOCAL_PASS_KEY));//
		cyberArkPoolPasswordUtil.setInitialSize(Integer.parseInt(environment.getProperty(DataSourcePropertyKeyConstants.INITIAL_SIZE)));
		cyberArkPoolPasswordUtil.setMaxActive(Integer.parseInt(environment.getProperty(DataSourcePropertyKeyConstants.MAX_ACTIVE)));
		cyberArkPoolPasswordUtil.setMaxIdle(Integer.parseInt(environment.getProperty(DataSourcePropertyKeyConstants.MAX_IDLE)));
		cyberArkPoolPasswordUtil.setMinIdle(Integer.parseInt(environment.getProperty(DataSourcePropertyKeyConstants.MIN_IDLE)));
		cyberArkPoolPasswordUtil.setValidationQuery(environment.getProperty(DataSourcePropertyKeyConstants.VALIDATION_QUERY));
		cyberArkPoolPasswordUtil.setTestWhileIdle(Boolean.parseBoolean(environment.getProperty(DataSourcePropertyKeyConstants.TRUE_PROP)));
		cyberArkPoolPasswordUtil.setValidationInterval(Long.parseLong(environment.getProperty(DataSourcePropertyKeyConstants.VALIDATION_INTERVAL)));
		cyberArkPoolPasswordUtil.setAccessToUnderlyingConnectionAllowed(Boolean.parseBoolean(environment.getProperty(DataSourcePropertyKeyConstants.TRUE_PROP)));

		return cyberArkPoolPasswordUtil;
	}
	
	@Bean(name="jdbcTemplate")
	public JdbcTemplate jdbcTemplate() {
		JdbcTemplate jdbcTemplate = new JdbcTemplate(getOracleDataSource());
		//jdbcTemplate.setDataSource(getOracleDataSource());
		return jdbcTemplate;
	}


	
	
	
}
