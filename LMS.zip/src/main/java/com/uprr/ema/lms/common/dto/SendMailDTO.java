package com.uprr.ema.lms.common.dto;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.commons.codec.binary.Base64;

import com.uprr.ema.lms.common.constant.LmsConstants;
import com.uprr.ema.lms.common.util.CommonUtils;

public class SendMailDTO implements Serializable {
	private static final long serialVersionUID = 1L;
	/** The content type. */
	private String contentType = LmsConstants.HTML_CONTENT_TYPE;
	private String subject = null;
	private String bodyContent = null;
	private String fromAddress = null;
	private List<String> toAddressLst = new ArrayList<String>(LmsConstants.THREE);
	private List<String> ccAddressLst = new ArrayList<String>(LmsConstants.THREE);
	private List<String> bccAddressLst = new ArrayList<String>(LmsConstants.THREE);
	private byte[] attachmentBytes = null;
	private String attachedDocMimeType = LmsConstants.PDF_CONTENT_TYPE;
	private String attachedDocName = LmsConstants.EMA_RPT_FILE_NAME;

	
	
	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getBodyContent() {
		return bodyContent;
	}

	public void setBodyContent(String bodyContent) {
		this.bodyContent = bodyContent;
	}

	public String getFromAddress() {
		return fromAddress;
	}

	public void setFromAddress(String fromAddress) {
		this.fromAddress = fromAddress;
	}

	public List<String> getToAddressLst() {
		return toAddressLst;
	}

	public void setToAddressLst(List<String> toAddressLst) {
		this.toAddressLst = toAddressLst;
	}

	public List<String> getCcAddressLst() {
		return ccAddressLst;
	}

	public void setCcAddressLst(List<String> ccAddressLst) {
		this.ccAddressLst = ccAddressLst;
	}

	public List<String> getBccAddressLst() {
		return bccAddressLst;
	}

	public void setBccAddressLst(List<String> bccAddressLst) {
		this.bccAddressLst = bccAddressLst;
	}

	public byte[] getAttachmentBytes() {
		return attachmentBytes;
	}

	public void setAttachmentBytes(byte[] attachmentBytes) {
		this.attachmentBytes = attachmentBytes;
	}

	public String getAttachedDocMimeType() {
		return attachedDocMimeType;
	}

	public void setAttachedDocMimeType(String attachedDocMimeType) {
		this.attachedDocMimeType = attachedDocMimeType;
	}

	public String getAttachedDocName() {
		return attachedDocName;
	}

	public void setAttachedDocName(String attachedDocName) {
		this.attachedDocName = attachedDocName;
	}

	/**
	 * 
	 * @return ENANotification message as XML String
	 */
	public String toXMLStrong() {
		StringBuilder xmlBuffer = new StringBuilder();
		xmlBuffer.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
		xmlBuffer.append("<notification-request xmlns=\"http://uprr.com/app/ena3/model/notifications\" version=\"1.0\">");
		xmlBuffer.append("<header><requestor><tla>EMA</tla><ena-group-id>ANY</ena-group-id><ena-sub-group-id>ANY</ena-sub-group-id></requestor></header>");
		xmlBuffer.append("<notification mode=\"EMAIL\">");
		xmlBuffer.append("<messages><message mime-type='"+this.getContentType()+"'>");
		//Add the senders email
		xmlBuffer.append("<sender><name>");
		xmlBuffer.append("EMA</name>");
		xmlBuffer.append("<from-address>");
		if(this.getFromAddress() != null){
			xmlBuffer.append("<![CDATA["+this.getFromAddress()+"]]>");
		}else {
			xmlBuffer.append("no-reply");
		}
		xmlBuffer.append("</from-address></sender>");
		
		xmlBuffer.append("<subject>");
		// add the subject
		xmlBuffer.append(this.getSubject());
		xmlBuffer.append("</subject>");
		
		xmlBuffer.append("<content>");
		// add the content
		xmlBuffer.append("<![CDATA["+this.getBodyContent()+"]]>");
		xmlBuffer.append("</content>");
		
		if(this.getAttachmentBytes() != null){
		    byte[] encodedBytes = Base64.encodeBase64(this.getAttachmentBytes());
		    String attchmentInBase64 = new String(encodedBytes);
			xmlBuffer.append("<attachment mime-type='"+this.getAttachedDocMimeType()+"' encoding='base64' file-name='"+this.getAttachedDocName()+"'>");
			xmlBuffer.append(attchmentInBase64);
			xmlBuffer.append("</attachment>");
		}
		xmlBuffer.append("</message></messages>");
		xmlBuffer.append("<delivery><receivers><to><address-list>");
		xmlBuffer.append("<![CDATA["+CommonUtils.getCommaSeparedStrVal(this.getToAddressLst())+"]]>");
		xmlBuffer.append("</address-list></to>");
		xmlBuffer.append("<cc><address-list>");
		xmlBuffer.append("<![CDATA["+CommonUtils.getCommaSeparedStrVal(this.getCcAddressLst())+"]]>");
		xmlBuffer.append("</address-list></cc>");
		xmlBuffer.append("<bcc><address-list>");
		xmlBuffer.append("<![CDATA["+CommonUtils.getCommaSeparedStrVal(this.getBccAddressLst())+"]]>");
		xmlBuffer.append("</address-list></bcc>");
		xmlBuffer.append("</receivers>");
		//Add element expires-on
		xmlBuffer.append("<expires-on>");
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		cal.add(Calendar.HOUR, 1);
		xmlBuffer.append(sdf.format(cal.getTime()).replace(" ", "T"));
		xmlBuffer.append("</expires-on>");
		//End of Delivery tag
		xmlBuffer.append("</delivery></notification></notification-request>");
		return xmlBuffer.toString();
	}
}
