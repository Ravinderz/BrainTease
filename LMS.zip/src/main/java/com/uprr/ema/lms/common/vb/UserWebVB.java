package com.uprr.ema.lms.common.vb;

import java.io.Serializable;
import java.util.ArrayList;

import com.uprr.ema.lms.common.dto.BaseDTO;

public class UserWebVB extends BaseDTO implements Serializable {
private static final long serialVersionUID = 1L;
    
    private String userId;
    private String empId;
    private boolean unAuthorized;
    private String userName;
    private String token;
    private boolean view;
    private boolean admin;
    private boolean manager;
    private boolean approver;
    private boolean legal;
    private boolean disapprover;
	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}
	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}
	/**
	 * @return the empId
	 */
	public String getEmpId() {
		return empId;
	}
	/**
	 * @param empId the empId to set
	 */
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	/**
	 * @return the unAuthorized
	 */
	public boolean isUnAuthorized() {
		return unAuthorized;
	}
	/**
	 * @param unAuthorized the unAuthorized to set
	 */
	public void setUnAuthorized(boolean unAuthorized) {
		this.unAuthorized = unAuthorized;
	}
	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}
	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}
	/**
	 * @return the token
	 */
	public String getToken() {
		return token;
	}
	/**
	 * @param token the token to set
	 */
	public void setToken(String token) {
		this.token = token;
	}
	/**
	 * @return the view
	 */
	public boolean isView() {
		return view;
	}
	/**
	 * @param view the view to set
	 */
	public void setView(boolean view) {
		this.view = view;
	}
	/**
	 * @return the admin
	 */
	public boolean isAdmin() {
		return admin;
	}
	/**
	 * @param admin the admin to set
	 */
	public void setAdmin(boolean admin) {
		this.admin = admin;
	}
	/**
	 * @return the manager
	 */
	public boolean isManager() {
		return manager;
	}
	/**
	 * @param manager the manager to set
	 */
	public void setManager(boolean manager) {
		this.manager = manager;
	}
	/**
	 * @return the approver
	 */
	public boolean isApprover() {
		return approver;
	}
	/**
	 * @param approver the approver to set
	 */
	public void setApprover(boolean approver) {
		this.approver = approver;
	}
	/**
	 * @return the legal
	 */
	public boolean isLegal() {
		return legal;
	}
	/**
	 * @param legal the legal to set
	 */
	public void setLegal(boolean legal) {
		this.legal = legal;
	}
	/**
	 * @return the disapprover
	 */
	public boolean isDisapprover() {
		return disapprover;
	}
	/**
	 * @param disapprover the disapprover to set
	 */
	public void setDisapprover(boolean disapprover) {
		this.disapprover = disapprover;
	}
	
	/**
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
    
    
}
