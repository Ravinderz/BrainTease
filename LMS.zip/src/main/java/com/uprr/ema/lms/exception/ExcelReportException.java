package com.uprr.ema.lms.exception;

import java.util.Date;

public class ExcelReportException extends RuntimeException{


    // default
    private static final long serialVersionUID = 1L;
    private String errorCode;
    private String userMessage;

    private String statusCode;
    private String statusDesc;
    private String statusType;


    /**
     * @purpose Overloaded constructor for CustomException class
     * @param message
     * @param messageType
     * @param messageTitle
     * @param status
     */
    public ExcelReportException(String statusCode, String statusDesc, String statusType) {
	this.statusCode = statusCode;
	this.statusDesc = statusDesc;
	this.statusType = statusType;
    }

    public ExcelReportException() {
	super();
	userMessage = "Current Time: " + new Date().toString() + "  "
		+ "The system has experienced a fatal error and is no longer available for service."
		+ "  Call OSS at (402)544-5555 to report the error.";
    }

    public ExcelReportException(String userMessage) {
	super(userMessage);
	this.userMessage = userMessage;
    }

    public ExcelReportException(Throwable cause) {
	super(cause);
    }

    public ExcelReportException(String userMessage, Throwable cause) {
	super(userMessage, cause);
	this.userMessage = userMessage;
    }

    public String getUserMessage() {
	return userMessage;
    }

    public void setUserMessage(String userMessage) {
	this.userMessage = userMessage;
    }

    /**
     * @return the statusCode
     */
    public String getStatusCode() {
	return statusCode;
    }

    /**
     * @param statusCode the statusCode to set
     */
    public void setStatusCode(String statusCode) {
	this.statusCode = statusCode;
    }

    /**
     * @return the statusDesc
     */
    public String getStatusDesc() {
	return statusDesc;
    }

    /**
     * @param statusDesc the statusDesc to set
     */
    public void setStatusDesc(String statusDesc) {
	this.statusDesc = statusDesc;
    }

    /**
     * @return the statusType
     */
    public String getStatusType() {
	return statusType;
    }

    /**
     * @param statusType the statusType to set
     */
    public void setStatusType(String statusType) {
	this.statusType = statusType;
    }
   

    /**
     * @return the errorCode
     */
    public String getErrorCode() {
	return errorCode;
    }

    /**
     * @param errorCode the errorCode to set
     */
    public void setErrorCode(String errorCode) {
	this.errorCode = errorCode;
    }


}
