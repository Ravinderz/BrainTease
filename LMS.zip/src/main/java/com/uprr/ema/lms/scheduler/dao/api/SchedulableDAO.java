package com.uprr.ema.lms.scheduler.dao.api;

import java.util.List;

import com.uprr.ema.lms.liabilityProject.dto.SnapshotDTO;

public interface SchedulableDAO {
    public boolean saveMonthAmount(List<SnapshotDTO> monthSnapshotList);
}
