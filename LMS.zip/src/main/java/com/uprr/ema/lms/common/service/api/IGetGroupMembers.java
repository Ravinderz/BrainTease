package com.uprr.ema.lms.common.service.api;

import java.util.List;

public interface IGetGroupMembers {
	String GET_GROUP_MEMEBERS_SERVICE_NAME = "user/get-group-members/1.0";
	String GET_GROUP_MEMEBERS_NAMESPACE = "http://services.www.up.com/" + GET_GROUP_MEMEBERS_SERVICE_NAME;
	public List<String> getGroupMembers(String empId);
}
