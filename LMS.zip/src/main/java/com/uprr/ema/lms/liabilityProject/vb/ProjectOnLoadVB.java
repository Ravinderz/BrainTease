package com.uprr.ema.lms.liabilityProject.vb;

import java.io.Serializable;
import java.util.List;

import com.uprr.ema.lms.common.dto.DropDownInfo;
import com.uprr.ema.lms.common.dto.ManagerDTO;
import com.uprr.ema.lms.common.vb.StatusDetailsVB;

public class ProjectOnLoadVB extends StatusDetailsVB  implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private List<DropDownInfo> sources;
	private List<DropDownInfo> types;
	private List<DropDownInfo> drivers;
	private List<DropDownInfo> estimators;
	private List<ManagerDTO> siteRemManagers;
	private List<DropDownInfo> railRoads;
	private List<DropDownInfo> federalLeads;
	private List<DropDownInfo> balanceSheets;
	private List<DropDownInfo> subAccounts;
	private List<DropDownInfo> states;
	private List<DropDownInfo> costTypes;
	private List<DropDownInfo> costSubTypes;
	private List<ProjectCostVB> projectCostVBList;
	private List<ProjectCostVB> currentCostVBList;
	private List<DropDownInfo> tubeLevelList;
	private List<DropDownInfo> changeReasons;
	private ProjectVB projectVB;
	
	/**
	 * @return the sources
	 */
	public List<DropDownInfo> getSources() {
		return sources;
	}
	/**
	 * @param sources the sources to set
	 */
	public void setSources(List<DropDownInfo> sources) {
		this.sources = sources;
	}
	/**
	 * @return the types
	 */
	public List<DropDownInfo> getTypes() {
		return types;
	}
	/**
	 * @param types the types to set
	 */
	public void setTypes(List<DropDownInfo> types) {
		this.types = types;
	}
	/**
	 * @return the drivers
	 */
	public List<DropDownInfo> getDrivers() {
		return drivers;
	}
	/**
	 * @param drivers the drivers to set
	 */
	public void setDrivers(List<DropDownInfo> drivers) {
		this.drivers = drivers;
	}
	/**
	 * @return the estimators
	 */
	public List<DropDownInfo> getEstimators() {
		return estimators;
	}
	/**
	 * @param estimators the estimators to set
	 */
	public void setEstimators(List<DropDownInfo> estimators) {
		this.estimators = estimators;
	}
	/**
	 * @return the railRoads
	 */
	public List<DropDownInfo> getRailRoads() {
		return railRoads;
	}
	/**
	 * @param railRoads the railRoads to set
	 */
	public void setRailRoads(List<DropDownInfo> railRoads) {
		this.railRoads = railRoads;
	}
	/**
	 * @return the federalLeads
	 */
	public List<DropDownInfo> getFederalLeads() {
		return federalLeads;
	}
	/**
	 * @param federalLeads the federalLeads to set
	 */
	public void setFederalLeads(List<DropDownInfo> federalLeads) {
		this.federalLeads = federalLeads;
	}
	/**
	 * @return the balanceSheets
	 */
	public List<DropDownInfo> getBalanceSheets() {
		return balanceSheets;
	}
	/**
	 * @param balanceSheets the balanceSheets to set
	 */
	public void setBalanceSheets(List<DropDownInfo> balanceSheets) {
		this.balanceSheets = balanceSheets;
	}
	/**
	 * @return the subAccounts
	 */
	public List<DropDownInfo> getSubAccounts() {
		return subAccounts;
	}
	/**
	 * @param subAccounts the subAccounts to set
	 */
	public void setSubAccounts(List<DropDownInfo> subAccounts) {
		this.subAccounts = subAccounts;
	}
	/**
	 * @return the siteRemManagers
	 */
	public List<ManagerDTO> getSiteRemManagers() {
		return siteRemManagers;
	}
	/**
	 * @param siteRemManagers the siteRemManagers to set
	 */
	public void setSiteRemManagers(List<ManagerDTO> siteRemManagers) {
		this.siteRemManagers = siteRemManagers;
	}
	/**
	 * @return the states
	 */
	public List<DropDownInfo> getStates() {
		return states;
	}
	/**
	 * @param states the states to set
	 */
	public void setStates(List<DropDownInfo> states) {
		this.states = states;
	}
	public List<ProjectCostVB> getProjectCostVBList() {
		return projectCostVBList;
	}
	public void setProjectCostVBList(List<ProjectCostVB> projectCostVBList) {
		this.projectCostVBList = projectCostVBList;
	}
	public List<DropDownInfo> getCostTypes() {
		return costTypes;
	}
	public void setCostTypes(List<DropDownInfo> costTypes) {
		this.costTypes = costTypes;
	}
	
	
	/**
	 * @return the costSubTypes
	 */
	public List<DropDownInfo> getCostSubTypes() {
	    return costSubTypes;
	}
	/**
	 * @param costSubTypes the costSubTypes to set
	 */
	public void setCostSubTypes(List<DropDownInfo> costSubTypes) {
	    this.costSubTypes = costSubTypes;
	}
	public List<DropDownInfo> getTubeLevelList() {
	    return tubeLevelList;
	}
	public void setTubeLevelList(List<DropDownInfo> tubeLevelList) {
	    this.tubeLevelList = tubeLevelList;
	}
	public List<DropDownInfo> getChangeReasons() {
	    return changeReasons;
	}
	public void setChangeReasons(List<DropDownInfo> changeReasons) {
	    this.changeReasons = changeReasons;
	}
	/**
	 * @return the projectVB
	 */
	public ProjectVB getProjectVB() {
	    return projectVB;
	}
	/**
	 * @param projectVB the projectVB to set
	 */
	public void setProjectVB(ProjectVB projectVB) {
	    this.projectVB = projectVB;
	}
	/**
	 * @return the currentCostVBList
	 */
	public List<ProjectCostVB> getCurrentCostVBList() {
	    return currentCostVBList;
	}
	/**
	 * @param currentCostVBList the currentCostVBList to set
	 */
	public void setCurrentCostVBList(List<ProjectCostVB> currentCostVBList) {
	    this.currentCostVBList = currentCostVBList;
	}
}