package com.uprr.ema.lms.reports.service.impl;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Sheet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.uprr.ema.lms.common.dto.DocumentDTO;
import com.uprr.ema.lms.common.service.api.IDocumentService;
import com.uprr.ema.lms.common.service.util.ExcelUtils;
import com.uprr.ema.lms.common.util.WebDateUtils;
import com.uprr.ema.lms.exception.LmsException;
import com.uprr.ema.lms.liabilityProject.dto.AccountCostDTO;
import com.uprr.ema.lms.reports.dao.api.ReportsDao;
import com.uprr.ema.lms.reports.dao.api.ReportsOracleDao;
import com.uprr.ema.lms.reports.dto.BusinessPrepPlanDTO;
import com.uprr.ema.lms.reports.dto.LCRRprtChartDTO;
import com.uprr.ema.lms.reports.dto.LCRRprtDTO;
import com.uprr.ema.lms.reports.dto.LCRRprtSearchCriteriaDTO;
import com.uprr.ema.lms.reports.dto.MonthlySpendDTO;
import com.uprr.ema.lms.reports.dto.OverAllDataLCRRprtDTO;
import com.uprr.ema.lms.reports.dto.ProjCountWaterfallDTO;
import com.uprr.ema.lms.reports.dto.SiteSourceDTO;
import com.uprr.ema.lms.reports.helper.ReportsHelper;
import com.uprr.ema.lms.reports.service.api.ReportsService;
import com.uprr.ema.lms.reports.vb.DocumentVB;

@Service
public class ReportsServiceImpl implements ReportsService{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ReportsServiceImpl.class);
	
	@Autowired
	ReportsDao reportsDao;
	
	@Autowired 
	ReportsOracleDao oracleDao;
	
	@Autowired
	private ReportsHelper reportsHelper;
	
	@Autowired
	private IDocumentService docService;

	@Override
	public void getBppdExcelReport(HttpServletResponse response,String month, String year) {
		List<String[]> headersList = new ArrayList<>(5);
		String ReportHeaderMonthAndYear = "Business Plan Prep Data - "+month+" "+year;
    	String[] excelReportHeader = {ReportHeaderMonthAndYear};
    	String[] exelHeaders = { "Estimator", "Fiscper", "Project Name","WO","Desc","Invoice Nbr","Amount","Site Rem Manager"};
    	headersList.add(excelReportHeader);
    	headersList.add(exelHeaders);
    	List<BusinessPrepPlanDTO> teradataList = reportsDao.getBusinessPrepPlanData(year+"001",year+getMonthInNumeric(month));
    	Set<String> networkNumberSet = getDistinctNetworkValues(teradataList);
    	List<BusinessPrepPlanDTO> oracleList = new ArrayList<>();
    	if(networkNumberSet != null && networkNumberSet.size() > 0){
    		oracleList = oracleDao.getProjectDetailsBasedOnNetworkId(networkNumberSet);
    	}
    	
    	
    	Sheet sheet = ExcelUtils.generateBusinessPrepPlanExcel("Business Prep Plan Report", headersList,getReportList(teradataList,oracleList));
    	response.setHeader("Content-Disposition", "inline; filename="+ "Business Prep Plan Report");
		response.setContentType("application/vnd.ms-excel");
		ServletOutputStream outputStream;
		try {
			outputStream = response.getOutputStream();
			response.setCharacterEncoding("UTF-8");
			sheet.getWorkbook().write(outputStream);
			outputStream.flush();
		} catch (IOException e) { 
			e.printStackTrace();
		}
				
	}
	
	@Override
	public void getSiteSourceExcelReport(HttpServletResponse response,String month,String year) {
		List<String[]> headersList = new ArrayList<>(10);   
		List<SiteSourceDTO> siteSourceList = oracleDao.getSiteSourceProjDetailsBasedOnNetworkId(getTotalDaysCountInAMonth(Integer.parseInt(year),month).toString()+" - "+month.substring(0,3)+year);
		Set<String> networkNumberSet = getDistinctNetworkValues(siteSourceList);
		List<SiteSourceDTO> spendingPerYearData = new ArrayList<>();
		if(networkNumberSet != null && networkNumberSet.size() > 0){
			spendingPerYearData = reportsDao.getPerYearSpendingData(networkNumberSet,year+getMonthInNumeric(month));	
		}
		List<SiteSourceDTO> resultList = mapSpendingDataToSiteSourceList(siteSourceList,spendingPerYearData,Integer.parseInt(year));
		  
		String ReportHeaderMonthAndYear = "UPRR SITE REMEDIATION ENVIRONMENTAL LIABILITY MANAGEMENT - "+year;
    	String[] MainReportHeader = {ReportHeaderMonthAndYear};
    	String[] headerManager = {"Managers:"};
    	String[] headerLiability = {"Liability:","","","","","",generateFormuleHeaderForSiteSource("liabilities",year,siteSourceList.size()+9)};
    	String[] headerProjects = {"Projects:","","","","","",generateFormuleHeaderForSiteSource("projects",year,siteSourceList.size()+9)};
    	String[] headerProjectCount = {"SUBTOTAL(3,A9:A"+Integer.toString(siteSourceList.size()+9)+")#"};
    	String[] headerTillMonth = {"Through "+month+" "+year};
    	String[] headerEmpty = {""};
    	String[] exelHeaders = { "Line", "Project", "RR","Source","State","Listed","Closed",generateYearsTillDate(year),"Total UP Spending","Total Pre-merger Spending","Total Project Spending thru "+month+" "+year,getQuartersBasedOnMonth(month)+" "+year+" ELC","Total Committed Costs","15-year Rule"};
    	headersList.add(MainReportHeader);
    	headersList.add(headerManager);
    	headersList.add(headerLiability);
    	headersList.add(headerProjects);
    	headersList.add(headerProjectCount);
    	headersList.add(headerTillMonth);
    	headersList.add(headerEmpty);
    	headersList.add(exelHeaders);
    	
    	String sheetName = "Site Source List - "+year+" update";
    	
    	
    	Sheet sheet = ExcelUtils.generateSiteSourceExcel("Spent to Date Update", headersList,resultList);
    	response.setHeader("Content-Disposition", "inline; filename="+ sheetName);
		response.setContentType("application/vnd.ms-excel");
		ServletOutputStream outputStream;
		try {
			outputStream = response.getOutputStream();
			response.setCharacterEncoding("UTF-8");
			sheet.getWorkbook().write(outputStream);
			outputStream.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
				
	}
	
	@Override
	public void getMonthlySpendReport(HttpServletResponse response, String month, String year) {
		List<String[]> headersList = new ArrayList<>(10);
		List<MonthlySpendDTO> monthlySpendOracleList = oracleDao.getMonthlySpendDataFromOracle();
		Set<String> networkNumberSet = getDistinctNetworkValues(monthlySpendOracleList);
		List<MonthlySpendDTO> monthlySpendTeraDataList = new ArrayList<>();
		if(networkNumberSet != null && networkNumberSet.size() > 0){
			monthlySpendTeraDataList = reportsDao.getMonthlySpendDataFromTeradata(networkNumberSet,year+getMonthInNumeric("January"),year+getMonthInNumeric(month));
		}
		List<MonthlySpendDTO> resultList = mapSpendingDataToMonthlySpendList(monthlySpendOracleList,monthlySpendTeraDataList);
		
		String timeStamp = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss").format(Calendar.getInstance().getTime());
		String[] MainReportHeader = {"Latest Data Update (MultiProvider)",timeStamp};
		String[] emptyHeader = {""};
		String yearRange = "JAN "+year+" - "+month.substring(0,3)+" "+year;
		String[] yearRangeHeader = {"Enter Fiscal Year/Period Range",yearRange};
		String[] stringHeader = {"Detailed Enviornmental Charges"};
		String[] excelHeaders = {"Fiscal year/period","Project Name","WO","Activity","Job","Account","Doc Type","Type","Identifier","Document Header Text","Invoice Number","Amount"};
		headersList.add(MainReportHeader);
		headersList.add(emptyHeader);
		headersList.add(yearRangeHeader);
		headersList.add(emptyHeader);
		headersList.add(stringHeader);
		headersList.add(emptyHeader);
		headersList.add(excelHeaders);
		String sheetName = "Monthly Spend Report - "+month+" "+year;
		
		
		Sheet sheet = ExcelUtils.generateMonthlySpendExcel(sheetName, headersList,resultList);
    	response.setHeader("Content-Disposition", "inline; filename="+ sheetName);
		response.setContentType("application/vnd.ms-excel");
		ServletOutputStream outputStream;
		try {
			outputStream = response.getOutputStream();
			response.setCharacterEncoding("UTF-8");
			sheet.getWorkbook().write(outputStream);
			outputStream.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
	}
	
	@Override
	public List<List<Integer>> getProjectCountWaterfallReport(String month, String year) {
		int beginningProjCount = oracleDao.getBeginningProjCount(year);
		List<ProjCountWaterfallDTO> projCountWaterfallList =  oracleDao.getProjCountWaterfallList(year);
		return generateProjectCountwaterfallResponse(beginningProjCount,projCountWaterfallList,Integer.parseInt(projCountWaterfallList.get(0).getYr()),Integer.parseInt(year));
	}
	
	public List<List<Integer>> generateProjectCountwaterfallResponse(int count,List<ProjCountWaterfallDTO> countList,int endYear,int selectedYear){
		List<Integer> beginningProjCountList = new ArrayList<>(12);
		List<Integer> closedSitesCountList = new ArrayList<>(12);
		List<Integer> newSitesCountList = new ArrayList<>(12);
		int startYear = selectedYear - 10;
		List<ProjCountWaterfallDTO> CombinedList = new ArrayList<>(12);
		generateFinalDataList(count, countList, startYear, endYear, CombinedList);
		  
		int previousBeginningProjCount = 0;
		for(ProjCountWaterfallDTO dto: CombinedList){
			if(previousBeginningProjCount == 0){
				previousBeginningProjCount = count;
				beginningProjCountList.add(count);	
			}else{
				beginningProjCountList.add(previousBeginningProjCount);
			}
			
			LOGGER.info("Year "+dto.getYr() +" :: ClosedSites "+dto.getClosedSites() +" :: Newsites "+dto.getNewSites());
			
			closedSitesCountList.add(dto.getClosedSites());
			newSitesCountList.add(dto.getNewSites());
			previousBeginningProjCount = previousBeginningProjCount + dto.getNewSites() - dto.getClosedSites(); 
			
		}
		
		List<List<Integer>> responseList = new ArrayList<>(5);
		responseList.add(beginningProjCountList);
		responseList.add(closedSitesCountList);
		responseList.add(newSitesCountList);
		return responseList;
	}

	/**
	 * @param count
	 * @param countList
	 * @param startYear
	 * @param endYear
	 * @param CombinedList
	 * @return
	 */
	public void generateFinalDataList(int count, List<ProjCountWaterfallDTO> countList, int startYear, int endYear,
			List<ProjCountWaterfallDTO> CombinedList) {
		for(;startYear < endYear; startYear++){
			ProjCountWaterfallDTO dto = new ProjCountWaterfallDTO(count, 0, 0, Integer.toString(startYear));
			CombinedList.add(dto);
			if(startYear + 1 == endYear){
				int temp = endYear;  
				for(int i = 0 ; i < countList.size(); i++){
					LOGGER.info("CountList Object :: "+countList.get(i));
					if(Integer.parseInt(countList.get(i).getYr()) == temp){
						CombinedList.add(countList.get(i));	
						temp++;
					}else{
						addMissingYearsDataToList(count, countList, CombinedList, temp, i);
					}
				}
			}
		}
	}

	public void addMissingYearsDataToList(int count, List<ProjCountWaterfallDTO> countList,List<ProjCountWaterfallDTO> CombinedList, int temp, int i) {
		for(;temp <= Integer.parseInt(countList.get(i).getYr());temp++){
			if(temp == Integer.parseInt(countList.get(i).getYr())){
				CombinedList.add(countList.get(i));	
			}else{
				ProjCountWaterfallDTO pcw = new ProjCountWaterfallDTO(count, 0, 0, Integer.toString(temp));
				CombinedList.add(pcw);	
			}
				
		}
	}
	

	
	
	@Override
	public void getQuarterlyAuditBackupReport(HttpServletResponse response, String month, String year) {
		reportsHelper.generateLewbReort(response, month, year, "QuarterlyAuditBackup");
	}
	
	

	public Map<String,List<String>> generateMapFromSiteSourceSpendingList(List<SiteSourceDTO> spendingPerYearData){
		HashMap<String,List<String>> map = new HashMap<>();
		
		for(SiteSourceDTO dto : spendingPerYearData){
			map.put(dto.getNetwork(), dto.getSpendingPerYear());
		}
		
		return map;
	}
	
	public List<MonthlySpendDTO> mapSpendingDataToMonthlySpendList(List<MonthlySpendDTO> monthlySpendOracleList,List<MonthlySpendDTO> monthlySpendTeraDataList){
		List<MonthlySpendDTO> resultList = new ArrayList<>();
		
		Map<String,String> map = new HashMap<>();
		for(MonthlySpendDTO dto : monthlySpendOracleList){
			map.put(dto.getNetwork(), dto.getProjName());
		}
		
		for(MonthlySpendDTO dto : monthlySpendTeraDataList){
			if(map.containsKey(dto.getNetwork())){
				dto.setProjName(map.get(dto.getNetwork()));
				resultList.add(dto);	
			}
		}
		
		return resultList;
	}
	
	public List<SiteSourceDTO> mapSpendingDataToSiteSourceList(List<SiteSourceDTO> siteSourceList,List<SiteSourceDTO> spendingPerYearData,int year){
		List<SiteSourceDTO> resultList = new ArrayList<>();
		
		Map<String,List<String>> map = generateMapFromSiteSourceSpendingList(spendingPerYearData);
		int recordCount = 9;
		for(SiteSourceDTO dto : siteSourceList){
			if(map.containsKey(dto.getNetwork())){
				dto.setSpendingPerYear(map.get(dto.getNetwork()));
				dto.setTotalUpSpending(generateTotalUpSpendingFormula(year, recordCount));
				dto.setTotalProjectSpending(generateTotalProjectSpendingFormula(dto.getTotalUpSpending().split(":")[1], recordCount));
				dto.setTotalCommittedCost(generateTotalCommittedCostFormula(dto.getTotalUpSpending().split(":")[1], recordCount));
				LOGGER.info(dto.getTotalUpSpending());
				LOGGER.info(dto.getTotalProjectSpending());
				LOGGER.info(dto.getTotalCommittedCost());
			}else{
				List<String> zeroList = new ArrayList<>();
				for(int startyear = 1982; startyear <= year; startyear++){
					zeroList.add("0");
				}
				dto.setSpendingPerYear(zeroList);
				dto.setTotalUpSpending(generateTotalUpSpendingFormula(year, recordCount));
				dto.setTotalProjectSpending(generateTotalProjectSpendingFormula(dto.getTotalUpSpending().split(":")[1], recordCount));
				dto.setTotalCommittedCost(generateTotalCommittedCostFormula(dto.getTotalUpSpending().split(":")[1], recordCount));
				LOGGER.info(dto.getTotalUpSpending());
				LOGGER.info(dto.getTotalProjectSpending());
				LOGGER.info(dto.getTotalCommittedCost());
			}
			
			resultList.add(dto);
			recordCount++;
		}
		
		return resultList;
	}
	
	public String getTotalDaysCountInAMonth(int year, String month){
		
		List<String> months =Arrays.asList("January,February,March,April,May,June,July,August,September,October,November,December".split(","));
		
		int iMonth = months.indexOf(month); 
		int iDay = 1;

		Calendar mycal = new GregorianCalendar(year, iMonth, iDay);

		int daysInMonth = mycal.getActualMaximum(Calendar.DAY_OF_MONTH);
		
		return Integer.toString(daysInMonth);
	}
	
	public String generateTotalUpSpendingFormula(int year,int recordCount){
		char[] alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".toCharArray();
		String formula = "SUM(H"+recordCount+":";
		int startYear = 1982;
		int currentYear = year;
		int diff = currentYear - startYear;
		int secondIndex = ((int)diff % 26) + 7;
		
		if((diff % 26 + 7) >= 26){
		    diff = diff + 7;
		    secondIndex = ((int)diff % 26);
		}
			
		formula = formula + alphabet[(int)Math.ceil((diff / 26)) -1]+alphabet[secondIndex]+recordCount+")";
		
		return formula;
	}
	
	public String generateTotalProjectSpendingFormula(String column,int recordCount){
		
		char[] alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".toCharArray();
		column = column.replace(")","").trim();
		int index = new String(alphabet).indexOf(column.charAt(1));
		String formula = "";
		if(index == 25){
			int firstIndex = new String(alphabet).indexOf(column.charAt(1));
			formula =  formula + alphabet[firstIndex+1]+alphabet[firstIndex+1]+column.substring(2, column.length())+"+"+alphabet[firstIndex+1]+alphabet[firstIndex+2]+column.substring(2, column.length());
		}
		formula =  formula + column.charAt(0)+alphabet[index+1]+column.substring(2, column.length())+"+"+column.charAt(0)+alphabet[index+2]+column.substring(2, column.length());
		return formula;
	}
	
	public String generateTotalCommittedCostFormula(String column,int recordCount){
		
		char[] alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".toCharArray();
		column = column.replace(")","").trim();
		int index = new String(alphabet).indexOf(column.charAt(1));
		String formula = "";
		if(index == 25){
			int firstIndex = new String(alphabet).indexOf(column.charAt(1));
			formula =  formula + alphabet[firstIndex+1]+alphabet[firstIndex+3]+column.substring(2, column.length())+"+"+alphabet[firstIndex+1]+alphabet[firstIndex+4]+column.substring(2, column.length());
		}
		formula =  formula + column.charAt(0)+alphabet[index+3]+column.substring(2, column.length())+"+"+column.charAt(0)+alphabet[index+4]+column.substring(2, column.length());
		return formula;
	}
	
	
	
	public String generateYearsTillDate(String year){
		int startYear = 1982;
		int currentYear = Integer.parseInt(year);
		String yearRow = "";
		for(startYear = 1982 ; startYear <= currentYear ; startYear++){
			if(startYear != currentYear)
				yearRow = yearRow + startYear +",";
			else
				yearRow = yearRow + startYear;
		}
		return yearRow;
	}
	
	public String getQuartersBasedOnMonth(String month){
		String quarter = "";
		if(month.equalsIgnoreCase("january") || month.equalsIgnoreCase("feburary") || month.equalsIgnoreCase("march")){
			quarter = "1st Qtr";
		}else if(month.equalsIgnoreCase("april") || month.equalsIgnoreCase("may") || month.equalsIgnoreCase("june")){
			quarter = "2nd Qtr";
		}else if(month.equalsIgnoreCase("july") || month.equalsIgnoreCase("august") || month.equalsIgnoreCase("september")){
			quarter = "3rd Qtr";
		}else if(month.equalsIgnoreCase("october") || month.equalsIgnoreCase("november") || month.equalsIgnoreCase("december")){
			quarter = "4th Qtr";
		}
		
		return quarter;
	}
	
	public String generateFormuleHeaderForSiteSource(String headerType,String year,int recordsCount){
		char[] alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".toCharArray();
		String startRow = "9";
		String endRow = Integer.toString(recordsCount);
		String formula = "=SUBTOTAL(9,";
		if(headerType.equalsIgnoreCase("liabilities")){
			formula = "SUBTOTAL(9,";
		}else{
			formula = "SUBTOTAL(3,";
		}
		String formulaHeader = "";
		int startYear = 1982;
		int i = 0;
		int j = 7;
		boolean singleDigit = true;
		for(startYear = 1982 ; startYear <= Integer.parseInt(year)+5 ; startYear++){
			
			if(j == alphabet.length-1){
				if(singleDigit){
					formula = formula + alphabet[j]+startRow+":"+alphabet[j]+endRow+")";
					singleDigit = false;
				}else{
					formula = formula + alphabet[i]+alphabet[j]+startRow+":"+alphabet[i]+alphabet[j]+endRow+")";
					i++;
				}
				
				j = 0;
				
			}else if(j < alphabet.length){
				if(singleDigit){
					formula = formula + alphabet[j]+startRow+":"+alphabet[j]+endRow+")";	
				}else{
					formula = formula + alphabet[i]+alphabet[j]+startRow+":"+alphabet[i]+alphabet[j]+endRow+")";	
				}
				
				j++;
				
			}
			
			if(startYear != Integer.parseInt(year)+5)
				formulaHeader = formulaHeader  + formula +"#";
			else
				formulaHeader = formulaHeader  + formula;
			
			if(headerType.equalsIgnoreCase("liabilities")){
				formula = "SUBTOTAL(9,";
			}else{
				formula = "SUBTOTAL(3,";
			}
			
		}
		return formulaHeader;
	}
	
	
	
	public List<BusinessPrepPlanDTO> getReportList(List<BusinessPrepPlanDTO> teradataList,List<BusinessPrepPlanDTO> oracleList){
		List<BusinessPrepPlanDTO> resultList = new ArrayList<>();
		
		Map<String,BusinessPrepPlanDTO> map = new HashMap<>();
		for(BusinessPrepPlanDTO dto : oracleList){
			LOGGER.info("DTO VALUE :: "+dto.toString());
			map.put(dto.getNetwork(), dto);
		}
		
		for(BusinessPrepPlanDTO dto : teradataList){
			if(map.containsKey(dto.getNetwork())){
				dto.setEstimtor(map.get(dto.getNetwork()).getEstimtor());
				dto.setSiteRemManager(map.get(dto.getNetwork()).getSiteRemManager());
				dto.setWoDesc(map.get(dto.getNetwork()).getWoDesc());
				resultList.add(dto);
			}
		}
		
		return resultList;
	}
	
	public String getMonthInString(int month){
		String[] months ="January,February,March,April,May,June,July,August,September,October,November,December".split(",");
		return months[month];
	}
	
	public String getMonthInNumeric(String month){
		String numericMonth = "000";
		switch(month){
			case "January":
				numericMonth = "001";
				break;
			case "February":
				numericMonth = "002";
				break;
			case "March":
				numericMonth = "003";
				break;
			case "April":
				numericMonth = "004";
				break;	
			case "May":
				numericMonth = "005";
				break;
			case "June":
				numericMonth = "006";
				break;
			case "July":
				numericMonth = "007";
				break;
			case "August":
				numericMonth = "008";
				break;
			case "September":
				numericMonth = "009";
				break;
			case "October":
				numericMonth = "010";
				break;	
			case "November":
				numericMonth = "011";
				break;	
			case "December":
				numericMonth = "012";
				break;		
		}
		return numericMonth;
	}
	
	public Set<String> getDistinctNetworkValues(List<?> list){
		Set<String> networkNumberSet = new HashSet<>();
		
		for(int i = 0 ; i < list.size(); i++){
			if(list.get(i) instanceof BusinessPrepPlanDTO){
				BusinessPrepPlanDTO dto = (BusinessPrepPlanDTO)list.get(i);
				networkNumberSet.add(dto.getNetwork());
			}else if(list.get(i) instanceof SiteSourceDTO){
				SiteSourceDTO dto = (SiteSourceDTO)list.get(i);
				networkNumberSet.add(dto.getNetwork());
			}else if(list.get(i) instanceof MonthlySpendDTO){
				MonthlySpendDTO dto = (MonthlySpendDTO)list.get(i);
				networkNumberSet.add(dto.getNetwork());
			}
		}
		return networkNumberSet;
	}
	
	/*public static Set<String> getDistinctNetworkValues(List<SiteSourceDTO> list){
		Set<String> networkNumberSet = new HashSet<>();
		for(SiteSourceDTO dto : list){
			networkNumberSet.add(dto.getNetwork());
		}
		return networkNumberSet;
	}*/
	
	public List<AccountCostDTO> getAccountData(String netwrokNumbers) {
		int year = Calendar.getInstance().get(Calendar.YEAR);
		int month = Calendar.getInstance().get(Calendar.MONTH)+1;
		String startDate = year+"001";
		String endDate =  null;
		if(month > 9){
		    endDate = year+"0"+month;
		}else{
		    endDate = year+"00"+month;
		}
		
		return reportsDao.getAccountData(startDate,endDate,netwrokNumbers);
	    }

	@Override
	public void getLCRReport(HttpServletResponse response, LCRRprtSearchCriteriaDTO lcrRprtSearchCriteria) {
		try {
			
			OverAllDataLCRRprtDTO overAllDataLCRRprtDTO = new OverAllDataLCRRprtDTO();
			List<LCRRprtDTO> lcrRprtLiabEstAmt = oracleDao.getAllProjectLstforSumOfLiabEst(lcrRprtSearchCriteria);
			
			List<LCRRprtDTO> lcrRprtChngedAmtIncDecBy10000List = oracleDao.getProjectListIncrsedChngdEstBy10000forMMYYYY(lcrRprtSearchCriteria);
			List<List<LCRRprtDTO>> lcrRprtDTOLstofLst = getProjectLstForLCRReport(lcrRprtChngedAmtIncDecBy10000List);

			List<LCRRprtDTO> lcrRptDTOAllPrjctLstforTubeLevelGrtrThanSix = oracleDao.getAllProjectLstforTubelevelGreaterThan6(lcrRprtSearchCriteria);
			
			List<LCRRprtDTO> lcrRptDTOAllNewProjectLst = oracleDao.getNewProjectListforMMYYYY(lcrRprtSearchCriteria);
			
			Integer totalLiabilityEstAmt = getSumAllLiabilityEstForLCRReport(lcrRprtLiabEstAmt);
			Integer totalLiabilityEstChanged = getSumAllChangedEstForLCRReport(lcrRprtChngedAmtIncDecBy10000List);
			Integer totalLiabilityEstChangedForQrtr = getSumOfAllLiabilityEstOfQuarterLCRRpt(lcrRprtSearchCriteria);
			
			
			
			overAllDataLCRRprtDTO.setLcrRprtChngedAmtIncDecBy10000List(lcrRprtChngedAmtIncDecBy10000List);
			overAllDataLCRRprtDTO.setLcrRprtDTOLstofLst(lcrRprtDTOLstofLst);
			overAllDataLCRRprtDTO.setLcrRprtLiabEstAmt(lcrRprtLiabEstAmt);
			overAllDataLCRRprtDTO.setLcrRptDTOAllNewProjectLst(lcrRptDTOAllNewProjectLst);
			overAllDataLCRRprtDTO.setLcrRptDTOAllPrjctLstforTubeLevelGrtrThanSix(lcrRptDTOAllPrjctLstforTubeLevelGrtrThanSix);
			overAllDataLCRRprtDTO.setTotalLiabilityEstAmt(totalLiabilityEstAmt);
			overAllDataLCRRprtDTO.setTotalLiabilityEstChanged(totalLiabilityEstChanged);
			overAllDataLCRRprtDTO.setTotalLiabilityEstChangedForQrtr(totalLiabilityEstChangedForQrtr);
			
			String[] firstLastDayStrings = WebDateUtils.getFirstLastDayInMMMMddyyyyFormat(lcrRprtSearchCriteria.getMonth(), lcrRprtSearchCriteria.getYear());
			overAllDataLCRRprtDTO.setFirstLastDayStrings(firstLastDayStrings);
			
			//reportsHelper.getLCRReport(response,lcrRprtSearchCriteria,totalLiabilityEstAmt,totalLiabilityEstChanged,totalLiabilityEstChangedForQrtr,lcrRptDTOAllNewProjectLst,lcrRprtDTOLstofLst,lcrRptDTOAllPrjctLstforTubeLevelGrtrThanSix);
			reportsHelper.getLCRReport(response,lcrRprtSearchCriteria,overAllDataLCRRprtDTO);
		} catch (Exception e) {
			throw new LmsException(e);
		}
	}

	@Override
	public String getlastQuarterMonth(String month) {
	
		String numericMonth = "000";
		switch(month){
			case "January":
				numericMonth = "012"+"##"+"December";
				break;
			case "February":
				numericMonth = "012"+"##"+"December";
				break;
			case "March":
				numericMonth = "012"+"##"+"December";
				break;
			case "April":
				numericMonth = "003"+"##"+"March";
				break;	
			case "May":
				numericMonth = "003"+"##"+"March";
				break;
			case "June":
				numericMonth = "003"+"##"+"March";
				break;
			case "July":
				numericMonth = "006"+"##"+"June";
				break;
			case "August":
				numericMonth = "006"+"##"+"June";
				break;
			case "September":
				numericMonth = "006"+"##"+"June";
				break;
			case "October":
				numericMonth = "009"+"##"+"September";
				break;	
			case "November":
				numericMonth = "009"+"##"+"September";
				break;	
			case "December":
				numericMonth = "009"+"##"+"September";
				break;		
		}
		return numericMonth;
	}

	public List<List<LCRRprtDTO>> getProjectLstForLCRReport(List<LCRRprtDTO> LCRRprtDTOLst) {
		List<LCRRprtDTO> LCRRprtDTOIncBy10000Lst = new ArrayList<LCRRprtDTO>();
		List<LCRRprtDTO> LCRRprtDTODecBy10000Lst = new ArrayList<LCRRprtDTO>();
		for(LCRRprtDTO lcrrprtDTO : LCRRprtDTOLst){
			if(lcrrprtDTO.getChangedLiabilityEstimate() < 10000){
				LCRRprtDTO lcrrprtdecby10000DTO = new LCRRprtDTO();
				lcrrprtdecby10000DTO = lcrrprtDTO;
				LCRRprtDTODecBy10000Lst.add(lcrrprtdecby10000DTO);
			}
			if(lcrrprtDTO.getChangedLiabilityEstimate() >= 10000){
				LCRRprtDTO lcrrprtincby10000DTO = new LCRRprtDTO();
				lcrrprtincby10000DTO = lcrrprtDTO;
				LCRRprtDTOIncBy10000Lst.add(lcrrprtincby10000DTO);
			}
		}
		List<List<LCRRprtDTO>>  LCRRprtDTOLstofLst= new ArrayList<List<LCRRprtDTO>>();
		LCRRprtDTOLstofLst.add(LCRRprtDTOIncBy10000Lst);
		LCRRprtDTOLstofLst.add(LCRRprtDTODecBy10000Lst);	
		return LCRRprtDTOLstofLst;
	}

	public Integer getSumAllChangedEstForLCRReport(List<LCRRprtDTO> lcrRprtChngedAmtIncDecBy10000List) {
		Integer totalLiabEstChanged =0;
		for(LCRRprtDTO lcrrprtDTO : lcrRprtChngedAmtIncDecBy10000List){
			totalLiabEstChanged += lcrrprtDTO.getChangedLiabilityEstimate();
		}
		return totalLiabEstChanged;
	}
	public Integer getSumAllLiabilityEstForLCRReport(List<LCRRprtDTO> lcrRprtLiabEstAmt) {
		Integer totalLiabEstAmt =0;
		for(LCRRprtDTO lcrrprtDTO : lcrRprtLiabEstAmt){
			totalLiabEstAmt += lcrrprtDTO.getTotalLiabEstAmt();
		}
		return totalLiabEstAmt;
	}
	
	public Integer getSumOfAllLiabilityEstOfQuarterLCRRpt(LCRRprtSearchCriteriaDTO lcrRprtSearchCriteria) {
		List<String> monthYearStrLst = WebDateUtils.getAllMonthsOfQuarterInMMMYYYY(lcrRprtSearchCriteria.getMonth(),lcrRprtSearchCriteria.getYear());
		monthYearStrLst.add(lcrRprtSearchCriteria.getMonth().toUpperCase()+"-"+lcrRprtSearchCriteria.getYear());
		LCRRprtSearchCriteriaDTO lcrRprtSearchCriteriaForQuarter = new LCRRprtSearchCriteriaDTO();
		Integer totalLiabilityEstChangedForQrtr = 0;
		for(String monthYearStr : monthYearStrLst){
			String[] strArray = monthYearStr.split("-");
			lcrRprtSearchCriteriaForQuarter.setMonth(strArray[0]);
			lcrRprtSearchCriteriaForQuarter.setYear(strArray[1]);
			List<LCRRprtDTO> lcrRprtChngedAmtIncDecBy10000List = oracleDao.getProjectListIncrsedChngdEstBy10000forMMYYYY(lcrRprtSearchCriteriaForQuarter);
			if(lcrRprtChngedAmtIncDecBy10000List != null && !lcrRprtChngedAmtIncDecBy10000List.isEmpty()){
			totalLiabilityEstChangedForQrtr += getSumAllChangedEstForLCRReport(lcrRprtChngedAmtIncDecBy10000List);
			}
		}
		return totalLiabilityEstChangedForQrtr;
	}

	@Override
	public List<List<Float>> generateLCRBarChart(HttpServletResponse response, String month, String year) {
			List<List<Float>> listOfXYValues = new ArrayList<>();
		try {
			List<LCRRprtChartDTO> lcrRprtDTOlst = reportsDao.getActualExpenditureData(month, year);
			Float totalCost = oracleDao.getTotalCostPlannedExpndtrForYear(year);
			List<Float> plannedcostListMonthwise = new ArrayList<>();
			List<Float> actualExpenditureCostListMonthwise = new ArrayList<>();
			
			Float plannedcost=0F;		
			for(int i=0;i<12;i++){
				plannedcost= plannedcost+totalCost;
				plannedcostListMonthwise.add(plannedcost);
			}
			Float totalActualExpences =0f;
			
			
			for (LCRRprtChartDTO lcrRprtChartDTO : lcrRprtDTOlst) {
				double scale = Math.pow(10, 1);
				totalActualExpences =totalActualExpences + lcrRprtChartDTO.getTotalLiabilityChangeAmtForMonth();
				Float desiMalFormatter = (float) (Math.round(totalActualExpences * scale) / scale);
				actualExpenditureCostListMonthwise.add(desiMalFormatter);
				System.out.println(lcrRprtChartDTO.getMonthYear() + " " + desiMalFormatter);
			}
			
			for (Float floatCost : actualExpenditureCostListMonthwise) {
				System.out.println("floatCost= " +floatCost);
			}
			System.out.println("Total Cost =  " + totalCost);
			System.out.println("Total Actual Cost =  " + totalActualExpences);
			
			listOfXYValues.add(actualExpenditureCostListMonthwise);
			listOfXYValues.add(plannedcostListMonthwise);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return listOfXYValues;
	}

	@Override
	public String archieveLEWBReport(MultipartFile file, String month, String year) throws IOException {
		String guid = docService.uploadDocument(file);
		System.out.println("insdie archiveve service ");
		DocumentDTO doc = new DocumentDTO("", guid, file.getOriginalFilename(), file.getName(), file.getName(), "LEWB", file.getOriginalFilename().split(".")[1], "C", "01-"+month.substring(0,3).toLowerCase()+"-"+year,"");
		DocumentDTO savedDoc = oracleDao.getSavedDoc(month, year, "LEWB");
		if(savedDoc.getDocId() != null && savedDoc.getDocName() != null){
			oracleDao.updateDoc(savedDoc);	
		}
		oracleDao.saveDoc(doc);
		return guid;
	}
	
	@Override
	public String archieveLCRReport(MultipartFile file, String month, String year) throws IOException {
		String guid = docService.uploadDocument(file);
		System.out.println("insdie archiveve service ");
		DocumentDTO doc = new DocumentDTO("", guid, file.getOriginalFilename(), file.getName(), file.getName(), "LCR", file.getOriginalFilename().split(".")[1], "C", "01-"+month.substring(0,3).toLowerCase()+"-"+year,"");
		DocumentDTO savedDoc = oracleDao.getSavedDoc(month, year, "LCR");
		if(savedDoc.getDocId() != null && savedDoc.getDocName() != null){
			oracleDao.updateDoc(savedDoc);	
		}
		oracleDao.saveDoc(doc);
		return guid;
	}

	@Override
	public DocumentVB downloadLEWBReport(String month,String year) {
		DocumentDTO savedDoc = oracleDao.getSavedDoc(month, year, "LEWB");
		DocumentVB docResponse = new DocumentVB();
		if(savedDoc.getGuid() != null){
			docResponse.setGuid(savedDoc.getGuid());
			docResponse.setFileName(savedDoc.getDocName());
			docResponse.setResponse(docService.downloadDocument(savedDoc.getGuid()));
		}
		
		return docResponse;
	}
	
	@Override
	public DocumentVB downloadLCRReport(String month,String year) {
		DocumentDTO savedDoc = oracleDao.getSavedDoc(month, year, "LCR");
		DocumentVB docResponse = new DocumentVB();
		if(savedDoc.getGuid() != null){
			docResponse.setGuid(savedDoc.getGuid());
			docResponse.setFileName(savedDoc.getDocName());
			docResponse.setResponse(docService.downloadDocument(savedDoc.getGuid()));
		}
		
		return docResponse;
	}
}
