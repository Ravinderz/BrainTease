package com.uprr.ema.lms.common.web.util;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import com.uprr.ema.lms.exception.LmsException;
public class WebDateUtil {
	public static String DEFAULT_DISPLAY_FORMAT = "MM/dd/yyyy";

	   /**
	    * get date in specific format
	    * 
	    * @param date
	    * @return
	    */
	   public static String getDisplayformat(Date date) {
	      if (date == null){
	         return null;
	      }
	      SimpleDateFormat format = new SimpleDateFormat(DEFAULT_DISPLAY_FORMAT);
	      return format.format(date);
	   }

	   /**
	    * get date in MM/dd/yyyy hh:mm a format
	    * 
	    * @param date
	    * @return
	    */
	   public static String getDateInMMddyyyyhhmma(Date date) {
	      if (date == null){
	         return null;
	      }
	      SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss a");
	      return format.format(date);
	   }

	   /**
	    * This method will return the string date in MM-dd-yyyy hh:mm:ss
	    * format
	    * @param date
	    * @return
	    */
	   
	   public static Date getDateMMddyyyy(String date) {
		      try {
		         SimpleDateFormat format = new SimpleDateFormat("MM-dd-yyyy hh:mm:ss");
		         return format.parse(date);
		      } catch (ParseException pe) {
		         return null;
		      }
		   }
	   
	   /**
	    * 
	    * @param date
	    * should be in yyyy-MM-dd-hh:mm format.
	    * @return
	    * @throws ParseException
	    */
	   public static Date getDate(String date) {
	      try {
	         SimpleDateFormat format = new SimpleDateFormat(DEFAULT_DISPLAY_FORMAT);
	         return format.parse(date);
	      } catch (ParseException pe) {
	         return null;
	      }
	   }

	   

	   /**
	    * This method is to get the difference of two dates
	    * @param date1
	    * @param date2
	    * @return
	    * @throws EMASITEREMException
	    */
	   public static long getDateDiff(Date date1, Date date2) {
	      long diff = 0;
	      try {
	         Calendar c1 = new GregorianCalendar();
	         c1.setTime(date1);
	         Calendar c2 = new GregorianCalendar();
	         c2.setTime(date2);

	         diff = (c1.getTime().getTime() - c2.getTime().getTime()) ;
	      } catch (Exception e) {
	         throw new LmsException(e);
	      }
	      return diff;
	   }

	  
	  
	   
	   public static String getDateInMMDDYYYY(Date date){
	       DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
	       String text = dateFormat.format(date);
	       return text;
	   }
	  
	   public static Date getDateFromddMMYYY(String inputDate) {
	       DateFormat formatter;
	       Date date;
	       try{
	       formatter = new SimpleDateFormat("MM/dd/yyyy");
	        date = (Date) formatter.parse(inputDate);
	       }catch(Exception e){
	    	   throw new LmsException("Exception Occured while parsing Date");
	       }
	       return date;
	   }
	   
	   /**
	    * 
	    * @param date
	    * should be in yyyy-MM-dd-hh:mm format.
	    * @return
	    * @throws ParseException
	    */
	   public static String getCurrentDate() {
	      try {
	    	  SimpleDateFormat dateformat = new SimpleDateFormat(DEFAULT_DISPLAY_FORMAT);
	    	  Date dateobj = new Date();
	         return dateformat.format(dateobj);
	      } catch (Exception pe) {
	         return null;
	      }
	   }
	    
	   
	   /**
	    * Takes date as string  format "MM/dd/yyyy" and converts to String format "yyyyMMdd"
	    * @param dateAsMMddyyyy
	    * @return
	    * @throws ParseException
	    */
	   public static String convertDateToyyyyMMddFormat(String dateAsMMddyyyy) {
		   String dateInString="";
		   try{
	       DateFormat fromFormat = new SimpleDateFormat("MM/dd/yyyy");
	       fromFormat.setLenient(false);
	       DateFormat toFormat = new SimpleDateFormat("yyyyMMdd");
	       toFormat.setLenient(false);
	       Date date = fromFormat.parse(dateAsMMddyyyy);
	       dateInString= toFormat.format(date);
		   }catch(Exception e){
			   throw new LmsException();
		   }
		   return dateInString;
	   }
}
