package com.uprr.ema.lms.common.vb;

public class SearchCriteriaVB {
	private static final long serialVersionUID = 1L;

	private int startIndex;

	private int endIndex;

	private int recordsCount;

	private int currentPage;

	private int totalPages;

	private String orderByColumn;

	private String sortingType;

	private int recordsPerPage;

	private boolean isExportExcel;

	/**
	 * @return the startIndex
	 */
	public int getStartIndex() {
		return startIndex;
	}

	/**
	 * @param startIndex the startIndex to set
	 */
	public void setStartIndex(int startIndex) {
		this.startIndex = startIndex;
	}

	/**
	 * @return the endIndex
	 */
	public int getEndIndex() {
		return endIndex;
	}

	/**
	 * @param endIndex the endIndex to set
	 */
	public void setEndIndex(int endIndex) {
		this.endIndex = endIndex;
	}

	/**
	 * @return the recordsCount
	 */
	public int getRecordsCount() {
		return recordsCount;
	}

	/**
	 * @param recordsCount the recordsCount to set
	 */
	public void setRecordsCount(int recordsCount) {
		this.recordsCount = recordsCount;
	}

	/**
	 * @return the currentPage
	 */
	public int getCurrentPage() {
		return currentPage;
	}

	/**
	 * @param currentPage the currentPage to set
	 */
	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}

	/**
	 * @return the totalPages
	 */
	public int getTotalPages() {
		return totalPages;
	}

	/**
	 * @param totalPages the totalPages to set
	 */
	public void setTotalPages(int totalPages) {
		this.totalPages = totalPages;
	}

	/**
	 * @return the orderByColumn
	 */
	public String getOrderByColumn() {
		return orderByColumn;
	}

	/**
	 * @param orderByColumn the orderByColumn to set
	 */
	public void setOrderByColumn(String orderByColumn) {
		this.orderByColumn = orderByColumn;
	}

	/**
	 * @return the sortingType
	 */
	public String getSortingType() {
		return sortingType;
	}

	/**
	 * @param sortingType the sortingType to set
	 */
	public void setSortingType(String sortingType) {
		this.sortingType = sortingType;
	}

	/**
	 * @return the recordsPerPage
	 */
	public int getRecordsPerPage() {
		return recordsPerPage;
	}

	/**
	 * @param recordsPerPage the recordsPerPage to set
	 */
	public void setRecordsPerPage(int recordsPerPage) {
		this.recordsPerPage = recordsPerPage;
	}

	/**
	 * @return the isExportExcel
	 */
	public boolean isExportExcel() {
		return isExportExcel;
	}

	/**
	 * @param isExportExcel the isExportExcel to set
	 */
	public void setExportExcel(boolean isExportExcel) {
		this.isExportExcel = isExportExcel;
	}

	/**
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
	
}
