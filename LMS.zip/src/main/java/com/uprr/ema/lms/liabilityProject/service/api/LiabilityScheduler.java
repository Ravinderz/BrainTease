package com.uprr.ema.lms.liabilityProject.service.api;

public interface LiabilityScheduler {

    public void saveProjectUpdates();
    
}
