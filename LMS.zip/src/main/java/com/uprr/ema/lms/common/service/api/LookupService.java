/**
 * This interface deals with the business operations for the master data of the application.
 */
package com.uprr.ema.lms.common.service.api;

import java.util.List;

import com.uprr.ema.lms.common.dto.DropDownInfo;
import com.uprr.ema.lms.common.dto.ManagerDTO;

public interface LookupService {

	/**
	 * Used to retrieve all drop down values .
	 * 
	 * @param tableName
	 * @param code
	 * @param desc
	 * @param masterId
	 * @param sortOrdNbr
	 * @return List<DropDownInfo>
	 * @
	 */
	public List<DropDownInfo> getDropDownOnLoad(String tableName, String code, String desc,String masterId,String sortOrdNbr) ;
	public List<DropDownInfo> getDropDownOnLoadForId(String tableName, String codeId, String code, String desc);
	/**
	 * Used to retrieve all Siterem managers.
	 * @return List<ManagerDTO>
	 * @
	 */
	
	public List<ManagerDTO> getManagers() ;
	/**
	 * Used to retrieve all states
	 * @return List<DropDownInfo>
	 * @
	 */
	public List<DropDownInfo> getStates();
	
	
	
	public DropDownInfo getDropDownInfoByCode(String tableName,String masterIdColumn,String codeColumn,String descprtionColumn,String codeValue)  ;
	
	/*
	 *may be used later */
	
	/*public List<DropDownInfo> getDropDownOnLoadForGroups(String tableName, String code, String alternateCode, String desc)  ;
	
	*//**
	 * Used to retrieve all drop down values .
	 * 
	 * @param tableName
	 * @param code
	 * @param desc
	 * @param alternateCode
	 * @return
	 * @
	 *//*
	public List<DropDownInfo> getDropDownOnLoad(String tableName, String code, String alternateCode, 
		String desc) ;
	
	*//**
	 * 
	 * @param tableName
	 * @param codeId
	 * @param code
	 * @param desc
	 * @return
	 * @
	 *//*
	public List<DropDownInfo> getDropDownOnLoadForId(String tableName, 
		String codeId, String code, String desc) ;
	
	*//** 
	 * Used to retrieve all the dropdown details based on the UserRole
	 * 
	 * @param searchCode,UserRole 
	 * @return list 
	 * @
	 *//*
	public List<DropDownInfo> getInspListByRole(UserWebVB user) ;
	

	*//**
	 * To get the master data in the form of MultiSelect object.
	 * 
	 * @param id
	 * @param tableName
	 * @param code
	 * @param desc
	 * @return
	 * @
	 *//*
	public List<MultiSelect> getMultiSelectList(String id, String tableName, String code, 
		String desc) ;
	
	public List<MailPropInspectionDTO> getInspectionPropDtls(String inpsectionNb) ;
	
	*//**
	 * This method is used to get master data for the multi select components in
	 * property use and previous property use details sections under Lessee
	 * response tab
	 * @param id
	 * @param tableName
	 * @param code
	 * @param desc
	 * @return List<MultiSelect>
	 * @
	 *//*
	public List<MultiSelect> getMultiSelectListForLeseResp(String id, String tableName, String code, 
			String desc) ;
	
	*//**
	 * Get the DropDownInfo entire object based on the masterId for the given tableName
	 * @param masterId
	 * @param tableName
	 * @return
	 * @
	 *//*
	//public DropDownInfo getDropDownInfoByMstrId(long masterId, String tableName) ;
	
	
	
	public List<String> getCustomerNamesFromREMS(String custName) ;

	List<DropDownInfo> getDropDownOnLoadOrderBy(String tableName, String code, String alternateCode, String desc,
			String orderBy);
	
	public List<DropDownInfo> getDropDownsBySortOrder(String tableName, String id, 
		String code, String desc, String orderByColumn);
	
	*//**
	 * <p> Get Desription From Master Table based on Its Master Code </p>
	 *//*
	public String getDescription(String tableName,String masterCodeColumnName,String masterCode);*/
	
}
