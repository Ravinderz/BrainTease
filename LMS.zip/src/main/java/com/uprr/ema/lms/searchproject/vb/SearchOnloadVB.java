package com.uprr.ema.lms.searchproject.vb;

import java.util.List;

import com.uprr.ema.lms.common.dto.DropDownInfo;
import com.uprr.ema.lms.common.dto.ManagerDTO;
import com.uprr.ema.lms.common.vb.StatusDetailsVB;

public class SearchOnloadVB extends StatusDetailsVB {
	
private List<DropDownInfo> tubeLevelList;
private List<DropDownInfo> projectStatusList;
private List<DropDownInfo> projectNameList;
private List<DropDownInfo> estimators;
private List<ManagerDTO> siteRemManagers;
private boolean updateFlag;
private boolean viewFlag;


/**
 * @return the estimators
 */
public List<DropDownInfo> getEstimators() {
	return estimators;
}
/**
 * @param estimators the estimators to set
 */
public void setEstimators(List<DropDownInfo> estimators) {
	this.estimators = estimators;
}
/**
 * @return the siteRemManagers
 */
public List<ManagerDTO> getSiteRemManagers() {
	return siteRemManagers;
}
/**
 * @param siteRemManagers the siteRemManagers to set
 */
public void setSiteRemManagers(List<ManagerDTO> siteRemManagers) {
	this.siteRemManagers = siteRemManagers;
}
/**
 * @return the tubeLevelList
 */
public List<DropDownInfo> getTubeLevelList() {
	return tubeLevelList;
}
/**
 * @param tubeLevelList the tubeLevelList to set
 */
public void setTubeLevelList(List<DropDownInfo> tubeLevelList) {
	this.tubeLevelList = tubeLevelList;
}
/**
 * @return the projectStatusList
 */
public List<DropDownInfo> getProjectStatusList() {
	return projectStatusList;
}
/**
 * @param projectStatusList the projectStatusList to set
 */
public void setProjectStatusList(List<DropDownInfo> projectStatusList) {
	this.projectStatusList = projectStatusList;
}
/**
 * @return the projectNameList
 */
public List<DropDownInfo> getProjectNameList() {
	return projectNameList;
}
/**
 * @param projectNameList the projectNameList to set
 */
public void setProjectNameList(List<DropDownInfo> projectNameList) {
	this.projectNameList = projectNameList;
}
public boolean isUpdateFlag() {
    return updateFlag;
}
public void setUpdateFlag(boolean updateFlag) {
    this.updateFlag = updateFlag;
}
public boolean isViewFlag() {
    return viewFlag;
}
public void setViewFlag(boolean viewFlag) {
    this.viewFlag = viewFlag;
}



}
