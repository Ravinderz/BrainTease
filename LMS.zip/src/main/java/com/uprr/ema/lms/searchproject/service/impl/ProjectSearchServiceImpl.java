package com.uprr.ema.lms.searchproject.service.impl;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uprr.ema.lms.common.dao.api.LookupDao;
import com.uprr.ema.lms.common.dto.DropDownInfo;
import com.uprr.ema.lms.common.dto.ManagerDTO;
import com.uprr.ema.lms.common.service.api.IAuthorizationService;
import com.uprr.ema.lms.common.service.util.ServiceConstants;
import com.uprr.ema.lms.common.util.CommonUtils;
import com.uprr.ema.lms.reports.dao.api.ReportsDao;
import com.uprr.ema.lms.reports.dto.BusinessPrepPlanDTO;
import com.uprr.ema.lms.searchproject.dao.api.ProjectSearchDao;
import com.uprr.ema.lms.searchproject.dto.LEWBReportDto;
import com.uprr.ema.lms.searchproject.dto.ProjectSearchCriteriaDTO;
import com.uprr.ema.lms.searchproject.dto.SearchDTO;
import com.uprr.ema.lms.searchproject.service.api.ProjectSearchService;
import com.uprr.ema.lms.searchproject.vb.SearchOnloadVB;

@Service
public class ProjectSearchServiceImpl implements ProjectSearchService {
	
	@Autowired
	private LookupDao lookupDao; 
	
	@Autowired
	private ProjectSearchDao projectSearchDao;
	
	@Autowired
	private ReportsDao reportsDao;
	
	@Autowired
	private IAuthorizationService autherizationService;

	@Override
	public SearchOnloadVB getOnloadData(String userId) {
		SearchOnloadVB searchOnloadVB = new SearchOnloadVB();
		List<DropDownInfo> projectStausList = lookupDao.getDropDownOnLoad(ServiceConstants.EMA_LMS_PROJ_ACTN_MSTR, ServiceConstants.ACTN_CODE, ServiceConstants.ACTN_DESC);
		if(CommonUtils.isNotEmpty(projectStausList)){
			searchOnloadVB.setProjectStatusList(projectStausList);
		}
		List<DropDownInfo> tubeLevelList = 
			lookupDao.getDropDownOnLoad(ServiceConstants.EMA_LMS_TUBE_LEVL_MSTR, ServiceConstants.TUBE_LEVL_ID, ServiceConstants.TUBE_LEVL_CODE, ServiceConstants.TUBE_LEVL_DESC);
		
		if(CommonUtils.isNotEmpty(tubeLevelList)){
			searchOnloadVB.setTubeLevelList(tubeLevelList);
		}
		//List<DropDownInfo> projectNameList = lookupDao.getDropDownOnLoad(ServiceConstants.EMA_LMS_PROJ, ServiceConstants.PROJ_ID, ServiceConstants.PROJ_NAME);
		List<DropDownInfo> projectNameList = projectSearchDao.getProjectNames();
		if(CommonUtils.isNotEmpty(projectNameList)){
			searchOnloadVB.setProjectNameList(projectNameList);
		}
		List<DropDownInfo> estimatorList =lookupDao.getDropDownOnLoad(ServiceConstants.EMA_LMS_PROJ_ESTM_MSTR, ServiceConstants.PROJ_ESTM_CODE, ServiceConstants.PROJ_ESTM_DESC, ServiceConstants.PROJ_ESTM_ID, ServiceConstants.SORT_ORD);
		if(CommonUtils.isNotEmpty(estimatorList)){
			searchOnloadVB.setEstimators(estimatorList);
		}
		List<ManagerDTO> siteManagerList =lookupDao.getManagers();
		if(CommonUtils.isNotEmpty(siteManagerList)){
			searchOnloadVB.setSiteRemManagers(siteManagerList);
		}
		searchOnloadVB.setUpdateFlag(autherizationService.canUpdateProject(userId));
		searchOnloadVB.setViewFlag(autherizationService.canViewSummary(userId));
		return searchOnloadVB;
	}
	
	@Override
	public List<DropDownInfo> getProjectNames(String projectNames){
		//return lookupDao.getProjectNames(ServiceConstants.EMA_LMS_PROJ, ServiceConstants.PROJ_ID, ServiceConstants.PROJ_NAME,projectNames);
		return projectSearchDao.getProjectNames();
	}
	
	@Override
	public List<SearchDTO> getSearchResultThroughPagination(ProjectSearchCriteriaDTO projectSearchCriteriaDTO){
		return projectSearchDao.getSearchResultThroughPagination(projectSearchCriteriaDTO);
	}

	@Override
	public int getSearchResultRowCount(ProjectSearchCriteriaDTO projectSearchCriteriaDTO){
		return projectSearchDao.getSearchResultRowCount(projectSearchCriteriaDTO);
	}

	@Override
	public List<SearchDTO> getExcelReport(ProjectSearchCriteriaDTO projectSearchCriteriaDTO) {
		return projectSearchDao.getExcelReport(projectSearchCriteriaDTO);
	}

	@Override
	public List<LEWBReportDto> geLEWBtExcelReport(String fromdate, String toDate) {
		// TODO Auto-generated method stub
		return projectSearchDao.geLEWBtExcelReport(fromdate,toDate);
	}
	
	@Override
	public List<LEWBReportDto> getReasonChnage(Integer projectId) {
		// TODO Auto-generated method stub
		return projectSearchDao.getReasonChnage(projectId);
	}
	
	@Override
	public List<LEWBReportDto> getCostsData(Integer projectId) {
		// TODO Auto-generated method stub
		return projectSearchDao.getCostsData(projectId);
	}

	@Override
	public List<LEWBReportDto> getBeginingOfYearData(Integer projectId, String year) {
		// TODO Auto-generated method stub
		return projectSearchDao.getBeginingOfYearData(projectId,year);
	}

	@Override
	public List<BusinessPrepPlanDTO> getspentAmount(String spentAmountYear) {
		// TODO Auto-generated method stub
		return reportsDao.getspentAmount(spentAmountYear);
	}

	@Override
	public List<LEWBReportDto> getProjectIds(Set<String> networkNumberSet) {
		// TODO Auto-generated method stub
		return projectSearchDao.getspentAmount(networkNumberSet);
	}

	@Override
	public List<LEWBReportDto> getOmmCostsData(Integer projectId) {
		// TODO Auto-generated method stub
		return projectSearchDao.getOmmCostsData(projectId);
	}
	
	@Override
	public List<LEWBReportDto> getliabilityEstimateAmount(String liabiltyQueryString,Integer projectId) {
		// TODO Auto-generated method stub
		return projectSearchDao.getliabilityEstimateAmount(liabiltyQueryString,projectId);
	}
}
