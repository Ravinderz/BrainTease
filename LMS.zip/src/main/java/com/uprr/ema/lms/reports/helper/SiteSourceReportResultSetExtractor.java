package com.uprr.ema.lms.reports.helper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.uprr.ema.lms.reports.dto.SiteSourceDTO;

public class SiteSourceReportResultSetExtractor<T> implements ResultSetExtractor<T> {

	int year;
	
	public SiteSourceReportResultSetExtractor() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SiteSourceReportResultSetExtractor(int year) {
		super();
		this.year = year;
	}

	public T extractData(ResultSet rs) throws SQLException,
	DataAccessException {
		
		SiteSourceDTO dto = new SiteSourceDTO();
		dto.setNetwork(rs.getString("Network"));
		List<String> yearWiseSpending = new ArrayList<>();
		yearWiseSpending.add(rs.getString("spendYear1982"));
		yearWiseSpending.add(rs.getString("spendYear1983"));
		yearWiseSpending.add(rs.getString("spendYear1984"));
		yearWiseSpending.add(rs.getString("spendYear1985"));
		yearWiseSpending.add(rs.getString("spendYear1986"));
		yearWiseSpending.add(rs.getString("spendYear1987"));
		yearWiseSpending.add(rs.getString("spendYear1988"));
		yearWiseSpending.add(rs.getString("spendYear1989"));
		yearWiseSpending.add(rs.getString("spendYear1990"));
		yearWiseSpending.add(rs.getString("spendYear1991"));
		yearWiseSpending.add(rs.getString("spendYear1992"));
		yearWiseSpending.add(rs.getString("spendYear1993"));
		yearWiseSpending.add(rs.getString("spendYear1994"));
		yearWiseSpending.add(rs.getString("spendYear1995"));
		yearWiseSpending.add(rs.getString("spendYear1996"));
		yearWiseSpending.add(rs.getString("spendYear1997"));
		yearWiseSpending.add(rs.getString("spendYear1998"));
		yearWiseSpending.add(rs.getString("spendYear1999"));
		yearWiseSpending.add(rs.getString("spendYear2000"));
		yearWiseSpending.add(rs.getString("spendYear2001"));
		yearWiseSpending.add(rs.getString("spendYear2002"));
		yearWiseSpending.add(rs.getString("spendYear2003"));
		yearWiseSpending.add(rs.getString("spendYear2004"));
		yearWiseSpending.add(rs.getString("spendYear2005"));
		yearWiseSpending.add(rs.getString("spendYear2006"));
		yearWiseSpending.add(rs.getString("spendYear2007"));
		yearWiseSpending.add(rs.getString("spendYear2008"));
		yearWiseSpending.add(rs.getString("spendYear2009"));
		yearWiseSpending.add(rs.getString("spendYear2010"));
		yearWiseSpending.add(rs.getString("spendYear2011"));
		yearWiseSpending.add(rs.getString("spendYear2012"));
		yearWiseSpending.add(rs.getString("spendYear2013"));
		yearWiseSpending.add(rs.getString("spendYear2014"));
		yearWiseSpending.add(rs.getString("spendYear2015"));
		
		int endYear = this.year;
		int startYear = 2016;
		if(startYear <= endYear){
			for(;startYear <= endYear; startYear++){
				String columnName = "spendYear"+startYear;
				yearWiseSpending.add(rs.getString(columnName));
			}
		}
		
		dto.setSpendingPerYear(yearWiseSpending);
		
		return (T) dto;
	}
}
