package com.uprr.ema.lms.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.uprr.ema.lms.common.service.util.LMSUtils;
import com.uprr.ema.lms.common.vb.UserWebVB;
import com.uprr.ui.shared.user.ActiveUserId;
import com.uprr.ui.shared.user.spring.mvc.ActiveUser;

/**
 * This will invoke whenever the first request comes to EMA.
 * Also, used to identify the logged in user information like role, empid, superviosr's information etc.
 * @author xprk208
 * @version 1.0
 * @since 2018-04-30
 * 
 */
@RestController
@RequestMapping("/loginUserInfo")
public class LoginController {
	 /**
     * This will give the logged in user object including roles.
     * @param httpSession
     * @param httpRequest
     * @param user
     * @return
     */
	@GetMapping()
    public @ResponseBody  UserWebVB getUserWebVO(HttpSession httpSession, HttpServletRequest httpRequest,@ActiveUser ActiveUserId user) {
    	UserWebVB userVb= new UserWebVB();
    	//userVb=LMSUtils.getUserRole(httpRequest, userVb);
    	userVb.setUserId(user.getUserId());
    	userVb.setEmpId(user.getEmployeeId());
    	
	return userVb;
    }

}
