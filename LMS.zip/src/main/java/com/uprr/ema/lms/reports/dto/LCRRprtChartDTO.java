package com.uprr.ema.lms.reports.dto;

public class LCRRprtChartDTO {
	
	private Float totalLiabilityChangeAmtForMonth;	
	private Integer monthYear;
	public Float getTotalLiabilityChangeAmtForMonth() {
		return totalLiabilityChangeAmtForMonth;
	}
	public void setTotalLiabilityChangeAmtForMonth(Float totalLiabilityChangeAmtForMonth) {
		this.totalLiabilityChangeAmtForMonth = totalLiabilityChangeAmtForMonth;
	}
	public Integer getMonthYear() {
		return monthYear;
	}
	public void setMonthYear(Integer monthYear) {
		this.monthYear = monthYear;
	}
	@Override
	public String toString() {
		return "LCRRprtChartDTO [totalLiabilityChangeAmtForMonth=" + totalLiabilityChangeAmtForMonth + ", monthYear="
				+ monthYear + "]";
	}
	public LCRRprtChartDTO(Float totalLiabilityChangeAmtForMonth, Integer monthYear) {
		super();
		this.totalLiabilityChangeAmtForMonth = totalLiabilityChangeAmtForMonth;
		this.monthYear = monthYear;
	}
	public LCRRprtChartDTO() {
		super();
	}

}
