package com.uprr.ema.lms.email;

import static com.uprr.ema.lms.common.constant.JMSPropertyKeyConstants.ENA_QCF_00;

import javax.jms.ConnectionFactory;
import javax.jms.Destination;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jms.connection.UserCredentialsConnectionFactoryAdapter;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jndi.JndiObjectFactoryBean;

import com.uprr.ema.lms.jmsconfig.JNDIConfig;

@Configuration
public class ENAConfig extends JNDIConfig {

	private UserCredentialsConnectionFactoryAdapter enaAuthenticationConnectionFactory;
	private JndiObjectFactoryBean enaConnectionFactory;
	JndiObjectFactoryBean enaDestination;
	
	public ENAConfig() {
		// Auto-generated constructor stub
	}

	//Equals to queueConnectionFactory
	@Bean(name = "enaConnectionFactory")
	//@Conditional(value = NonLocalEnvCondition.class)
	public JndiObjectFactoryBean getEnaConnectionFactory() {
		if (enaConnectionFactory == null) {
			enaConnectionFactory = new JndiObjectFactoryBean();
			enaConnectionFactory.setJndiEnvironment(getJndiEnvironment());
			enaConnectionFactory.setJndiName(ENA_QCF_00);
		}
		return enaConnectionFactory;
	}

	//equals to enaQCF
	@Bean(name = "enaAuthenticationConnectionFactory")
	@Primary
	//@Conditional(value = NonLocalEnvCondition.class)
	public UserCredentialsConnectionFactoryAdapter getEnaAuthenticationConnectionFactory() {
		if (enaAuthenticationConnectionFactory == null) {
			UserCredentialsConnectionFactoryAdapter connectionFactoryAdapter = new UserCredentialsConnectionFactoryAdapter();
			connectionFactoryAdapter.setTargetConnectionFactory((ConnectionFactory) getEnaConnectionFactory().getObject());
			connectionFactoryAdapter.setUsername(environment.getProperty("ENA_JMS_USER_NAME"));
			connectionFactoryAdapter.setPassword(getJMSPasswordBean().getPasswordFromCyberArk());
			enaAuthenticationConnectionFactory = connectionFactoryAdapter;
		}
		return enaAuthenticationConnectionFactory;
	}
	
		
	//equals to jmsTemplate
	@Bean(name = "jmsTemplate")
	//@Conditional(value = NonLocalEnvCondition.class)
	//@Primary
	public JmsTemplate getJmsTemplate() {
		JmsTemplate jmsTemplate = new JmsTemplate(getEnaAuthenticationConnectionFactory());
		jmsTemplate.setDefaultDestination((Destination) getEnaDestination().getObject());
		return jmsTemplate;
	}
	
	//equals to  outboundEnaQueueDestination
	@Bean(name="enaDestination")
	//@Conditional(value = NonLocalEnvCondition.class)
	public JndiObjectFactoryBean getEnaDestination(){
		if(enaDestination == null){
			enaDestination = new JndiObjectFactoryBean();
			enaDestination.setJndiEnvironment(getJndiEnvironment());
			enaDestination.setJndiName(environment.getProperty("ENA_QUEUE_NAME"));
		}
		return enaDestination;
		}
	
}
