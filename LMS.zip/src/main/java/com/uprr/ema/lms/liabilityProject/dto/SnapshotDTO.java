package com.uprr.ema.lms.liabilityProject.dto;

import java.io.Serializable;
import java.util.Date;

public class SnapshotDTO implements Serializable{

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    //private String accountNbrData;
    private long snapshotId;
    private long projID;
    private Double monthlyCost;
    private Double quarterCost;
    private Double quarterMonthCost;
    private String actFlag;
    private String crtdUser;
    private String lastUptdUser;
    private Date crtdDate;
    private Date lastUptdDate;
    public long getSnapshotId() {
        return snapshotId;
    }
    public void setSnapshotId(long snapshotId) {
        this.snapshotId = snapshotId;
    }
    public Double getMonthlyCost() {
        return monthlyCost;
    }
    public void setMonthlyCost(Double monthlyCost) {
        this.monthlyCost = monthlyCost;
    }
    public Double getQuarterCost() {
        return quarterCost;
    }
    public void setQuarterCost(Double quarterCost) {
        this.quarterCost = quarterCost;
    }
    public Double getQuarterMonthCost() {
        return quarterMonthCost;
    }
    public void setQuarterMonthCost(Double quarterMonthCost) {
        this.quarterMonthCost = quarterMonthCost;
    }
    public String getActFlag() {
        return actFlag;
    }
    public void setActFlag(String actFlag) {
        this.actFlag = actFlag;
    }
    public String getCrtdUser() {
        return crtdUser;
    }
    public void setCrtdUser(String crtdUser) {
        this.crtdUser = crtdUser;
    }
    public String getLastUptdUser() {
        return lastUptdUser;
    }
    public void setLastUptdUser(String lastUptdUser) {
        this.lastUptdUser = lastUptdUser;
    }
    public Date getCrtdDate() {
        return crtdDate;
    }
    public void setCrtdDate(Date crtdDate) {
        this.crtdDate = crtdDate;
    }
    public Date getLastUptdDate() {
        return lastUptdDate;
    }
    public void setLastUptdDate(Date lastUptdDate) {
        this.lastUptdDate = lastUptdDate;
    }
    public long getProjID() {
        return projID;
    }
    public void setProjID(long projID) {
        this.projID = projID;
    }

}
