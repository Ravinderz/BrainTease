package com.uprr.ema.lms.scheduler.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSourceUtils;
import org.springframework.stereotype.Repository;

import com.uprr.ema.lms.common.dao.impl.OracleDaoImpl;
import com.uprr.ema.lms.liabilityProject.dto.SnapshotDTO;
import com.uprr.ema.lms.scheduler.dao.api.SchedulableDAO;



@Repository
@PropertySource(value = { "classpath:createUpdateProject/createUpdateProj_SQL.properties", "classpath:createUpdateProject/projectCost_SQL.properties" })
public class SchedulerDaoImpl extends OracleDaoImpl implements SchedulableDAO {

    @Autowired
    public Environment environment;

    @Override
    public boolean saveMonthAmount(List<SnapshotDTO> monthSnapshotList){
	int[] count = saveMonthDataAsBatch(monthSnapshotList);
	if(count.length > 0){
	    return true;
	}
	return false;
    }

    private int[] saveMonthDataAsBatch(final List<SnapshotDTO> monthSnapshotList) {
	SqlParameterSource[] accList = SqlParameterSourceUtils.createBatch(monthSnapshotList.toArray());
	//String insertQuery = environment.getProperty("SNP_MON_INSRT_QRY");
	return getNamedParameterJdbcTemplate().batchUpdate(environment.getProperty("SNP_MON_INSRT_QRY"), accList);
    }
}

