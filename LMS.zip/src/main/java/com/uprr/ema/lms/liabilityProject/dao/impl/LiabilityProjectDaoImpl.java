package com.uprr.ema.lms.liabilityProject.dao.impl;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSourceUtils;
import org.springframework.stereotype.Repository;

import com.uprr.ema.lms.common.dao.impl.OracleDaoImpl;
import com.uprr.ema.lms.exception.LmsException;
import com.uprr.ema.lms.liabilityProject.dao.api.LiabilityProjectDao;
import com.uprr.ema.lms.liabilityProject.dto.AccountCostDTO;
import com.uprr.ema.lms.liabilityProject.dto.DisapproveProjDTO;
import com.uprr.ema.lms.liabilityProject.dto.ProjectCostDTO;
import com.uprr.ema.lms.liabilityProject.dto.ProjectDTO;


@Repository
@PropertySource(value = { "classpath:createUpdateProject/createUpdateProj_SQL.properties", "classpath:createUpdateProject/projectCost_SQL.properties" })
public class LiabilityProjectDaoImpl extends OracleDaoImpl implements LiabilityProjectDao {
	
	@Autowired
	public Environment environment;

	
	/**	{@inheritDoc} */
	@Override
	public long saveProjId(ProjectDTO projectDTO) {
		long projDtlId = 0;
		projDtlId = this.getJdbcTemplate().queryForObject(environment.getProperty("PROJ_ID_SEQ_QRY"), Long.class);
		projectDTO.setProjID(projDtlId);
		saveOrUpdate(environment.getProperty("PROJ_ID_INSERT_QRY"), projectDTO);
		return projDtlId;
	}
	/**	{@inheritDoc} */
	@Override
	public long saveProjectDetails(ProjectDTO projectDTO) {
	    long projSeqID = 0;
	    projSeqID = this.getJdbcTemplate().queryForObject(environment.getProperty("PROJ_DTL_SEQ_QRY"), Long.class);
	    projectDTO.setProjDtlID(projSeqID);
	   /* if(projectDTO.getProjID() == 0){
		projectDTO.setProjID(projSeqID);
	    }*/
	    saveOrUpdate(environment.getProperty("PROJ_DTL_INSERT_QRY"), projectDTO);
	    return projSeqID;
	}
	/**	{@inheritDoc} *//*
	@Override
	public long saveApproval(ProjectStatusDetailsDTO projectStatusDTO) {
	    long projectDtlId = 0;
	    projectDtlId = this.getJdbcTemplate().queryForObject(environment.getProperty("PROJ_STAT_SEQ_QRY"), Long.class);
	    saveOrUpdate(environment.getProperty("APRROVE_PROJ_INSERT_QRY"), projectStatusDTO);
	    return projectDtlId;
	}*/
	/**	{@inheritDoc} */
	@Override
	public long saveProjectCostDetails(ProjectCostDTO projectDTO) {
		long projectCostDtlId = 0;
		projectCostDtlId = this.getJdbcTemplate().queryForObject(environment.getProperty("PROJ_COST_DTL_SEQ_QRY"), Long.class);
		projectDTO.setCostId(projectCostDtlId);
		saveOrUpdate(environment.getProperty("PROJ_COST_DTL_INSERT_QRY"), projectDTO);
		return projectCostDtlId;
	}
	/**	{@inheritDoc} */
	/*@Override
	public void updateProjectDetails(ProjectDTO projectDTO) {
		saveOrUpdate(environment.getProperty("PROJ_DTL_UPDATE_QRY"), projectDTO);
	}*/
	
	public void updateApprovedProjToHistory(ProjectDTO projectDTO) {
		saveOrUpdate(environment.getProperty("PROJ_UPDATE_APPRV_TO_HIS_QRY"), projectDTO);
	}
	/**	{@inheritDoc} */
	@Override
	public void updateProjectCostDetails(ProjectCostDTO projectDTO) {
		saveOrUpdate(environment.getProperty("PROJ_COST_DTL_UPDATE_QRY"), projectDTO);
	}
	/**	{@inheritDoc} */
	@Override
	public ProjectDTO getApprovedProjectDetails(long projectID) {
	    ProjectDTO projectDTO = null;
	    List<ProjectDTO> projects = (List<ProjectDTO>)getNamedParamResultsList(environment.getProperty("PROJ_APPROVED_SELECT_BY_PROJ_ID_QRY"), new Object[] { projectID }, ProjectDTO.class);
	    if(projects!=null && !projects.isEmpty()){
		projectDTO = projects.get(0);
	    }
	    return projectDTO;
	}
	
	public ProjectDTO getProjectByProjId(long projectID) {
	    ProjectDTO projectDTO = null;
	    List<ProjectDTO> projects = (List<ProjectDTO>)getNamedParamResultsList(environment.getProperty("PROJ_ALL_SELECT_BY_PROJ_ID_QRY"), new Object[] { projectID }, ProjectDTO.class);
	    if(projects!=null && !projects.isEmpty()){
		projectDTO = projects.get(0);
	    }
	    return projectDTO;
	}
	
	
	/**	{@inheritDoc} */
	@Override
	public List<ProjectCostDTO> getProjectCostDetails(long projectID) {
		return (List<ProjectCostDTO>)getNamedParamResultsList(environment.getProperty("PROJ_COST_DTL_SELECT_QRY"), new Object[] { projectID }, ProjectCostDTO.class);
	}
	
	public List<ProjectCostDTO> getCostsByprojIdAndCostType(long projectID, long costTypeId) {
	    return (List<ProjectCostDTO>)getNamedParamResultsList(environment.getProperty("PROJ_COST_DTL_SELECT_BY_COST_TYPE_QRY"), new Object[] { projectID,costTypeId }, ProjectCostDTO.class);
	}

	public List<ProjectCostDTO> getProjSubmitCosts(long projectID) {
	    return (List<ProjectCostDTO>)getNamedParamResultsList(environment.getProperty("PROJ_COST_SEL_PS_QRY"), new Object[] { projectID }, ProjectCostDTO.class);
	}

	public List<ProjectCostDTO> getProjApprovedCosts(long projectID) {
	    return (List<ProjectCostDTO>)getNamedParamResultsList(environment.getProperty("PROJ_COST_SEL_APPRVD_QRY"), new Object[] { projectID }, ProjectCostDTO.class);
	}
	
	public List<ProjectCostDTO> getProjNoneApprovedCosts(long projectID) {
	    return (List<ProjectCostDTO>)getNamedParamResultsList(environment.getProperty("PROJ_COST_SEL_NON_APPRVD_QRY"), new Object[] { projectID }, ProjectCostDTO.class);
	}
	
	public List<ProjectCostDTO> getCosts(long projectID,String actionType,String action) {
	    return (List<ProjectCostDTO>)getNamedParamResultsList(environment.getProperty("PROJ_COST_SEL_QRY"), new Object[] { actionType,action,projectID }, ProjectCostDTO.class);
	}
	
	public long saveChangeReason(ProjectDTO projectDTO) {
	    long changeReasonID = 0;
	    changeReasonID = this.getJdbcTemplate().queryForObject(environment.getProperty("CHNG_RESN_SEQ_QRY"), Long.class);
	    projectDTO.setChangeReasonDtlId(changeReasonID);
	    if(projectDTO.getChangeReasonDtlId() == 0){
		projectDTO.setChangeReasonDtlId(changeReasonID);
	    }
	    saveOrUpdate(environment.getProperty("CHNG_RESN_INSERT_QRY"), projectDTO);
	    return changeReasonID;
	}
	
	public void updateChangeReason(ProjectDTO projectDTO) {
	    saveOrUpdate(environment.getProperty("CHNG_RESN_UPDATE_QRY"), projectDTO);
	}
	@Override
	public long saveDisaprvProj(DisapproveProjDTO disapproveProjDTO) {
		long disapprvID = 0;
		disapprvID = this.getJdbcTemplate().queryForObject(environment.getProperty("DISAPRV_PROJ_SEQ_QRY"), Long.class);
		disapproveProjDTO.setDisaprvComtDtlID(disapprvID);
		saveOrUpdate(environment.getProperty("DISAPRV_PROJ_INSERT_QRY"), disapproveProjDTO);
		return disapprvID;
	}
	
	@Override
	public String getLastSubmittedProjUser(long projID) {
	    try { 
		return (String)this.getJdbcTemplate().queryForObject(environment.getProperty("PROJ_LAST_SUBMIT_USER_QRY"), new Object[] { projID }, String.class);
	    }  catch (EmptyResultDataAccessException e) {
		return null;
	    } catch (Exception e) {
		throw new LmsException(e);
	    }
	}
	
	@Override
	public String getLastChangeSubmittedProjUser(long projID) {
	    try {  
		return (String)this.getJdbcTemplate().queryForObject(environment.getProperty("PROJ_CHNG_LAST_SUBMIT_USER_QRY"), new Object[] { projID }, String.class);
	    }  catch (EmptyResultDataAccessException e) {
		return null;
	    } catch (Exception e) {
		throw new LmsException(e);
	    }
	}
	
	@Override
	public String getLastChangeSubmittedCostUser(long projID) {
	    try {
		return (String)this.getJdbcTemplate().queryForObject(environment.getProperty("PROJ_COST_CHNG_LAST_SUBMIT_USER_QRY"), new Object[] { projID }, String.class);
	    }  catch (EmptyResultDataAccessException e) {
		return null;
	    } catch (Exception e) {
		throw new LmsException(e);
	    }
	}
	
	@Override
	public List<ProjectDTO> getPendignApprovalProjects() {
		return (List<ProjectDTO>)getNamedParamResultsList(environment.getProperty("PENDING_APPROVAL_QUERY"), new Object[] {  }, ProjectDTO.class);
	}
	
	@Override
	public List<ProjectDTO> getDisApprovedProjects() {
		return (List<ProjectDTO>)getNamedParamResultsList(environment.getProperty("DIS_APPROVED_QUERY"), new Object[] {  }, ProjectDTO.class);
	}
	
	@Override
	public List<AccountCostDTO> getAccountUpdate() {
		return (List<AccountCostDTO>)getNamedParamResultsList(environment.getProperty("ACCOUNT_UPDATES_SELECT"), new Object[] {  }, AccountCostDTO.class);
	}
	
	public List<AccountCostDTO> getOracleAccountUpdate() {
		return (List<AccountCostDTO>)getNamedParamResultsList(environment.getProperty("ACCOUNT_UPDATES_ORACLE"), new Object[] {  }, AccountCostDTO.class);
	}
	
	/*@Override
	public List<AccountCostDTO> getSAPAccountUpdate(Set<String> networkNumberSet) {
	    //String sqlQuery = "";
	    MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("networkIds", networkNumberSet);
	    
	    return (List<AccountCostDTO>)getNamedParamResultsList(environment.getProperty("ACCOUNT_UPDATE_SAP"), parameters, AccountCostDTO.class);
	}*/
	/*public List<AccountCostDTO> getSAPAccountUpdate(String newtworkNumbers) {
	    //String sqlQuery = "";
	    MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("(:networkIds)", newtworkNumbers);
	    
	    return (List<AccountCostDTO>)getNamedParamResultsList(environment.getProperty("ACCOUNT_UPDATE_SAP"), parameters, AccountCostDTO.class);
	}*/
	@Override
	public boolean saveAccountUpdates(List<AccountCostDTO> accountUpdateList){
	    int[] count = saveAccountUpdatesAsBatch(accountUpdateList);
	    if(count.length > 0){
		return true;
	    }
	    return false;
	}
	
	private int[] saveAccountUpdatesAsBatch(final List<AccountCostDTO> accountUpdateList) {
	    SqlParameterSource[] accList = SqlParameterSourceUtils.createBatch(accountUpdateList.toArray());
	    getJdbcTemplate().update(environment.getProperty("ACCOUNT_UPDATES_UPDATE_HIS"));

	    String insertQuery = environment.getProperty("ACCOUNT_UPDATES_INSERT");
	    int[] updatesCount = getNamedParameterJdbcTemplate().batchUpdate(insertQuery, accList);
	    return updatesCount;
	}

	
	@Override
	public void updateProjectDetails(ProjectDTO projectDTO) {
		saveOrUpdate(environment.getProperty("PROJ_DTL_UPDATE_QRY"), projectDTO);
	}

}
