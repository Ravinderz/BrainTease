package com.uprr.ema.lms.scheduler.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.uprr.ema.lms.common.service.util.ServiceConstants;
import com.uprr.ema.lms.liabilityProject.dto.SnapshotDTO;
import com.uprr.ema.lms.scheduler.dao.api.SchedulableDAO;
import com.uprr.ema.lms.scheduler.service.api.SchedulableService;

@Service
public class SchedulerServiceImpl implements SchedulableService {

    @Autowired
    SchedulableDAO schedulableDAO;

    /*@Scheduled(cron = "0 0 0 * * ?")*/
    @Override
    @Transactional
    public void saveLEWBMonthData() {
	prepareLEWBMonthData(ServiceConstants.LMS_APP_USER_ID);
    }

    @Override
    @Transactional
    public void saveLEWBMonthData(String userId) {
	prepareLEWBMonthData(userId);
    }


    /*@Scheduled(cron = "0 0 0 * * ?")*/
    @Override
    @Transactional
    public void saveLEWBQuarterData() {
	prepareLEWBQuarterData(ServiceConstants.LMS_APP_USER_ID);
    }

    @Override
    @Transactional
    public void saveLEWBQuarterData(String userId) {
	prepareLEWBQuarterData(userId);
    }


    /*@Scheduled(cron = "0 0 0 * * ?")*/
    @Override
    @Transactional
    public void saveLEWBMonthInQuarterData() {
	prepareLEWBMonthInQuarterData(ServiceConstants.LMS_APP_USER_ID);
    }

    @Override
    @Transactional
    public void saveLEWBMonthInQuarterData(String userId) {
	prepareLEWBMonthInQuarterData(userId);
    }


    private void prepareLEWBMonthData(String userId){
	List<SnapshotDTO> monthSnapshotList = null;
	schedulableDAO.saveMonthAmount(monthSnapshotList);
    }

    private void prepareLEWBQuarterData(String userId){
	List<SnapshotDTO> monthSnapshotList = null;
	schedulableDAO.saveMonthAmount(monthSnapshotList);
    }

    private void prepareLEWBMonthInQuarterData(String userId){
	List<SnapshotDTO> monthSnapshotList = null;
	schedulableDAO.saveMonthAmount(monthSnapshotList);
    }

}
