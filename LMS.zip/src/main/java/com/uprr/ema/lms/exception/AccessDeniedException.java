package com.uprr.ema.lms.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * 
 * @author Anil Kumar Manchala
 *
 */
@ResponseStatus(value=HttpStatus.FORBIDDEN, reason="User is not authorised to access this resource.") 
public class AccessDeniedException extends RuntimeException {
	private static final long serialVersionUID = -8655562772304113223L;

	public AccessDeniedException() {
		super();
	}

	public AccessDeniedException(String message) {
		super(message);
	}

	public AccessDeniedException(Throwable cause) {
		super(cause.getMessage(), cause);
	}

	public AccessDeniedException(String message, Throwable cause) {
		super(message, cause);
	}




}
