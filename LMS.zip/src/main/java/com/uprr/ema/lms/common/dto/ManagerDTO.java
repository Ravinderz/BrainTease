package com.uprr.ema.lms.common.dto;

import java.io.Serializable;
import java.sql.Timestamp;

public class ManagerDTO implements Serializable {


    private static final long serialVersionUID = 1L;

    private long managerId;
    private String employeeId;
    private String userId;
    private String firstName;
    private String middleName;
    private String lastName;
    private String lastUpdateddUser;
    private Timestamp lastUpdatedDate;
    private String createdUser;
    private Timestamp createdDate;
    private String activeFlag; 
    private String fullName;

    /**
     * @return the managerId
     */
    public long getManagerId() {
	return managerId;
    }
    /**
     * @param managerId the managerId to set
     */
    public void setManagerId(long managerId) {
	this.managerId = managerId;
    }

    /**
	 * @return the employeeId
	 */
	public String getEmployeeId() {
		return employeeId;
	}
	/**
	 * @param employeeId the employeeId to set
	 */
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	/**
     * @return the userId
     */
    public String getUserId() {
	return userId;
    }
    /**
     * @param userId the userId to set
     */
    public void setUserId(String userId) {
	this.userId = userId;
    }
    /**
     * @return the firstName
     */
    public String getFirstName() {
	return firstName;
    }
    /**
     * @param firstName the firstName to set
     */
    public void setFirstName(String firstName) {
	this.firstName = firstName;
    }
    /**
     * @return the middleName
     */
    public String getMiddleName() {
	return middleName;
    }
    /**
     * @param middleName the middleName to set
     */
    public void setMiddleName(String middleName) {
	this.middleName = middleName;
    }
    /**
     * @return the lastName
     */
    public String getLastName() {
	return lastName;
    }
    /**
     * @param lastName the lastName to set
     */
    public void setLastName(String lastName) {
	this.lastName = lastName;
    }
    /**
     * @return the lastUpdateddUser
     */
    public String getLastUpdateddUser() {
	return lastUpdateddUser;
    }
    /**
     * @param lastUpdateddUser the lastUpdateddUser to set
     */
    public void setLastUpdateddUser(String lastUpdateddUser) {
	this.lastUpdateddUser = lastUpdateddUser;
    }
    /**
     * @return the lastUpdatedDate
     */
    public Timestamp getLastUpdatedDate() {
	return lastUpdatedDate;
    }
    /**
     * @param lastUpdatedDate the lastUpdatedDate to set
     */
    public void setLastUpdatedDate(Timestamp lastUpdatedDate) {
	this.lastUpdatedDate = lastUpdatedDate;
    }
    /**
     * @return the createdUser
     */
    public String getCreatedUser() {
	return createdUser;
    }
    /**
     * @param createdUser the createdUser to set
     */
    public void setCreatedUser(String createdUser) {
	this.createdUser = createdUser;
    }
    /**
     * @return the createdDate
     */
    public Timestamp getCreatedDate() {
	return createdDate;
    }
    /**
     * @param createdDate the createdDate to set
     */
    public void setCreatedDate(Timestamp createdDate) {
	this.createdDate = createdDate;
    }
    /**
     * @return the serialversionuid
     */
    public static long getSerialversionuid() {
	return serialVersionUID;
    }
    public String getActiveFlag() {
	return activeFlag;
    }
    public void setActiveFlag(String activeFlag) {
	this.activeFlag = activeFlag;
    }
	/**
	 * @return the fullName
	 */
	public String getFullName() {
		return fullName;
	}
	/**
	 * @param fullName the fullName to set
	 */
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

}
