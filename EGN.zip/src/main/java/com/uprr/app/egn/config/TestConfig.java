package com.uprr.app.egn.config;

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabase;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;


public class TestConfig {
	
	@Bean
    public JdbcTemplate getJdbcTemplate() {
        return new JdbcTemplate(dataSource());
    }
	
	@Bean
    public DataSource dataSource() {
		EmbeddedDatabaseBuilder builder = new EmbeddedDatabaseBuilder();
		EmbeddedDatabase db = builder
				.setName("egn")
				.ignoreFailedDrops(true)
	            .continueOnError(true)
			.setType(EmbeddedDatabaseType.H2)//.H2 or .DERBY
			.addScript("classpath:create-db.sql")
			.addScript("classpath:insert-data.sql")
			
			.build();
 
        return db;
    }
}
