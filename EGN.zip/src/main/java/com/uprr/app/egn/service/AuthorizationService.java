package com.uprr.app.egn.service;

/**
 * Generic Authorization Class for EGN Project.
 * @Author: (Krish)nappan Muthuraman (iots242)
 * Date: 05/07/18
 */

import com.uprr.app.azm.common.AzmRequest;
import com.uprr.app.azm.common.AzmSecurityUtils;
import com.uprr.app.azm.common.EvaluationBuilderFactory;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AuthorizationService implements IAuthorizationService {

	private final Logger logger = LogManager.getLogger(AuthorizationService.class);

	@Autowired
	private AzmSecurityUtils azmSecurityUtils;

	@Override
	public boolean canCreateEvalRequest(String userId) {
		boolean isAuthorized = false;
		EvaluationBuilderFactory.EvaluationBuilder eb = EvaluationBuilderFactory.newEvaluation("User-authorized-to-initiate-workstation-evaluation-process");
		eb.addSubject("subject-id", userId);
		eb.addAction("action-id", "access");
		eb.addResource("resource-id", "ergonomics");
		eb.addResource("feature-id", "create-request");
		AzmRequest authDto = new AzmRequest(eb.build());
		if(azmSecurityUtils.isAuthorized(authDto)) {
			isAuthorized = true;
		}
		logger.info(isAuthorized);
		return isAuthorized;
	}
	
	@Override
	public boolean canApproveMedicalRequest(String userId) {
		boolean isAuthorized = false;
		EvaluationBuilderFactory.EvaluationBuilder eb = EvaluationBuilderFactory.newEvaluation("User-authorized-to-initiate-workstation-evaluation-process");
		eb.addSubject("subject-id", userId);
		eb.addAction("action-id", "access");
		eb.addResource("resource-id", "ergonomics");
		eb.addResource("feature-id", "medical-disposition");
		AzmRequest authDto = new AzmRequest(eb.build());
		if(azmSecurityUtils.isAuthorized(authDto)) {
			isAuthorized = true;
		}
		logger.info(isAuthorized);
		return isAuthorized;
	}
	
	@Override
	public boolean canViewMedicalRecords(String userId) {
		boolean isAuthorized = false;
		EvaluationBuilderFactory.EvaluationBuilder eb = EvaluationBuilderFactory.newEvaluation("User-authorized-to-initiate-workstation-evaluation-process");
		eb.addSubject("subject-id", userId);
		eb.addAction("action-id", "access");
		eb.addResource("resource-id", "ergonomics");
		eb.addResource("feature-id", "medical-view");
		AzmRequest authDto = new AzmRequest(eb.build());
		if(azmSecurityUtils.isAuthorized(authDto)) {
			isAuthorized = true;
		}
		logger.info(isAuthorized);
		return isAuthorized;
	}
	
	@Override
	public boolean canCreateAssessment(String userId) {
		boolean isAuthorized = false;
		EvaluationBuilderFactory.EvaluationBuilder eb = EvaluationBuilderFactory.newEvaluation("User-authorized-to-initiate-workstation-evaluation-process");
		eb.addSubject("subject-id", userId);
		eb.addAction("action-id", "access");
		eb.addResource("resource-id", "ergonomics");
		eb.addResource("feature-id", "create-assessment");
		AzmRequest authDto = new AzmRequest(eb.build());
		if(azmSecurityUtils.isAuthorized(authDto)) {
			isAuthorized = true;
		}
		logger.info(isAuthorized);
		return isAuthorized;
	}
	
	@Override
	public boolean canCreateCostItems(String userId) {
		boolean isAuthorized = false;
		EvaluationBuilderFactory.EvaluationBuilder eb = EvaluationBuilderFactory.newEvaluation("User-authorized-to-initiate-workstation-evaluation-process");
		eb.addSubject("subject-id", userId);
		eb.addAction("action-id", "access");
		eb.addResource("resource-id", "ergonomics");
		eb.addResource("feature-id", "create-cost");
		AzmRequest authDto = new AzmRequest(eb.build());
		if(azmSecurityUtils.isAuthorized(authDto)) {
			isAuthorized = true;
		}
		logger.info(isAuthorized);
		return isAuthorized;
	}
	
	@Override
	public boolean canEditCostItems(String userId) {
		boolean isAuthorized = false;
		EvaluationBuilderFactory.EvaluationBuilder eb = EvaluationBuilderFactory.newEvaluation("User-authorized-to-initiate-workstation-evaluation-process");
		eb.addSubject("subject-id", userId);
		eb.addAction("action-id", "access");
		eb.addResource("resource-id", "ergonomics");
		eb.addResource("feature-id", "edit-cost");
		AzmRequest authDto = new AzmRequest(eb.build());
		if(azmSecurityUtils.isAuthorized(authDto)) {
			isAuthorized = true;
		}
		logger.info(isAuthorized);
		return isAuthorized;
	}
	
	
}
