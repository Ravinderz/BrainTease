package com.uprr.app.egn.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.uprr.app.egn.dto.WorkstationAssessment;

public class AssessmentResultSetExtractor<T> implements ResultSetExtractor<T> {
	

	public T extractData(ResultSet rs) throws SQLException,
			DataAccessException {
		
		WorkstationAssessment request = new WorkstationAssessment();
		request.setRequestId(rs.getString("req_id"));
		request.setAssessmentId(rs.getString("asmt_id"));
		String asmt_date = rs.getString("asmt_date");
		if(asmt_date != null){
			request.setDateofAssessment(asmt_date.split(" ")[0]);	
		}
		request.setWsAssessmentName(rs.getString("wkst_asmt_name"));
		request.setReasonForAssessment(rs.getString("asmt_resn_info"));
		request.setCurrentSymptoms(rs.getString("cur_symp_info"));
		request.setAssessmentWSPosture(rs.getString("asmt_wkst_pstr_desc"));
		request.setCurrentChair(rs.getString("cur_chr_desc"));
		request.setMonitor(rs.getString("mntr_desc"));
		request.setSeatHeight(rs.getString("seat_hgt"));
		request.setMonitorHeight(rs.getInt("mntr_hgt"));
		request.setSeatDepth(rs.getString("seat_deph"));
		request.setKeyboardTrayMouse(rs.getString("kybd_tray_mous_desc"));
		request.setBackRest(rs.getString("back_rest_desc"));
		request.setComments(rs.getString("asmt_cmnt"));
		request.setArmRest(rs.getString("arm_rest_desc"));
		request.setAdjustmentsMade(rs.getString("adj_made_info"));
		request.setChairRecommendations(rs.getString("chr_rcmn_desc"));
		request.setOtherEquipmentNeeds(rs.getString("oth_eqmt_need"));
		request.setSummary(rs.getString("asmt_smry_desc"));
		request.setFollowUpTherapist(rs.getString("flw_up_thrp_name"));
		request.setStatus(rs.getString("asmt_stat_info"));
		return (T) request;
	}
	

}
