package com.uprr.app.egn.service;

import static com.uprr.app.egn.util.Util.getAppName;
import static com.uprr.app.egn.util.Util.getDownloadServiceName;
import static com.uprr.app.egn.util.Util.getEchoServiceName;
import static com.uprr.app.egn.util.Util.getOwnerName;
import static com.uprr.app.egn.util.Util.getUploadServiceName;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

/**
 * Doc class to fetch/store documents for EGN Project.
 * @Author: (Krish)nappan Muthuraman (iots242)
 * Date: 05/07/18
 */

import com.fasterxml.jackson.databind.ObjectMapper;
import com.uprr.app.doc.utility_managed_content_upload_document_1_0.dto.UtilityManagedContentUploadDocumentRequest;
import com.uprr.app.egn.dao.IDocDAO;
import com.uprr.app.egn.dto.Document;
import com.uprr.enterprise.datetime.TimeZoneEnum;
import com.uprr.enterprise.datetime.UTCDateTime;

@Service
public class DocService implements IDocService {
	
	@Autowired
	IDocDAO docDAO;

	Logger logger = LogManager.getLogger(DocService.class);
	public final RestTemplate restTemplate;
	public final String esbUrl;

	public DocService(RestTemplateBuilder restTemplateBuilder, String esbUrl) {
		this.restTemplate = restTemplateBuilder.build();
		this.esbUrl = esbUrl;
	}

	@Override
	public void callEchoService() throws Exception {
		logger.info(" B4 echo Service call !!" + this.esbUrl + getEchoServiceName());
		ResponseEntity<String> entity = this.restTemplate.getForEntity(this.esbUrl + getEchoServiceName(), String.class);
		logger.info("After echo Service call !!" + entity.getStatusCodeValue());
	}

	@Override
	public Document persistDoc(MultipartFile file) throws Exception {
		UtilityManagedContentUploadDocumentRequest request = new UtilityManagedContentUploadDocumentRequest();
		Document doc = new Document(); 
		request.setApplication(getAppName());
		request.setMimeType("text/plain");
		request.setOwner(getOwnerName());
		request.setRetentionExpiration(UTCDateTime.createAmbiguousUTCDateTime(2019, 12,12,12,12,12, TimeZoneEnum.AMERICA_CHICAGO));
		String fileName = System.currentTimeMillis()+"_"+file.getOriginalFilename();
		doc.setDocumentName(fileName);
		doc.setDocumentDesc(file.getOriginalFilename());
		request.setFileName(fileName);
		logger.info(file.getOriginalFilename());
		ByteArrayResource fileAsResource = new ByteArrayResource(file.getBytes()) {
			@Override
			public String getFilename() {
					return fileName;
				}
		};
		MultiValueMap<String, Object> map = new LinkedMultiValueMap<>();
		ObjectMapper mapper = new ObjectMapper();
		map.add("properties", mapper.writeValueAsString(request));
		map.add("file", fileAsResource);
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.MULTIPART_FORM_DATA);
		HttpEntity<MultiValueMap<String, Object>> requestHttpEntity = new HttpEntity<>(map, headers);
		ResponseEntity<String> response = this.restTemplate.exchange(this.esbUrl+getUploadServiceName(), HttpMethod.POST, requestHttpEntity, String.class);
		String body = response.getBody();
		JSONObject jsonObj = new JSONObject(body.substring(0, body.length()).trim());
		Map<String, Object> docMap = jsonObj.toMap();
		Map<String, Object> valueMap = (Map<String, Object>) docMap.get("document-identifiers");
		logger.info((String)valueMap.get("document-id"));
		doc.setDocumentGuid((String)valueMap.get("document-id"));
		return doc;
		//getDoc((String)valueMap.get("document-id"));
	}

	@Override
	public byte[] getDoc(String docId) throws Exception {
		HttpHeaders headers = new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_OCTET_STREAM));
		HttpEntity<String> entity = new HttpEntity<>(headers);
		final StringBuilder uri = new StringBuilder(this.esbUrl+getDownloadServiceName()+"?document-identifier=").append(docId.trim());
		ResponseEntity<byte[]> response = this.restTemplate.exchange(uri.toString(), HttpMethod.GET, entity, byte[].class);
		byte[] file = response.getBody();
		return file;
	}
	
	@Transactional
	public boolean saveDocs(List<Document> docs){
		return docDAO.saveMultipleDocs(docs);
	}
	
	
}
