package com.uprr.app.egn.controller;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.uprr.app.egn.dto.ActionItem;
import com.uprr.app.egn.dto.RequestHistory;
import com.uprr.app.egn.dto.WorkstationEvaluation;
import com.uprr.app.egn.service.IAuthorizationService;
import com.uprr.app.egn.service.ItemService;
import com.uprr.app.egn.util.Util;
import com.uprr.ui.shared.user.ActiveUserId;
import com.uprr.ui.shared.user.spring.mvc.ActiveUser;

@RestController
@RequestMapping("purchaseItem")
public class ItemController {

	 Logger logger = LogManager.getLogger(ItemController.class);
	 
	 @Autowired
	 private ItemService itemService;
	 
	 @Autowired
	 IAuthorizationService authService;
	 @PostMapping(value = "addPurchaseItem")
	    public @ResponseBody ResponseEntity<ActionItem> insertPurchaseItem(@RequestBody ActionItem item,@ActiveUser ActiveUserId activeUser){

	        logger.info("entering insertPurchaseItem in ItemController");
	        ActionItem actionItem = null;
	        if(Util.isLocalMode() || authService.canCreateAssessment(activeUser.getUserId()) || authService.canCreateCostItems(activeUser.getUserId()) || authService.canEditCostItems(activeUser.getUserId())){
	        	actionItem = itemService.insertPurchaseItem(item);
		        if(actionItem.getItemId() > 0){
		        	 return new ResponseEntity<ActionItem>(actionItem, HttpStatus.OK);
		        }else{
		            return new ResponseEntity<ActionItem>(actionItem, HttpStatus.INTERNAL_SERVER_ERROR);
		        }	
	        }else{
	        	return new ResponseEntity<ActionItem>(actionItem, HttpStatus.FORBIDDEN);
	        }
	    }
	 
	 @PostMapping(value = "updatePurchaseItem")
	    public @ResponseBody ResponseEntity<ActionItem> updatePurchaseItem(@RequestBody ActionItem item,@ActiveUser ActiveUserId activeUser){

	        logger.info("entering insertPurchaseItem in ItemController");
	        
	        if(Util.isLocalMode() || authService.canEditCostItems(activeUser.getUserId()) || activeUser.getEmployeeId().equalsIgnoreCase(item.getAssignedToEmployeeId()) || activeUser.getEmployeeId().equalsIgnoreCase(item.getSupervisorId())){
	        	 boolean result = false;
	 			try {
	 				result = itemService.updatePurchaseItem(item);
	 				
	 			} catch (Exception e) {
	 				logger.info(e.getMessage());
	 			}
	 			 if(result){
	 		            return new ResponseEntity<ActionItem>(item, HttpStatus.OK);
	 		        }else{
	 		            return new ResponseEntity<ActionItem>(item, HttpStatus.INTERNAL_SERVER_ERROR);
	 		        }
	        }else{
	        	ActionItem actItem = null;
	        	 return new ResponseEntity<ActionItem>(actItem, HttpStatus.FORBIDDEN);
	        }
	    }
	 
	 @GetMapping("getItemAssignedToSupervisor/{empId}")
	 public @ResponseBody ResponseEntity<List<WorkstationEvaluation>> getItemsAssignedToSupervisor(@PathVariable("empId") String empId,@ActiveUser ActiveUserId activeUser){
		 if(Util.isLocalMode() || activeUser.getEmployeeId().equalsIgnoreCase(empId)){
			 List<WorkstationEvaluation> list = itemService.getItemsAssignedToSupervisor(empId);
	         return new ResponseEntity<List<WorkstationEvaluation>>(list, HttpStatus.OK);	 
		 }else{
			 List<WorkstationEvaluation> list = null;
			 return new ResponseEntity<List<WorkstationEvaluation>>(list, HttpStatus.FORBIDDEN);
		 }
		 

	 }
	 
	 @GetMapping("getItemHistory/{itemId}")
	    public @ResponseBody ResponseEntity<List<RequestHistory>> getEvalRequestHistory(@PathVariable("itemId") String itemId){
	    	logger.info("entering getEvalRequestHistory in WorkStationRequestController "+itemId);
	        List<RequestHistory> history = itemService.getItemHistory(itemId);
	        if(history.size() > 0){
	            return new ResponseEntity<List<RequestHistory>>(history, HttpStatus.OK);
	        }else{
	            return new ResponseEntity<List<RequestHistory>>(HttpStatus.INTERNAL_SERVER_ERROR);
	        }
	    }
	 
}
