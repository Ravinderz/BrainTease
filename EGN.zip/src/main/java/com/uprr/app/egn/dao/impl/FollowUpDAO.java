package com.uprr.app.egn.dao.impl;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.uprr.app.egn.dao.IFollowUpDAO;
import com.uprr.app.egn.dao.mapper.FollowUpMapper;
import com.uprr.app.egn.dto.FollowUpVO;

@Repository
public class FollowUpDAO implements IFollowUpDAO{

	Logger logger = LogManager.getLogger(FollowUpDAO.class);
	
	private String ADD_FOLLOWUP_NOTE = "insert into egn_asmt_flw_up_note(FLW_UP_ID,ASMT_ID,FLW_UP_DESC,CRTD_USER_ID,CRTN_TMST,last_updt_user_id,last_updt_tmst) values (EGN_ASMT_FLW_UP_NOTE_Q1.nextval,?,?,?,sysdate,?,sysdate)";
	
	private String GET_ALL_NOTES_BY_ASMT_ID = "select * from egn_asmt_flw_up_note where asmt_id = ?";

	@Autowired private JdbcTemplate jdbcTemplate;

	@Override
	public boolean addFollowUp(FollowUpVO followUp) {
		boolean flag = false;
		int i = jdbcTemplate.update(ADD_FOLLOWUP_NOTE,
				new Object[] {followUp.getAsmtId(),followUp.getNoteDesc(),followUp.getCreatedBy(),followUp.getUpdatedBy()});
		
		if(i == 1){
			flag = true;
			logger.info("object  inserted successfully");
		}else{
			flag = false;
			logger.info("failed to insert object ");
		}
		return flag;
	}

	@Override
	public List<FollowUpVO> getAllFollowUpNotesByAsmtId(String asmtId) {
		return jdbcTemplate.query(GET_ALL_NOTES_BY_ASMT_ID, new Object[]{asmtId}, new FollowUpMapper<FollowUpVO>());
		
	}
}
