package com.uprr.app.egn.dto;

import java.util.List;

public class WorkstationAssessment {

	private String requestId;
	private String assessmentId;
	private String dateofAssessment;
	private String wsAssessmentName;
	private String reasonForAssessment;
	private String currentSymptoms;
	private String assessmentWSPosture;
	private String currentChair;
	private String monitor;
	private String seatHeight;
	private int monitorHeight;
	private String seatDepth;
	private String keyboardTrayMouse;
	private String backRest;
	private String comments;
	private String armRest;
	private String adjustmentsMade;
	private String chairRecommendations;
	private String otherEquipmentNeeds;
	private String summary;
	private String followUpTherapist;
	private String followUp;
	private String status;
	private LoggedUserVO loggedEmployee;
	private List<ActionItem> actionItemList;
	

	
	public String getRequestId() {
		return requestId;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	public String getAssessmentId() {
		return assessmentId;
	}
	public void setAssessmentId(String assessmentId) {
		this.assessmentId = assessmentId;
	}
	public String getDateofAssessment() {
		return dateofAssessment;
	}
	public void setDateofAssessment(String dateofAssessment) {
		this.dateofAssessment = dateofAssessment;
	}
	public String getWsAssessmentName() {
		return wsAssessmentName;
	}
	public void setWsAssessmentName(String wsAssessmentName) {
		this.wsAssessmentName = wsAssessmentName;
	}
	public String getReasonForAssessment() {
		return reasonForAssessment;
	}
	public void setReasonForAssessment(String reasonForAssessment) {
		this.reasonForAssessment = reasonForAssessment;
	}
	public String getCurrentSymptoms() {
		return currentSymptoms;
	}
	public void setCurrentSymptoms(String currentSymptoms) {
		this.currentSymptoms = currentSymptoms;
	}
	public String getAssessmentWSPosture() {
		return assessmentWSPosture;
	}
	public void setAssessmentWSPosture(String assessmentWSPosture) {
		this.assessmentWSPosture = assessmentWSPosture;
	}
	public String getCurrentChair() {
		return currentChair;
	}
	public void setCurrentChair(String currentChair) {
		this.currentChair = currentChair;
	}
	public String getMonitor() {
		return monitor;
	}
	public void setMonitor(String monitor) {
		this.monitor = monitor;
	}
	public String getSeatHeight() {
		return seatHeight;
	}
	public void setSeatHeight(String seatHeight) {
		this.seatHeight = seatHeight;
	}
	public int getMonitorHeight() {
		return monitorHeight;
	}
	public void setMonitorHeight(int monitorHeight) {
		this.monitorHeight = monitorHeight;
	}
	public String getSeatDepth() {
		return seatDepth;
	}
	public void setSeatDepth(String seatDepth) {
		this.seatDepth = seatDepth;
	}
	public String getKeyboardTrayMouse() {
		return keyboardTrayMouse;
	}
	public void setKeyboardTrayMouse(String keyboardTrayMouse) {
		this.keyboardTrayMouse = keyboardTrayMouse;
	}
	public String getBackRest() {
		return backRest;
	}
	public void setBackRest(String backRest) {
		this.backRest = backRest;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getArmRest() {
		return armRest;
	}
	public void setArmRest(String armRest) {
		this.armRest = armRest;
	}
	public String getAdjustmentsMade() {
		return adjustmentsMade;
	}
	public void setAdjustmentsMade(String adjustmentsMade) {
		this.adjustmentsMade = adjustmentsMade;
	}
	public String getChairRecommendations() {
		return chairRecommendations;
	}
	public void setChairRecommendations(String chairRecommendations) {
		this.chairRecommendations = chairRecommendations;
	}
	public String getOtherEquipmentNeeds() {
		return otherEquipmentNeeds;
	}
	public void setOtherEquipmentNeeds(String otherEquipmentNeeds) {
		this.otherEquipmentNeeds = otherEquipmentNeeds;
	}
	public String getSummary() {
		return summary;
	}
	public void setSummary(String summary) {
		this.summary = summary;
	}
	public String getFollowUpTherapist() {
		return followUpTherapist;
	}
	public void setFollowUpTherapist(String followUpTherapist) {
		this.followUpTherapist = followUpTherapist;
	}
	public String getFollowUp() {
		return followUp;
	}
	public void setFollowUp(String followUp) {
		this.followUp = followUp;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public LoggedUserVO getLoggedEmployee() {
		return loggedEmployee;
	}
	public void setLoggedEmployee(LoggedUserVO loggedEmployee) {
		this.loggedEmployee = loggedEmployee;
	}
	public List<ActionItem> getActionItemList() {
		return actionItemList;
	}
	public void setActionItemList(List<ActionItem> actionItemList) {
		this.actionItemList = actionItemList;
	}
	public WorkstationAssessment() {
		super();
	}
	public WorkstationAssessment(String requestId, String assessmentId, String dateofAssessment,
			String wsAssessmentName, String reasonForAssessment, String currentSymptoms, String assessmentWSPosture,
			String currentChair, String monitor, String seatHeight, int monitorHeight, String seatDepth,
			String keyboardTrayMouse, String backRest, String comments, String armRest, String adjustmentsMade,
			String chairRecommendations, String otherEquipmentNeeds, String summary, String followUpTherapist,
			String followUp, String status, LoggedUserVO loggedEmployee, List<ActionItem> actionItemList) {
		super();
		this.requestId = requestId;
		this.assessmentId = assessmentId;
		this.dateofAssessment = dateofAssessment;
		this.wsAssessmentName = wsAssessmentName;
		this.reasonForAssessment = reasonForAssessment;
		this.currentSymptoms = currentSymptoms;
		this.assessmentWSPosture = assessmentWSPosture;
		this.currentChair = currentChair;
		this.monitor = monitor;
		this.seatHeight = seatHeight;
		this.monitorHeight = monitorHeight;
		this.seatDepth = seatDepth;
		this.keyboardTrayMouse = keyboardTrayMouse;
		this.backRest = backRest;
		this.comments = comments;
		this.armRest = armRest;
		this.adjustmentsMade = adjustmentsMade;
		this.chairRecommendations = chairRecommendations;
		this.otherEquipmentNeeds = otherEquipmentNeeds;
		this.summary = summary;
		this.followUpTherapist = followUpTherapist;
		this.followUp = followUp;
		this.status = status;
		this.loggedEmployee = loggedEmployee;
		this.actionItemList = actionItemList;
	}
	@Override
	public String toString() {
		return "WorkstationAssessment [requestId=" + requestId + ", assessmentId=" + assessmentId
				+ ", dateofAssessment=" + dateofAssessment + ", wsAssessmentName=" + wsAssessmentName
				+ ", reasonForAssessment=" + reasonForAssessment + ", currentSymptoms=" + currentSymptoms
				+ ", assessmentWSPosture=" + assessmentWSPosture + ", currentChair=" + currentChair + ", monitor="
				+ monitor + ", seatHeight=" + seatHeight + ", monitorHeight=" + monitorHeight + ", seatDepth="
				+ seatDepth + ", keyboardTrayMouse=" + keyboardTrayMouse + ", backRest=" + backRest + ", comments="
				+ comments + ", armRest=" + armRest + ", adjustmentsMade=" + adjustmentsMade + ", chairRecommendations="
				+ chairRecommendations + ", otherEquipmentNeeds=" + otherEquipmentNeeds + ", summary=" + summary
				+ ", followUpTherapist=" + followUpTherapist + ", followUp=" + followUp + ", status=" + status
				+ ", loggedEmployee=" + loggedEmployee + ", actionItemList=" + actionItemList + "]";
	}
	
	
	
	
	
	
}
