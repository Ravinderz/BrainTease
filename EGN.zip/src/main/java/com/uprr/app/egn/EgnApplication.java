package com.uprr.app.egn;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.eclipse.jetty.security.ConstraintMapping;
import org.eclipse.jetty.security.ConstraintSecurityHandler;
import org.eclipse.jetty.security.HashLoginService;
import org.eclipse.jetty.security.authentication.BasicAuthenticator;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.server.handler.HandlerCollection;
import org.eclipse.jetty.util.security.Constraint;
import org.springframework.boot.Banner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.web.DispatcherServletAutoConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.context.embedded.EmbeddedServletContainerFactory;
import org.springframework.boot.context.embedded.jetty.JettyEmbeddedServletContainerFactory;
import org.springframework.boot.context.embedded.jetty.JettyServerCustomizer;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.web.servlet.DispatcherServlet;

/**
 * Main Application class for EGN Project.
 * @Author: (Krish)nappan Muthuraman (iots242)
 * Date: 05/1/18
*/

import com.uprr.app.egn.util.Util;

@SpringBootApplication
public class EgnApplication extends SpringBootServletInitializer {

    private static ConfigurableApplicationContext appContext;

    public static void main(String[] args) {
		Map<String, Object> defaultProperties = new HashMap<String, Object>();
        defaultProperties.put("server.port", System.getProperty("app.default.http.port"));
        if (Util.isLocalMode()) {
            defaultProperties.put("uprr.implementation.environment", "local");
            System.setProperty("uprr.implementation.environment", "local");
        }
        defaultProperties.put("org.springframework.boot.logging.LoggingSystem","none");
        SpringApplication app = new SpringApplication(EgnApplication.class);
        app.setDefaultProperties(defaultProperties);
        app.setBannerMode(Banner.Mode.OFF);
        appContext = app.run(args);
	}

    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        return application.sources(EgnApplication.class);
    }

    @Bean
    public DispatcherServlet dispatcherServlet() {
        return new DispatcherServlet();
    }

    @Bean
    public ServletRegistrationBean dispatchServletRegistration() {
        final String urlMapping = Util.isLocalMode() ? "/egn/secure/jas/*" : "/secure/jas/*";
        ServletRegistrationBean registration = new ServletRegistrationBean(dispatcherServlet(), urlMapping);
        registration.setName(DispatcherServletAutoConfiguration.DEFAULT_DISPATCHER_SERVLET_REGISTRATION_BEAN_NAME);
        return registration;
    }
    
    @Bean
	public EmbeddedServletContainerFactory servletContainer() {
		JettyEmbeddedServletContainerFactory factory = new JettyEmbeddedServletContainerFactory();
		factory.setSessionTimeout(2, TimeUnit.MINUTES);
		factory.setPort(8080);
		factory.setContextPath("/egn/secure/jas");
		factory.addInitializers(new DelegatingServletContextInitializer(new ApplicationInitializer()));
		factory.addServerCustomizers(new JettyServerCustomizer() {
			@Override
			public void customize(Server server) {
				try{
					HashLoginService hashLoginService  = new HashLoginService("Test Realm");
					hashLoginService.setConfig("src/test/resources/test-realm.properties");
					hashLoginService.setHotReload(true);					
					//hashLoginService.setRefreshInterval(5);
					server.addBean(hashLoginService);
					
					Constraint constraint = new  Constraint();
					constraint.setName(Constraint.__BASIC_AUTH);
					constraint.setRoles(new String[]{"supervisor"});
					constraint.setAuthenticate(Boolean.TRUE);
					
					ConstraintMapping constraintMapping = new ConstraintMapping();
					constraintMapping.setConstraint(constraint);
					constraintMapping.setPathSpec("/*");
					Set<String> roles = new HashSet<String>();
					roles.add("supervisor");
					
					List<ConstraintMapping> constraintMappings = new ArrayList<ConstraintMapping>();
					constraintMappings.add(constraintMapping);
					
					ConstraintSecurityHandler constraintSecurityHandler = new ConstraintSecurityHandler();
					constraintSecurityHandler.setConstraintMappings(constraintMappings,roles);
					constraintSecurityHandler.setAuthenticator(new BasicAuthenticator());
					constraintSecurityHandler.setLoginService(hashLoginService);
					
					HandlerCollection handlerCollection = new HandlerCollection();
					handlerCollection.setHandlers(server.getHandlers());
					server.setHandler(handlerCollection);
					constraintSecurityHandler.setHandler(handlerCollection);
					server.setHandler(constraintSecurityHandler);
					
					
				}catch(Exception exception){
					logger.error("Failed to initialize",exception);
				}
			}
		});
		
		return factory;
	}
}