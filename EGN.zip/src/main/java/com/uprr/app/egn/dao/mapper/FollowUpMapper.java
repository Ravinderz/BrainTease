package com.uprr.app.egn.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class FollowUpMapper<T> implements RowMapper<T> {
	public T mapRow(ResultSet arg0, int arg1) throws SQLException {
		FollowUpResultSetExtractor<T> docExtractor = new FollowUpResultSetExtractor<T>();
		return docExtractor.extractData(arg0);
	}

}
