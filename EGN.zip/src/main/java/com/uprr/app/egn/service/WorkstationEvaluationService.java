package com.uprr.app.egn.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;  

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.JmsException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.uprr.app.egn.dao.IRequestUpdateHistoryDAO;
import com.uprr.app.egn.dao.IWorkstationEvaluationDAO;
import com.uprr.app.egn.dto.Document;
import com.uprr.app.egn.dto.LoggedUserVO; 
import com.uprr.app.egn.dto.RequestHistory;
import com.uprr.app.egn.dto.SendMailVO;
import com.uprr.app.egn.dto.UpdateStatus;
import com.uprr.app.egn.dto.WorkstationEvaluation;
import com.uprr.app.egn.util.Util;

@Service
public class WorkstationEvaluationService { 

    @Autowired
    private IWorkstationEvaluationDAO wsEvaluationdao;
    
    @Autowired
    private IEmailService emailService;
    
    @Autowired
    private IEmplService emplService;

    @Autowired
    private IRequestUpdateHistoryDAO reqHistDao;
    
    Logger logger = LogManager.getLogger(WorkstationEvaluationService.class);
    
    public List<WorkstationEvaluation> getRequestDataFromDB(String supvid){
        logger.info("entering getRequestDataFromDB method in WorkstationEvaluationService");
        return wsEvaluationdao.getRequestData(supvid);
    }
	
    public List<WorkstationEvaluation> getAllMedicalRequests(){
        logger.info("entering getRequestDataFromDB method in WorkstationEvaluationService");
        return wsEvaluationdao.getAllMedicalRequests();
    }
    
    public List<WorkstationEvaluation> getRequestDataFromDB(){
        logger.info("entering getRequestDataFromDB method in WorkstationEvaluationService");
        return wsEvaluationdao.getRequestData();
    }

   @Transactional
    public WorkstationEvaluation submitWorkStationRequest(WorkstationEvaluation WSEvaluation) throws JmsException, Exception{ 
        logger.info("entering submitWorkStationRequest method in WorkstationEvaluationService");
        int count = emplService.getCountFromEmpl(WSEvaluation.getEmpId());
        if(count > 0 ){
        	int reqId = wsEvaluationdao.submitWorkStationRequest(WSEvaluation); 
        	reqHistDao.insertRequestUpdateHistory("NA", "Submitted", null,WSEvaluation.getUpdatedBy(), Integer.toString(reqId), null, null);
            WSEvaluation.setRequestId(Integer.toString(reqId));	
        }else{
        	emplService.insertEmployeeRecord(WSEvaluation);
        	int reqId = wsEvaluationdao.submitWorkStationRequest(WSEvaluation); 
        	reqHistDao.insertRequestUpdateHistory("NA","Submitted", null,WSEvaluation.getUpdatedBy(), Integer.toString(reqId), null, null);
            WSEvaluation.setRequestId(Integer.toString(reqId));	
        }
        if(WSEvaluation.getStatus().equalsIgnoreCase("Submitted") && WSEvaluation.isNonMedical()){
 			SendMailVO nonMedReqSubmittedMail = Util.setEmlForNonMedicalRequestSubmitted(WSEvaluation.getRequestingSupervisor(),WSEvaluation.getEmpId(),WSEvaluation.getEmpId(),WSEvaluation.getRequestId(),"Prasanna Joshi");
 			emailService.sendEmailNotification(nonMedReqSubmittedMail);
 		}else if(WSEvaluation.getStatus().equalsIgnoreCase("Submitted") && WSEvaluation.isMedical()){
 			SendMailVO medReqSubmittedMail = Util.setEmlForMedicalRequestSubmitted(WSEvaluation.getRequestingSupervisor(),WSEvaluation.getEmpId(),WSEvaluation.getRequestId(),"Prasanna Joshi");
 			emailService.sendEmailNotification(medReqSubmittedMail);
 		}
        
        return WSEvaluation;
    }

    @Transactional
    public boolean updateWorkStationRequest(WorkstationEvaluation WSEvaluation) throws JmsException, Exception{
        logger.info("entering submitWorkStationRequest method in WorkstationEvaluationService");
        boolean flag = false;
        flag = wsEvaluationdao.updateWorkStationRequest(WSEvaluation);
        if(flag && WSEvaluation.getStatus().equalsIgnoreCase("Submitted")){
        	reqHistDao.insertRequestUpdateHistory("New","Submitted", null,WSEvaluation.getUpdatedBy(), WSEvaluation.getRequestId(), null, null);
        	if(WSEvaluation.isNonMedical()){
     			SendMailVO nonMedReqSubmittedMail = Util.setEmlForNonMedicalRequestSubmitted(WSEvaluation.getRequestingSupervisor(),WSEvaluation.getEmpId(),WSEvaluation.getEmpId(),WSEvaluation.getRequestId(),"Prasanna Joshi");
     			emailService.sendEmailNotification(nonMedReqSubmittedMail);
     		}else if( WSEvaluation.isMedical()){
     			SendMailVO medReqSubmittedMail = Util.setEmlForMedicalRequestSubmitted(WSEvaluation.getRequestingSupervisor(),WSEvaluation.getEmpId(),WSEvaluation.getRequestId(),"Prasanna Joshi");
     			emailService.sendEmailNotification(medReqSubmittedMail);
     		}
        }
        return flag;
    }

    @Transactional
    public boolean updateStatus(UpdateStatus updateStatus) throws JmsException, Exception{
        logger.info("entering updateStatus method in WorkstationEvaluationService");
         if(wsEvaluationdao.updateStatus(updateStatus)){
        	
         	 for(WorkstationEvaluation ws : updateStatus.getWorkstationEvaluationList()){
         		
         		if(updateStatus.getStatus().equalsIgnoreCase("supervisor rejected")){
         			reqHistDao.insertRequestUpdateHistory(ws.getStatus(), updateStatus.getStatus(),updateStatus.getRejectReason(), ws.getUpdatedBy(), ws.getRequestId(), null, null);
         			SendMailVO nonMedRejectMail = Util.getNonMedicalRejectNotification(ws.getEmpId(),ws.getRequestingSupervisor(),"Rejected",updateStatus.getStatus());
         			emailService.sendEmailNotification(nonMedRejectMail);
         		}
         		
         		if(updateStatus.getStatus().equalsIgnoreCase("Supervisor Approved") || updateStatus.getStatus().equalsIgnoreCase("Medical Approved")){
         			reqHistDao.insertRequestUpdateHistory(ws.getStatus(), updateStatus.getStatus(),updateStatus.getRejectReason(), ws.getUpdatedBy(), ws.getRequestId(), null, null);
         			SendMailVO specialistEmail = Util.getRequestApprovedNotification(ws.getEmpId(), ws.getEmpName(), ws.getRequestId());
         			emailService.sendEmailNotification(specialistEmail);
         		}
         		
         		if(updateStatus.getStatus().equalsIgnoreCase("Medical Rejected")){
         			reqHistDao.insertRequestUpdateHistory(ws.getStatus(), updateStatus.getStatus(), updateStatus.getRejectReason(),ws.getUpdatedBy(), ws.getRequestId(), null, null);
					wsEvaluationdao.updateStatus(updateStatus.getRequestIds().get(0), updateStatus.getEmpId(), "Submitted");																								
         			SendMailVO specialistEmail = Util.setEmailForMdclRejectsToSupvsrEGNIHTeam(ws.getRequestingSupervisorId(),ws.getEmpName(),ws.getRequestId(), "emailGroup");
        			emailService.sendEmailNotification(specialistEmail);
         		}

         	} 

        };
        
        return true;
    }

    public WorkstationEvaluation getRequestById(String requestId){
        logger.info("entering getRequestById method in WorkstationEvaluationService");
        return wsEvaluationdao.getRequestById(requestId);
    }
    
    public  List<WorkstationEvaluation> getRequestByUser(String emplId){
        logger.info("entering getRequestById method in WorkstationEvaluationService");
        return wsEvaluationdao.getRequestByUser(emplId);
    }

    public List<Document> getDocumentsByRequestId(String requestId){
        logger.info("entering getDocumentsByRequestId method in WorkstationEvaluationService");
        return wsEvaluationdao.getDocumentsByRequestId(requestId);
    }
    
    @Transactional
    public WorkstationEvaluation saveWorkStationRequest(WorkstationEvaluation WSEvaluation){
		logger.info("entering saveWorkStationRequest method in WorkstationEvaluationService");
		 int count = emplService.getCountFromEmpl(WSEvaluation.getEmpId());
	        if(count > 0 ){
	        	int reqId = wsEvaluationdao.saveWorkStationRequest(WSEvaluation);
	        	reqHistDao.insertRequestUpdateHistory("NA", "New", null,WSEvaluation.getUpdatedBy(), Integer.toString(reqId), null, null);
	            WSEvaluation.setRequestId(Integer.toString(reqId));	
	        }else{
	        	emplService.insertEmployeeRecord(WSEvaluation);
	        	int reqId = wsEvaluationdao.saveWorkStationRequest(WSEvaluation);
	        	reqHistDao.insertRequestUpdateHistory("NA", "New", null,WSEvaluation.getUpdatedBy(), Integer.toString(reqId), null, null);
	            WSEvaluation.setRequestId(Integer.toString(reqId));	
	        }
        return WSEvaluation;
	}
	
     public List<RequestHistory> getEvalRequestHistory(String reqId){
		logger.info("entering getEvalRequestHistory method in WorkstationEvaluationService");
		List<RequestHistory> list = reqHistDao.getEvalRequestHistoryByRequestId(reqId);
		Set<String> set = new HashSet<>(list.size());
		list.forEach(hist -> set.add(hist.getChangedBy()));
		List<LoggedUserVO> userList = emplService.getUserDetails(set);
		List<RequestHistory> updatedList = new ArrayList<>();
		for(RequestHistory hist : list){
			for(LoggedUserVO user: userList){
				if(hist.getChangedBy().equalsIgnoreCase(user.getEmployeeId())){
					hist.setChangedByName(user.getFullName());
					updatedList.add(hist);
				}
				
			}
		} 
		logger.info(updatedList);
		return updatedList;
	}

}
