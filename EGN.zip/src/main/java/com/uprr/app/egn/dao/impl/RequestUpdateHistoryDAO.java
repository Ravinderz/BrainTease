package com.uprr.app.egn.dao.impl;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.uprr.app.egn.dao.IRequestUpdateHistoryDAO;
import com.uprr.app.egn.dao.mapper.RequestHistoryMapper;
import com.uprr.app.egn.dto.ActionItem;
import com.uprr.app.egn.dto.RequestHistory;

@Repository
public class RequestUpdateHistoryDAO implements IRequestUpdateHistoryDAO{
	
	Logger logger = LogManager.getLogger(RequestUpdateHistoryDAO.class);
	
	//To capture status change 
			String INSERT_INTO_HISTORY_TABLE = "insert into egn_req_hist(req_hist_id,eval_req_id,asmt_id,item_id,old_stat_valu,new_stat_valu,rejt_resn_info,CHNG_BY_USER_ID,chng_tmst,crtd_user_id,crtn_tmst,last_updt_user_id,last_updt_tmst) values (EGN_REQ_HIST_Q1.nextval,?,?,?,?,?,?,?,sysdate,?,sysdate,?,sysdate)";
			
			//To fetch status history for particular record
			String GET_EVAL_REQ_HIST = "select req_hist_id,eval_req_id,asmt_id,old_stat_valu,new_stat_valu,rejt_resn_info,CHNG_BY_USER_ID,chng_tmst,crtd_user_id,crtn_tmst,last_updt_user_id,last_updt_tmst,item_id from egn_req_hist where eval_req_id = ? order by crtn_tmst desc";
			
			//To fetch assessment history
			String GET_ASMT_HIST = "select req_hist_id,eval_req_id,asmt_id,old_stat_valu,new_stat_valu,rejt_resn_info,CHNG_BY_USER_ID,chng_tmst,crtd_user_id,crtn_tmst,last_updt_user_id,last_updt_tmst,item_id from egn_req_hist where asmt_id = ? order by crtn_tmst desc";
			
			//To fetch Item history
			String GET_PURCHASE_ITEM_HIST = "select req_hist_id,eval_req_id,asmt_id,old_stat_valu,new_stat_valu,rejt_resn_info,CHNG_BY_USER_ID,chng_tmst,crtd_user_id,crtn_tmst,last_updt_user_id,last_updt_tmst,item_id from egn_req_hist where item_id = ? order by crtn_tmst desc";
			
			//To fetch Item history
			String GET_LATEST_PURCHASE_ITEM_STATUS_HIST = "select * from EGN_REQ_HIST pa where  pa.req_hist_id in (select max(sub.req_hist_id) from EGN_REQ_HIST sub where sub.asmt_id = ? and sub.item_id = ? ) ";
			 
			@Autowired private JdbcTemplate jdbcTemplate;

	@Override
	public boolean insertRequestUpdateHistory(String oldStatus, String newStatus, String rejectReason,String empId, String reqId, String asmtId, String itemId){
		boolean flag = false;
		int i = jdbcTemplate.update(INSERT_INTO_HISTORY_TABLE,
				new Object[] {reqId,asmtId,itemId,oldStatus,newStatus,rejectReason,empId,empId,empId});
		
		if(i == 1){
			flag = true;
			logger.info("object  inserted successfully");
		}else{
			flag = false;
			logger.info("failed to insert object ");
		}
		return flag;
	}
	
	@Override
	public boolean bulkInsertRequestStatusHistory(List<ActionItem> actionItems,int reqId,int asmtId) {
		logger.info(actionItems);
		jdbcTemplate.batchUpdate(INSERT_INTO_HISTORY_TABLE,new BatchPreparedStatementSetter() {

			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				ps.setInt(1, reqId);
				ps.setInt(2, asmtId);
				ps.setInt(3, actionItems.get(i).getItemId());
				ps.setString(4, actionItems.get(i).getOldStatus());
				ps.setString(5, actionItems.get(i).getSupvAprvlStatus());
				ps.setString(6, null);
				ps.setString(7, actionItems.get(i).getAssignedToEmployeeId());
				ps.setString(8, actionItems.get(i).getAssignedToEmployeeId());
				ps.setString(9, actionItems.get(i).getAssignedToEmployeeId());
			}

			@Override
			public int getBatchSize() {
				return actionItems.size();
			}
		  });
		
		return true;
	}
	
	@Override
	public List<RequestHistory> getEvalRequestHistoryByRequestId(String reqId){
		return jdbcTemplate.query(GET_EVAL_REQ_HIST, new Object[]{reqId}, new RequestHistoryMapper<RequestHistory>());
	}
	
	@Override
	public List<RequestHistory> getItemHistoryByItemId(String itemId){
		return jdbcTemplate.query(GET_PURCHASE_ITEM_HIST, new Object[]{itemId}, new RequestHistoryMapper<RequestHistory>());
	}

	@Override
	public List<RequestHistory> getItmLtstUpdtdStatusHistryByItmId(ActionItem item){
		return jdbcTemplate.query(GET_LATEST_PURCHASE_ITEM_STATUS_HIST, new Object[]{item.getAssessmentId(),item.getItemId()}, new RequestHistoryMapper<RequestHistory>());
	}
	
}
