package com.uprr.app.egn.util;

public class EGNConstants {
	
	public static final String ITEM_ORDER_STATUS_NEW="New";
	public static final String ITEM_ORDER_STATUS_ORDERED="Ordered";
	public static final String ITEM_ORDER_STATUS_CANCELLED="Cancelled";
	public static final String ITEM_ORDER_STATUS_COMPLETE="Complete";
	public static final String ITEM_ORDER_STATUS_REJECTED="Rejected";
	public static final String SUPVSR_APRVL_STATUS_NEW="New";
	public static final String SUPVSR_APRVL_STATUS_APPROVED="Approved";
	public static final String SUPVSR_APRVL_STATUS_REJECTED="Rejected";
	public static final String ITEM_STATUS_NA = "NA";
	public static final String ITEM_STATUS_ASSESSMENT_COMPLETE = "Assessment Complete";
	public static final String ITEM_STATUS_ASSESSMENT_PROVIDED = "Assessment Provided";
	
	//Email constants
	public static final String EMAIL_SERVICE_NAME = "notification/send-enterprise-notification/2.0";
	public static final String EMAIL_SERVICE_REQUESTOR = "cn=degn001,ou=uprr,o=up";
	
	//AZM Constants
	
	//User Roles
	public static final String USER_ROLE = "user";
	public static final String SUPERVISOR_ROLE = "supervisor";
	public static final String ADA_NURSE_ROLE = "ada nurse";
	public static final String ERGONOMICS_SPECIALIST_ROLE = "ergonomics specialist";
	public static final String INDUSTRY_HYGIENE_SPECIALIST_ROLE = "industrial hygiene specialist";
	public static final String FACILITIES_MANAGEMENT_ROLE = "facilities management";
	
	//user id constants
	public static final String XMIE001 = "xmie001";
	public static final String XMIE002 = "xmie002";
	public static final String XMIE003 = "xmie003";
	public static final String XMIE004 = "xmie004";
	public static final String XMIE005 = "xmie005";
	public static final String XMIE006 = "xmie006";	
	
	
	public static final String ALPHA_NUMERIC_STRING = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
	
}
