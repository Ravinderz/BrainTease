package com.uprr.app.egn.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.JmsException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.uprr.app.egn.dao.IItemDAO;
import com.uprr.app.egn.dao.IRequestUpdateHistoryDAO;
import com.uprr.app.egn.dao.IWorkstationAssessmentDAO;
import com.uprr.app.egn.dao.IWorkstationEvaluationDAO;
import com.uprr.app.egn.dto.ActionItem;
import com.uprr.app.egn.dto.Dropdown;
import com.uprr.app.egn.dto.SendMailVO;
import com.uprr.app.egn.dto.WorkstationAssessment;
import com.uprr.app.egn.dto.WorkstationEvaluation;
import com.uprr.app.egn.util.Util;

@Service
public class WorkstationAssessmentService {
	
	@Autowired
	IWorkstationAssessmentDAO wsAssessmentdao;
	
	@Autowired
    private IEmailService emailService;
	
	@Autowired
    private IRequestUpdateHistoryDAO reqHistDao;
	
	@Autowired
	private IItemDAO itemDao;
	
	@Autowired
	private IWorkstationEvaluationDAO wsEvalDao;
	
	Logger logger = LogManager.getLogger(WorkstationAssessmentService.class);
	
	@Transactional
	public int submitWorkstationAssessment(WorkstationAssessment WSAssessment){
		logger.info("entering submitWorkstationAssessment method in service layer");
		int assessmentId = wsAssessmentdao.saveWorkstationAssessment(WSAssessment);
		
		WorkstationEvaluation wsEval = wsEvalDao.getRequestById(WSAssessment.getRequestId());
		try {
			this.getNotificationBasedOnUpdatedStatus(WSAssessment,wsEval,assessmentId);
		} catch (JmsException e) {
			logger.info(e.getMessage());
		} catch (Exception e) {
			logger.info(e.getMessage());
		}
		
		return assessmentId;
	}
	
	private void getNotificationBasedOnUpdatedStatus(WorkstationAssessment WSAssessment,WorkstationEvaluation wsEval,int assessmentId) throws JmsException, Exception{
		try {
			 if(WSAssessment.getStatus().equalsIgnoreCase("Assessment Complete")){
				wsEvalDao.updateStatus(WSAssessment.getRequestId(), WSAssessment.getLoggedEmployee().getEmployeeId(), "Assessment Complete");
				reqHistDao.insertRequestUpdateHistory(wsEval.getStatus(), WSAssessment.getStatus(), null, WSAssessment.getLoggedEmployee().getEmployeeId(), WSAssessment.getRequestId(),Integer.toString(assessmentId), null);
				SendMailVO specialistEmail = Util.setEmlForAsmtCmpltWithoutPurchaseItems("xprk408", "xsat860", "Prasanna Joshi", WSAssessment.getAssessmentId(), "");
				emailService.sendEmailNotification(specialistEmail);
			}else{
				wsEvalDao.updateStatus(WSAssessment.getRequestId(), WSAssessment.getLoggedEmployee().getEmployeeId(), "Assessment Provided");
				reqHistDao.insertRequestUpdateHistory(wsEval.getStatus(), WSAssessment.getStatus(), null, WSAssessment.getLoggedEmployee().getEmployeeId(), WSAssessment.getRequestId(), Integer.toString(assessmentId), null);
				SendMailVO specialistEmail = Util.setEmlForAsmtPrvidedNPrchseItmsRqrd("xsat860", "xsat860", WSAssessment.getAssessmentId(), "");
				emailService.sendEmailNotification(specialistEmail);
			}
			} catch (JmsException e) {
				logger.info(e.getMessage());
			} catch (Exception e) {
				logger.info(e.getMessage());
		}
	}
	
	@Transactional
	public int saveWorkstationAssessment(WorkstationAssessment WSAssessment){
		logger.info("entering saveWorkstationAssessment method in service layer");
		int count = wsAssessmentdao.getAssessmentForReqIdCount(WSAssessment.getRequestId());
		int assessmentId = 0;
		if(count == 0){
			assessmentId = wsAssessmentdao.saveWorkstationAssessment(WSAssessment);	
		}
		
		if(WSAssessment.getStatus().equalsIgnoreCase("Assessment Complete")){
			reqHistDao.insertRequestUpdateHistory("Assessment Complete", "Assessment Pending", null, WSAssessment.getLoggedEmployee().getEmployeeId(), WSAssessment.getRequestId(), WSAssessment.getAssessmentId(), null);
		}else{
			WorkstationEvaluation wsEval = wsEvalDao.getRequestById(WSAssessment.getRequestId());
			wsEvalDao.updateStatus(WSAssessment.getRequestId(), WSAssessment.getLoggedEmployee().getEmployeeId(), "Assessment Pending");
			reqHistDao.insertRequestUpdateHistory(wsEval.getStatus(), "Assessment Pending", null, WSAssessment.getLoggedEmployee().getEmployeeId(), WSAssessment.getRequestId(), Integer.toString(assessmentId), null);
		}
		
		return assessmentId;
	}
	
	public WorkstationAssessment getRequestById(String requestId){
		logger.info("entering getRequestById method in WorkstationAssessmentService");
		WorkstationAssessment wsAssessment = wsAssessmentdao.getRequestById(requestId);
		wsAssessment.setActionItemList(itemDao.getAllItemsByAsmtId(requestId));	
		return wsAssessment;
	}
	
	@Transactional
	public boolean updateWorkStationAssessment(WorkstationAssessment WSAssessment) {
		logger.info("entering updateWorkStationAssessment method in WorkstationAssessmentService");

		WorkstationAssessment asmt = wsAssessmentdao.getRequestById(WSAssessment.getAssessmentId());
		wsAssessmentdao.updateWorkStationAssessment(WSAssessment);
		/*if(WSAssessment.getStatus().equalsIgnoreCase("Assessment Reopened")){
			wsEvalDao.updateStatus(WSAssessment.getRequestId(), WSAssessment.getLoggedEmployee().getEmployeeId(), WSAssessment.getStatus());
			reqHistDao.insertRequestUpdateHistory(asmt.getStatus(), WSAssessment.getStatus(), null, WSAssessment.getLoggedEmployee().getEmployeeId(),WSAssessment.getRequestId(), WSAssessment.getAssessmentId(), null);
			WSAssessment.setStatus("Assessment Pending");
			wsAssessmentdao.updateWorkStationAssessment(WSAssessment);
			wsEvalDao.updateStatus(WSAssessment.getRequestId(), WSAssessment.getLoggedEmployee().getEmployeeId(), WSAssessment.getStatus());
			reqHistDao.insertRequestUpdateHistory(asmt.getStatus(), WSAssessment.getStatus(), null, WSAssessment.getLoggedEmployee().getEmployeeId(),WSAssessment.getRequestId(), WSAssessment.getAssessmentId(), null);
			logger.info("asmt.getStatus() = "+asmt.getStatus() + " , WSAssessment.getStatus() = "+WSAssessment.getStatus());
		}else */if(!asmt.getStatus().equalsIgnoreCase(WSAssessment.getStatus())){
			logger.info("asmt.getStatus() = "+asmt.getStatus() + " , WSAssessment.getStatus() = "+WSAssessment.getStatus());
			wsEvalDao.updateStatus(WSAssessment.getRequestId(), WSAssessment.getLoggedEmployee().getEmployeeId(), WSAssessment.getStatus());
			reqHistDao.insertRequestUpdateHistory(asmt.getStatus(), WSAssessment.getStatus(), null, WSAssessment.getLoggedEmployee().getEmployeeId(),WSAssessment.getRequestId(), WSAssessment.getAssessmentId(), null);
			try {
				this.getNotificationifStatusAsmtProvided(WSAssessment);
			} catch (JmsException e) {
				logger.info(e.getMessage());
			} catch (Exception e) {
				logger.info(e.getMessage());
			}
			
		}
		return true;
	}
	
	private void getNotificationifStatusAsmtProvided(WorkstationAssessment WSAssessment) throws JmsException, Exception{
		if(WSAssessment.getStatus().equalsIgnoreCase("Assessment Provided")){
			try {
			if(WSAssessment.getActionItemList().size() > 0){
				SendMailVO specialistEmail = Util.setEmlForAsmtPrvidedNPrchseItmsRqrd("xprk408", "xprk408", WSAssessment.getAssessmentId(), "");
				emailService.sendEmailNotification(specialistEmail);
			}else{
				SendMailVO specialistEmail = Util.setEmlForAsmtCmpltWithoutPurchaseItems("xprk408", "xsat860", "Prasanna Joshi", WSAssessment.getAssessmentId(), "");
				emailService.sendEmailNotification(specialistEmail);
			}
			} catch (JmsException e) {
				logger.info(e.getMessage());
			} catch (Exception e) {
				logger.info(e.getMessage());
			}
		}
	}
	
	@Transactional
	public boolean updateWorkstationAssessmentStatus(WorkstationAssessment WSAssessment){
		WorkstationEvaluation wsEval = wsEvalDao.getRequestById(WSAssessment.getRequestId());
		boolean flag = false;
		flag =  wsAssessmentdao.updateWorkstationAssessmentStatus(WSAssessment.getAssessmentId(), WSAssessment.getStatus());
		if(flag){
			reqHistDao.insertRequestUpdateHistory(wsEval.getStatus(), WSAssessment.getStatus(), null, WSAssessment.getLoggedEmployee().getEmployeeId(),WSAssessment.getRequestId(), WSAssessment.getAssessmentId(), null);
		}
		return flag;
	}

	
	public Map<String,List<String>> getDropdownValues(){	
		Map<String,List<String>> dropdownValues = new HashMap<>();
		List<Dropdown> dropdownList =  wsAssessmentdao.getDropdownValues();
		if(org.springframework.util.CollectionUtils.isEmpty(dropdownList)){
			return dropdownValues;
		} else {
			dropdownList.stream().forEach(d -> {
				if (!dropdownValues.containsKey(d.getFieldName())) {
					dropdownValues.put(d.getFieldName(), new ArrayList<>());
				}
				dropdownValues.get(d.getFieldName()).add(d.getFieldValue());
			});
		}
		return dropdownValues;
	}
	

}
