package com.uprr.app.egn.dao.impl;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.uprr.app.egn.dao.IDocDAO;
import com.uprr.app.egn.dto.Document;

@Repository
public class DocDAO implements IDocDAO{
	
	@Autowired 
	private JdbcTemplate jdbcTemplate;

	String SAVE_DOCS = "insert into egn_updt_docs(req_id,doc_guid,doc_name,doc_desc,crtd_user_id,crtn_tmst,last_uptd_user_id,last_uptd_tmst) values (?,?,?,?,?,sysdate,?,sysdate)";
	
	@Override
	public boolean saveMultipleDocs(List<Document> docs){
		
		
		jdbcTemplate.batchUpdate(SAVE_DOCS,new BatchPreparedStatementSetter() {

			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				ps.setString(1, docs.get(i).getRequestId());
				ps.setString(2, docs.get(i).getDocumentGuid());
				ps.setString(3, docs.get(i).getDocumentName());
				ps.setString(4, docs.get(i).getDocumentDesc());
				ps.setString(5, docs.get(i).getCreatedBy());
				ps.setString(6, docs.get(i).getUpdatedBy());
			}

			@Override
			public int getBatchSize() {
				return docs.size();
			}
		  });
		
		return true;
		
	}

}
