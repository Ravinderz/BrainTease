package com.uprr.app.egn.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.uprr.app.egn.dto.RequestHistory;

public class RequestHistoryResultSetExtractor<T> implements ResultSetExtractor<T> {

	public T extractData(ResultSet rs) throws SQLException,
	DataAccessException {
		RequestHistory history = new RequestHistory();
		history.setReqHistoryId(rs.getString("REQ_HIST_ID"));
		history.setEvalReqId(rs.getString("EVAL_REQ_ID"));
		history.setEvalAsmtId(rs.getString("ASMT_ID"));
		history.setItemId(rs.getString("ITEM_ID"));
		history.setOldStatusValue(rs.getString("OLD_STAT_VALU"));
		history.setNewStatusValue(rs.getString("NEW_STAT_VALU"));
		history.setRejectReason(rs.getString("REJT_RESN_INFO"));
		history.setChangedBy(rs.getString("CHNG_BY_USER_ID"));
		history.setChangedDate(rs.getString("CHNG_TMST").split(" ")[0]);
		history.setCreatedBy(rs.getString("CRTD_USER_ID"));
		history.setCreatedDate(rs.getString("CRTN_TMST").split(" ")[0]);
		history.setUpdatedBy(rs.getString("LAST_UPDT_USER_ID"));
		history.setUpdatedDate(rs.getString("LAST_UPDT_TMST").split(" ")[0]);
		return (T) history;
	}

}
