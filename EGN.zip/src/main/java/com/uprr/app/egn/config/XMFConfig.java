package com.uprr.app.egn.config;

import java.io.IOException;
import java.util.Properties;

import javax.jms.ConnectionFactory;
import javax.jms.Destination;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.jms.connection.UserCredentialsConnectionFactoryAdapter;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jndi.JndiObjectFactoryBean;

import com.uprr.app.egn.util.CyberArkUtil;
import com.uprr.app.egn.util.Util;
import com.uprr.app.xmf.MessageUtilities;
import com.uprr.app.xmf.StaxMessageUtilities;
import com.uprr.app.xmf.client.ServiceProxy;
import com.uprr.app.xmf.client.ServiceProxyException;
import com.uprr.app.xmf.client.ServiceProxyFactory;
import com.uprr.app.xmf.client.core.ServiceProxyFactoryImpl;

@Configuration
@PropertySource("classpath:application.properties")
public class XMFConfig {
	
	 	@Value("${tibco.ems.userid}")
	    private String jmsUserName;
	    
	    @Value("${tibco.ems.password}")
	    private String jmsPassword;
	    
	    @Value("${connectionFactory.jndiName}")
	    private String enaConFactory;
	    
	    @Value("${esbQueue.jndiName}")
	    private String enaQueueName;
	    
	    @Value("${jms.initialContextFactory}")
	    private String initialContextFactory;
	    
	    @Value("${tibco.ems.jndi.url}")
	    private String jmsUrl;
	
	    @Bean(name = "enaConnectionFactory")
	    public JndiObjectFactoryBean queueConnectionFactory()
	    {
	    	JndiObjectFactoryBean queueConnectionFactory=new JndiObjectFactoryBean();
	    	setBaseJNDIConfigurationBean(queueConnectionFactory);
	    	queueConnectionFactory.setJndiName(enaConFactory);
	    	return queueConnectionFactory;
	    }
	    
	    @Bean(name = "enaAuthenticationConnectionFactory")
	    @Primary
	    public UserCredentialsConnectionFactoryAdapter  userCredentialsConnectionFactoryAdapter() 
	    {
	    	UserCredentialsConnectionFactoryAdapter userCredentialsConnectionFactoryAdapter = new UserCredentialsConnectionFactoryAdapter();
	    	userCredentialsConnectionFactoryAdapter.setTargetConnectionFactory( (ConnectionFactory) queueConnectionFactory().getObject());
	    	userCredentialsConnectionFactoryAdapter.setUsername(jmsUserName);
			CyberArkUtil pwdUtil = new CyberArkUtil();
			pwdUtil.setInstance("JMS");
			pwdUtil.setType("JMS");
			pwdUtil.setUserID(jmsUserName);
			pwdUtil.setUsername(jmsUserName);						
			pwdUtil.setAppTLA("EGN");
			pwdUtil.setRunEnv(Util.getEnvironment());
			pwdUtil.setLocalEnvPassword(jmsPassword);
	    	userCredentialsConnectionFactoryAdapter.setPassword(pwdUtil.getPasswordFrmCyberArk());		 
	    	//userCredentialsConnectionFactoryAdapter.setPassword(jmsPassword);
	    	return userCredentialsConnectionFactoryAdapter;
	    }

	    
	    @Bean(name="enaDestination") 
	    public JndiObjectFactoryBean outboundEnaQueueDestination()
	    {
	    	JndiObjectFactoryBean outboundEnaQueueDestination=new JndiObjectFactoryBean();
	    	setBaseJNDIConfigurationBean(outboundEnaQueueDestination);
	    	outboundEnaQueueDestination.setJndiName(enaQueueName);
	    	return outboundEnaQueueDestination;
	    }
	    
	    public void setBaseJNDIConfigurationBean(JndiObjectFactoryBean basejndaconfiguration)
	    {
	    	Properties properties =new Properties();
	    	properties.setProperty("java.naming.factory.initial", initialContextFactory);
	    	properties.setProperty("java.naming.provider.url", jmsUrl);
	    	properties.setProperty("java.naming.security.principal", jmsUserName);
	    	properties.setProperty("java.naming.security.credentials", jmsPassword);
	    	properties.setProperty("java.naming.referral", "throw");
	    	basejndaconfiguration.setJndiEnvironment(properties);
	    }
	    
	    
	    @Bean
	    public JmsTemplate jmsTemplate() 
	    {
	    	JmsTemplate jmsTemplate=new JmsTemplate();
	    	jmsTemplate.setConnectionFactory(userCredentialsConnectionFactoryAdapter());
	    	jmsTemplate.setDefaultDestination((Destination) outboundEnaQueueDestination().getObject());
	    	return jmsTemplate;
	    }
	    
	    @Bean(name = "serviceProviderFactory")
	    public ServiceProxyFactory serviceProxyFactory(){
	    	ServiceProxyFactory serviceProxyFactory = new ServiceProxyFactoryImpl(userCredentialsConnectionFactoryAdapter());
	    	return serviceProxyFactory;
	    }
	    
	    @Bean(name = "serviceProxy" )
	    public ServiceProxy serviceProxy() throws ServiceProxyException{
	    	ServiceProxyFactory serviceProxyFactory = serviceProxyFactory();
	    	ServiceProxy serviceProxy =  serviceProxyFactory.createServiceProxy();
	    	Destination destination = (Destination) outboundEnaQueueDestination().getObject();
	    	serviceProxy.setRequestDestination(destination);
	    	return serviceProxy;
	    }
	    
	    @Bean
	    public MessageUtilities messageUtilities(){
	    	return new StaxMessageUtilities();
	    }

	@Bean
	public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() throws IOException {
		return new PropertySourcesPlaceholderConfigurer();
	}
}
