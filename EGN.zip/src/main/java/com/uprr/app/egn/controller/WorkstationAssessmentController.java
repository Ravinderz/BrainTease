package com.uprr.app.egn.controller;

import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.uprr.app.egn.dto.WorkstationAssessment;
import com.uprr.app.egn.service.IAuthorizationService;
import com.uprr.app.egn.service.WorkstationAssessmentService;
import com.uprr.app.egn.util.Util;
import com.uprr.azm.shared.mvc.security.authorization.Attribute;
import com.uprr.azm.shared.mvc.security.authorization.Authorize;
import com.uprr.ui.shared.user.ActiveUserId;
import com.uprr.ui.shared.user.spring.mvc.ActiveUser;

@RestController
@RequestMapping("workstationAssessment")
public class WorkstationAssessmentController {
	
	@Autowired
	WorkstationAssessmentService wsService;
	
	@Autowired
	IAuthorizationService authService;
	
	Logger logger = LogManager.getLogger(WorkstationAssessmentController.class);

	@PostMapping("submitWorkstationAssessment")
	 @Authorize(
	    	    actions = {@Attribute(key="action-id", value="access")},
	    	    resources = {@Attribute(key="resource-id", value="ergonomics"),@Attribute(key="feature-id", value="create-assessment")}
	    	    )
	public @ResponseBody ResponseEntity<WorkstationAssessment> submitWorkstationAssessment(@RequestBody WorkstationAssessment WSAssessment){
		
		logger.info("entering submitWorkstationAssessment method in controller");
		
		int assessmentId = wsService.submitWorkstationAssessment(WSAssessment);
		WSAssessment.setAssessmentId(Integer.toString(assessmentId));
		if(assessmentId != 0){
			return new ResponseEntity<WorkstationAssessment>(WSAssessment, HttpStatus.OK);
		}else{
			return new ResponseEntity<WorkstationAssessment>(WSAssessment, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PostMapping("saveWorkstationAssessment")
	 @Authorize(
	    	    actions = {@Attribute(key="action-id", value="access")},
	    	    resources = {@Attribute(key="resource-id", value="ergonomics"),@Attribute(key="feature-id", value="create-assessment")}
	    	    )
	public @ResponseBody ResponseEntity<WorkstationAssessment> saveWorkstationAssessment(@RequestBody WorkstationAssessment WSAssessment){
		
		logger.info("entering submitWorkstationAssessment method in controller");
		int assessmentId = wsService.saveWorkstationAssessment(WSAssessment);
		WSAssessment.setAssessmentId(Integer.toString(assessmentId));
		if(assessmentId != 0){
			return new ResponseEntity<WorkstationAssessment>(WSAssessment, HttpStatus.OK);
		}else{
			return new ResponseEntity<WorkstationAssessment>(WSAssessment, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PostMapping("updateWorkstationAssessment")
	public @ResponseBody ResponseEntity<WorkstationAssessment> updateWorkstationAssessment(@RequestBody WorkstationAssessment WSAssessment,@ActiveUser ActiveUserId activeUser){
		
		logger.info("entering updateWorkstationAssessment in WorkStationRequestController");
		
		if(Util.isLocalMode() || authService.canCreateAssessment(activeUser.getUserId()) || authService.canCreateCostItems(activeUser.getUserId())){
			if(wsService.updateWorkStationAssessment(WSAssessment)){
				return new ResponseEntity<WorkstationAssessment>(WSAssessment, HttpStatus.OK);
			}else{
				return new ResponseEntity<WorkstationAssessment>(WSAssessment, HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}else{
			WorkstationAssessment asmt = null;
			return new ResponseEntity<WorkstationAssessment>(asmt, HttpStatus.FORBIDDEN);
		}
			
		
	}
	
	@PostMapping("updateWorkstationAssessmentStatus")
	public @ResponseBody ResponseEntity<WorkstationAssessment> updateWorkstationAssessmentStatus(@RequestBody WorkstationAssessment WSAssessment){
		
		logger.info("entering updateWorkstationAssessment in WorkStationRequestController");
		
		if(wsService.updateWorkstationAssessmentStatus(WSAssessment)){
			return new ResponseEntity<WorkstationAssessment>(WSAssessment, HttpStatus.OK);
		}else{
			return new ResponseEntity<WorkstationAssessment>(WSAssessment, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping("getDropdownValues")
	public @ResponseBody ResponseEntity<Map<String,List<String>>> getDropdownValues(){
		return new ResponseEntity<Map<String,List<String>>>(wsService.getDropdownValues(), HttpStatus.OK);
	}
	
	@GetMapping("getAssessmentRequestById/{requestId}")
	public @ResponseBody ResponseEntity<WorkstationAssessment> getRequestById(@PathVariable("requestId") String requestId){
		logger.info("entering getRequestById in WorkStationRequestController "+requestId);
		WorkstationAssessment assessment = wsService.getRequestById(requestId);
		return new ResponseEntity<WorkstationAssessment>(assessment, HttpStatus.OK);
	}
}
