package com.uprr.app.egn.dao;

import java.util.List;
import java.util.Set;
import com.uprr.app.egn.dto.LoggedUserVO;
import com.uprr.app.egn.dto.WorkstationEvaluation;

public interface IEmployeeDAO {

	public boolean insertEmployeeRecord(WorkstationEvaluation wsEval);
	
	public boolean insertEmployeeRecord(LoggedUserVO user);
	
	public boolean updateEmployeeRecord(WorkstationEvaluation wsEval);
	
	public boolean updateEmployeeRecord(LoggedUserVO user);
	
	public int getEmployeeCount(String empId);
	
	public LoggedUserVO getEmployeeFromView(String empId);				
	
	public List<LoggedUserVO> getEmployeeFromTable(Set<String> userIds); 
}
