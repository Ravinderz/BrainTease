package com.uprr.app.egn.controller;

import java.util.List;

import javax.jms.JMSException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jms.JmsException;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.uprr.app.egn.dto.Document;
import com.uprr.app.egn.dto.LoggedUserVO;
import com.uprr.app.egn.dto.RequestHistory;
import com.uprr.app.egn.dto.UpdateStatus;
import com.uprr.app.egn.dto.WorkstationEvaluation;
import com.uprr.app.egn.service.EmpCostCenterService;
import com.uprr.app.egn.service.IAuthorizationService;
import com.uprr.app.egn.service.WorkstationEvaluationService;
import com.uprr.app.egn.util.Util;
import com.uprr.azm.shared.mvc.security.authorization.Attribute;
import com.uprr.azm.shared.mvc.security.authorization.Authorize;
import com.uprr.ui.shared.user.ActiveUserId;
import com.uprr.ui.shared.user.spring.mvc.ActiveUser;

@RestController
@RequestMapping("workstationRequest")
public class WorkstationRequestController {

	@Autowired
	private WorkstationEvaluationService wsService;

	@Autowired
	private EmpCostCenterService costCenterService;

	@Autowired
	IAuthorizationService authService; 

	Logger logger = LogManager.getLogger(WorkstationRequestController.class);

	@GetMapping("getDataFromDB")
	public List<WorkstationEvaluation> getWorkstationRequestsFromDB(){
		logger.info("entering getWorkstationRequestsFromDB method");
		return wsService.getRequestDataFromDB();
	}

	@GetMapping("getDataFromDB/{supvid}")
	public @ResponseBody ResponseEntity<List<WorkstationEvaluation>> getWorkstationRequestsForSupvId(@PathVariable("supvid") String supvid,@ActiveUser ActiveUserId activeUser){
		logger.info("entering getWorkstationRequestsFromDB method "+supvid);
		List<WorkstationEvaluation> list = null;
		if(Util.isLocalMode() || activeUser.getEmployeeId().equalsIgnoreCase(supvid)){
			list = wsService.getRequestDataFromDB(supvid);
			return new ResponseEntity<List<WorkstationEvaluation>>(list, HttpStatus.OK);
		}else{
			return new ResponseEntity<List<WorkstationEvaluation>>(list, HttpStatus.FORBIDDEN);
		}
	}

	@GetMapping("getAllMedicalRequests")
	@Authorize(
			actions = {@Attribute(key="action-id", value="access")},
			resources = {@Attribute(key="resource-id", value="ergonomics"),@Attribute(key="feature-id", value="medical-disposition")}
			)
	public @ResponseBody ResponseEntity<List<WorkstationEvaluation>> getAllMedicalRequests(){
		logger.info("entering getAllMedicalRequests method");
		List<WorkstationEvaluation> allMedicalRequestList = wsService.getAllMedicalRequests();
		if(allMedicalRequestList != null && !allMedicalRequestList.isEmpty()){
			return new ResponseEntity<List<WorkstationEvaluation>>(allMedicalRequestList, HttpStatus.OK);
		}else{
			return new ResponseEntity<List<WorkstationEvaluation>>(allMedicalRequestList, HttpStatus.NO_CONTENT);
		}
	}
 

	@PostMapping(value = "updateStatus" , produces="text/plain")
	public @ResponseBody ResponseEntity<String> updateStatus(@RequestBody UpdateStatus updateStatus,@ActiveUser ActiveUserId activeUser){

		String supvId = updateStatus.getWorkstationEvaluationList().get(0).getRequestingSupervisorId();
		
		if(Util.isLocalMode() || authService.canApproveMedicalRequest(activeUser.getUserId()) || supvId.equalsIgnoreCase(activeUser.getEmployeeId()) || updateStatus.getEmpId().equalsIgnoreCase(activeUser.getEmployeeId())){
			try {
				if(wsService.updateStatus(updateStatus)){
					return new ResponseEntity<String>("status updated successfull ", HttpStatus.OK);
				}else{
					return new ResponseEntity<String>("status was not updated ", HttpStatus.INTERNAL_SERVER_ERROR);
				}
			} catch (JMSException e) {
				return new ResponseEntity<String>("status was not updated ", HttpStatus.INTERNAL_SERVER_ERROR);
			} catch (Exception e) {
				return new ResponseEntity<String>("status was not updated ", HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}else{
			return new ResponseEntity<String>("Forbidden ", HttpStatus.FORBIDDEN);
		}
	}

	@PostMapping(value = "submitWorkstationRequest")
	@Authorize(
			actions = {@Attribute(key="action-id", value="access")},
			resources = {@Attribute(key="resource-id", value="ergonomics"),@Attribute(key="feature-id", value="create-request")}
			)
	public @ResponseBody ResponseEntity<WorkstationEvaluation> submitWorkstationRequest(@RequestBody WorkstationEvaluation WSEvaluation){

		logger.info("entering submitWorkstationRequest in WorkStationRequestController");
		WorkstationEvaluation wsEval = null;
		try {
			wsEval = wsService.submitWorkStationRequest(WSEvaluation);

			if (wsEval.getRequestId() != null) {
				return new ResponseEntity<WorkstationEvaluation>(wsEval, HttpStatus.OK);
			} else {
				return new ResponseEntity<WorkstationEvaluation>(wsEval, HttpStatus.INTERNAL_SERVER_ERROR);
			} 
		} catch (JMSException e) {
			return new ResponseEntity<WorkstationEvaluation>(wsEval, HttpStatus.INTERNAL_SERVER_ERROR);
		} catch (Exception e) {
			return new ResponseEntity<WorkstationEvaluation>(wsEval, HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	@PostMapping(value = "updateWorkstationRequest", produces="text/plain")
	@Authorize(
			actions = {@Attribute(key="action-id", value="access")},
			resources = {@Attribute(key="resource-id", value="ergonomics"),@Attribute(key="feature-id", value="create-request")}
			)
	public @ResponseBody ResponseEntity<String> updateWorkstationRequest(@RequestBody WorkstationEvaluation WSEvaluation) throws JmsException, Exception{

		logger.info("entering updateWorkstationRequest in WorkStationRequestController");

		if(wsService.updateWorkStationRequest(WSEvaluation)){
			return new ResponseEntity<String>("successfull "+WSEvaluation, HttpStatus.OK);
		}else{
			return new ResponseEntity<String>("unsuccessfull "+WSEvaluation, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PostMapping("getRequestByIdSrcMail/{requestId}")
	public @ResponseBody ResponseEntity<WorkstationEvaluation> getRequestByIdSrcMail(@PathVariable("requestId") String requestId,@RequestBody LoggedUserVO loggedUser,@ActiveUser ActiveUserId activeUser) throws Exception{
		logger.info("entering getRequestById in WorkStationRequestController "+requestId);
		String reqId = Util.decrypt(requestId, Util.ENCRYPT_KEY);
		WorkstationEvaluation eval = wsService.getRequestById(reqId);
		if(Util.isLocalMode() || activeUser.getEmployeeId().equalsIgnoreCase(eval.getRequestingSupervisorId()) || activeUser.getEmployeeId().equalsIgnoreCase(eval.getEmpId()) || authService.canCreateAssessment(activeUser.getUserId()) || authService.canApproveMedicalRequest(activeUser.getUserId()) || authService.canEditCostItems(activeUser.getUserId())){
			if(eval != null){
				return new ResponseEntity<WorkstationEvaluation>(eval, HttpStatus.OK);
			}else{
				return new ResponseEntity<WorkstationEvaluation>(eval, HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}else{
			eval = null;
			return new ResponseEntity<WorkstationEvaluation>(eval, HttpStatus.FORBIDDEN);
		}
		
	}
	
	@PostMapping("getRequestById/{requestId}")
	public @ResponseBody ResponseEntity<WorkstationEvaluation> getRequestById(@PathVariable("requestId") String requestId,@RequestBody LoggedUserVO loggedUser,@ActiveUser ActiveUserId activeUser) throws Exception{
		logger.info("entering getRequestById in WorkStationRequestController "+requestId);
		String reqId = requestId;
		WorkstationEvaluation eval = wsService.getRequestById(reqId);
		if(Util.isLocalMode() || activeUser.getEmployeeId().equalsIgnoreCase(eval.getRequestingSupervisorId()) || activeUser.getEmployeeId().equalsIgnoreCase(eval.getEmpId()) || authService.canCreateAssessment(activeUser.getUserId()) || authService.canApproveMedicalRequest(activeUser.getUserId()) || authService.canEditCostItems(activeUser.getUserId())){
			if(eval != null){
				return new ResponseEntity<WorkstationEvaluation>(eval, HttpStatus.OK);
			}else{
				return new ResponseEntity<WorkstationEvaluation>(eval, HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}else{
			eval = null;
			return new ResponseEntity<WorkstationEvaluation>(eval, HttpStatus.FORBIDDEN);
		}
		
	}


	@PostMapping("getRequestByUser/{emplId}")
	public @ResponseBody ResponseEntity<List<WorkstationEvaluation>> getRequestByUser(@PathVariable("emplId") String emplId,@ActiveUser ActiveUserId activeUser){
		logger.info("entering getRequestById in WorkStationRequestController "+emplId);
		List<WorkstationEvaluation> list = null;
		if(Util.isLocalMode() || activeUser.getEmployeeId().equalsIgnoreCase(emplId)){
			list = wsService.getRequestByUser(emplId);
			return new ResponseEntity<List<WorkstationEvaluation>>(list, HttpStatus.OK);
		}else{
			return new ResponseEntity<List<WorkstationEvaluation>>(list, HttpStatus.FORBIDDEN);
		}
	}


	@GetMapping("getDocumentsByRequestId/{emplId}/{requestId}")
	public @ResponseBody ResponseEntity<List<Document>> getDocumentsByRequestId(@PathVariable("emplId") String emplId,@PathVariable("requestId") String requestId,@ActiveUser ActiveUserId activeUser){
		logger.info("entering getDocumentsByRequestId in WorkStationRequestController "+requestId);
		List<Document> list = null;
		if(Util.isLocalMode() || activeUser.getEmployeeId().equalsIgnoreCase(emplId) || authService.canViewMedicalRecords(activeUser.getUserId())){
			list = wsService.getDocumentsByRequestId(requestId);
			return new ResponseEntity<List<Document>>(list, HttpStatus.OK);
		}else{
			return new ResponseEntity<List<Document>>(list, HttpStatus.FORBIDDEN);
		}
	}

	@PostMapping("saveWorkstationRequest")
	@Authorize(
			actions = {@Attribute(key="action-id", value="access")},
			resources = {@Attribute(key="resource-id", value="ergonomics"),@Attribute(key="feature-id", value="create-request")}
			)
	public @ResponseBody ResponseEntity<WorkstationEvaluation> saveWorkstationRequest(@RequestBody WorkstationEvaluation WSEvaluation){

		logger.info("entering saveWorkstationRequest in WorkStationRequestController");
		WorkstationEvaluation wsEval = wsService.saveWorkStationRequest(WSEvaluation);
		if(wsEval.getRequestId() != null){
			return new ResponseEntity<WorkstationEvaluation>(WSEvaluation, HttpStatus.OK);
		}else{
			return new ResponseEntity<WorkstationEvaluation>(WSEvaluation, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}


	@GetMapping("getCostCenterDtls/{employeeId}")
	public @ResponseBody ResponseEntity<List<String>> getCostCenterDtls(@PathVariable("employeeId") String employeeId) throws Exception{
		logger.info("entering getDocumentsByRequestId in WorkStationRequestController "+employeeId);
		List<String> costCenter = costCenterService.getCostCenterDetails(employeeId);
		if(!StringUtils.isEmpty(costCenter)){
			return new ResponseEntity<List<String>>(costCenter, HttpStatus.OK);
		}else{
			return new ResponseEntity<List<String>>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping("getRequestHistory/{requestId}")
	public @ResponseBody ResponseEntity<List<RequestHistory>> getEvalRequestHistory(@PathVariable("requestId") String requestId){
		logger.info("entering getEvalRequestHistory in WorkStationRequestController "+requestId);
		List<RequestHistory> history = wsService.getEvalRequestHistory(requestId);
		if(history.size() > 0){
			return new ResponseEntity<List<RequestHistory>>(history, HttpStatus.OK);
		}else{
			return new ResponseEntity<List<RequestHistory>>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}



}