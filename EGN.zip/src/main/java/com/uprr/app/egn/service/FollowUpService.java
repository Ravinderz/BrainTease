package com.uprr.app.egn.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.uprr.app.egn.dao.IFollowUpDAO;
import com.uprr.app.egn.dto.FollowUpVO;
import com.uprr.app.egn.dto.LoggedUserVO;

@Service
public class FollowUpService {

	Logger logger = LogManager.getLogger(FollowUpService.class);
	
	@Autowired
	IFollowUpDAO followUpDao;
	
	@Autowired
    private IEmplService emplService;
	
	@Transactional
	public boolean addFollowUpNote(FollowUpVO followUp){
		return followUpDao.addFollowUp(followUp);
	}
	
	public List<FollowUpVO> getAllNotesByAsmtId(String asmtId){
		List<FollowUpVO> list = followUpDao.getAllFollowUpNotesByAsmtId(asmtId);
		Set<String> set = new HashSet<>(list.size());
		list.forEach(hist -> set.add(hist.getCreatedBy()));
		List<LoggedUserVO> userList = emplService.getUserDetails(set);
		List<FollowUpVO> updatedList = new ArrayList<>();
		for(FollowUpVO hist : list){
			for(LoggedUserVO user: userList){
				if(hist.getCreatedBy().equalsIgnoreCase(user.getEmployeeId())){
					hist.setCreatedBy(user.getFullName());
					updatedList.add(hist);
				}
				
			}
		} 
		logger.info(updatedList);
		return updatedList;
	}
}
