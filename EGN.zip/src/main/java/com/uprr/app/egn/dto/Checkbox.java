package com.uprr.app.egn.dto;

public class Checkbox {

	private boolean cADWS = false;
	private boolean shippingMailroomStocking = false;
	private boolean rMCC = false;
	private boolean parts = false;
	private boolean administrativeClerical = false;
	private boolean computerKeyboardMouse = false;
	private boolean chairFootrest = false;
	private boolean sitToStand = false;
	private boolean computerMonitor = false;
	private boolean generalWorkstationEvaluation = false;
	private boolean generalOfficeWorkEmpEval = false;
	
	public boolean iscADWS() {
		return cADWS;
	}
	public void setcADWS(boolean cADWS) {
		this.cADWS = cADWS;
	}
	public boolean isShippingMailroomStocking() {
		return shippingMailroomStocking;
	}
	public void setShippingMailroomStocking(boolean shippingMailroomStocking) {
		this.shippingMailroomStocking = shippingMailroomStocking;
	}
	public boolean isrMCC() {
		return rMCC;
	}
	public void setrMCC(boolean rMCC) {
		this.rMCC = rMCC;
	}
	public boolean isParts() {
		return parts;
	}
	public void setParts(boolean parts) {
		this.parts = parts;
	}
	public boolean isAdministrativeClerical() {
		return administrativeClerical;
	}
	public void setAdministrativeClerical(boolean administrativeClerical) {
		this.administrativeClerical = administrativeClerical;
	}
	public boolean isComputerKeyboardMouse() {
		return computerKeyboardMouse;
	}
	public void setComputerKeyboardMouse(boolean computerKeyboardMouse) {
		this.computerKeyboardMouse = computerKeyboardMouse;
	}
	public boolean isChairFootrest() {
		return chairFootrest;
	}
	public void setChairFootrest(boolean chairFootrest) {
		this.chairFootrest = chairFootrest;
	}
	public boolean isSitToStand() {
		return sitToStand;
	}
	public void setSitToStand(boolean sitToStand) {
		this.sitToStand = sitToStand;
	}
	public boolean isComputerMonitor() {
		return computerMonitor;
	}
	public void setComputerMonitor(boolean computerMonitor) {
		this.computerMonitor = computerMonitor;
	}
	public boolean isGeneralWorkstationEvaluation() {
		return generalWorkstationEvaluation;
	}
	public void setGeneralWorkstationEvaluation(boolean generalWorkstationEvaluation) {
		this.generalWorkstationEvaluation = generalWorkstationEvaluation;
	}
	public boolean isGeneralOfficeWorkEmpEval() {
		return generalOfficeWorkEmpEval;
	}
	public void setGeneralOfficeWorkEmpEval(boolean generalOfficeWorkEmpEval) {
		this.generalOfficeWorkEmpEval = generalOfficeWorkEmpEval;
	}
	public Checkbox() {

	}
	@Override
	public String toString() {
		return "Checkbox [cADWS=" + cADWS + ", shippingMailroomStocking=" + shippingMailroomStocking + ", rMCC=" + rMCC
				+ ", parts=" + parts + ", administrativeClerical=" + administrativeClerical + ", computerKeyboardMouse="
				+ computerKeyboardMouse + ", chairFootrest=" + chairFootrest + ", sitToStand=" + sitToStand
				+ ", computerMonitor=" + computerMonitor + ", generalWorkstationEvaluation="
				+ generalWorkstationEvaluation + ", generalOfficeWorkEmpEval=" + generalOfficeWorkEmpEval + "]";
	}
	public Checkbox(boolean cADWS, boolean shippingMailroomStocking, boolean rMCC, boolean parts,
			boolean administrativeClerical, boolean computerKeyboardMouse, boolean chairFootrest, boolean sitToStand,
			boolean computerMonitor, boolean generalWorkstationEvaluation, boolean generalOfficeWorkEmpEval) {
		super();
		this.cADWS = cADWS;
		this.shippingMailroomStocking = shippingMailroomStocking;
		this.rMCC = rMCC;
		this.parts = parts;
		this.administrativeClerical = administrativeClerical;
		this.computerKeyboardMouse = computerKeyboardMouse;
		this.chairFootrest = chairFootrest;
		this.sitToStand = sitToStand;
		this.computerMonitor = computerMonitor;
		this.generalWorkstationEvaluation = generalWorkstationEvaluation;
		this.generalOfficeWorkEmpEval = generalOfficeWorkEmpEval;
	}
}
