package com.uprr.app.egn.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.uprr.app.egn.dto.ActionItem;

public class ItemResultSetExtractor<T> implements ResultSetExtractor<T> {

	public T extractData(ResultSet rs) throws SQLException,
	DataAccessException {
		ActionItem item = new ActionItem();
		item.setAssessmentId(rs.getString("ASMT_ID"));
		item.setItemId(rs.getInt("ASMT_WORK_ORD_ID"));
		item.setItemTextDesc(rs.getString("WORK_ORD_DESC"));
		item.setEstimatedCost(rs.getString("WORK_ORD_EST_COST"));
		item.setNote(rs.getString("WORK_ORD_NOTE_INFO"));
		item.setAssignedToEmployeeId(rs.getString("ASGN_TO_ID"));
		item.setAssignedToEmployeeName(rs.getString("ASGN_TO_NAME"));
		item.setDateAssigned(rs.getString("ASGN_DATE").split(" ")[0]);
		item.setSupvAprvlStatus(rs.getString("SUPV_APVL_INFO"));
		item.setItemOrderStatus(rs.getString("WORK_ORD_STAT_INFO"));
		item.setCreatedById(rs.getString("CRTD_USER_ID"));
		item.setUpdatedById(rs.getString("LAST_UPDT_USER_ID"));
		return (T) item;
	}
}
