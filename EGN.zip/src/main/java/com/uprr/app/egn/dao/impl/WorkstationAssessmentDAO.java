package com.uprr.app.egn.dao.impl;

import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.uprr.app.egn.dao.IWorkstationAssessmentDAO;
import com.uprr.app.egn.dao.mapper.ItemMapper;
import com.uprr.app.egn.dao.mapper.WSAssessmentMapper;
import com.uprr.app.egn.dto.ActionItem;
import com.uprr.app.egn.dto.Dropdown;
import com.uprr.app.egn.dto.WorkstationAssessment;
import com.uprr.app.egn.util.Util;

@Repository
public class WorkstationAssessmentDAO implements IWorkstationAssessmentDAO {

	Logger logger = LogManager.getLogger(WorkstationAssessmentDAO.class);

	private String INSERT_WORKSTATION_ASSESSMENT = "insert into egn_wkst_asmt (req_id,asmt_id,asmt_date,wkst_asmt_name,asmt_resn_info,cur_symp_info,asmt_wkst_pstr_desc,cur_chr_desc,mntr_desc,seat_hgt,mntr_hgt,seat_deph,kybd_tray_mous_desc,back_rest_desc,asmt_cmnt,arm_rest_desc,adj_made_info,chr_rcmn_desc,oth_eqmt_need,asmt_smry_desc,flw_up_thrp_name,asmt_stat_info,crtd_user_id,crtn_tmst,last_updt_user_id,last_updt_tmst,EMPL_INFO) values (?,egn_wkst_asmt_q1.nextval,TO_DATE(?,'yyyy-MM-dd'),?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,sysdate,?,sysdate,?)";

	private String UPDATE_WORKSTATION_ASSESSMENT = "update egn_wkst_asmt set wkst_asmt_name=?,asmt_resn_info=?,cur_symp_info=?,asmt_wkst_pstr_desc=?,cur_chr_desc=?,mntr_desc=?,seat_hgt=?,mntr_hgt=?,seat_deph=?,kybd_tray_mous_desc=?,back_rest_desc=?,asmt_cmnt=?,arm_rest_desc=?,adj_made_info=?,chr_rcmn_desc=?,oth_eqmt_need=?,asmt_smry_desc=?,flw_up_thrp_name=?,asmt_stat_info=?,last_updt_user_id=?,last_updt_tmst = sysdate where asmt_id = ?";

	private String GET_DROPDOWN_VALUES_LOCAL = "select fld_name as fieldName,fld_valu as fieldValue from egn_drop_down_lkup";
	
	private String GET_DROPDOWN_VALUES = "select fld_name as fieldName,fld_valu as fieldValue from EGN.egn_drop_down_lkup";

	private String GET_ASSESSMENT_REQUEST_BY_ID = "select req_id,wkst_asmt_name,mntr_hgt,crtd_user_id,crtn_tmst,last_updt_user_id,last_updt_tmst,asmt_date,asmt_resn_info,cur_symp_info,asmt_wkst_pstr_desc,cur_chr_desc,mntr_desc,seat_deph,kybd_tray_mous_desc,back_rest_desc,asmt_cmnt,arm_rest_desc,adj_made_info,chr_rcmn_desc,oth_eqmt_need,asmt_stat_info,flw_up_thrp_name,asmt_smry_desc,seat_hgt,asmt_id from egn_wkst_asmt where asmt_id = ?";
	
	private String GET_ASSESSMENT_REQUEST_BY_REQUEST_ID = "select count(*) from egn_wkst_asmt where asmt_id = ?";	
	
	private String SAVE_ACTION_ITEMS = "insert into EGN_ASMT_WORK_ORD_INFO(asmt_work_ord_id,asmt_id,work_ord_item_name,work_ord_desc,work_ord_note_info,work_ord_est_cost,work_ord_stat_info,asgn_to_id,asgn_date,crtd_user_id,crtn_tmst,last_updt_user_id,last_updt_tmst) values (egn_asmt_work_ord_info_q1.nextval,?,?,?,?,?,?,?,sysdate,?,sysdate,?,sysdate)";
	
	private String UPDATE_ACTION_ITEMS = "update EGN_ASMT_WORK_ORD_INFO set work_ord_item_name = ?,work_ord_desc = ?,work_ord_note_info = ?,work_ord_est_cost = ?,work_ord_stat_info = ?,asgn_to_id = ?,asgn_date = sysdate,last_updt_user_id = ?,last_updt_tmst = sysdate where asmt_work_ord_id = ?";
	
	private String GET_ALL_ITEMS_BY_ASSESSMENT_ID = "select asmt_work_ord_id,work_ord_item_name,work_ord_desc,work_ord_note_info,work_ord_est_cost,asgn_to_id,asgn_date,work_ord_stat_info,crtd_user_id,crtn_tmst,last_updt_user_id,last_updt_tmst,asmt_id,asgn_to_name,supv_apvl_info from egn_asmt_work_ord_info where asmt_id = ?";
	
	private String UPDATE_ASSESSMENT_STATUS = "update egn_wkst_asmt set asmt_stat_info = ? where asmt_id = ?";

	@Autowired private JdbcTemplate jdbcTemplate;

	@Override
	public int submitWorkstationAssessment(WorkstationAssessment WSAssessment) { 
		logger.info(WSAssessment);
		KeyHolder holder = new GeneratedKeyHolder();
		int assessmtId = 0;
		jdbcTemplate.update(con -> {
			PreparedStatement ps = con.prepareStatement(INSERT_WORKSTATION_ASSESSMENT, new String[] {"asmt_id"});
			ps.setString( 1  ,WSAssessment.getRequestId());
			ps.setString( 2  ,WSAssessment.getDateofAssessment());
			ps.setString( 3  ,WSAssessment.getWsAssessmentName());
			ps.setString( 4 ,WSAssessment.getReasonForAssessment());
			ps.setString( 5 ,WSAssessment.getCurrentSymptoms());
			ps.setString( 6 ,WSAssessment.getAssessmentWSPosture());
			ps.setString( 7 ,WSAssessment.getCurrentChair());
			ps.setString( 8 ,WSAssessment.getMonitor());
			ps.setString( 9 ,WSAssessment.getSeatHeight());
			ps.setInt( 10 ,WSAssessment.getMonitorHeight());
			ps.setString( 11 ,WSAssessment.getSeatDepth());
			ps.setString( 12 ,WSAssessment.getKeyboardTrayMouse());
			ps.setString( 13 ,WSAssessment.getBackRest());
			ps.setString( 14 ,WSAssessment.getComments());
			ps.setString( 15 ,WSAssessment.getArmRest());
			ps.setString( 16 ,WSAssessment.getAdjustmentsMade());
			ps.setString( 17 ,WSAssessment.getChairRecommendations());
			ps.setString( 18 ,WSAssessment.getOtherEquipmentNeeds());
			ps.setString( 19 ,WSAssessment.getSummary());
			ps.setString( 20 ,WSAssessment.getLoggedEmployee().getEmployeeId());
			ps.setString( 21 ,WSAssessment.getStatus());
			ps.setString( 22 ,WSAssessment.getLoggedEmployee().getEmployeeId());
			ps.setString( 23 ,WSAssessment.getLoggedEmployee().getEmployeeId());
			ps.setString( 24 ,WSAssessment.getLoggedEmployee().getEmployeeId());
			return ps;
	}, holder);
			BigDecimal i =  (BigDecimal) holder.getKeys().get("asmt_id");
			assessmtId = i.intValue();
		
		return assessmtId;
	}
	
	@Override
	public int saveWorkstationAssessment(WorkstationAssessment WSAssessment) {
		logger.info(WSAssessment);
		KeyHolder holder = new GeneratedKeyHolder();
		int assessmtId = 0;

			jdbcTemplate.update(con -> {
					PreparedStatement ps = con.prepareStatement(INSERT_WORKSTATION_ASSESSMENT, new String[] {"asmt_id"});
					ps.setString( 1  ,WSAssessment.getRequestId());
					ps.setString( 2  ,WSAssessment.getDateofAssessment());
					ps.setString( 3  ,WSAssessment.getWsAssessmentName());
					ps.setString( 4 ,WSAssessment.getReasonForAssessment());
					ps.setString( 5 ,WSAssessment.getCurrentSymptoms());
					ps.setString( 6 ,WSAssessment.getAssessmentWSPosture());
					ps.setString( 7 ,WSAssessment.getCurrentChair());
					ps.setString( 8 ,WSAssessment.getMonitor());
					ps.setString( 9 ,WSAssessment.getSeatHeight());
					ps.setInt( 10 ,WSAssessment.getMonitorHeight());
					ps.setString( 11 ,WSAssessment.getSeatDepth());
					ps.setString( 12 ,WSAssessment.getKeyboardTrayMouse());
					ps.setString( 13 ,WSAssessment.getBackRest());
					ps.setString( 14 ,WSAssessment.getComments());
					ps.setString( 15 ,WSAssessment.getArmRest());
					ps.setString( 16 ,WSAssessment.getAdjustmentsMade());
					ps.setString( 17 ,WSAssessment.getChairRecommendations());
					ps.setString( 18 ,WSAssessment.getOtherEquipmentNeeds());
					ps.setString( 19 ,WSAssessment.getSummary());
					ps.setString( 20 ,WSAssessment.getLoggedEmployee().getEmployeeId());
					ps.setString( 21 ,WSAssessment.getStatus());
					ps.setString( 22 ,WSAssessment.getLoggedEmployee().getEmployeeId());
					ps.setString( 23 ,WSAssessment.getLoggedEmployee().getEmployeeId());
					ps.setString( 24 ,WSAssessment.getLoggedEmployee().getEmployeeId());
					return ps;
			}, holder);
			BigDecimal i =  (BigDecimal) holder.getKeys().get("asmt_id");
			assessmtId = i.intValue();
		
		return assessmtId;
	}
	
	@Override
	public boolean updateWorkStationAssessment(WorkstationAssessment WSAssessment) {
		boolean flag = false;
		
		int updatedRow = jdbcTemplate.update(UPDATE_WORKSTATION_ASSESSMENT, new PreparedStatementSetter(){
			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setString( 1  ,WSAssessment.getWsAssessmentName());
				ps.setString( 2 ,WSAssessment.getReasonForAssessment());
				ps.setString( 3 ,WSAssessment.getCurrentSymptoms());
				ps.setString( 4 ,WSAssessment.getAssessmentWSPosture());
				ps.setString( 5 ,WSAssessment.getCurrentChair());
				ps.setString( 6 ,WSAssessment.getMonitor());
				ps.setString( 7 ,WSAssessment.getSeatHeight());
				ps.setInt( 8 , WSAssessment.getMonitorHeight());
				ps.setString( 9 ,WSAssessment.getSeatDepth());
				ps.setString( 10 ,WSAssessment.getKeyboardTrayMouse());
				ps.setString( 11 ,WSAssessment.getBackRest());
				ps.setString( 12 ,WSAssessment.getComments());
				ps.setString( 13 ,WSAssessment.getArmRest());
				ps.setString( 14 ,WSAssessment.getAdjustmentsMade());
				ps.setString( 15 ,WSAssessment.getChairRecommendations());
				ps.setString( 16 ,WSAssessment.getOtherEquipmentNeeds());
				ps.setString( 17 ,WSAssessment.getSummary());
				ps.setString( 18 ,WSAssessment.getFollowUpTherapist());
				ps.setString( 19 ,WSAssessment.getStatus());
				ps.setString( 20 ,WSAssessment.getLoggedEmployee().getEmployeeId());
				ps.setString( 21, WSAssessment.getAssessmentId());
				
			}
			
		});
		if(updatedRow > 0){
			flag = true;
		}
		else{
			flag = false;
		}
		return flag;
	}
	
	@Override
	public boolean saveActionItems(List<ActionItem> actionItems,int asmtId) {
		logger.info(actionItems);
		
		jdbcTemplate.batchUpdate(SAVE_ACTION_ITEMS,new BatchPreparedStatementSetter() {

			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				ps.setInt(1, asmtId);
				ps.setString(2, actionItems.get(i).getItemTextDesc());
				ps.setString(3, actionItems.get(i).getItemTextDesc());
				ps.setString(4, actionItems.get(i).getNote());
				ps.setString(5, actionItems.get(i).getEstimatedCost());
				ps.setString(6, actionItems.get(i).getSupvAprvlStatus());
				ps.setString(7, actionItems.get(i).getAssignedToEmployeeId());
				ps.setString(8, actionItems.get(i).getAssignedToEmployeeId());
				ps.setString(9, actionItems.get(i).getAssignedToEmployeeId());
			}

			@Override
			public int getBatchSize() {
				return actionItems.size();
			}
		  });
		
		return true;
	}

	@Override
	public List<Dropdown> getDropdownValues() {
		String query = GET_DROPDOWN_VALUES_LOCAL;
		//String query = GET_DROPDOWN_VALUES;
		if(!Util.isLocalMode()){
			query = GET_DROPDOWN_VALUES;
		}
		return jdbcTemplate.query(query, new BeanPropertyRowMapper<Dropdown>(Dropdown.class));
		
	}

	@Override
	public WorkstationAssessment getRequestById(String requestId) {
		return jdbcTemplate.queryForObject(GET_ASSESSMENT_REQUEST_BY_ID, new Object[]{requestId} , new WSAssessmentMapper<WorkstationAssessment>());
	}
	
	public List<ActionItem> getAllItemsByAsmtId(String assessmentId){
		return jdbcTemplate.query(GET_ALL_ITEMS_BY_ASSESSMENT_ID, new Object[]{assessmentId}, new ItemMapper<ActionItem>());
	}
	
	@Override
	public boolean updateWorkstationAssessmentStatus(String asmtId, String status){
		
		boolean flag = false;
		
		int updatedRow = jdbcTemplate.update(UPDATE_ASSESSMENT_STATUS, new PreparedStatementSetter(){
			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setString(1, status);
				ps.setString(2, asmtId);
			}
			
		});
		if(updatedRow > 0){
			flag = true;
		}
		else{
			flag = false;
		}
		return flag;
	}
	
	@Override
	public boolean updateActionItems(List<ActionItem> actionItems) {
		logger.info(actionItems);
		
		jdbcTemplate.batchUpdate(UPDATE_ACTION_ITEMS,new BatchPreparedStatementSetter() {
			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				ps.setString(1, actionItems.get(i).getItemTextDesc());
				ps.setString(2, actionItems.get(i).getItemTextDesc());
				ps.setString(3, actionItems.get(i).getNote());
				ps.setString(4, actionItems.get(i).getEstimatedCost());
				ps.setString(5, actionItems.get(i).getSupvAprvlStatus());
				ps.setString(6, actionItems.get(i).getAssignedToEmployeeId());
				ps.setString(7, actionItems.get(i).getAssignedToEmployeeId());
				ps.setInt(8, actionItems.get(i).getItemId());
			}

			@Override
			public int getBatchSize() {
				return actionItems.size();
			}
		  });
		
		return true;
	}

	@Override
	public int getAssessmentForReqIdCount(String requestId) {
		return jdbcTemplate.queryForObject(GET_ASSESSMENT_REQUEST_BY_REQUEST_ID, new Object[]{requestId} , Integer.class);
		//return 0;
	}

	
}
