package com.uprr.app.egn.dto;

public class ActionItem {
	
	private int 	itemId;
	private String  assessmentId;
	private String  requestId;
	private String  itemTextDesc;
	private String  assignedToEmployeeId;
	private String  assignedToEmployeeName;
	private String  dateAssigned;
	private String  estimatedCost;
	private String  supvAprvlStatus;
	private String  supervisorId;
	private String 	rejectReason;
	private String  oldStatus;
	private String  note;
	private String  createdBy;
	private String  createdById;
	private String  updatedBy;
	private String  updatedById;
	private String  itemOrderStatus;
	
	
	
	
	public String getSupervisorId() {
		return supervisorId;
	}
	public void setSupervisorId(String supervisorId) {
		this.supervisorId = supervisorId;
	}
	public String getRejectReason() {
		return rejectReason;
	}
	public void setRejectReason(String rejectReason) {
		this.rejectReason = rejectReason;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getCreatedById() {
		return createdById;
	}
	public void setCreatedById(String createdById) {
		this.createdById = createdById;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public String getUpdatedById() {
		return updatedById;
	}
	public void setUpdatedById(String updatedById) {
		this.updatedById = updatedById;
	}
	public String getRequestId() {
		return requestId;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	public int getItemId() {
		return itemId;
	}
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	public String getAssessmentId() {
		return assessmentId;
	}
	public void setAssessmentId(String assessmentId) {
		this.assessmentId = assessmentId;
	}
	public String getItemTextDesc() {
		return itemTextDesc;
	}
	public void setItemTextDesc(String itemTextDesc) {
		this.itemTextDesc = itemTextDesc;
	}
	public String getAssignedToEmployeeId() {
		return assignedToEmployeeId;
	}
	public void setAssignedToEmployeeId(String assignedToEmployeeId) {
		this.assignedToEmployeeId = assignedToEmployeeId;
	}
	public String getAssignedToEmployeeName() {
		return assignedToEmployeeName;
	}
	public void setAssignedToEmployeeName(String assignedToEmployeeName) {
		this.assignedToEmployeeName = assignedToEmployeeName;
	}
	public String getDateAssigned() {
		return dateAssigned;
	}
	public void setDateAssigned(String dateAssigned) {
		this.dateAssigned = dateAssigned;
	}
	public String getEstimatedCost() {
		return estimatedCost;
	}
	public void setEstimatedCost(String estimatedCost) {
		this.estimatedCost = estimatedCost;
	}
	public String getSupvAprvlStatus() {
		return supvAprvlStatus;
	}
	public void setSupvAprvlStatus(String supvAprvlStatus) {
		this.supvAprvlStatus = supvAprvlStatus;
	}
	public String getOldStatus() {
		return oldStatus;
	}
	public void setOldStatus(String oldStatus) {
		this.oldStatus = oldStatus;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	public String getItemOrderStatus() {
		return itemOrderStatus;
	}
	public void setItemOrderStatus(String itemOrderStatus) {
		this.itemOrderStatus = itemOrderStatus;
	}
	public ActionItem() {
		super();
	}
	@Override
	public String toString() {
		return "ActionItem [itemId=" + itemId + ", assessmentId=" + assessmentId + ", requestId=" + requestId
				+ ", itemTextDesc=" + itemTextDesc + ", assignedToEmployeeId=" + assignedToEmployeeId
				+ ", assignedToEmployeeName=" + assignedToEmployeeName + ", dateAssigned=" + dateAssigned
				+ ", estimatedCost=" + estimatedCost + ", supvAprvlStatus=" + supvAprvlStatus + ", supervisorId="
				+ supervisorId + ", rejectReason=" + rejectReason + ", oldStatus=" + oldStatus + ", note=" + note
				+ ", createdBy=" + createdBy + ", createdById=" + createdById + ", updatedBy=" + updatedBy
				+ ", updatedById=" + updatedById + ", itemOrderStatus=" + itemOrderStatus + "]";
	}
	
	
	
}
