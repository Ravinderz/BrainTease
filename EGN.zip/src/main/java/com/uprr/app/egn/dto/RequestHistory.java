package com.uprr.app.egn.dto;

public class RequestHistory {

	String reqHistoryId;
	String evalReqId;
	String evalAsmtId;
	String itemId;
	String oldStatusValue;
	String newStatusValue;
	String rejectReason;
	String changedBy;
	String changedByName;				  
	String changedDate;
	String createdBy;
	String createdDate;
	String updatedBy;
	String updatedDate;
	
	
	public String getChangedByName() {
		return changedByName;
	}
	public void setChangedByName(String changedByName) {
		this.changedByName = changedByName;
	}
	public String getReqHistoryId() {
		return reqHistoryId;
	}
	public void setReqHistoryId(String reqHistoryId) {
		this.reqHistoryId = reqHistoryId;
	}
	public String getEvalReqId() {
		return evalReqId;
	}
	public void setEvalReqId(String evalReqId) {
		this.evalReqId = evalReqId;
	}
	public String getEvalAsmtId() {
		return evalAsmtId;
	}
	public void setEvalAsmtId(String evalAsmtId) {
		this.evalAsmtId = evalAsmtId;
	}
	public String getItemId() {
		return itemId;
	}
	public void setItemId(String itemId) {
		this.itemId = itemId;
	}
	public String getOldStatusValue() {
		return oldStatusValue;
	}
	public void setOldStatusValue(String oldStatusValue) {
		this.oldStatusValue = oldStatusValue;
	}
	public String getNewStatusValue() {
		return newStatusValue;
	}
	public void setNewStatusValue(String newStatusValue) {
		this.newStatusValue = newStatusValue;
	}
	public String getRejectReason() {
		return rejectReason;
	}
	public void setRejectReason(String rejectReason) {
		this.rejectReason = rejectReason;
	}
	public String getChangedBy() {
		return changedBy;
	}
	public void setChangedBy(String changedBy) {
		this.changedBy = changedBy;
	}
	public String getChangedDate() {
		return changedDate;
	}
	public void setChangedDate(String changedDate) {
		this.changedDate = changedDate;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public String getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(String updatedDate) {
		this.updatedDate = updatedDate;
	}
	public RequestHistory() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String toString() {
		return "RequestHistory [reqHistoryId=" + reqHistoryId + ", evalReqId=" + evalReqId + ", evalAsmtId="
				+ evalAsmtId + ", itemId=" + itemId + ", oldStatusValue=" + oldStatusValue + ", newStatusValue="
				+ newStatusValue + ", rejectReason=" + rejectReason + ", changedBy=" + changedBy + ", changedByName="
				+ changedByName + ", changedDate=" + changedDate + ", createdBy=" + createdBy + ", createdDate="
				+ createdDate + ", updatedBy=" + updatedBy + ", updatedDate=" + updatedDate + "]";
	}
	
}
