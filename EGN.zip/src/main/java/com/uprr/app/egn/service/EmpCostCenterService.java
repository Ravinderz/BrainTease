package com.uprr.app.egn.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.uprr.app.xmf.MessageUtilities;
import com.uprr.app.xmf.client.ServiceProxy;

/**
 * Service to send Email from EGN
 * @author xprk408
 * Date : May 5, 2018.
 */
 @ Service
public class EmpCostCenterService implements IEmpCostCenterService {

	 @ Autowired
	ServiceProxy serviceProxy;

	 @ Autowired
	MessageUtilities messageUtilities;

	Logger logger = LogManager.getLogger(EmpCostCenterService.class);

	 @ Override
	public List<String> getCostCenterDetails(String employeeId) {
		
			logger.info("entered the get cost center details method");
			if (null != employeeId && employeeId.equalsIgnoreCase("")) {
				logger.error("Sending ENA Notification -- Message body cannot be empty.");
			}

			String xmfRequestMessage = this.getRequest(employeeId);
			return sendMessage(xmfRequestMessage);
	}

	private List<String> sendMessage(final String strmsg) {
		String responseXML = null;
		List<String> costCtrBldgWrkspc = new ArrayList<String>();
		String costCenter = null;
		try {
			final String serviceName = "person/find-cached-employee-summary/1.0";
			final String requestor = "cn=degn001,ou=uprr,o=up";
			final String xmfHeader = messageUtilities.createXMFRequestHeader(requestor, serviceName);
			logger.info(xmfHeader);
			
			final String requestMessage = messageUtilities.createXMFMessage(xmfHeader, strmsg);
			logger.info(requestMessage);

			final String replyMessage = serviceProxy.invoke(requestMessage, 100000);
			logger.info(replyMessage);

			/* Validate XMF response */
			if (replyMessage == null) {
				logger.error("XMF Service [" + serviceName + "] response is null. \nService [" + serviceName + "] Timeout [10000]");
				throw new Exception("XMF Service [" + serviceName + "] response is null");
			}

			/* Extract the body from XMF response */
			responseXML = messageUtilities.getXMFBody(replyMessage);
			logger.info("Service [" + serviceName + "] response: \n" + responseXML);

			logger.info(responseXML);

			if (!StringUtils.isEmpty(responseXML)) {
				costCenter = this.getExtractCostCenterData(responseXML, "cost-center");
				logger.info(costCenter);
				if(!StringUtils.isEmpty(costCenter)){
					costCtrBldgWrkspc.add(costCenter);
				}else{
					costCtrBldgWrkspc.add("");
				}
				this.getExtractBldngWrkstNo(responseXML, costCtrBldgWrkspc);
				this.getExtractCityState(responseXML, costCtrBldgWrkspc);
				
				logger.info(costCtrBldgWrkspc.toArray());
			}
			
			/* Verify the response body */
			String errorDetails = null;
			if (messageUtilities.isFault(responseXML)) {
				// Get the error details
				errorDetails = messageUtilities.getFaultDetail(responseXML);
				// could be infrastructure connectivity is up but the service is not in working state
				logger.error("XMF Service [" + serviceName + "] response is faulty. " + errorDetails);
				throw new Exception("XMF Service [" + serviceName + "] response is faulty. " + errorDetails);
			}
			logger.info("Response XML : " + replyMessage);

		} catch (Exception e) {
			logger.error("Error occured while sending email notification . : " + e.getMessage());
		}
		return costCtrBldgWrkspc;
	}


	public String getRequest(String employeeId) {
		String content = "<request xmlns='http://services.www.uprr.com/person/find-cached-employee-summary/1.0'><filter-criteria><employee-id>" + employeeId + "</employee-id></filter-criteria><paging-criteria><page-size>4</page-size><page-number>1</page-number></paging-criteria><include-name>true</include-name><include-business-address>true</include-business-address><include-communication-information>true</include-communication-information><include-job-details>true</include-job-details></request>";
		return content;
	}

	public String getExtractCostCenterData(String xmfResponseBody, String status) {
		String searchStr = "<" + "cost-center" + ">";
		String result = "";
		int index = xmfResponseBody.indexOf(searchStr);
		if (index > -1) {
			result = xmfResponseBody.substring(index + searchStr.length());
			result = result.substring(0, result.indexOf("<"));
		}
		return result;
	}
	
	private List<String> getExtractBldngWrkstNo(String xmfResponseBody, List<String> costCtrBldgWrkspc) {
		String bldngStr = "<" + "building-code" + ">";
		String resultbldngStr = "";
		int index = xmfResponseBody.indexOf(bldngStr);
		if (index > -1) {
			resultbldngStr = xmfResponseBody.substring(index + bldngStr.length());
			resultbldngStr = resultbldngStr.substring(0, resultbldngStr.indexOf("<"));
		}
		String wrkSpaceStr = "<" + "work-space" + ">";
		String resultwrkSpaceStr = "";
		index = xmfResponseBody.indexOf(wrkSpaceStr);
		if (index > -1) {
			resultwrkSpaceStr = xmfResponseBody.substring(index + wrkSpaceStr.length());
			resultwrkSpaceStr = resultwrkSpaceStr.substring(0, resultwrkSpaceStr.indexOf("<"));
		}
		if(!StringUtils.isEmpty(resultbldngStr)){
			costCtrBldgWrkspc.add(resultbldngStr);
		}else{
			costCtrBldgWrkspc.add("");
		}
		if(!StringUtils.isEmpty(resultwrkSpaceStr)){
			costCtrBldgWrkspc.add(resultwrkSpaceStr);	
		}else{
			costCtrBldgWrkspc.add("");	
		}
		
		return costCtrBldgWrkspc;
	}
	
	private List<String> getExtractCityState(String xmfResponseBody, List<String> costCtrBldgWrkspc) {
		String cityStr = "<" + "city" + ">";
		String resultcityStr = "";
		int index = xmfResponseBody.indexOf(cityStr);
		if (index > -1) {
			resultcityStr = xmfResponseBody.substring(index + cityStr.length());
			resultcityStr = resultcityStr.substring(0, resultcityStr.indexOf("<"));
		}
		String stateStr = "<" + "state" + ">";
		String resultstateStr = "";
		index = xmfResponseBody.indexOf(stateStr);
		if (index > -1) {
			resultstateStr = xmfResponseBody.substring(index + stateStr.length());
			resultstateStr = resultstateStr.substring(0, resultstateStr.indexOf("<"));
		}
		if(!StringUtils.isEmpty(resultcityStr)){
			costCtrBldgWrkspc.add(resultcityStr);
		}else{
			costCtrBldgWrkspc.add("");
		}
		if(!StringUtils.isEmpty(resultstateStr)){
			costCtrBldgWrkspc.add(resultstateStr);	
		}else{
			costCtrBldgWrkspc.add("");	
		}
		
		return costCtrBldgWrkspc;
	}
}