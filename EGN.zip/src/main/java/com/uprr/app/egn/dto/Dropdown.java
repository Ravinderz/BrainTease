package com.uprr.app.egn.dto;

public class Dropdown {

	private String fieldName;
	private String fieldValue;
	
	
	
	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public String getFieldValue() {
		return fieldValue;
	}

	public void setFieldValue(String fieldValue) {
		this.fieldValue = fieldValue;
	}

	public Dropdown() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Dropdown(String fieldName, String fieldValue) {
		super();
		this.fieldName = fieldName;
		this.fieldValue = fieldValue;
	}

	@Override
	public String toString() {
		return "Dropdown [fieldName=" + fieldName + ", fieldValue=" + fieldValue + "]";
	}
	
	
	
	
	
	
}
