package com.uprr.app.egn.service;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.uprr.app.egn.dao.IEmployeeDAO;
import com.uprr.app.egn.dto.LoggedUserVO;
import com.uprr.app.egn.dto.WorkstationEvaluation;

@Service
public class EmplService implements IEmplService{

	@Autowired
	IEmployeeDAO empDao;
	
	public int getCountFromEmpl(String empId){
		return empDao.getEmployeeCount(empId);
	}
	
	@Transactional
	public boolean insertEmployeeRecord(WorkstationEvaluation wsEval){
		return empDao.insertEmployeeRecord(wsEval);
	}
	
	@Transactional
	public boolean insertEmployeeRecord(LoggedUserVO user){
		return empDao.insertEmployeeRecord(user);
	}
	
	@Transactional
	public boolean updateEmployeeRecord(WorkstationEvaluation eval){
		return empDao.updateEmployeeRecord(eval);
	}
	
	@Transactional
	public boolean updateEmployeeRecord(LoggedUserVO user){
		return empDao.updateEmployeeRecord(user);
	}

	@Override
	public LoggedUserVO getEmployeeFromView(String empId) {
		return empDao.getEmployeeFromView(empId);
	}
	public List<LoggedUserVO> getUserDetails(Set<String> UserIds){
		return empDao.getEmployeeFromTable(UserIds);
	}
}
