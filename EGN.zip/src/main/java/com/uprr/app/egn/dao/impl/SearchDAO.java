package com.uprr.app.egn.dao.impl;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.stereotype.Repository;

import com.uprr.app.egn.dao.ISearchDAO;
import com.uprr.app.egn.dao.mapper.WSEvaluationMapper;
import com.uprr.app.egn.dto.SearchCriteria;
import com.uprr.app.egn.dto.SearchRequest;
import com.uprr.app.egn.dto.WorkstationEvaluation;


@Repository
public class SearchDAO implements ISearchDAO {
	
	Logger logger = LogManager.getLogger(SearchDAO.class);

	@Autowired private JdbcTemplate jdbcTemplate; 
	
	@Override
	public List<WorkstationEvaluation> initialSearchWorkstationRequest(String role,String supvId) {
		logger.info("Inside searchWorkstationRequest method in searchDao"+supvId);
		StringBuilder query = new StringBuilder();

		if(role.equalsIgnoreCase("supervisor")){
			
			query.append("select w.req_id,e.empl_id,e.empl_name,e.empl_wkst_loca_city,e.empl_wkst_loca_bldg,e.empl_shft_hrs,e.rqng_supv_id,e.rqng_supv_name,e.rqng_supv_emal_addr,e.rqng_supv_ph_nbr,w.req_date,e.cost_cent_info,w.work_addr_oth_info,w.mdcl_req_flag,w.non_mdcl_req_flag,w.expd_rtrn_date,w.ffd_nrs_name,w.pcp_name,w.pcp_ph,w.evln_desc,w.req_stat_info,w.cad_wkst_flag,w.shpg_mail_room_stk_flag,w.dsph_cust_svc_flag,w.part_asby_flag,w.admn_clcl_flag,w.comp_kybd_mous_flag,w.chr_foot_rest_flag,w.sit_stnd_desk_flag,w.comp_mntr_flag,w.genl_wkst_eval_flag,w.wkst_evln_scpe_oth_info, w.genl_off_work , w.empl_work_act_info,w.crtd_user_id,w.last_updt_user_id,w.str_addr,w.city_info,w.zip_code ,wa.asmt_id from egn_empl e inner join egn_wkst_evln w on e.empl_id = w.empl_id left outer  join egn_wkst_asmt wa on w.req_id = wa.req_id where e.rqng_supv_id = ? and w.non_mdcl_req_flag = 1");
			
		}else{
			
			query.append("select w.req_id,e.empl_id,e.empl_name,e.empl_wkst_loca_city,e.empl_wkst_loca_bldg,e.empl_shft_hrs,e.rqng_supv_id,e.rqng_supv_name,e.rqng_supv_emal_addr,e.rqng_supv_ph_nbr,w.req_date,e.cost_cent_info,w.work_addr_oth_info,w.mdcl_req_flag,w.non_mdcl_req_flag,w.expd_rtrn_date,w.ffd_nrs_name,w.pcp_name,w.pcp_ph,w.evln_desc,w.req_stat_info,w.cad_wkst_flag,w.shpg_mail_room_stk_flag,w.dsph_cust_svc_flag,w.part_asby_flag,w.admn_clcl_flag,w.comp_kybd_mous_flag,w.chr_foot_rest_flag,w.sit_stnd_desk_flag,w.comp_mntr_flag,w.genl_wkst_eval_flag,w.wkst_evln_scpe_oth_info, w.genl_off_work , w.empl_work_act_info,w.crtd_user_id,w.last_updt_user_id,w.str_addr,w.city_info,w.zip_code ,wa.asmt_id from egn_empl e inner join egn_wkst_evln w on e.empl_id = w.empl_id left outer  join egn_wkst_asmt wa on w.req_id = wa.req_id");
			
		}

		query.append(" order by w.req_date desc");

		if(role.equalsIgnoreCase("supervisor")){
		return (List<WorkstationEvaluation>) jdbcTemplate.query(query.toString(),
				new PreparedStatementSetter() {
			public void setValues(PreparedStatement ps) throws SQLException {
				int i = 0;
				if(role.equalsIgnoreCase("supervisor")) {
					ps.setString(++i, supvId);
				}
			
			}
		}, new WSEvaluationMapper<WorkstationEvaluation>());
		}else{
			return  jdbcTemplate.query(query.toString(),new WSEvaluationMapper<WorkstationEvaluation>());
		}
	}
	
	@Override
	public List<WorkstationEvaluation> searchWorkstationRequest(SearchRequest request,String role) {
		logger.info("Inside searchWorkstationRequest method in searchDao"+request);
		StringBuilder query = new StringBuilder();

		if(role.equalsIgnoreCase("supervisor")){
			
			query.append("select w.req_id,e.empl_id,e.empl_name,e.empl_wkst_loca_city,e.empl_wkst_loca_bldg,e.empl_shft_hrs,e.rqng_supv_id,e.rqng_supv_name,e.rqng_supv_emal_addr,e.rqng_supv_ph_nbr,w.req_date,e.cost_cent_info,w.work_addr_oth_info,w.mdcl_req_flag,w.non_mdcl_req_flag,w.expd_rtrn_date,w.ffd_nrs_name,w.pcp_name,w.pcp_ph,w.evln_desc,w.req_stat_info,w.cad_wkst_flag,w.shpg_mail_room_stk_flag,w.dsph_cust_svc_flag,w.part_asby_flag,w.admn_clcl_flag,w.comp_kybd_mous_flag,w.chr_foot_rest_flag,w.sit_stnd_desk_flag,w.comp_mntr_flag,w.genl_wkst_eval_flag,w.wkst_evln_scpe_oth_info, w.genl_off_work , w.empl_work_act_info,w.crtd_user_id,w.last_updt_user_id,w.str_addr,w.city_info,w.zip_code ,wa.asmt_id from egn_empl e inner join egn_wkst_evln w on e.empl_id = w.empl_id left outer  join egn_wkst_asmt wa on w.req_id = wa.req_id where e.rqng_supv_id = ? and w.non_mdcl_req_flag = 1");
			
		}else{
			
			query.append("select w.req_id,e.empl_id,e.empl_name,e.empl_wkst_loca_city,e.empl_wkst_loca_bldg,e.empl_shft_hrs,e.rqng_supv_id,e.rqng_supv_name,e.rqng_supv_emal_addr,e.rqng_supv_ph_nbr,w.req_date,e.cost_cent_info,w.work_addr_oth_info,w.mdcl_req_flag,w.non_mdcl_req_flag,w.expd_rtrn_date,w.ffd_nrs_name,w.pcp_name,w.pcp_ph,w.evln_desc,w.req_stat_info,w.cad_wkst_flag,w.shpg_mail_room_stk_flag,w.dsph_cust_svc_flag,w.part_asby_flag,w.admn_clcl_flag,w.comp_kybd_mous_flag,w.chr_foot_rest_flag,w.sit_stnd_desk_flag,w.comp_mntr_flag,w.genl_wkst_eval_flag,w.wkst_evln_scpe_oth_info, w.genl_off_work , w.empl_work_act_info,w.crtd_user_id,w.last_updt_user_id,w.str_addr,w.city_info,w.zip_code ,wa.asmt_id from egn_empl e inner join egn_wkst_evln w on e.empl_id = w.empl_id left outer  join egn_wkst_asmt wa on w.req_id = wa.req_id");
			
		}

		this.prepareSqlForSearchWrkstationRqst(query,request,role);
		List<WorkstationEvaluation> workstationEvaluationLst = this.executeStmtForSearchWrkstationRqst(query, request, role);

		return workstationEvaluationLst;

	}
	
	private void prepareSqlForSearchWrkstationRqst(StringBuilder query,SearchRequest request,String role){
		query = buildQueryForEmpl("e.empl_id",query,request);
		query = buildQueryForStatus("w.req_stat_info",query,request);
		query = buildQueryForFromDate("w.req_date",query,request);
		query = buildQueryForToDate("to_date",query,request);
		query.append(" order by w.req_date desc");
	}
	
	private List<WorkstationEvaluation> executeStmtForSearchWrkstationRqst(StringBuilder query,SearchRequest request,String role){
		return (List<WorkstationEvaluation>) jdbcTemplate.query(query.toString(),
				new PreparedStatementSetter() {
			public void setValues(PreparedStatement ps) throws SQLException {
				int i = 0;
				if(role.equalsIgnoreCase("supervisor")){
					ps.setString(++i, role);
				}
				if((request.getEmployeeId() != null && request.getEmployeeId().length() > 0)) {
					ps.setString(++i, request.getEmployeeId());
				}
				if((request.getStatus() != null && request.getStatus().length() > 0)) {
					ps.setString(++i, request.getStatus());
				}
				if(request.getFromDate() != null && request.getFromDate().length() > 0){
					ps.setString(++i, request.getFromDate());
				}
				if(request.getToDate() != null && request.getToDate().length() > 0){
					ps.setString(++i, request.getToDate());
				}
			}
		}, new WSEvaluationMapper<WorkstationEvaluation>());
	}
	
	@Override
	public List<WorkstationEvaluation> getSearchWorkstationRequests(SearchRequest request,String role,SearchCriteria searchCriteria) {
		logger.info("Inside searchWorkstationRequest method in searchDao"+request);
		StringBuilder query = new StringBuilder();

		if(role.equalsIgnoreCase("supervisor")){
			
			query.append("select w.req_id,e.empl_id,e.empl_name,e.empl_wkst_loca_city,e.empl_wkst_loca_bldg,e.empl_shft_hrs,e.rqng_supv_id,e.rqng_supv_name,e.rqng_supv_emal_addr,e.rqng_supv_ph_nbr,w.req_date,e.cost_cent_info,w.work_addr_oth_info,w.mdcl_req_flag,w.non_mdcl_req_flag,w.expd_rtrn_date,w.ffd_nrs_name,w.pcp_name,w.pcp_ph,w.evln_desc,w.req_stat_info,w.cad_wkst_flag,w.shpg_mail_room_stk_flag,w.dsph_cust_svc_flag,w.part_asby_flag,w.admn_clcl_flag,w.comp_kybd_mous_flag,w.chr_foot_rest_flag,w.sit_stnd_desk_flag,w.comp_mntr_flag,w.genl_wkst_eval_flag,w.wkst_evln_scpe_oth_info, w.genl_off_work , w.empl_work_act_info,w.crtd_user_id,w.last_updt_user_id,w.str_addr,w.city_info,w.zip_code ,wa.asmt_id from egn_empl e inner join egn_wkst_evln w on e.empl_id = w.empl_id left outer  join egn_wkst_asmt wa on w.req_id = wa.req_id where ((e.rqng_supv_id = ? and w.non_mdcl_req_flag = 1) or e.empl_id= ? )");
			
		}else{
			
			query.append("select w.req_id,e.empl_id,e.empl_name,e.empl_wkst_loca_city,e.empl_wkst_loca_bldg,e.empl_shft_hrs,e.rqng_supv_id,e.rqng_supv_name,e.rqng_supv_emal_addr,e.rqng_supv_ph_nbr,w.req_date,e.cost_cent_info,w.work_addr_oth_info,w.mdcl_req_flag,w.non_mdcl_req_flag,w.expd_rtrn_date,w.ffd_nrs_name,w.pcp_name,w.pcp_ph,w.evln_desc,w.req_stat_info,w.cad_wkst_flag,w.shpg_mail_room_stk_flag,w.dsph_cust_svc_flag,w.part_asby_flag,w.admn_clcl_flag,w.comp_kybd_mous_flag,w.chr_foot_rest_flag,w.sit_stnd_desk_flag,w.comp_mntr_flag,w.genl_wkst_eval_flag,w.wkst_evln_scpe_oth_info, w.genl_off_work , w.empl_work_act_info,w.crtd_user_id,w.last_updt_user_id,w.str_addr,w.city_info,w.zip_code ,wa.asmt_id from egn_empl e inner join egn_wkst_evln w on e.empl_id = w.empl_id left outer  join egn_wkst_asmt wa on w.req_id = wa.req_id");
			
		}

		//query.append("select w.req_id,e.empl_id,e.empl_name,e.empl_wkst_loca_city,e.empl_wkst_loca_bldg,e.empl_shft_hrs,e.rqng_supv_id,e.rqng_supv_name,e.rqng_supv_emal_addr,e.rqng_supv_ph_nbr,w.req_date,e.cost_cent_info,w.work_addr_oth_info,w.mdcl_req_flag,w.non_mdcl_req_flag,w.expd_rtrn_date,w.ffd_nrs_name,w.pcp_name,w.pcp_ph,w.evln_desc,w.req_stat_info,w.cad_wkst_flag,w.shpg_mail_room_stk_flag,w.dsph_cust_svc_flag,w.part_asby_flag,w.admn_clcl_flag,w.comp_kybd_mous_flag,w.chr_foot_rest_flag,w.sit_stnd_desk_flag,w.comp_mntr_flag,w.genl_wkst_eval_flag,w.wkst_evln_scpe_oth_info, w.genl_off_work , w.empl_work_act_info,w.crtd_user_id,w.last_updt_user_id,w.str_addr,w.city_info,w.zip_code ,wa.asmt_id from egn_empl e inner join egn_wkst_evln w on e.empl_id = w.empl_id left outer  join egn_wkst_asmt wa on w.req_id = wa.req_id");
		
		this.appendCriteriaForSearchWorkstationRequestsInSql(query,request,role,searchCriteria);
		
		StringBuilder finalQuery = new StringBuilder();
		
		finalQuery.append("SELECT * FROM  (select searchrecords.* , ROWNUM rnum from  ( ");
		finalQuery.append(query.toString());
		finalQuery.append(" ) searchrecords where rownum <= ? ) where  rnum >= ? ");
		List<WorkstationEvaluation> workstationEvaluationLst = this.executeStmtSearchWorkstationRequests(finalQuery, request, role, searchCriteria);

		return workstationEvaluationLst;

	}
	
	private void appendCriteriaForSearchWorkstationRequestsInSql(StringBuilder query,SearchRequest request,String role,SearchCriteria searchCriteria){
		query = buildQueryForEmpl("e.empl_id",query,request);
		query = buildQueryForStatus("w.req_stat_info",query,request);
		query = buildQueryForFromDate("w.req_date",query,request);
		query = buildQueryForToDate("to_date",query,request);
		query.append(" order by w."+searchCriteria.getOrderByColumn()+" "+searchCriteria.getSortingType());
	}
	
	private List<WorkstationEvaluation> executeStmtSearchWorkstationRequests(StringBuilder finalQuery,SearchRequest request,String role,SearchCriteria searchCriteria){
		return (List<WorkstationEvaluation>) jdbcTemplate.query(finalQuery.toString(),
				new PreparedStatementSetter() {
			public void setValues(PreparedStatement ps) throws SQLException {
				int i = 0;
				if(role.equalsIgnoreCase("supervisor")){
					ps.setString(++i, searchCriteria.getSupvId());
					ps.setString(++i, searchCriteria.getSupvId());
				}
				if((request.getEmployeeId() != null && request.getEmployeeId().length() > 0)) {
					ps.setString(++i, request.getEmployeeId());
				}
				if((request.getStatus() != null && request.getStatus().length() > 0)) {
					ps.setString(++i, request.getStatus());
				}
				if(request.getFromDate() != null && request.getFromDate().length() > 0){
					ps.setString(++i, request.getFromDate());
				}
				if(request.getToDate() != null && request.getToDate().length() > 0){
					ps.setString(++i, request.getToDate());
				}
				ps.setInt(++i, searchCriteria.getRecordsPerPage());
				ps.setInt(++i, (searchCriteria.getStartIndex()));
			}
		}, new WSEvaluationMapper<WorkstationEvaluation>());
	}

	@Override
	public int getSearchCriteriaCount(SearchCriteria searchCriteria,SearchRequest request,String role) {
		StringBuilder query = new StringBuilder();
		logger.info(searchCriteria.getSupvId());
		if(role.equalsIgnoreCase("supervisor")){
			query.append("select COUNT(*) as count from (select w.req_id,e.empl_id,e.empl_name,e.empl_wkst_loca_city,e.empl_wkst_loca_bldg,e.empl_shft_hrs,e.rqng_supv_id,e.rqng_supv_name,e.rqng_supv_emal_addr,e.rqng_supv_ph_nbr,w.req_date,e.cost_cent_info,w.work_addr_oth_info,w.mdcl_req_flag,w.non_mdcl_req_flag,w.expd_rtrn_date,w.ffd_nrs_name,w.pcp_name,w.pcp_ph,w.evln_desc,w.req_stat_info,w.cad_wkst_flag,w.shpg_mail_room_stk_flag,w.dsph_cust_svc_flag,w.part_asby_flag,w.admn_clcl_flag,w.comp_kybd_mous_flag,w.chr_foot_rest_flag,w.sit_stnd_desk_flag,w.comp_mntr_flag,w.genl_wkst_eval_flag,w.wkst_evln_scpe_oth_info, w.genl_off_work , w.empl_work_act_info,w.crtd_user_id,w.last_updt_user_id,w.str_addr,w.city_info,w.zip_code ,wa.asmt_id from egn_empl e inner join egn_wkst_evln w on e.empl_id = w.empl_id left outer  join egn_wkst_asmt wa on w.req_id = wa.req_id where ((e.rqng_supv_id = '"+searchCriteria.getSupvId()+"' and w.non_mdcl_req_flag = 1) or e.empl_id='"+searchCriteria.getSupvId()+"' )");
		}else{
			query.append("select COUNT(*) as count from (select w.req_id,e.empl_id,e.empl_name,e.empl_wkst_loca_city,e.empl_wkst_loca_bldg,e.empl_shft_hrs,e.rqng_supv_id,e.rqng_supv_name,e.rqng_supv_emal_addr,e.rqng_supv_ph_nbr,w.req_date,e.cost_cent_info,w.work_addr_oth_info,w.mdcl_req_flag,w.non_mdcl_req_flag,w.expd_rtrn_date,w.ffd_nrs_name,w.pcp_name,w.pcp_ph,w.evln_desc,w.req_stat_info,w.cad_wkst_flag,w.shpg_mail_room_stk_flag,w.dsph_cust_svc_flag,w.part_asby_flag,w.admn_clcl_flag,w.comp_kybd_mous_flag,w.chr_foot_rest_flag,w.sit_stnd_desk_flag,w.comp_mntr_flag,w.genl_wkst_eval_flag,w.wkst_evln_scpe_oth_info, w.genl_off_work , w.empl_work_act_info,w.crtd_user_id,w.last_updt_user_id,w.str_addr,w.city_info,w.zip_code ,wa.asmt_id from egn_empl e inner join egn_wkst_evln w on e.empl_id = w.empl_id left outer  join egn_wkst_asmt wa on w.req_id = wa.req_id");
		}
		//query.append("select COUNT(*) as count from (select w.req_id,e.empl_id,e.empl_name,e.empl_wkst_loca_city,e.empl_wkst_loca_bldg,e.empl_shft_hrs,e.rqng_supv_id,e.rqng_supv_name,e.rqng_supv_emal_addr,e.rqng_supv_ph_nbr,w.req_date,e.cost_cent_info,w.work_addr_oth_info,w.mdcl_req_flag,w.non_mdcl_req_flag,w.expd_rtrn_date,w.ffd_nrs_name,w.pcp_name,w.pcp_ph,w.evln_desc,w.req_stat_info,w.cad_wkst_flag,w.shpg_mail_room_stk_flag,w.dsph_cust_svc_flag,w.part_asby_flag,w.admn_clcl_flag,w.comp_kybd_mous_flag,w.chr_foot_rest_flag,w.sit_stnd_desk_flag,w.comp_mntr_flag,w.genl_wkst_eval_flag,w.wkst_evln_scpe_oth_info, w.genl_off_work , w.empl_work_act_info,w.crtd_user_id,w.last_updt_user_id,w.str_addr,w.city_info,w.zip_code ,wa.asmt_id from egn_empl e inner join egn_wkst_evln w on e.empl_id = w.empl_id left outer  join egn_wkst_asmt wa on w.req_id = wa.req_id");
		
			query = buildCountQueryForEmpl("e.empl_id",query,request);
			query = buildCountQueryForStatus("w.req_stat_info",query,request);
			query = buildCountQueryForFromDate("w.req_date",query,request);
			query = buildCountQueryForToDate("to_date",query,request);
			query.append(")");
		
		return  jdbcTemplate.queryForObject(query.toString(),Integer.class);
		
	}
	

	@Override
	public int getWorkstationEvalSearchTotalCount(SearchCriteria searchCriteria) {
		
		StringBuilder query = new StringBuilder();
		int count = 0;
		query.append("select COUNT(*) as count from (select w.req_id,e.empl_id,e.empl_name,e.empl_wkst_loca_city,e.empl_wkst_loca_bldg,e.empl_shft_hrs,e.rqng_supv_id,e.rqng_supv_name,e.rqng_supv_emal_addr,e.rqng_supv_ph_nbr,w.req_date,e.cost_cent_info,w.work_addr_oth_info,w.mdcl_req_flag,w.non_mdcl_req_flag,w.expd_rtrn_date,w.ffd_nrs_name,w.pcp_name,w.pcp_ph,w.evln_desc,w.req_stat_info,w.cad_wkst_flag,w.shpg_mail_room_stk_flag,w.dsph_cust_svc_flag,w.part_asby_flag,w.admn_clcl_flag,w.comp_kybd_mous_flag,w.chr_foot_rest_flag,w.sit_stnd_desk_flag,w.comp_mntr_flag,w.genl_wkst_eval_flag,w.wkst_evln_scpe_oth_info, w.genl_off_work , w.empl_work_act_info,w.crtd_user_id,w.last_updt_user_id,w.str_addr,w.city_info,w.zip_code ,wa.asmt_id from egn_empl e inner join egn_wkst_evln w on e.empl_id = w.empl_id left outer  join egn_wkst_asmt wa on w.req_id = wa.req_id)");
		count = jdbcTemplate.queryForObject(query.toString(),Integer.class);
		
		return count;
	}

	public StringBuilder buildCountQueryForEmpl(String argument,StringBuilder query,SearchRequest request){

		if(request.getEmployeeId() != null && request.getEmployeeId().length() > 0){
			if(query.toString().contains("where")){
				query.append(" and "+argument+" ='"+request.getEmployeeId()+"'");
			}else{
				query.append(" where "+argument+" = '"+request.getEmployeeId()+"'");
			}
		}

		return query;
	}

	public StringBuilder buildCountQueryForStatus(String argument,StringBuilder query,SearchRequest request){

		if(request.getStatus() != null && request.getStatus().length() > 0){
			if(query.toString().contains("where")){
				query.append(" and "+argument+" = '"+request.getStatus()+"'");
			}else{
				query.append(" where "+argument+" = '"+request.getStatus()+"'");
			}
		}

		return query;
	}

	public StringBuilder buildCountQueryForFromDate(String argument,StringBuilder query,SearchRequest request){

		if(request.getFromDate() != null && request.getFromDate().length() > 0){
			if(query.toString().contains("where")){
				query.append(" and "+argument+" between TO_DATE('"+request.getFromDate()+"','YYYY-MM-DD') ");
			}else{
				query.append(" where "+argument+" between TO_DATE('"+request.getFromDate()+"','YYYY-MM-DD') ");
			}
		}

		return query;
	}



	public StringBuilder buildCountQueryForToDate(String argument,StringBuilder query,SearchRequest request){

		if(request.getToDate() != null && request.getToDate().length() > 0){
			if(query.toString().contains("where")){
				query.append(" and TO_DATE('"+request.getToDate()+"','YYYY-MM-DD') ");
			}else{
				query.append(" where TO_DATE('"+request.getToDate()+"','YYYY-MM-DD') ");
			}
		}

		return query;
	}

	public StringBuilder buildQueryForEmpl(String argument,StringBuilder query,SearchRequest request){

		if(request.getEmployeeId() != null && request.getEmployeeId().length() > 0){
			if(query.toString().contains("where")){
				query.append(" and "+argument+" = ?");
			}else{
				query.append(" where "+argument+" = ?");
			}
		}
		return query;
	}

	public StringBuilder buildQueryForStatus(String argument,StringBuilder query,SearchRequest request){

		if(request.getStatus() != null && request.getStatus().length() > 0){
			if(query.toString().contains("where")){
				query.append(" and "+argument+" = ?");
			}else{
				query.append(" where "+argument+" = ?");
			}
		}

		return query;
	}

	public StringBuilder buildQueryForFromDate(String argument,StringBuilder query,SearchRequest request){

		if(request.getFromDate() != null && request.getFromDate().length() > 0){
			if(query.toString().contains("where")){
				query.append(" and "+argument+" between TO_DATE(?,'YYYY-MM-DD') ");
			}else{
				query.append(" where "+argument+" between TO_DATE(?,'YYYY-MM-DD') ");
			}
		}

		return query;
	}



	public StringBuilder buildQueryForToDate(String argument,StringBuilder query,SearchRequest request){

		if(request.getToDate() != null && request.getToDate().length() > 0){
			if(query.toString().contains("where")){
				query.append(" and TO_DATE(?,'YYYY-MM-DD') ");
			}else{
				query.append(" where TO_DATE(?,'YYYY-MM-DD') ");
			}
		}

		return query;
	}

	
}
