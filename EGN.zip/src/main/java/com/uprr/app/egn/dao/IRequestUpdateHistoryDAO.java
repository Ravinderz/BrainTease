package com.uprr.app.egn.dao;

import java.util.List;

import com.uprr.app.egn.dto.ActionItem;
import com.uprr.app.egn.dto.RequestHistory;

public interface IRequestUpdateHistoryDAO {

	public boolean insertRequestUpdateHistory(String oldStatus, String newStatus, String rejectReason, String empId, String reqId, String asmtId, String itemId);
	
	public boolean bulkInsertRequestStatusHistory(List<ActionItem> actionItems,int reqId,int asmtId);
	 
	public List<RequestHistory> getEvalRequestHistoryByRequestId(String reqId);
	 
	public List<RequestHistory> getItemHistoryByItemId(String itemId);

	public List<RequestHistory> getItmLtstUpdtdStatusHistryByItmId(ActionItem item);
}
