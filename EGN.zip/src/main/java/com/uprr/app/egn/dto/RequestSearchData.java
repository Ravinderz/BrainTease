package com.uprr.app.egn.dto;

import java.util.ArrayList;
import java.util.List;

public class RequestSearchData {
	
	private String  sortingType= "desc";
	private String orderByColumn;						  
	private int 	currentPage= 1;
	private int  totalPages= 1;
	private int  recordsCount= 0;
	private int  recordsPerPage=10;
	private int  startIndex= 1;
	private int  endIndex= 10;
	
	private List<WorkstationEvaluation> evalSearchData=new ArrayList<WorkstationEvaluation>();
 	
	public String getOrderByColumn() {
		return orderByColumn;
	}

	public void setOrderByColumn(String orderByColumn) {
		this.orderByColumn = orderByColumn;
	}

	public String getSortingType() {
		return sortingType;
	}

	public void setSortingType(String sortingType) {
		this.sortingType = sortingType;
	}

	public int getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}

	public int getTotalPages() {
		return totalPages;
	}

	public void setTotalPages(int totalPages) {
		this.totalPages = totalPages;
	}

	public int getRecordsCount() {
		return recordsCount;
	}

	public void setRecordsCount(int recordsCount) {
		this.recordsCount = recordsCount;
	}

	public int getRecordsPerPage() {
		return recordsPerPage;
	}

	public void setRecordsPerPage(int recordsPerPage) {
		this.recordsPerPage = recordsPerPage;
	}

	public int getStartIndex() {
		return startIndex;
	}

	public void setStartIndex(int startIndex) {
		this.startIndex = startIndex;
	}

	public int getEndIndex() {
		return endIndex;
	}

	public void setEndIndex(int endIndex) {
		this.endIndex = endIndex;
	}

	public List<WorkstationEvaluation> getEvalSearchData() {
		return evalSearchData;
	}

	public void setEvalSearchData(List<WorkstationEvaluation> evalSearchData) {
		this.evalSearchData = evalSearchData;
	}

	public RequestSearchData() {
		super();
		// TODO Auto-generated constructor stub
	}

	public RequestSearchData(String sortingType, int currentPage, int totalPages, int recordsCount, int recordsPerPage,
			int startIndex, int endIndex, List<WorkstationEvaluation> evalSearchData) {
		super();
		this.sortingType = sortingType;
		this.currentPage = currentPage;
		this.totalPages = totalPages;
		this.recordsCount = recordsCount;
		this.recordsPerPage = recordsPerPage;
		this.startIndex = startIndex;
		this.endIndex = endIndex;
		this.evalSearchData = evalSearchData;
	}

	@Override
	public String toString() {
		return "RequestSearchData [sortingType=" + sortingType + ", orderByColumn=" + orderByColumn + ", currentPage="
				+ currentPage + ", totalPages=" + totalPages + ", recordsCount=" + recordsCount + ", recordsPerPage="
				+ recordsPerPage + ", startIndex=" + startIndex + ", endIndex=" + endIndex + ", evalSearchData="
				+ evalSearchData + "]";
	}

	
}
