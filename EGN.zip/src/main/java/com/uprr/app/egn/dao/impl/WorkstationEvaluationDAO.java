package com.uprr.app.egn.dao.impl;

import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.stereotype.Repository;

import com.uprr.app.egn.dao.IWorkstationEvaluationDAO;
import com.uprr.app.egn.dao.mapper.DocumentMapper;
import com.uprr.app.egn.dao.mapper.WSEvaluationMapper;
import com.uprr.app.egn.dto.Document;
import com.uprr.app.egn.dto.SearchCriteria;
import com.uprr.app.egn.dto.UpdateStatus;
import com.uprr.app.egn.dto.WorkstationEvaluation;
import com.uprr.app.egn.util.Util;

@Repository
public class WorkstationEvaluationDAO implements IWorkstationEvaluationDAO { 
	
	Logger logger = LogManager.getLogger(WorkstationEvaluationDAO.class);
	
	//Insert queries
		//Query to save a workstation evalution request
		String SAVE_INSERT_WORKSTATION_REQUEST = "insert into egn_wkst_evln(req_id,empl_id,req_date,work_addr_oth_info,mdcl_req_flag,non_mdcl_req_flag,expd_rtrn_date,ffd_nrs_name,pcp_name,pcp_ph,evln_desc,req_stat_info,cad_wkst_flag,shpg_mail_room_stk_flag,dsph_cust_svc_flag,part_asby_flag,admn_clcl_flag,comp_kybd_mous_flag,chr_foot_rest_flag,sit_stnd_desk_flag,comp_mntr_flag,genl_wkst_eval_flag,crtd_user_id,crtn_tmst,last_updt_user_id,last_updt_tmst,wkst_evln_scpe_oth_info,genl_off_work,empl_work_act_info,str_addr,city_info,zip_code) values (egn_wkst_evln_q1.nextval,?,TO_DATE(?,'yyyy-MM-dd'),?,?,?,TO_DATE(?,'yyyy-MM-dd'),?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,sysdate,?,sysdate,?,?,?,?,?,? )";
		
		//Query to insert a workstation evaluation request
		String INSERT_WORKSTATION_REQUEST = "insert into egn_wkst_evln(req_id,empl_id,req_date,work_addr_oth_info,mdcl_req_flag,non_mdcl_req_flag,expd_rtrn_date,ffd_nrs_name,pcp_name,pcp_ph,evln_desc,req_stat_info,cad_wkst_flag,shpg_mail_room_stk_flag,dsph_cust_svc_flag,part_asby_flag,admn_clcl_flag,comp_kybd_mous_flag,chr_foot_rest_flag,sit_stnd_desk_flag,comp_mntr_flag,genl_wkst_eval_flag,crtd_user_id,crtn_tmst,last_updt_user_id,last_updt_tmst,wkst_evln_scpe_oth_info,genl_off_work,empl_work_act_info,str_addr,city_info,zip_code) values (egn_wkst_evln_q1.nextval,?,TO_DATE(?,'yyyy-MM-dd'),?,?,?,TO_DATE(?,'yyyy-MM-dd'),?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,sysdate,?,sysdate,?,?,?,?,?,? )";
		//Update queries
		//query to update status of a request 
		String UPDATE_STATUS = "update egn_wkst_evln set req_stat_info = ?,last_updt_user_id=?,last_updt_tmst = sysdate where req_id = ?";
		
		//query to change the status of a medical request when ADA nurse rejects it.
		String UPDATE_STATUS_FOR_MEDICAL_REQUESTS = "update egn_wkst_evln set req_stat_info = ?,non_mdcl_req_flag=1,mdcl_req_flag=0,last_updt_user_id=?,last_updt_tmst = sysdate where req_id = ?";
		
		//query to update workstation request.
		String UPDATE_WORKSTATION_REQUEST = "update egn_wkst_evln set req_date = TO_DATE(?,'yyyy-MM-dd'),work_addr_oth_info = ?,mdcl_req_flag = ?,non_mdcl_req_flag = ?, expd_rtrn_date =TO_DATE(?,'yyyy-MM-dd'),ffd_nrs_name=?,pcp_name=?,pcp_ph=?,evln_desc=?,req_stat_info=?,cad_wkst_flag=?,shpg_mail_room_stk_flag=?,dsph_cust_svc_flag=?,part_asby_flag=?,admn_clcl_flag=?,comp_kybd_mous_flag=?,chr_foot_rest_flag=?,sit_stnd_desk_flag=?,comp_mntr_flag=?,genl_wkst_eval_flag=?,last_updt_user_id=?,last_updt_tmst = sysdate , wkst_evln_scpe_oth_info= ? , genl_off_work= ? , empl_work_act_info= ?, str_addr =?, city_info = ?, zip_code = ? where req_id = ?";
		  
		//get queries
		//get all requests for a particular supervisor
		String GET_ALL_EVALUATION_REQUESTS_FOR_SUPVID = "select w.req_id,e.empl_id,e.empl_name,e.empl_wkst_loca_city,e.empl_wkst_loca_bldg,e.empl_shft_hrs,e.rqng_supv_id,e.rqng_supv_name,e.rqng_supv_emal_addr,e.rqng_supv_ph_nbr,w.req_date,e.cost_cent_info,w.work_addr_oth_info,w.mdcl_req_flag,w.non_mdcl_req_flag,w.expd_rtrn_date,w.ffd_nrs_name,w.pcp_name,w.pcp_ph,w.evln_desc,w.req_stat_info,w.cad_wkst_flag,w.shpg_mail_room_stk_flag,w.dsph_cust_svc_flag,w.part_asby_flag,w.admn_clcl_flag,w.comp_kybd_mous_flag,w.chr_foot_rest_flag,w.sit_stnd_desk_flag,w.comp_mntr_flag,w.genl_wkst_eval_flag,w.wkst_evln_scpe_oth_info, w.genl_off_work , w.empl_work_act_info,w.crtd_user_id,w.last_updt_user_id,w.str_addr,w.city_info,w.zip_code,wa.asmt_id from egn_empl e inner join egn_wkst_evln w on e.empl_id = w.empl_id left outer join egn_wkst_asmt wa on w.req_id = wa.req_id where e.rqng_supv_id = ? and w.non_mdcl_req_flag = 1 and w.req_stat_info IN ('Submitted','Medical Rejected') order by w.req_date desc";
		
		//get all requests for ergonomics specialist
		String GET_REQUESTS_FOR_SPECIALIST = "select w.req_id,e.empl_id,e.empl_name,e.empl_wkst_loca_city,e.empl_wkst_loca_bldg,e.empl_shft_hrs,e.rqng_supv_id,e.rqng_supv_name,e.rqng_supv_emal_addr,e.rqng_supv_ph_nbr,w.req_date,e.cost_cent_info,w.work_addr_oth_info,w.mdcl_req_flag,w.non_mdcl_req_flag,w.expd_rtrn_date,w.ffd_nrs_name,w.pcp_name,w.pcp_ph,w.evln_desc,w.req_stat_info,w.cad_wkst_flag,w.shpg_mail_room_stk_flag,w.dsph_cust_svc_flag,w.part_asby_flag,w.admn_clcl_flag,w.comp_kybd_mous_flag,w.chr_foot_rest_flag,w.sit_stnd_desk_flag,w.comp_mntr_flag,w.genl_wkst_eval_flag,w.wkst_evln_scpe_oth_info, w.genl_off_work , w.empl_work_act_info ,w.crtd_user_id,w.last_updt_user_id,w.str_addr,w.city_info,w.zip_code,wa.asmt_id from egn_empl e inner join egn_wkst_evln w on e.empl_id = w.empl_id left outer join egn_wkst_asmt wa on w.req_id = wa.req_id where w.req_stat_info IN ('Supervisor Approved','Medical Approved','Assessment Pending','Assessment Provided','Assessment Reopened','Assessment Complete')";
		
		//get all medical rejected request for a supervisor
		String GET_ALL_MEDICAL_REJECTED_REQUESTS_FOR_SUPVID = "select w.req_id,e.empl_id,e.empl_name,e.empl_wkst_loca_city,e.empl_wkst_loca_bldg,e.empl_shft_hrs,e.rqng_supv_id,e.rqng_supv_name,e.rqng_supv_emal_addr,e.rqng_supv_ph_nbr,w.req_date,e.cost_cent_info,w.work_addr_oth_info,w.mdcl_req_flag,w.non_mdcl_req_flag,w.expd_rtrn_date,w.ffd_nrs_name,w.pcp_name,w.pcp_ph,w.evln_desc,w.req_stat_info,w.cad_wkst_flag,w.shpg_mail_room_stk_flag,w.dsph_cust_svc_flag,w.part_asby_flag,w.admn_clcl_flag,w.comp_kybd_mous_flag,w.chr_foot_rest_flag,w.sit_stnd_desk_flag,w.comp_mntr_flag,w.genl_wkst_eval_flag,w.wkst_evln_scpe_oth_info, w.genl_off_work , w.empl_work_act_info,w.crtd_user_id,w.last_updt_user_id,w.str_addr,w.city_info,w.zip_code ,wa.asmt_id from egn_empl e inner join egn_wkst_evln w on e.empl_id = w.empl_id left outer join egn_wkst_asmt wa on w.req_id = wa.req_id where e.rqng_supv_id = ? and w.mdcl_req_flag = 1 and w.req_stat_info = 'Medical Rejected' order by w.req_date desc";
		
		//get search results for a supervisor
		String SEARCH_EVALUATION_REQUESTS_FOR_SUPVID = "select w.req_id,e.empl_id,e.empl_name,e.empl_wkst_loca_city,e.empl_wkst_loca_bldg,e.empl_shft_hrs,e.rqng_supv_id,e.rqng_supv_name,e.rqng_supv_emal_addr,e.rqng_supv_ph_nbr,w.req_date,e.cost_cent_info,w.work_addr_oth_info,w.mdcl_req_flag,w.non_mdcl_req_flag,w.expd_rtrn_date,w.ffd_nrs_name,w.pcp_name,w.pcp_ph,w.evln_desc,w.req_stat_info,w.cad_wkst_flag,w.shpg_mail_room_stk_flag,w.dsph_cust_svc_flag,w.part_asby_flag,w.admn_clcl_flag,w.comp_kybd_mous_flag,w.chr_foot_rest_flag,w.sit_stnd_desk_flag,w.comp_mntr_flag,w.genl_wkst_eval_flag,w.wkst_evln_scpe_oth_info, w.genl_off_work , w.empl_work_act_info,w.crtd_user_id,w.last_updt_user_id,w.str_addr,w.city_info,w.zip_code ,wa.asmt_id from egn_empl e inner join egn_wkst_evln w on e.empl_id = w.empl_id left outer join egn_wkst_asmt wa on w.req_id = wa.req_id where e.rqng_supv_id = ? and w.non_mdcl_req_flag = 1";
		
		//get all requests
		String GET_ALL_EVALUATION_REQUESTS = "select w.req_id,e.empl_id,e.empl_name,e.empl_wkst_loca_city,e.empl_wkst_loca_bldg,e.empl_shft_hrs,e.rqng_supv_id,e.rqng_supv_name,e.rqng_supv_emal_addr,e.rqng_supv_ph_nbr,w.req_date,e.cost_cent_info,w.work_addr_oth_info,w.mdcl_req_flag,w.non_mdcl_req_flag,w.expd_rtrn_date,w.ffd_nrs_name,w.pcp_name,w.pcp_ph,w.evln_desc,w.req_stat_info,w.cad_wkst_flag,w.shpg_mail_room_stk_flag,w.dsph_cust_svc_flag,w.part_asby_flag,w.admn_clcl_flag,w.comp_kybd_mous_flag,w.chr_foot_rest_flag,w.sit_stnd_desk_flag,w.comp_mntr_flag,w.genl_wkst_eval_flag,w.wkst_evln_scpe_oth_info, w.genl_off_work , w.empl_work_act_info,w.crtd_user_id,w.last_updt_user_id,w.str_addr,w.city_info,w.zip_code ,wa.asmt_id from egn_empl e inner join egn_wkst_evln w on e.empl_id = w.empl_id left outer join egn_wkst_asmt wa on w.req_id = wa.req_id";
		
		//get all requests for a particular user
		String GET_ALL_USER_REQUESTS = "select w.req_id,e.empl_id,e.empl_name,e.empl_wkst_loca_city,e.empl_wkst_loca_bldg,e.empl_shft_hrs,e.rqng_supv_id,e.rqng_supv_name,e.rqng_supv_emal_addr,e.rqng_supv_ph_nbr,w.req_date,e.cost_cent_info,w.work_addr_oth_info,w.mdcl_req_flag,w.non_mdcl_req_flag,w.expd_rtrn_date,w.ffd_nrs_name,w.pcp_name,w.pcp_ph,w.evln_desc,w.req_stat_info,w.cad_wkst_flag,w.shpg_mail_room_stk_flag,w.dsph_cust_svc_flag,w.part_asby_flag,w.admn_clcl_flag,w.comp_kybd_mous_flag,w.chr_foot_rest_flag,w.sit_stnd_desk_flag,w.comp_mntr_flag,w.genl_wkst_eval_flag,w.wkst_evln_scpe_oth_info, w.genl_off_work , w.empl_work_act_info,w.crtd_user_id,w.last_updt_user_id,w.str_addr,w.city_info,w.zip_code ,wa.asmt_id from egn_empl e inner join egn_wkst_evln w on e.empl_id = w.empl_id left outer join egn_wkst_asmt wa on w.req_id = wa.req_id where w.empl_id = ? OR e.rqng_supv_id = ?" ;
		
		//get a request by ID
		String GET_REQUEST_BY_ID = "select w.req_id,e.empl_id,e.empl_name,e.empl_wkst_loca_city,e.empl_wkst_loca_bldg,e.empl_shft_hrs,e.rqng_supv_id,e.rqng_supv_name,e.rqng_supv_emal_addr,e.rqng_supv_ph_nbr,w.req_date,e.cost_cent_info,w.work_addr_oth_info,w.mdcl_req_flag,w.non_mdcl_req_flag,w.expd_rtrn_date,w.ffd_nrs_name,w.pcp_name,w.pcp_ph,w.evln_desc,w.req_stat_info,w.cad_wkst_flag,w.shpg_mail_room_stk_flag,w.dsph_cust_svc_flag,w.part_asby_flag,w.admn_clcl_flag,w.comp_kybd_mous_flag,w.chr_foot_rest_flag,w.sit_stnd_desk_flag,w.comp_mntr_flag,w.genl_wkst_eval_flag,w.wkst_evln_scpe_oth_info, w.genl_off_work , w.empl_work_act_info,w.crtd_user_id,w.last_updt_user_id,w.str_addr,w.city_info,w.zip_code ,wa.asmt_id from egn_empl e inner join egn_wkst_evln w on e.empl_id = w.empl_id left outer join egn_wkst_asmt wa on w.req_id = wa.req_id  where w.req_id = ? order by w.req_date desc";
		
		//get a request by ID
		String GET_REQUEST_BY_USER = "select w.req_id,e.empl_id,e.empl_name,e.empl_wkst_loca_city,e.empl_wkst_loca_bldg,e.empl_shft_hrs,e.rqng_supv_id,e.rqng_supv_name,e.rqng_supv_emal_addr,e.rqng_supv_ph_nbr,w.req_date,e.cost_cent_info,w.work_addr_oth_info,w.mdcl_req_flag,w.non_mdcl_req_flag,w.expd_rtrn_date,w.ffd_nrs_name,w.pcp_name,w.pcp_ph,w.evln_desc,w.req_stat_info,w.cad_wkst_flag,w.shpg_mail_room_stk_flag,w.dsph_cust_svc_flag,w.part_asby_flag,w.admn_clcl_flag,w.comp_kybd_mous_flag,w.chr_foot_rest_flag,w.sit_stnd_desk_flag,w.comp_mntr_flag,w.genl_wkst_eval_flag, w.wkst_evln_scpe_oth_info, w.genl_off_work , w.empl_work_act_info,w.crtd_user_id,w.last_updt_user_id,w.str_addr,w.city_info,w.zip_code, wa.asmt_id from egn_empl e inner join egn_wkst_evln w on e.empl_id = w.empl_id left outer join egn_wkst_asmt wa on w.req_id = wa.req_id  where w.empl_id = ? and w.req_stat_info NOT IN ('Assessment Complete','Medical Rejected','Supervisor Rejected') order by w.req_date desc";
				
		//get all documents for a particular request
		String GET_ALL_DOCUMENTS_BY_REQUEST_ID = "select doc_guid,doc_name,doc_desc,crtd_user_id,crtn_tmst,last_uptd_user_id,last_uptd_tmst,req_id from egn_updt_docs where req_id = ?";
		
		//get all non medical request for a particular supervisor
		String GET_NON_MEDICAL_REQUESTS_BY_SUPERVISOR = "select w.req_id,e.empl_id,e.empl_name,e.empl_wkst_loca_city,e.empl_wkst_loca_bldg,e.empl_shft_hrs,e.rqng_supv_id,e.rqng_supv_name,e.rqng_supv_emal_addr,e.rqng_supv_ph_nbr,w.req_date,e.cost_cent_info,w.work_addr_oth_info,w.mdcl_req_flag,w.non_mdcl_req_flag,w.expd_rtrn_date,w.ffd_nrs_name,w.pcp_name,w.pcp_ph,w.evln_desc,w.req_stat_info,w.cad_wkst_flag,w.shpg_mail_room_stk_flag,w.dsph_cust_svc_flag,w.part_asby_flag,w.admn_clcl_flag,w.comp_kybd_mous_flag,w.chr_foot_rest_flag,w.sit_stnd_desk_flag,w.comp_mntr_flag,w.genl_wkst_eval_flag,w.wkst_evln_scpe_oth_info, w.genl_off_work , w.empl_work_act_info,w.crtd_user_id,w.last_updt_user_id,w.str_addr,w.city_info,w.zip_code ,wa.asmt_id from egn_empl e inner join egn_wkst_evln w on e.empl_id = w.empl_id left outer join egn_wkst_asmt wa on w.req_id = wa.req_id where e.rqng_supv_id = ? and w.non_mdcl_req_flag = 1 order by w.req_date desc";
		
		//get all medical request
		String GET_ALL_MEDICAL_REQUESTS = "select w.req_id,e.empl_id,e.empl_name,e.empl_wkst_loca_city,e.empl_wkst_loca_bldg,e.empl_shft_hrs,e.rqng_supv_id,e.rqng_supv_name,e.rqng_supv_emal_addr,e.rqng_supv_ph_nbr,w.req_date,e.cost_cent_info,w.work_addr_oth_info,w.mdcl_req_flag,w.non_mdcl_req_flag,w.expd_rtrn_date,w.ffd_nrs_name,w.pcp_name,w.pcp_ph,w.evln_desc,w.req_stat_info,w.cad_wkst_flag,w.shpg_mail_room_stk_flag,w.dsph_cust_svc_flag,w.part_asby_flag,w.admn_clcl_flag,w.comp_kybd_mous_flag,w.chr_foot_rest_flag,w.sit_stnd_desk_flag,w.comp_mntr_flag,w.genl_wkst_eval_flag,w.wkst_evln_scpe_oth_info, w.genl_off_work , w.empl_work_act_info,w.crtd_user_id,w.last_updt_user_id,w.str_addr,w.city_info,w.zip_code ,wa.asmt_id from egn_empl e inner join egn_wkst_evln w on e.empl_id = w.empl_id left outer join egn_wkst_asmt wa on w.req_id = wa.req_id where w.mdcl_req_flag = 1 and w.req_stat_info = 'Submitted'  order by w.req_date desc";
		
		String GET_REQUESTS_FOR_FACLTYMGMT_LOCAL = "select w.req_id,e.empl_id,e.empl_name,e.empl_wkst_loca_city,e.empl_wkst_loca_bldg,e.empl_shft_hrs,e.rqng_supv_id,e.rqng_supv_name,e.rqng_supv_emal_addr,e.rqng_supv_ph_nbr,w.req_date,e.cost_cent_info,w.work_addr_oth_info,w.mdcl_req_flag,w.non_mdcl_req_flag,w.expd_rtrn_date,w.ffd_nrs_name,w.pcp_name,w.pcp_ph,w.evln_desc,w.req_stat_info,w.cad_wkst_flag,w.shpg_mail_room_stk_flag,w.dsph_cust_svc_flag,w.part_asby_flag,w.admn_clcl_flag,w.comp_kybd_mous_flag,w.chr_foot_rest_flag,w.sit_stnd_desk_flag,w.comp_mntr_flag,w.genl_wkst_eval_flag,w.wkst_evln_scpe_oth_info, w.genl_off_work , w.empl_work_act_info,w.crtd_user_id,w.last_updt_user_id,w.str_addr,w.city_info,w.zip_code ,wa.asmt_id from egn_empl e inner join egn_wkst_evln w on e.empl_id = w.empl_id left outer join egn_wkst_asmt wa on w.req_id = wa.req_id where wa.asmt_id in  (select distinct(woi.asmt_id) from EGN_ASMT_WORK_ORD_INFO woi where asgn_to_id = '9999994' and work_ord_Stat_info NOT IN ('Complete','Cancelled','Rejected'))";
		
		String GET_REQUESTS_FOR_FACLTYMGMT = "select w.req_id,e.empl_id,e.empl_name,e.empl_wkst_loca_city,e.empl_wkst_loca_bldg,e.empl_shft_hrs,e.rqng_supv_id,e.rqng_supv_name,e.rqng_supv_emal_addr,e.rqng_supv_ph_nbr,w.req_date,e.cost_cent_info,w.work_addr_oth_info,w.mdcl_req_flag,w.non_mdcl_req_flag,w.expd_rtrn_date,w.ffd_nrs_name,w.pcp_name,w.pcp_ph,w.evln_desc,w.req_stat_info,w.cad_wkst_flag,w.shpg_mail_room_stk_flag,w.dsph_cust_svc_flag,w.part_asby_flag,w.admn_clcl_flag,w.comp_kybd_mous_flag,w.chr_foot_rest_flag,w.sit_stnd_desk_flag,w.comp_mntr_flag,w.genl_wkst_eval_flag,w.wkst_evln_scpe_oth_info, w.genl_off_work , w.empl_work_act_info,w.crtd_user_id,w.last_updt_user_id,w.str_addr,w.city_info,w.zip_code ,wa.asmt_id from egn_empl e inner join egn_wkst_evln w on e.empl_id = w.empl_id left outer join egn_wkst_asmt wa on w.req_id = wa.req_id where wa.asmt_id in  (select distinct(woi.asmt_id) from EGN_ASMT_WORK_ORD_INFO woi where asgn_to_id = '9999997' and work_ord_Stat_info NOT IN ('Complete','Cancelled','Rejected'))";
		
		String GET_REQUESTS_FOR_FACLTYMGMT_BYCRITERIA_LOCAL = "select w.req_id,e.empl_id,e.empl_name,e.empl_wkst_loca_city,e.empl_wkst_loca_bldg,e.empl_shft_hrs,e.rqng_supv_id,e.rqng_supv_name,e.rqng_supv_emal_addr,e.rqng_supv_ph_nbr,w.req_date,e.cost_cent_info,w.work_addr_oth_info,w.mdcl_req_flag,w.non_mdcl_req_flag,w.expd_rtrn_date,w.ffd_nrs_name,w.pcp_name,w.pcp_ph,w.evln_desc,w.req_stat_info,w.cad_wkst_flag,w.shpg_mail_room_stk_flag,w.dsph_cust_svc_flag,w.part_asby_flag,w.admn_clcl_flag,w.comp_kybd_mous_flag,w.chr_foot_rest_flag,w.sit_stnd_desk_flag,w.comp_mntr_flag,w.genl_wkst_eval_flag,w.wkst_evln_scpe_oth_info,w.genl_off_work, , w.empl_work_act_info,w.crtd_user_id,w.last_updt_user_id,w.str_addr,w.city_info,w.zip_code , wa.asmt_id from egn_empl e inner join egn_wkst_evln w on e.empl_id = w.empl_id left outer join egn_wkst_asmt wa on w.req_id = wa.req_id where wa.asmt_id in  (select distinct(woi.asmt_id) from EGN_ASMT_WORK_ORD_INFO woi where asgn_to_id = '9999994') ";
		
		String GET_REQUESTS_FOR_FACLTYMGMT_BYCRITERIA = "select w.req_id,e.empl_id,e.empl_name,e.empl_wkst_loca_city,e.empl_wkst_loca_bldg,e.empl_shft_hrs,e.rqng_supv_id,e.rqng_supv_name,e.rqng_supv_emal_addr,e.rqng_supv_ph_nbr,w.req_date,e.cost_cent_info,w.work_addr_oth_info,w.mdcl_req_flag,w.non_mdcl_req_flag,w.expd_rtrn_date,w.ffd_nrs_name,w.pcp_name,w.pcp_ph,w.evln_desc,w.req_stat_info,w.cad_wkst_flag,w.shpg_mail_room_stk_flag,w.dsph_cust_svc_flag,w.part_asby_flag,w.admn_clcl_flag,w.comp_kybd_mous_flag,w.chr_foot_rest_flag,w.sit_stnd_desk_flag,w.comp_mntr_flag,w.genl_wkst_eval_flag,w.wkst_evln_scpe_oth_info,w.genl_off_work, , w.empl_work_act_info,w.crtd_user_id,w.last_updt_user_id,w.str_addr,w.city_info,w.zip_code , wa.asmt_id from egn_empl e inner join egn_wkst_evln w on e.empl_id = w.empl_id left outer join egn_wkst_asmt wa on w.req_id = wa.req_id where wa.asmt_id in  (select distinct(woi.asmt_id) from EGN_ASMT_WORK_ORD_INFO woi where asgn_to_id = '9999997') ";
	
	@Autowired private JdbcTemplate jdbcTemplate;

	@Override
	public int submitWorkStationRequest(WorkstationEvaluation WSEvaluation) {
		logger.info(WSEvaluation);
		
		GeneratedKeyHolder keyHolder = new GeneratedKeyHolder();
		String id_column = "req_id";
		jdbcTemplate.update(con -> {
		    PreparedStatement ps = con.prepareStatement(INSERT_WORKSTATION_REQUEST, new String[]{id_column});
		    ps.setString(1, WSEvaluation.getEmpId());
		    ps.setString(2, WSEvaluation.getRequestDate());
		    ps.setString(3, WSEvaluation.getWorkAddressOther());
		    ps.setBoolean(4, WSEvaluation.isMedical());
		    ps.setBoolean(5, WSEvaluation.isNonMedical());
		    ps.setString(6, WSEvaluation.getExpDateOfReturn());
		    ps.setString(7, WSEvaluation.getfFDNurseName());
		    ps.setString(8, WSEvaluation.getPhysicianName());
		    ps.setString(9, WSEvaluation.getPhysicianPhNo());
		    ps.setString(10, WSEvaluation.getWsEvalDesc());
		    ps.setString(11, WSEvaluation.getStatus());
		    ps.setBoolean(12, WSEvaluation.getCheckbox().iscADWS());
		    ps.setBoolean(13, WSEvaluation.getCheckbox().isShippingMailroomStocking());
		    ps.setBoolean(14, WSEvaluation.getCheckbox().isrMCC());
		    ps.setBoolean(15, WSEvaluation.getCheckbox().isParts());
		    ps.setBoolean(16, WSEvaluation.getCheckbox().isAdministrativeClerical());
		    ps.setBoolean(17, WSEvaluation.getCheckbox().isComputerKeyboardMouse());
		    ps.setBoolean(18, WSEvaluation.getCheckbox().isChairFootrest());
		    ps.setBoolean(19, WSEvaluation.getCheckbox().isSitToStand());
		    ps.setBoolean(20, WSEvaluation.getCheckbox().isComputerMonitor());
		    ps.setBoolean(21, WSEvaluation.getCheckbox().isGeneralWorkstationEvaluation());
		    ps.setString(22, WSEvaluation.getCreatedBy());
		    ps.setString(23, WSEvaluation.getUpdatedBy());
		    ps.setString(24, WSEvaluation.getWrkEvalScopOthr());
		    ps.setBoolean(25, WSEvaluation.getCheckbox().isGeneralOfficeWorkEmpEval());
		    ps.setString(26, WSEvaluation.getEmpWrkActOthr());
		    ps.setString(27, WSEvaluation.getStrAddr());
		    ps.setString(28, WSEvaluation.getCityInfo());
		    ps.setString(29, WSEvaluation.getZipCode());
		    return ps;
		  }
		  , keyHolder);
		BigDecimal i =  (BigDecimal) keyHolder.getKeys().get(id_column);
		
		logger.info("object "+WSEvaluation+" inserted successfully request id "+i.intValue());
		return i.intValue();
	}
	
	@Override
	public boolean updateStatus(UpdateStatus updateStatus){
		
		String query = UPDATE_STATUS;
		
		if(updateStatus.getStatus().equalsIgnoreCase("Medical Rejected")){
			query = UPDATE_STATUS_FOR_MEDICAL_REQUESTS;
		}
		
		
		jdbcTemplate.batchUpdate(query,new BatchPreparedStatementSetter() {

			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				ps.setString(1, updateStatus.getStatus());
				ps.setString(2, updateStatus.getEmpId());
				ps.setString(3, updateStatus.getRequestIds().get(i));
			}

			@Override
			public int getBatchSize() {
				return updateStatus.getRequestIds().size();
			}
		  });
		
		return true;
		
	}
	
	@Override
	public boolean updateStatus(String reqId,String empId,String status){
		boolean flag = false;
		String query = UPDATE_STATUS;
		
		int updatedRow = jdbcTemplate.update(query,new PreparedStatementSetter() {

			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setString(1, status);
				ps.setString(2, empId);
				ps.setString(3, reqId);
			}

		
		  });
		
		if(updatedRow > 0)
			flag = true;
		else
			flag = false;
			
			return flag;
		
	}
	

	@Override
	public boolean updateWorkStationRequest(WorkstationEvaluation WSEvaluation) {
		boolean flag = false;
		int updatedRow = jdbcTemplate.update(UPDATE_WORKSTATION_REQUEST, new PreparedStatementSetter(){

			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setString(1, WSEvaluation.getRequestDate());
				ps.setString(2, WSEvaluation.getWorkAddressOther());
				ps.setBoolean(3, WSEvaluation.isMedical());
				ps.setBoolean(4, WSEvaluation.isNonMedical());
				ps.setString(5, WSEvaluation.getExpDateOfReturn());
				ps.setString(6, WSEvaluation.getfFDNurseName());
				ps.setString(7, WSEvaluation.getPhysicianName());
				ps.setString(8, WSEvaluation.getPhysicianPhNo());
				ps.setString(9, WSEvaluation.getWsEvalDesc());
				ps.setString(10, WSEvaluation.getStatus());
				ps.setBoolean(11, WSEvaluation.getCheckbox().iscADWS());
				ps.setBoolean(12, WSEvaluation.getCheckbox().isShippingMailroomStocking());
				ps.setBoolean(13, WSEvaluation.getCheckbox().isrMCC());
				ps.setBoolean(14, WSEvaluation.getCheckbox().isParts());
				ps.setBoolean(15, WSEvaluation.getCheckbox().isAdministrativeClerical());
				ps.setBoolean(16, WSEvaluation.getCheckbox().isComputerKeyboardMouse());
				ps.setBoolean(17, WSEvaluation.getCheckbox().isChairFootrest());
				ps.setBoolean(18, WSEvaluation.getCheckbox().isSitToStand());
				ps.setBoolean(19, WSEvaluation.getCheckbox().isComputerMonitor());
				ps.setBoolean(20, WSEvaluation.getCheckbox().isGeneralWorkstationEvaluation());
				ps.setString(21, WSEvaluation.getUpdatedBy());
				ps.setString(22, WSEvaluation.getWrkEvalScopOthr());
				ps.setBoolean(23, WSEvaluation.getCheckbox().isGeneralOfficeWorkEmpEval());
				ps.setString(24, WSEvaluation.getEmpWrkActOthr());
				ps.setString(25, WSEvaluation.getStrAddr());
			    ps.setString(26, WSEvaluation.getCityInfo());
			    ps.setString(27, WSEvaluation.getZipCode());
				ps.setString(28, WSEvaluation.getRequestId());
				
			}
			
		});
		if(updatedRow > 0)
			flag = true;
		else
			flag = false;
			
			return flag;
	}
	@Override
	public WorkstationEvaluation getRequestById(String requestId) {
		return jdbcTemplate.queryForObject(GET_REQUEST_BY_ID, new Object[]{requestId},new WSEvaluationMapper<WorkstationEvaluation>());
	}
	
	@Override
	public List<WorkstationEvaluation> getRequestByUser(String emplId) {
		
		List<WorkstationEvaluation> list = new ArrayList<>();
		try {	
		 list = jdbcTemplate.query(GET_REQUEST_BY_USER, new Object[]{emplId},new WSEvaluationMapper<WorkstationEvaluation>());
		}catch(EmptyResultDataAccessException e){
			return list;
		}
		return list;
	}
	
	@Override
	public List<Document> getDocumentsByRequestId(String requestId) {
		return jdbcTemplate.query(GET_ALL_DOCUMENTS_BY_REQUEST_ID, new Object[]{requestId},new DocumentMapper<Document>());
	}
	
	@Override
	public List<WorkstationEvaluation> getNonMedicalRequests(String supvId,SearchCriteria searchCriteria) {
		logger.info("entering getNonMedicalRequests method in WorkstationEvaluationDAO");
		logger.info("executing query : "+GET_ALL_EVALUATION_REQUESTS_FOR_SUPVID);
		StringBuilder finalQuery = new StringBuilder();
		
		finalQuery.append("SELECT * FROM  (select searchrecords.* , ROWNUM rnum from  ( ");
		finalQuery.append(GET_ALL_EVALUATION_REQUESTS_FOR_SUPVID);
		finalQuery.append(" ) searchrecords where rownum <= ? ) where  rnum >= ? ");
		
		return jdbcTemplate.query(finalQuery.toString(),new Object[]{supvId,searchCriteria.getRecordsPerPage(),(searchCriteria.getStartIndex()-1)}, new WSEvaluationMapper<WorkstationEvaluation>());
	}
	
	@Override
	public List<WorkstationEvaluation> searchNonMedicalRequests(String supvId,SearchCriteria searchCriteria) {
		logger.info("entering getNonMedicalRequests method in WorkstationEvaluationDAO");
		logger.info("executing query : "+SEARCH_EVALUATION_REQUESTS_FOR_SUPVID);
		StringBuilder finalQuery = new StringBuilder();
		
		finalQuery.append("SELECT * FROM  (select searchrecords.* , ROWNUM rnum from  ( ");
		finalQuery.append(SEARCH_EVALUATION_REQUESTS_FOR_SUPVID+" order by w."+searchCriteria.getOrderByColumn()+" "+searchCriteria.getSortingType());
		finalQuery.append(" ) searchrecords where rownum <= ? ) where  rnum >= ? ");
		
		return jdbcTemplate.query(finalQuery.toString(),new Object[]{supvId,searchCriteria.getRecordsPerPage(),(searchCriteria.getStartIndex()-1)}, new WSEvaluationMapper<WorkstationEvaluation>());
	}
	
	public int saveWorkStationRequest(WorkstationEvaluation WSEvaluation) {
		logger.info(WSEvaluation);
		GeneratedKeyHolder keyHolder = new GeneratedKeyHolder();
		String id_column = "req_id";
		
		jdbcTemplate.update(con -> {
		    PreparedStatement ps = con.prepareStatement(SAVE_INSERT_WORKSTATION_REQUEST, new String[]{id_column});
		    ps.setString(1, WSEvaluation.getEmpId());
		    ps.setString(2, WSEvaluation.getRequestDate());
		    ps.setString(3, WSEvaluation.getWorkAddressOther());
		    ps.setBoolean(4, WSEvaluation.isMedical());
		    ps.setBoolean(5, WSEvaluation.isNonMedical());
		    ps.setString(6, WSEvaluation.getExpDateOfReturn());
		    ps.setString(7, WSEvaluation.getfFDNurseName());
		    ps.setString(8, WSEvaluation.getPhysicianName());
		    ps.setString(9, WSEvaluation.getPhysicianPhNo());
		    ps.setString(10, WSEvaluation.getWsEvalDesc());
		    ps.setString(11, WSEvaluation.getStatus());
		    ps.setBoolean(12, WSEvaluation.getCheckbox().iscADWS());
		    ps.setBoolean(13, WSEvaluation.getCheckbox().isShippingMailroomStocking());
		    ps.setBoolean(14, WSEvaluation.getCheckbox().isrMCC());
		    ps.setBoolean(15, WSEvaluation.getCheckbox().isParts());
		    ps.setBoolean(16, WSEvaluation.getCheckbox().isAdministrativeClerical());
		    ps.setBoolean(17, WSEvaluation.getCheckbox().isComputerKeyboardMouse());
		    ps.setBoolean(18, WSEvaluation.getCheckbox().isChairFootrest());
		    ps.setBoolean(19, WSEvaluation.getCheckbox().isSitToStand());
		    ps.setBoolean(20, WSEvaluation.getCheckbox().isComputerMonitor());
		    ps.setBoolean(21, WSEvaluation.getCheckbox().isGeneralWorkstationEvaluation());
		    ps.setString(22, WSEvaluation.getCreatedBy());
		    ps.setString(23, WSEvaluation.getUpdatedBy());
		    ps.setString(24, WSEvaluation.getWrkEvalScopOthr());
		    ps.setBoolean(25, WSEvaluation.getCheckbox().isGeneralOfficeWorkEmpEval());
		    ps.setString(26, WSEvaluation.getEmpWrkActOthr());
		    ps.setString(27, WSEvaluation.getStrAddr());
		    ps.setString(28, WSEvaluation.getCityInfo());
		    ps.setString(29, WSEvaluation.getZipCode());
		    
		    return ps;
		  }
		  , keyHolder);
		BigDecimal i =  (BigDecimal) keyHolder.getKeys().get(id_column);
		
		logger.info("object "+WSEvaluation+" inserted successfully request id "+i.intValue());
		return i.intValue();
	}

	@Override
	public List<WorkstationEvaluation> getRequestData(String supvid){ 
		logger.info("entering getRequestData method in WorkstationEvaluationDAO");
		logger.info("executing query : "+GET_ALL_EVALUATION_REQUESTS);
		List<WorkstationEvaluation> list = new ArrayList<>();
		try {
			list = jdbcTemplate.query(GET_ALL_EVALUATION_REQUESTS_FOR_SUPVID, new Object[] { supvid },
					new WSEvaluationMapper<WorkstationEvaluation>());
		} catch (Exception e) {
			logger.info(e.getMessage());
		}
		return list;
	}
	
	@Override
	public List<WorkstationEvaluation> getMedicalRejectedRequestsForSupervisorData(String supvid){
		logger.info("entering getRequestData method in WorkstationEvaluationDAO");
		logger.info("executing query : "+GET_ALL_MEDICAL_REJECTED_REQUESTS_FOR_SUPVID);
		List<WorkstationEvaluation> list = new ArrayList<>();
		try {
			list =  jdbcTemplate.query(GET_ALL_MEDICAL_REJECTED_REQUESTS_FOR_SUPVID, new Object[] { supvid },
					new WSEvaluationMapper<WorkstationEvaluation>());
		} catch (Exception e) {
			logger.info(e.getMessage());
		}
		return list;
	}
	
	@Override
	public int getUserRequestsCount(String userId) {
		
		StringBuilder query = new StringBuilder();
		int count = 0;
		query.append("select COUNT(*) as count from (select w.req_id,e.empl_id,e.empl_name,e.empl_wkst_loca_city,e.empl_wkst_loca_bldg,e.empl_shft_hrs,e.rqng_supv_id,e.rqng_supv_name,e.rqng_supv_emal_addr,e.rqng_supv_ph_nbr,w.req_date,e.cost_cent_info,w.work_addr_oth_info,w.mdcl_req_flag,w.non_mdcl_req_flag,w.expd_rtrn_date,w.ffd_nrs_name,w.pcp_name,w.pcp_ph,w.evln_desc,w.req_stat_info,w.cad_wkst_flag,w.shpg_mail_room_stk_flag,w.dsph_cust_svc_flag,w.part_asby_flag,w.admn_clcl_flag,w.comp_kybd_mous_flag,w.chr_foot_rest_flag,w.sit_stnd_desk_flag,w.comp_mntr_flag,w.genl_wkst_eval_flag,w.wkst_evln_scpe_oth_info, w.genl_off_work , w.empl_work_act_info,w.crtd_user_id,w.last_updt_user_id,w.str_addr,w.city_info,w.zip_code ,wa.asmt_id from egn_empl e inner join egn_wkst_evln w on e.empl_id = w.empl_id left outer join egn_wkst_asmt wa on w.req_id = wa.req_id where w.empl_id = ? OR e.rqng_supv_id = ?)");
		count = jdbcTemplate.queryForObject(query.toString(),new Object[] { userId,userId },Integer.class);
		
		return count;
	}
	
	@Override
	public List<WorkstationEvaluation> getAllRequestsByUser(String userId,SearchCriteria searchCriteria){
		logger.info("entering getAllRequestsByUser method in WorkstationEvaluationDAO");
		logger.info("executing query : "+GET_ALL_USER_REQUESTS);
		List<WorkstationEvaluation> list = new ArrayList<>();
		StringBuilder finalQuery = new StringBuilder();
		
		finalQuery.append("SELECT * FROM  (select searchrecords.* , rownum rnum from  ( ");
		finalQuery.append(GET_ALL_USER_REQUESTS);
		finalQuery.append(" order by w."+searchCriteria.getOrderByColumn()+" "+searchCriteria.getSortingType());																								  
		finalQuery.append(" ) searchrecords where rownum <= ? ) where  rnum >= ? ");
		
		try {
			list = jdbcTemplate.query(finalQuery.toString(), new Object[] { userId,userId, searchCriteria.getEndIndex(),searchCriteria.getStartIndex()},
					new WSEvaluationMapper<WorkstationEvaluation>());
		} catch (Exception e) {
			logger.info(e.getMessage());
		}
		return list;
	}
	
	@Override
	public List<WorkstationEvaluation> getRequestData(){
		logger.info("entering getRequestData method in WorkstationEvaluationDAO");
		List<WorkstationEvaluation> list = new ArrayList<>();
		logger.info("executing query : "+GET_ALL_EVALUATION_REQUESTS);
		try {
			list =  jdbcTemplate.query(GET_ALL_EVALUATION_REQUESTS,new WSEvaluationMapper<WorkstationEvaluation>());
		} catch (Exception e) {
			logger.info(e.getMessage());
		}
		return list;
	}
	
	@Override
	public List<WorkstationEvaluation> getPaginatedRequestData(SearchCriteria searchCriteria){
		logger.info("entering getRequestData method in WorkstationEvaluationDAO");
		logger.info("executing query : "+GET_ALL_EVALUATION_REQUESTS);
		List<WorkstationEvaluation> list = new ArrayList<>();
		StringBuilder finalQuery = new StringBuilder();
		
		finalQuery.append("SELECT * FROM  (select searchrecords.* , ROWNUM rnum from  ( ");
		finalQuery.append(GET_ALL_EVALUATION_REQUESTS+" order by w."+searchCriteria.getOrderByColumn()+" "+searchCriteria.getSortingType());
		finalQuery.append(" ) searchrecords where rownum <= ? ) where  rnum >= ? ");

		try {
			list = jdbcTemplate.query(finalQuery.toString(), new Object[]{searchCriteria.getEndIndex(),searchCriteria.getStartIndex()},new WSEvaluationMapper<WorkstationEvaluation>());
		} catch (Exception e) {
			logger.info(e.getMessage());
		}
		return list;
	}

	@Override
	public List<WorkstationEvaluation> getAllMedicalRequests(){
		logger.info("entering getRequestData method in WorkstationEvaluationDAO");
		logger.info("executing query : "+GET_ALL_MEDICAL_REQUESTS);
		List<WorkstationEvaluation> list = new ArrayList<>();
		try {
			list = jdbcTemplate.query(GET_ALL_MEDICAL_REQUESTS,new WSEvaluationMapper<WorkstationEvaluation>());
		} catch (Exception e) {
			logger.info(e.getMessage());
		}
		return list;
	}
	
	@Override
	public int getResultsForSpecialistCount() {
		
		StringBuilder query = new StringBuilder();
		int count = 0;
		query.append("select COUNT(*) as count from egn_wkst_evln where req_stat_info IN ('Supervisor Approved','Medical Approved','Assessment Pending','Assessment Provided','Assessment Reopened','Assessment Complete')");
		count = jdbcTemplate.queryForObject(query.toString(),Integer.class);
		
		return count;
	}
	
	@Override
	public List<WorkstationEvaluation> getResultsForSpecialist(SearchCriteria searchCriteria){
		logger.info("entering getResultsForSpecialist method in WorkstationEvaluationDAO");
		logger.info("executing query : "+GET_REQUESTS_FOR_SPECIALIST);
		List<WorkstationEvaluation> list = new ArrayList<>();
		StringBuilder finalQuery = new StringBuilder();
		
		finalQuery.append("SELECT * FROM  (select searchrecords.* , ROWNUM rnum from  ( ");
		finalQuery.append(GET_REQUESTS_FOR_SPECIALIST+" order by w."+searchCriteria.getOrderByColumn()+" "+searchCriteria.getSortingType());
		finalQuery.append(" ) searchrecords where rownum <= ? ) where  rnum >= ? ");

		try {
			list = jdbcTemplate.query(finalQuery.toString(),new Object[]{searchCriteria.getEndIndex(),(searchCriteria.getStartIndex())},
					new WSEvaluationMapper<WorkstationEvaluation>());
		} catch (Exception e) {
			logger.info(e.getMessage());
		}
		return list;
	}
	
	@Override
	public int getResultsForFacilitiesMgmtCount() {
		
		StringBuilder query = new StringBuilder();
		int count = 0;
		//query.append("select COUNT(*) as count from egn_wkst_evln where req_stat_info IN ('Supervisor Approved','Medical Approved')");
		
		
		if(Util.isLocalMode()){
			query.append("select COUNT(*) as count from EGN_WKST_ASMT where asmt_id in  (select distinct(asmt_id) from EGN_ASMT_WORK_ORD_INFO where asgn_to_id = 'xmie006')");	
		}else{
			query.append("select COUNT(*) as count from EGN_WKST_ASMT where asmt_id in  (select distinct(asmt_id) from EGN_ASMT_WORK_ORD_INFO where asgn_to_id = '9999997')");
		}
		count = jdbcTemplate.queryForObject(query.toString(),Integer.class);
		
		return count;
	}
	
	@Override
	public List<WorkstationEvaluation> getResultsForFacilitiesMgmt(SearchCriteria searchCriteria){
		
		logger.info("entering getResultsForFacilitiesMgmt method in WorkstationEvaluationDAO");
		String query = GET_REQUESTS_FOR_FACLTYMGMT_LOCAL;
		if(!Util.isLocalMode()){
			query = GET_REQUESTS_FOR_FACLTYMGMT;
		}
		logger.info("executing query : "+query);
		List<WorkstationEvaluation> list = new ArrayList<>();
		try {
		StringBuilder finalQuery = new StringBuilder();
		
		finalQuery.append("SELECT * FROM  (select searchrecords.* , ROWNUM rnum from  ( ");
		finalQuery.append(query+" order by w."+searchCriteria.getOrderByColumn()+" "+searchCriteria.getSortingType());
		finalQuery.append(" ) searchrecords where rownum <= ? ) where  rnum >= ? ");

		
			list = jdbcTemplate.query(finalQuery.toString(),new Object[]{searchCriteria.getEndIndex(),(searchCriteria.getStartIndex())},
					new WSEvaluationMapper<WorkstationEvaluation>());
		} catch (Exception e) {
			logger.info(e.getMessage());
		}
		return list;
	}
	
	@Override
	public List<WorkstationEvaluation> getResultsForFacilitiesMgmtWithCrtrea(SearchCriteria searchCriteria){
		
		logger.info("entering getResultsForFacilitiesMgmt method in WorkstationEvaluationDAO");
		String query = GET_REQUESTS_FOR_FACLTYMGMT_BYCRITERIA_LOCAL;
		if(!Util.isLocalMode()){
			query = GET_REQUESTS_FOR_FACLTYMGMT_BYCRITERIA;
		}
		logger.info("executing query : "+query);
		List<WorkstationEvaluation> list = new ArrayList<>();
		try {
		StringBuilder finalQuery = new StringBuilder();
		
		finalQuery.append("SELECT * FROM  (select searchrecords.* , ROWNUM rnum from  ( ");
		finalQuery.append(query);
		if(searchCriteria.getStatus() != null && searchCriteria.getStatus().length() > 0 ){
			finalQuery.append(" and w.asmt_stat_info = '"+searchCriteria.getStatus()+"'");
		}
		finalQuery.append(" order by w."+searchCriteria.getOrderByColumn()+" "+searchCriteria.getSortingType());
		
		finalQuery.append(" ) searchrecords where rownum <= ? ) where  rnum >= ? ");

		
			list = jdbcTemplate.query(finalQuery.toString(),new Object[]{searchCriteria.getEndIndex(),(searchCriteria.getStartIndex())},
					new WSEvaluationMapper<WorkstationEvaluation>());
		} catch (Exception e) {
			logger.info(e.getMessage());
		}
		return list;
	}
	
	@Override
	public int getResultsForFacilitiesMgmtCountWithCrtrea(SearchCriteria searchCriteria) {
		
		StringBuilder query = new StringBuilder();
		int count = 0;
		//query.append("select COUNT(*) as count from egn_wkst_evln where req_stat_info IN ('Supervisor Approved','Medical Approved')");
		if(Util.isLocalMode()){
			query.append("select COUNT(*) as count from EGN_WKST_ASMT wa where wa.asmt_id in  (select distinct(asmt_id) from EGN_ASMT_WORK_ORD_INFO where asgn_to_id = 'xmie006')");
		}else{
			query.append("select COUNT(*) as count from EGN_WKST_ASMT wa where wa.asmt_id in  (select distinct(asmt_id) from EGN_ASMT_WORK_ORD_INFO where asgn_to_id = '9999997')");
		}
			if(searchCriteria.getStatus() != null && searchCriteria.getStatus().length() > 0 ){
					query.append(" and wa.asmt_stat_info = '"+searchCriteria.getStatus()+"'");
				}
		count = jdbcTemplate.queryForObject(query.toString(),Integer.class);
		
		return count;
	}
}
