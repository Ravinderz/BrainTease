package com.uprr.app.egn.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.uprr.app.egn.dto.Checkbox;
import com.uprr.app.egn.dto.WorkstationEvaluation;

public class EvaluationResultSetExtractor<T> implements ResultSetExtractor<T> {
	

	public T extractData(ResultSet rs) throws SQLException,
			DataAccessException {
		WorkstationEvaluation request = new WorkstationEvaluation();
		Checkbox checkbox = new Checkbox();
		String expDate = "";
		String reqDate = "";
		
		request.setRequestId(rs.getString("req_id"));
		request.setAssessmentId(rs.getString("asmt_id"));
		request.setEmpId(rs.getString("empl_id"));
		request.setEmpName(rs.getString("empl_name"));
		request.setEmpWorkstationLocCity(rs.getString("empl_wkst_loca_city"));
		request.setEmpWorkstationLocBld(rs.getString("empl_wkst_loca_bldg"));
		request.setEmpShiftHrs(rs.getString("empl_shft_hrs"));
		request.setRequestingSupervisor(rs.getString("rqng_supv_name"));
		request.setRequestingSupervisorId(rs.getString("rqng_supv_id"));
		request.setRequestingSupervisorEmail(rs.getString("rqng_supv_emal_addr"));
		request.setRequestingSupervisorPhNo(rs.getString("rqng_supv_ph_nbr"));
		
		reqDate = rs.getString("req_date");
		request.setRequestDate(reqDate.split(" ")[0]);
		request.setCostCenter(rs.getString("cost_cent_info"));
		request.setWorkAddressOther(rs.getString("work_addr_oth_info"));
		request.setWrkEvalScopOthr(rs.getString("wkst_evln_scpe_oth_info"));
		request.setEmpWrkActOthr(rs.getString("empl_work_act_info"));
		request.setMedical(getBoolean(rs.getInt("mdcl_req_flag")));
		request.setNonMedical(getBoolean(rs.getInt("non_mdcl_req_flag")));
		request.setCreatedBy(rs.getString("CRTD_USER_ID"));
		request.setUpdatedBy(rs.getString("LAST_UPDT_USER_ID"));
		expDate = rs.getString("expd_rtrn_date");
		if(expDate != null){
			request.setExpDateOfReturn(expDate.split(" ")[0]);
		}else{
			request.setExpDateOfReturn(expDate);	
		}
		request.setfFDNurseName(rs.getString("ffd_nrs_name"));
		request.setPhysicianName(rs.getString("pcp_name"));
		request.setPhysicianPhNo(rs.getString("pcp_ph"));
		request.setWsEvalDesc(rs.getString("evln_desc"));
		request.setStrAddr(rs.getString("str_addr"));
		request.setCityInfo(rs.getString("city_info"));
		request.setZipCode(rs.getString("zip_code"));
		request.setStatus(rs.getString("req_stat_info"));
		checkbox.setcADWS(getBoolean(rs.getInt("cad_wkst_flag")));
		checkbox.setShippingMailroomStocking(getBoolean(rs.getInt("shpg_mail_room_stk_flag")));
		checkbox.setrMCC(getBoolean(rs.getInt("dsph_cust_svc_flag")));
		checkbox.setParts(getBoolean(rs.getInt("part_asby_flag")));
		checkbox.setAdministrativeClerical(getBoolean(rs.getInt("admn_clcl_flag")));
		checkbox.setComputerKeyboardMouse(getBoolean(rs.getInt("comp_kybd_mous_flag")));
		checkbox.setChairFootrest(getBoolean(rs.getInt("chr_foot_rest_flag")));
		checkbox.setSitToStand(getBoolean(rs.getInt("sit_stnd_desk_flag")));
		checkbox.setComputerMonitor(getBoolean(rs.getInt("comp_mntr_flag")));
		checkbox.setGeneralWorkstationEvaluation(getBoolean(rs.getInt("genl_wkst_eval_flag")));
		checkbox.setGeneralOfficeWorkEmpEval(getBoolean(rs.getInt("genl_off_work")));
		request.setCheckbox(checkbox);
		return (T) request;
	}
	
	
	public static boolean getBoolean(int number) {
		boolean result = false;
		if(number == 1){
			result = true;
		}else{
			result = false;
		}
	    return result;
	}

}
