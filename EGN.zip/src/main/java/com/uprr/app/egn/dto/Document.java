package com.uprr.app.egn.dto;

public class Document {

	private String requestId;
	private String documentGuid;
	private String documentName;
	private String documentDesc;
	private String createdBy;
	private String creationDate;
	private String updatedBy;
	private String updatedDate;
	
	
	public String getRequestId() {
		return requestId;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	public String getDocumentGuid() {
		return documentGuid;
	}
	public void setDocumentGuid(String documentGuid) {
		this.documentGuid = documentGuid;
	}
	public String getDocumentName() {
		return documentName;
	}
	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}
	public String getDocumentDesc() {
		return documentDesc;
	}
	public void setDocumentDesc(String documentDesc) {
		this.documentDesc = documentDesc;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public String getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(String updatedDate) {
		this.updatedDate = updatedDate;
	}
	
	
	public Document() {
		super();
	}
	
	@Override
	public String toString() {
		return "Document [requestId=" + requestId + ", documentGuid=" + documentGuid + ", documentName=" + documentName
				+ ", documentDesc=" + documentDesc + ", createdBy=" + createdBy + ", creationDate=" + creationDate
				+ ", updatedBy=" + updatedBy + ", updatedDate=" + updatedDate + "]";
	}
	
	

}
