package com.uprr.app.egn.dto;

public class LoggedUserVO {

	private String userId;
	private String employeeId;
	private String role;
	private String firstName;
	private String lastName;
	private String middleName;
	private String fullName;
	private String email;
	private String phone;
	private String supervisorUserId;
	private String supervisorEmpId;
	private String supervisorName;
	private String supervisorEmail;
	private String supervisorPh;
	private String costCenter;
	private String deptPayorName;
	private String location;
	private String city;
	private String state;
	private String building;
	private String workstationId;
	private boolean canAccessApplication;
	private boolean canCreateRequest;
	private boolean canApproveMedicalRequests;
	private boolean canCreateAssessment;
	private boolean canCreateCostItems;
	private boolean canViewMedicalDocs;
	
	
	
	
	public String getSupervisorPh() {
		return supervisorPh;
	}
	public void setSupervisorPh(String supervisorPh) {
		this.supervisorPh = supervisorPh;
	}
	public boolean isCanViewMedicalDocs() {
		return canViewMedicalDocs;
	}
	public void setCanViewMedicalDocs(boolean canViewMedicalDocs) {
		this.canViewMedicalDocs = canViewMedicalDocs;
	}
	public boolean isCanAccessApplication() {
		return canAccessApplication;
	}
	public void setCanAccessApplication(boolean canAccessApplication) {
		this.canAccessApplication = canAccessApplication;
	}
	public boolean isCanCreateRequest() {
		return canCreateRequest;
	}
	public void setCanCreateRequest(boolean canCreateRequest) {
		this.canCreateRequest = canCreateRequest;
	}
	public boolean isCanApproveMedicalRequests() {
		return canApproveMedicalRequests;
	}
	public void setCanApproveMedicalRequests(boolean canApproveMedicalRequests) {
		this.canApproveMedicalRequests = canApproveMedicalRequests;
	}
	public boolean isCanCreateAssessment() {
		return canCreateAssessment;
	}
	public void setCanCreateAssessment(boolean canCreateAssessment) {
		this.canCreateAssessment = canCreateAssessment;
	}
	public boolean isCanCreateCostItems() {
		return canCreateCostItems;
	}
	public void setCanCreateCostItems(boolean canCreateCostItems) {
		this.canCreateCostItems = canCreateCostItems;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getSupervisorUserId() {
		return supervisorUserId;
	}
	public void setSupervisorUserId(String supervisorUserId) {
		this.supervisorUserId = supervisorUserId;
	}
	public String getSupervisorEmpId() {
		return supervisorEmpId;
	}
	public void setSupervisorEmpId(String supervisorEmpId) {
		this.supervisorEmpId = supervisorEmpId;
	}
	public String getSupervisorName() {
		return supervisorName;
	}
	public void setSupervisorName(String supervisorName) {
		this.supervisorName = supervisorName;
	}
	public String getSupervisorEmail() {
		return supervisorEmail;
	}
	public void setSupervisorEmail(String supervisorEmail) {
		this.supervisorEmail = supervisorEmail;
	}
	public String getCostCenter() {
		return costCenter;
	}
	public void setCostCenter(String costCenter) {
		this.costCenter = costCenter;
	}
	public String getDeptPayorName() {
		return deptPayorName;
	}
	public void setDeptPayorName(String deptPayorName) {
		this.deptPayorName = deptPayorName;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getBuilding() {
		return building;
	}
	public void setBuilding(String building) {
		this.building = building;
	}
	public String getWorkstationId() {
		return workstationId;
	}
	public void setWorkstationId(String workstationId) {
		this.workstationId = workstationId;
	}
	public LoggedUserVO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public LoggedUserVO(String userId, String employeeId, String role, String firstName, String lastName,
			String middleName, String fullName, String email, String phone, String supervisorUserId,
			String supervisorEmpId, String supervisorName, String supervisorEmail, String costCenter,
			String deptPayorName, String location, String city, String state, String building, String workstationId) {
		super();
		this.userId = userId;
		this.employeeId = employeeId;
		this.role = role;
		this.firstName = firstName;
		this.lastName = lastName;
		this.middleName = middleName;
		this.fullName = fullName;
		this.email = email;
		this.phone = phone;
		this.supervisorUserId = supervisorUserId;
		this.supervisorEmpId = supervisorEmpId;
		this.supervisorName = supervisorName;
		this.supervisorEmail = supervisorEmail;
		this.costCenter = costCenter;
		this.deptPayorName = deptPayorName;
		this.location = location;
		this.city = city;
		this.state = state;
		this.building = building;
		this.workstationId = workstationId;
	}
	@Override
	public String toString() {
		return "LoggedUserVO [userId=" + userId + ", employeeId=" + employeeId + ", role=" + role + ", firstName="
				+ firstName + ", lastName=" + lastName + ", middleName=" + middleName + ", fullName=" + fullName
				+ ", email=" + email + ", phone=" + phone + ", supervisorUserId=" + supervisorUserId
				+ ", supervisorEmpId=" + supervisorEmpId + ", supervisorName=" + supervisorName + ", supervisorEmail="
				+ supervisorEmail + ", costCenter=" + costCenter + ", deptPayorName=" + deptPayorName + ", location="
				+ location + ", city=" + city + ", state=" + state + ", building=" + building + ", workstationId="
				+ workstationId + "]";
	}
	
	
	
}
