package com.uprr.app.egn.util;

import java.util.ArrayList;
import java.util.List;

import org.apache.tomcat.jdbc.pool.PoolProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.uprr.app.iae.cyberark.client.CyberArkClient;
import com.uprr.app.iae.cyberark.client.dto.CyberArkPasswordRequestDTO;
import com.uprr.app.iae.cyberark.client.dto.CyberArkPasswordResponseDTO;

public class CyberArkUtil extends PoolProperties {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private static final Logger logger = LoggerFactory.getLogger(CyberArkUtil.class);
	private String instance;
	private String userID;
	private String type;
	private String appTLA;
	private String runEnv;
	private String localEnvPassword;
	
	@Override
	public boolean isJmxEnabled() {
		return false;
	}

	@Override
	public boolean isPoolSweeperEnabled() {
		return true;
	}

	@Override
	public String getUsername() {
		return getUserID();
	}

	@Override
	public String getPassword() {
		return getPasswordFrmCyberArk();
	}

	/**
	 * This method returns the Password stored in Cyber-Ark for the defined set of Properties
	 * @return
	 */
	public String getPasswordFrmCyberArk() {
		if (Util.isLocalMode()) {
			logger.info("::::Local Password :::: " + getInstance() + "Password " + getLocalEnvPassword());
			return getLocalEnvPassword();
		}
		
		/*if (Util.isDevMode()) {
			logger.info("::::Local Password :::: " + getInstance() + "Password " + getLocalEnvPassword());
			return getLocalEnvPassword();
		}*/
		
		
	
		String password = null;
		CyberArkPasswordResponseDTO passwordDetails = null;
		try {
			CyberArkPasswordRequestDTO cyberArkPasswordRequestDTOObj = new CyberArkPasswordRequestDTO();
			cyberArkPasswordRequestDTOObj.setEnvironment(getRunEnv());
			cyberArkPasswordRequestDTOObj.setSystem(getType()); 
			cyberArkPasswordRequestDTOObj.setTla(getAppTLA());
			cyberArkPasswordRequestDTOObj.setApplicationId(getUserID());
			cyberArkPasswordRequestDTOObj.setResource(getInstance()); 
			CyberArkClient cyberArkClientObj = new CyberArkClient();
			passwordDetails = cyberArkClientObj.getPassword(cyberArkPasswordRequestDTOObj);
			if(passwordDetails != null) {
				password = passwordDetails.getPassword();
			}
			logger.info("::::Pcode Retrieval Successful for :::: " + getInstance() + "Ergonomics" + passwordDetails + "hgdjf " +  password );
			logger.info("Password for cyberark for JMS :::  " +  password );
		} catch (Exception e) {
			logger.error(":::Error occurred while retrieving the Pcode from CyberArk for " + getInstance(), e);
		}	
		return password;
	}

	/**
	 * This method checks the logged in environment.
	 */
	public static Boolean isValidEnv() {
		boolean isValidEnv = false;
		String envProperty = System.getProperty(Util.getEnvironment());
		List<String> envLst = getListOfEnvironemnts();
		if (envLst.contains(envProperty)) {
			isValidEnv = true;
		}
		return isValidEnv;
	}
	
	
	/**
	 * Gets the list of valid environments except local 
	 * @return
	 */
	public static List<String> getListOfEnvironemnts() {
		List<String> envLst = new ArrayList<String>(Util.THREE);
		envLst.add(Util.DEV_ENVIRONMENT);
		envLst.add(Util.TEST_ENVIRONMENT);
		envLst.add(Util.PROD_ENVIRONMENT);
		return envLst;
	}
	
	/**
	 * @return the instance
	 */
	public String getInstance() {
		return instance;
	}
	/**
	 * @param instance the instance to set
	 */
	public void setInstance(String instance) {
		this.instance = instance;
	}

	/**
	 * @return the userID
	 */
	public String getUserID() {
		return userID;
	}
	/**
	 * @param userID the userID to set
	 */
	public void setUserID(String userID) {
		this.userID = userID;
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}
	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return the appTLA
	 */
	public String getAppTLA() {
		return appTLA;
	}
	/**
	 * @param appTLA the appTLA to set
	 */
	public void setAppTLA(String appTLA) {
		this.appTLA = appTLA;
	}

	/**
	 * @return the runEnv
	 */
	public String getRunEnv() {
		return runEnv;
	}
	/**
	 * @param runEnv the runEnv to set
	 */
	public void setRunEnv(String runEnv) {
		this.runEnv = runEnv;
	}

	/**
	 * @return the localEnvPassword
	 */
	public String getLocalEnvPassword() {
		return localEnvPassword;
	}
	/**
	 * @param localEnvPassword the localEnvPassword to set
	 */
	public void setLocalEnvPassword(String localEnvPassword) {
		this.localEnvPassword = localEnvPassword;
	}
}
