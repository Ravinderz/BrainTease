package com.uprr.app.egn.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.uprr.app.egn.dto.LoggedUserVO;
import com.uprr.app.egn.dto.MenuVO;
import com.uprr.app.egn.dto.SendMailVO;
import com.uprr.app.egn.dto.UserVO;
import com.uprr.app.egn.service.AppService;
import com.uprr.app.egn.service.EmailService;
import com.uprr.app.egn.service.IEmplService;
import com.uprr.app.egn.util.EGNConstants;
import com.uprr.app.egn.util.Util;
import com.uprr.ui.shared.user.ActiveUserId;
import com.uprr.ui.shared.user.spring.mvc.ActiveUser;


@RestController
public class AppController { 
	
	Logger logger = LogManager.getLogger(AppController.class);
	
	@Autowired
	AppService appService;
	
	@Autowired
	EmailService emailService;
	
    @Autowired
    private IEmplService emplService;
	
	@GetMapping("/getMenu/{empId}")
	public ResponseEntity<List<MenuVO>> getMenu(@PathVariable("empId") String empId,@ActiveUser ActiveUserId activeUser) throws IOException{
		logger.info("inside getMenu method");
		//String role = roleService.getRole(empId);
		if(Util.isLocalMode() || activeUser.getUserId().equalsIgnoreCase(empId)){
			String role = appService.getRole(empId);
			return new ResponseEntity<List<MenuVO>>(appService.getMenuItems(role), HttpStatus.OK);
		}else{
			List<MenuVO> list = null;
			return new ResponseEntity<List<MenuVO>>(list, HttpStatus.FORBIDDEN);
		}


	}
	
	@GetMapping("/getHomeList/{empId}")
	public ResponseEntity<List<MenuVO>> getHomeList(@PathVariable("empId") String empId,@ActiveUser ActiveUserId activeUser) throws IOException{
		//String role = roleService.getRole(empId);
		if(Util.isLocalMode() || activeUser.getUserId().equalsIgnoreCase(empId)){
			String role = appService.getRole(empId);
			return new ResponseEntity<List<MenuVO>>(appService.getHomeListItems(role), HttpStatus.OK);
		}else{
			List<MenuVO> list = null;
			return new ResponseEntity<List<MenuVO>>(list, HttpStatus.FORBIDDEN);
		}
	}
	
	@GetMapping(value = "/getLoggedInUser")
	public @ResponseBody ResponseEntity<LoggedUserVO> getLoggedInUser(@ActiveUser ActiveUserId activeUser){
		System.out.println(activeUser.getUserId());
		logger.info("logged in user ID "+activeUser.getUserId());
		LoggedUserVO loggedUser = new LoggedUserVO();
		loggedUser.setUserId(activeUser.getUserId());
		if(activeUser.getUserId() != null && !activeUser.getUserId().equalsIgnoreCase("UNKNOWN")){
																																																																																		
				String role = appService.getRole(activeUser.getUserId());
				loggedUser = appService.populateUser(activeUser.getUserId(), role, activeUser.getEmployeeId());
				if(loggedUser.getEmployeeId() != null){
					if(emplService.getCountFromEmpl(loggedUser.getEmployeeId()) > 0){
						emplService.updateEmployeeRecord(loggedUser);
					}else{
						emplService.insertEmployeeRecord(loggedUser);
					}	
				}
			return new ResponseEntity<LoggedUserVO>(loggedUser, HttpStatus.OK);
		}else{
			String id = "xmie002";
			String role = appService.getRole(id);
			loggedUser = appService.populateUser(id, role,"");
			return new ResponseEntity<LoggedUserVO>(loggedUser, HttpStatus.OK);
		}
	} 

	@GetMapping(value = "/getLoggedInUserObject")
	public @ResponseBody ResponseEntity<UserVO> getLoggedInUserObject(@ActiveUser ActiveUserId activeUser){
		System.out.println(activeUser.getUserId());
		logger.info("logged in user ID "+activeUser.getUserId());
		UserVO user = new UserVO();
		if(activeUser.getUserId() != null && activeUser.getUserId() != "UNKNOWN"){
			user.setUserID(activeUser.getUserId());
			user.setEmployeeID(activeUser.getEmployeeId());
			user.setRole(appService.getRole(user.getUserID()));
			//user.setRole("ada nurse");
			return new ResponseEntity<UserVO>(user, HttpStatus.OK);
		}else{
			user = new UserVO("xmie002", "9999998", EGNConstants.SUPERVISOR_ROLE);
			return new ResponseEntity<UserVO>(user, HttpStatus.OK);
		}
		
	}
	
	@GetMapping(value = "/sendTestEmail" , produces="text/plain")
	public String sendTestEmail() throws Exception{
		SendMailVO vo = new SendMailVO();
		List<String> toAddresLst = new ArrayList<String>();
		toAddresLst.add("xprk408");
		vo.setToAddressLst(toAddresLst);
		vo.setContentType("text/html");
		String subject = "Test";
		if(Util.isLocalMode()){
			subject = "EGN LOCAL TEST MAIL";
		}else if(Util.isTestMode()){
			subject = "EGN XTEST TEST MAIL";
		}else if(Util.isProdMode()){
			subject = "EGN PROD MAIL";
		}
		vo.setSubject(subject);
		vo.setBodyContent("This is test mail from EGN code base, to check if the configuration is proper");
		emailService.sendEmailNotification(vo);
		return "sent";
	}
	
		
}
