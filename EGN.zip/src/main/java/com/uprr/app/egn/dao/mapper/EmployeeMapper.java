package com.uprr.app.egn.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class EmployeeMapper<T> implements RowMapper<T> {
	public T mapRow(ResultSet arg0, int arg1) throws SQLException {
		EmployeeResultSetExtractor<T> empExtractor = new EmployeeResultSetExtractor<T>();
		return empExtractor.extractData(arg0);
	}
}
