package com.uprr.app.egn.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.uprr.app.egn.dto.Document;
import com.uprr.app.egn.service.IAuthorizationService;
import com.uprr.app.egn.service.IDocService;
import com.uprr.app.egn.util.Util;
import com.uprr.azm.shared.mvc.security.authorization.Attribute;
import com.uprr.azm.shared.mvc.security.authorization.Authorize;
import com.uprr.ui.shared.user.ActiveUserId;
import com.uprr.ui.shared.user.spring.mvc.ActiveUser;

@RestController
@RequestMapping("upload")
public class UploadController {
	
	
	@Autowired
	IDocService docService;
	
	@Autowired
	IAuthorizationService authService;

	
	Logger logger = LogManager.getLogger(UploadController.class);
	
	@GetMapping(value = "callEchoService" , produces="text/plain")
	public String callEchoServices() throws Exception {
		logger.info("entering single file upload method");
		  docService.callEchoService();
		  return "done";
		 
	}
	
	@PostMapping(value = "EdocsFile")
	@Authorize(
			actions = {@Attribute(key="action-id", value="access")},
			resources = {@Attribute(key="resource-id", value="ergonomics"),@Attribute(key="feature-id", value="create-request")}
			)
	public List<Document> uploadFileToEdocs(@RequestParam("uploadFiles") MultipartFile[] files) throws IOException, Exception{
		logger.info("entering file upload method");
		List<Document> docIdList = new ArrayList<Document>();
		for(MultipartFile file : files){
			docIdList.add(docService.persistDoc(file));
		}
		return docIdList;
		 
	}
	
	@GetMapping(value = "downloadEdocsFile/{emplId}/{docId}" , produces=MediaType.APPLICATION_OCTET_STREAM_VALUE)
	public byte[] downloadFileFromEdocs(@PathVariable ("emplId") String emplId,@PathVariable ("docId") String docId,@ActiveUser ActiveUserId activeUser) throws IOException, Exception{
		logger.info("entering edocs file upload method");
		if(Util.isLocalMode() || authService.canApproveMedicalRequest(activeUser.getUserId()) || authService.canCreateAssessment(activeUser.getUserId()) || activeUser.getEmployeeId().equalsIgnoreCase(emplId)){
			return docService.getDoc(docId);	
		}else{
			return null;
		}

	}
	
	@PostMapping(value = "saveUploadedFiles" , produces="text/plain")
	public String saveFileToDatabase(@RequestBody List<Document> docs) throws IOException, Exception{
		logger.info("entering uploadFileToEdocs method");
		return "Success" +docService.saveDocs(docs);
		 
	}
	
}
