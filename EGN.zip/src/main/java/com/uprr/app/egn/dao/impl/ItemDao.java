package com.uprr.app.egn.dao.impl;

import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.uprr.app.egn.dao.IItemDAO;
import com.uprr.app.egn.dao.mapper.ItemMapper;
import com.uprr.app.egn.dao.mapper.WSEvaluationMapper;
import com.uprr.app.egn.dto.ActionItem;
import com.uprr.app.egn.dto.WorkstationEvaluation;	  

@Repository
public class ItemDao implements IItemDAO{
	
	Logger logger = LogManager.getLogger(ItemDao.class);
	
	private String SAVE_ACTION_ITEMS = "insert into EGN_ASMT_WORK_ORD_INFO(asmt_work_ord_id,asmt_id,work_ord_item_name,work_ord_desc,work_ord_note_info,work_ord_est_cost,supv_apvl_info,asgn_to_id,asgn_to_name,asgn_date,crtd_user_id,crtn_tmst,last_updt_user_id,last_updt_tmst,work_ord_stat_info) values (egn_asmt_work_ord_info_q1.nextval,?,?,?,?,?,?,?,?,sysdate,?,sysdate,?,sysdate,?)";
	
	private String UPDATE_ACTION_ITEMS = "update EGN_ASMT_WORK_ORD_INFO set work_ord_item_name = ?,work_ord_desc = ?,work_ord_note_info = ?,work_ord_est_cost = ?,supv_apvl_info = ?,asgn_to_id = ?,asgn_date = sysdate,last_updt_user_id = ?,last_updt_tmst = sysdate ,work_ord_stat_info = ? where asmt_work_ord_id = ?";
	
	private String GET_ALL_ITEMS_BY_ASSESSMENT_ID = "select asmt_work_ord_id,work_ord_item_name,work_ord_desc,work_ord_note_info,work_ord_est_cost,asgn_to_id,asgn_date,work_ord_stat_info,crtd_user_id,crtn_tmst,last_updt_user_id,last_updt_tmst,asmt_id,asgn_to_name,supv_apvl_info from egn_asmt_work_ord_info where asmt_id = ?";
	//private String GET_ITEMS_ASSIGNED_TO_SUPERVISOR = "select asmt_work_ord_id,work_ord_item_name,work_ord_desc,work_ord_note_info,work_ord_est_cost,asgn_to_id,asgn_date,work_ord_stat_info,crtd_user_id,crtn_tmst,last_updt_user_id,last_updt_tmst,asmt_id,asgn_to_name,supv_apvl_info from egn_asmt_work_ord_info where asgn_to_id = ? and work_ord_stat_info NOT IN ('Completed','Cancelled')";
	
	//private String GET_ITEMS_ASSIGNED_TO_SUPERVISOR = "select wosi.asmt_work_ord_id,wosi.work_ord_item_name,wosi.work_ord_desc,wosi.work_ord_note_info,wosi.work_ord_est_cost,wosi.asgn_to_id, wosi.asgn_date,work_ord_stat_info,wosi.crtd_user_id,wosi.crtn_tmst,wosi.last_updt_user_id,wosi.last_updt_tmst,wosi.asmt_id,wosi.asgn_to_name, wosi.supv_apvl_info from egn_asmt_work_ord_info wosi where wosi.work_ord_stat_info NOT IN ('Complete','Cancelled') and wosi.asmt_id in ( select wa.asmt_id from egn_empl e inner join egn_wkst_evln w on e.empl_id = w.empl_id left outer  join egn_wkst_asmt wa on w.req_id = wa.req_id where e.rqng_supv_id = ? and w.non_mdcl_req_flag = 1 and w.req_stat_info NOT IN ('Assessment Complete')) order by wosi.ASMT_WORK_ORD_ID desc ";
	
	private String GET_ITEMS_ASSIGNED_TO_SUPERVISOR = "select w.req_id,e.empl_id,e.empl_name,e.empl_wkst_loca_city,e.empl_wkst_loca_bldg,e.empl_shft_hrs,e.rqng_supv_id,e.rqng_supv_name,e.rqng_supv_emal_addr,e.rqng_supv_ph_nbr,w.req_date,e.cost_cent_info,w.work_addr_oth_info,w.mdcl_req_flag,w.non_mdcl_req_flag,w.expd_rtrn_date,w.ffd_nrs_name,w.pcp_name,w.pcp_ph,w.evln_desc,w.req_stat_info,w.cad_wkst_flag,w.shpg_mail_room_stk_flag,w.dsph_cust_svc_flag,w.part_asby_flag,w.admn_clcl_flag,w.comp_kybd_mous_flag,w.chr_foot_rest_flag,w.sit_stnd_desk_flag,w.comp_mntr_flag,w.genl_wkst_eval_flag,w.wkst_evln_scpe_oth_info, w.genl_off_work , w.empl_work_act_info,w.crtd_user_id,w.last_updt_user_id,w.str_addr,w.city_info,w.zip_code ,wa.asmt_id from egn_empl e inner join egn_wkst_evln w on e.empl_id = w.empl_id left outer join egn_wkst_asmt wa on w.req_id = wa.req_id where e.rqng_supv_id = ? and w.non_mdcl_req_flag = 1 and w.req_stat_info NOT IN ('Assessment Complete') and wa.asmt_id IN (select DISTINCT(woi.asmt_id) from egn_asmt_work_ord_info woi where woi.asgn_to_id = ? and woi.work_ord_stat_info NOT IN ('Complete','Cancelled') OR woi.supv_apvl_info = 'New') order by w.req_date desc";
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	@Override
	public int insertPurchaseItem(ActionItem item) {
		KeyHolder holder = new GeneratedKeyHolder();
		int itemId = 0;
		try {
			jdbcTemplate.update(con ->  {
					
					PreparedStatement ps = con.prepareStatement(SAVE_ACTION_ITEMS, new String[] {"asmt_work_ord_id"});
						ps.setInt(1, Integer.parseInt(item.getAssessmentId()));
						ps.setString(2, item.getItemTextDesc());
						ps.setString(3, item.getItemTextDesc());
						ps.setString(4, item.getNote());
						ps.setString(5, item.getEstimatedCost());
						ps.setString(6, item.getSupvAprvlStatus());
						ps.setString(7, item.getAssignedToEmployeeId());
						ps.setString(8, item.getAssignedToEmployeeName());
						ps.setString(9, item.getCreatedById());
						ps.setString(10, item.getUpdatedById());
						ps.setString(11, item.getItemOrderStatus());
						return ps; 
			}, holder);
			BigDecimal i =  (BigDecimal) holder.getKeys().get("asmt_work_ord_id");
			itemId = i.intValue();
		} catch (Exception e) {			
			logger.info(e.getMessage());
		}
		
		return itemId;
	}
	
	@Override
	public boolean updatePurchaseItem(ActionItem item) {
		boolean flag = false;
		
		int updatedRow = jdbcTemplate.update(UPDATE_ACTION_ITEMS, new PreparedStatementSetter(){
			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setString(1, item.getItemTextDesc());
				ps.setString(2, item.getItemTextDesc());
				ps.setString(3, item.getNote());
				ps.setString(4, item.getEstimatedCost());
				ps.setString(5, item.getSupvAprvlStatus());
				ps.setString(6, item.getAssignedToEmployeeId());
				ps.setString(7, item.getUpdatedById());
				ps.setString(8, item.getItemOrderStatus());
				ps.setInt(9, item.getItemId());
				
				
			}
			
		});
		if(updatedRow > 0){
			flag = true;
		}
		else{
			flag = false;
		}
		return flag;
	}
	
	@Override
	public List<ActionItem> getAllItemsByAsmtId(String assessmentId){
		return jdbcTemplate.query(GET_ALL_ITEMS_BY_ASSESSMENT_ID, new Object[]{assessmentId}, new ItemMapper<ActionItem>());
	}

	/*@Override
	public List<ActionItem> getItemsAssignedToSupervisor(String empId) {
		return jdbcTemplate.query(GET_ITEMS_ASSIGNED_TO_SUPERVISOR, new Object[]{empId}, new ItemMapper<ActionItem>());
	}*/
	
	@Override
	public List<WorkstationEvaluation> getItemsAssignedToSupervisor(String empId) {
		return jdbcTemplate.query(GET_ITEMS_ASSIGNED_TO_SUPERVISOR, new Object[]{empId,empId}, new WSEvaluationMapper<WorkstationEvaluation>());
	}

}
