package com.uprr.app.egn.config;

/**
 * Azm Config class for EGN Project.
 * @Author: (Krish)nappan Muthuraman (iots242)
 * Date: 05/07/18
*/

import com.uprr.app.azm.cache.AzmCache;
import com.uprr.app.azm.common.AuthorizationService;
import com.uprr.app.azm.common.AzmSecurityUtils;
import com.uprr.app.azm.common.CacheableSecurityUtils;
import com.uprr.app.azm.common.RestAuthorizationService;
import com.uprr.app.azm.jcs.JcsAzmCache;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.*;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;

import java.io.IOException;

@Configuration
@PropertySource("classpath:application.properties")
public class AZMConfig {

	@Value("${rest.hostname}")
	private String restHostname;

	@Value("${rest.service.url}")
	private String restServiceUrl;

	@Value("${azm.cache.timeout}")
	private String cacheTimeout;

	@Bean(name = "azmService")
	public AuthorizationService buildRestAuthorizationService() {
		RestAuthorizationService azmService = new RestAuthorizationService(restHostname, restServiceUrl);
		return azmService;
	}

	@Bean(name = "azmSecurityUtils")
	public AzmSecurityUtils buildCacheableSecurityUtils() {
		CacheableSecurityUtils azmSecurityUtils = new CacheableSecurityUtils(buildRestAuthorizationService(), buildAzmCache());
		return azmSecurityUtils;
	}

	@Bean(name="azmCache")
	public AzmCache buildAzmCache(){
		JcsAzmCache azmCache = new JcsAzmCache(Long.parseLong(cacheTimeout));
		return azmCache;
	}

	@Bean
	public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() throws IOException {
		return new PropertySourcesPlaceholderConfigurer();
	}
}