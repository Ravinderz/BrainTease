package com.uprr.app.egn.dao;

import java.util.List;

import com.uprr.app.egn.dto.Document;

public interface IDocDAO {

	public boolean saveMultipleDocs(List<Document> docs);
}
