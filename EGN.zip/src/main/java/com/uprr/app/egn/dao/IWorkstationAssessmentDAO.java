package com.uprr.app.egn.dao;

import java.util.List;

import com.uprr.app.egn.dto.ActionItem;
import com.uprr.app.egn.dto.Dropdown;
import com.uprr.app.egn.dto.WorkstationAssessment;

public interface IWorkstationAssessmentDAO {

	 int submitWorkstationAssessment(WorkstationAssessment WSAssessment);
	
	 List<Dropdown> getDropdownValues();
	
	 WorkstationAssessment getRequestById(String requestId);
	int getAssessmentForReqIdCount(String requestId);

	boolean updateWorkStationAssessment(WorkstationAssessment WSAssessment);
	
	int saveWorkstationAssessment(WorkstationAssessment WSAssessment);
	
	boolean saveActionItems(List<ActionItem> list,int asmtId);
	
	boolean updateActionItems(List<ActionItem> list);
	
	public List<ActionItem> getAllItemsByAsmtId(String assessmentId);
	
	public boolean updateWorkstationAssessmentStatus(String asmtId, String status);
}
