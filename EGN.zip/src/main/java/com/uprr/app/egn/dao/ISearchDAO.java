package com.uprr.app.egn.dao;

import java.util.List;

import com.uprr.app.egn.dto.SearchCriteria;
import com.uprr.app.egn.dto.SearchRequest;
import com.uprr.app.egn.dto.WorkstationEvaluation;

public interface ISearchDAO {

	 List<WorkstationEvaluation> searchWorkstationRequest(SearchRequest request,String role);
	 
	 List<WorkstationEvaluation> getSearchWorkstationRequests(SearchRequest request,String role,SearchCriteria searchCriteria);
	
	 List<WorkstationEvaluation> initialSearchWorkstationRequest(String role,String supvId);
	 
	 int getSearchCriteriaCount(SearchCriteria searchCriteria,SearchRequest request,String role);
	 
	 int getWorkstationEvalSearchTotalCount(SearchCriteria searchCriteria);
}
