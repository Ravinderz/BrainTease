package com.uprr.app.egn.dao.impl;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.uprr.app.egn.dao.IEmployeeDAO;
import com.uprr.app.egn.dao.mapper.EmployeeMapper;
import com.uprr.app.egn.dto.LoggedUserVO;
import com.uprr.app.egn.dto.WorkstationEvaluation;

@Repository
public class EmployeeDAO implements IEmployeeDAO{
	
	Logger logger = LogManager.getLogger(EmployeeDAO.class);
	
	String INSERT_EMPLOYEE_RECORD = "insert into egn_empl(empl_id,empl_name,empl_wkst_loca_bldg,empl_wkst_loca_city,empl_shft_hrs,rqng_supv_name,rqng_supv_id,rqng_supv_emal_addr,rqng_supv_ph_nbr,CRTD_USER_ID,CRTN_TMST,LAST_UPDT_USER_ID,LAST_UPDT_TMST,cost_cent_info) values (?,?,?,?,?,?,?,?,?,?,sysdate,?,sysdate,?)";
	
	String UPDATE_EMPLOYEE_RECORD = "update egn_empl set empl_name = ?,empl_wkst_loca_bldg = ?,empl_wkst_loca_city = ?,rqng_supv_name= ?,rqng_supv_id = ?,rqng_supv_emal_addr =?,rqng_supv_ph_nbr = ?,LAST_UPDT_USER_ID= ?,LAST_UPDT_TMST = sysdate,cost_cent_info = ? where empl_id = ? ";
	
	String GET_COUNT_EMPLOYEE_RECORD = "select count(*) from egn_empl where empl_id = ?";
	
	String GET_EMPLOYEE_FROM_VIEW = "select supv.emplid as supervisor_id,supv.name as supervisor_name, supv.email_addr as supervisor_email, supv.upc_cell_phone as supervisor_ph,emp.* from egn.egn_empl_view_v1 emp inner join egn.EGN_EMPL_VIEW_V1 supv on emp.supervisor_id = supv.emplid and emp.emplid = ?";
	
	String GET_EMPLOYEE_DETAILS_FROM_TABLE = "select empl_id as emplid, empl_name as first_name, empl_name as middle_name,empl_name as last_name,empl_name as name,empl_wkst_loca_bldg as upc_bldg_address1,empl_wkst_loca_city as upc_bldg_city,empl_wkst_loca_city as upc_bldg_state,empl_wkst_loca_city as upc_wrk_space,empl_shft_hrs as work_phone,empl_shft_hrs as email_addr,empl_shft_hrs as upc_cost_center,empl_shft_hrs as supervisor_name,empl_shft_hrs as supervisor_email,empl_shft_hrs as supervisor_id,rqng_supv_ph_nbr as supervisor_ph  from egn.egn_empl where empl_id IN (:ids)";																																																																																																																																					   
	@Autowired private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate; 
	
	public boolean insertEmployeeRecord(WorkstationEvaluation wsEval){
		logger.info(wsEval);
		boolean status = false;
		int i = jdbcTemplate.update(INSERT_EMPLOYEE_RECORD,
				new Object[] {wsEval.getEmpId(),wsEval.getEmpName(),wsEval.getEmpWorkstationLocBld(),wsEval.getEmpWorkstationLocCity(),wsEval.getEmpShiftHrs(),wsEval.getRequestingSupervisor(),wsEval.getRequestingSupervisorId(),wsEval.getRequestingSupervisorEmail(),wsEval.getRequestingSupervisorPhNo(),wsEval.getEmpId(),wsEval.getEmpId(),wsEval.getCostCenter()});
		
		if(i == 1){
			status = true;
			logger.info("object "+wsEval+" inserted successfully");
		}else{
			status = false;
			logger.info("failed to insert object "+wsEval);
		}
		return status;
	}
	
	public boolean updateEmployeeRecord(WorkstationEvaluation eval){
		boolean flag = false;
		int updatedRow = jdbcTemplate.update(UPDATE_EMPLOYEE_RECORD, new PreparedStatementSetter(){

			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setString(1, eval.getEmpName());
				ps.setString(2, eval.getEmpWorkstationLocBld());
				ps.setString(3, eval.getEmpWorkstationLocCity());
				ps.setString(4, eval.getRequestingSupervisor());
				ps.setString(5, eval.getRequestingSupervisorId());
				ps.setString(6, eval.getRequestingSupervisorEmail());
				ps.setString(7, eval.getRequestingSupervisorPhNo());
				ps.setString(8,eval.getEmpId());
				ps.setString(9, eval.getCostCenter());
				ps.setString(10, eval.getEmpId());
			}
			
		});
		if(updatedRow > 0)
			flag = true;
		else
			flag = false;
			
			return flag;
	}
	
	public boolean insertEmployeeRecord(LoggedUserVO user){
		logger.info(user);
		boolean status = false;
		String city_state = user.getCity()+", "+user.getState();
		String building_wkstId = user.getBuilding()+", "+user.getWorkstationId();
		int i = jdbcTemplate.update(INSERT_EMPLOYEE_RECORD,
				new Object[] {user.getEmployeeId(),user.getFullName(),building_wkstId,city_state,"6 - 9",user.getSupervisorName(),user.getSupervisorEmpId(),user.getSupervisorEmail(),user.getSupervisorPh(),user.getEmployeeId(),user.getEmployeeId(),user.getCostCenter()});
		
		if(i == 1){
			status = true;
			logger.info("object "+user+" inserted successfully");
		}else{
			status = false;
			logger.info("failed to insert object "+user);
		}
		return status;
	}
	
	public boolean updateEmployeeRecord(LoggedUserVO user){
		boolean flag = false;
		int updatedRow = jdbcTemplate.update(UPDATE_EMPLOYEE_RECORD, new PreparedStatementSetter(){

			@Override
			public void setValues(PreparedStatement ps) throws SQLException {
				ps.setString(1, user.getFullName());
				ps.setString(2, user.getBuilding());
				ps.setString(3, user.getCity());
				ps.setString(4, user.getSupervisorName());
				ps.setString(5, user.getSupervisorEmpId());
				ps.setString(6, user.getSupervisorEmail());
				ps.setString(7, user.getSupervisorPh());
				ps.setString(8,user.getEmployeeId());
				ps.setString(9, user.getCostCenter());
				ps.setString(10, user.getEmployeeId());
			}
			
		});
		if(updatedRow > 0)
			flag = true;
		else
			flag = false;
			
			return flag;
	}
	
	public int getEmployeeCount(String empId){
		logger.info(empId);
		int count = jdbcTemplate.queryForObject(GET_COUNT_EMPLOYEE_RECORD,new Object[] { empId },Integer.class);
		return count;
	}

	@Override
	public LoggedUserVO getEmployeeFromView(String empId) {
		return jdbcTemplate.queryForObject(GET_EMPLOYEE_FROM_VIEW,new Object[] { empId },new EmployeeMapper<LoggedUserVO>());
  	
	}
	
	@Override
	public List<LoggedUserVO> getEmployeeFromTable(Set<String> userIds) {
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("ids", userIds);
		return namedParameterJdbcTemplate.query(GET_EMPLOYEE_DETAILS_FROM_TABLE,parameters,new EmployeeMapper<LoggedUserVO>());
		
	}

}
