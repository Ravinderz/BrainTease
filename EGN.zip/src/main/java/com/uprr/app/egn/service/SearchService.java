package com.uprr.app.egn.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uprr.app.egn.dao.ISearchDAO;
import com.uprr.app.egn.dao.IWorkstationEvaluationDAO;
import com.uprr.app.egn.dto.RequestSearchData;
import com.uprr.app.egn.dto.SearchCriteria;
import com.uprr.app.egn.dto.SearchRequest;
import com.uprr.app.egn.dto.WorkstationEvaluation;

@Service
public class SearchService {
	
	Logger logger = LogManager.getLogger(SearchService.class);
	
	@Autowired
	ISearchDAO searchDao;

	@Autowired
	IWorkstationEvaluationDAO wsEvalDao;

	public List<WorkstationEvaluation> searchRequest(SearchRequest request,String role){
		logger.info("Inside searchService");
		return searchDao.searchWorkstationRequest(request,role);
	}
	
	public RequestSearchData getSearchRequest(SearchRequest request,String role,SearchCriteria searchCriteria){ 
		logger.info("Inside searchService");
		int totalcount = searchCriteria.getRecordsCount();
		List<WorkstationEvaluation> searchDataList = new ArrayList<WorkstationEvaluation>();
		if (totalcount == 0) {
			
			totalcount = (int) searchDao.getSearchCriteriaCount(searchCriteria,request,role);
		}
		if (totalcount > 0) {
			
			searchCriteria.setRecordsCount((int) totalcount);
			searchDataList = searchDao.getSearchWorkstationRequests(request,role,searchCriteria);
		}

		final RequestSearchData searchData = new RequestSearchData();
		searchData.setStartIndex(searchCriteria.getStartIndex());
		searchData.setEndIndex(searchCriteria.getEndIndex());
		searchData.setRecordsCount(totalcount);
		searchData.setCurrentPage(searchCriteria.getCurrentPage());
		searchData.setTotalPages(totalcount / searchData.getRecordsPerPage());
		searchData.setEvalSearchData(searchDataList);
		searchData.setSortingType(searchCriteria.getSortingType());
		searchData.setOrderByColumn(searchCriteria.getOrderByColumn());														 
		return searchData;
	}
	
	public RequestSearchData initialSearchRequest(String role,String supvId,SearchCriteria searchCriteria){
		logger.info("Inside searchService");
		List<WorkstationEvaluation> searchDataList =  wsEvalDao.searchNonMedicalRequests(supvId, searchCriteria);/*searchDao.initialSearchWorkstationRequest(role,supvId,searchCriteria);*/
		final RequestSearchData searchData = new RequestSearchData();
		searchData.setStartIndex(searchCriteria.getStartIndex());
		searchData.setEndIndex(searchCriteria.getEndIndex());
		searchData.setRecordsCount((int) searchDataList.size());
		searchData.setCurrentPage(searchCriteria.getCurrentPage());
		searchData.setTotalPages((int) searchDataList.size() / searchData.getRecordsPerPage());
		searchData.setEvalSearchData(searchDataList);
		searchData.setSortingType(searchCriteria.getSortingType());
		searchData.setOrderByColumn(searchCriteria.getOrderByColumn());														 
		return searchData;
	}
	
	public RequestSearchData getSearchResults(SearchCriteria searchCriteria){
		logger.info(searchCriteria);
		int totalcount = searchCriteria.getRecordsCount();
		List<WorkstationEvaluation> searchDataList = new ArrayList<WorkstationEvaluation>();
		if (totalcount == 0) {
			
				totalcount = (int) searchDao.getWorkstationEvalSearchTotalCount(searchCriteria);
				logger.info("total count : "+totalcount);
		}

		if (totalcount > 0) {
			
			searchCriteria.setRecordsCount((int) totalcount);
			searchDataList = wsEvalDao.getPaginatedRequestData(searchCriteria);
		}
		
		final RequestSearchData searchData = new RequestSearchData();
		searchData.setStartIndex(searchCriteria.getStartIndex());
		searchData.setEndIndex(searchCriteria.getEndIndex());
		searchData.setRecordsCount((int) totalcount);
		searchData.setCurrentPage(searchCriteria.getCurrentPage());
		searchData.setTotalPages((int) totalcount / searchData.getRecordsPerPage());
		searchData.setEvalSearchData(searchDataList);
		searchData.setSortingType(searchCriteria.getSortingType());
		searchData.setOrderByColumn(searchCriteria.getOrderByColumn());														 
		return searchData;
	}
	
	public RequestSearchData getResultsForSpecialist(SearchCriteria searchCriteria){
		logger.info("Inside searchService");
		int totalcount = searchCriteria.getRecordsCount();
		List<WorkstationEvaluation> searchDataList = new ArrayList<WorkstationEvaluation>();
		if (totalcount == 0) {
			
			totalcount = (int) wsEvalDao.getResultsForSpecialistCount();
		}
		if (totalcount > 0) {
			
			searchCriteria.setRecordsCount((int) totalcount);
			searchDataList = wsEvalDao.getResultsForSpecialist(searchCriteria);
		}
		
		final RequestSearchData searchData = new RequestSearchData();
		searchData.setStartIndex(searchCriteria.getStartIndex());
		searchData.setEndIndex(searchCriteria.getEndIndex());
		searchData.setRecordsCount(totalcount);
		searchData.setCurrentPage(searchCriteria.getCurrentPage());
		searchData.setTotalPages(totalcount / searchData.getRecordsPerPage());
		searchData.setEvalSearchData(searchDataList);
		searchData.setSortingType(searchCriteria.getSortingType());
		searchData.setOrderByColumn(searchCriteria.getOrderByColumn());														 
		return searchData;
	}
	
	public RequestSearchData getUserRequests(String userId,SearchCriteria searchCriteria){
		logger.info("Inside searchService");
		int totalcount = searchCriteria.getRecordsCount();
		List<WorkstationEvaluation> searchDataList = new ArrayList<WorkstationEvaluation>();
		if (totalcount == 0) {
			
			totalcount = (int) wsEvalDao.getUserRequestsCount(userId);
		}
		if (totalcount > 0) {
			
			searchCriteria.setRecordsCount((int) totalcount);
			searchDataList =  wsEvalDao.getAllRequestsByUser(userId,searchCriteria);
		}
		
		final RequestSearchData searchData = new RequestSearchData();
		searchData.setStartIndex(searchCriteria.getStartIndex());
		searchData.setEndIndex(searchCriteria.getEndIndex());
		searchData.setRecordsCount(totalcount);
		searchData.setCurrentPage(searchCriteria.getCurrentPage());
		searchData.setTotalPages(totalcount / searchData.getRecordsPerPage());
		searchData.setEvalSearchData(searchDataList);
		searchData.setSortingType(searchCriteria.getSortingType());
		searchData.setOrderByColumn(searchCriteria.getOrderByColumn());														 
		return searchData;
	}
	
	public RequestSearchData getResultsForFacilitiesMgmt(SearchCriteria searchCriteria){
		logger.info("Inside searchService");
		int totalcount = searchCriteria.getRecordsCount();
		List<WorkstationEvaluation> searchDataList = new ArrayList<WorkstationEvaluation>();
		if (totalcount == 0) {
			
			totalcount = (int) wsEvalDao.getResultsForFacilitiesMgmtCount();
		}
		if (totalcount > 0) {
			
			searchCriteria.setRecordsCount((int) totalcount);
			searchDataList = wsEvalDao.getResultsForFacilitiesMgmt(searchCriteria);
		}
		
		final RequestSearchData searchData = new RequestSearchData();
		searchData.setStartIndex(searchCriteria.getStartIndex());
		searchData.setEndIndex(searchCriteria.getEndIndex());
		searchData.setRecordsCount(totalcount);
		searchData.setCurrentPage(searchCriteria.getCurrentPage());
		searchData.setTotalPages(totalcount / searchData.getRecordsPerPage());
		searchData.setEvalSearchData(searchDataList);
		searchData.setSortingType(searchCriteria.getSortingType());
		searchData.setOrderByColumn(searchCriteria.getOrderByColumn());														 
		return searchData;
	}
	
	public RequestSearchData getResultsForFacilitiesMgmtWithCrtrea(SearchCriteria searchCriteria){
		logger.info("Inside searchService");
		int totalcount = searchCriteria.getRecordsCount();
		List<WorkstationEvaluation> searchDataList = new ArrayList<WorkstationEvaluation>();
		if (totalcount == 0) {
			totalcount = (int) wsEvalDao.getResultsForFacilitiesMgmtCountWithCrtrea(searchCriteria);
		}
		if (totalcount > 0) {
			searchCriteria.setRecordsCount((int) totalcount);
			searchDataList = wsEvalDao.getResultsForFacilitiesMgmtWithCrtrea(searchCriteria);
		}
		
		final RequestSearchData searchData = new RequestSearchData();
		searchData.setStartIndex(searchCriteria.getStartIndex());
		searchData.setEndIndex(searchCriteria.getEndIndex());
		searchData.setRecordsCount(totalcount);
		searchData.setCurrentPage(searchCriteria.getCurrentPage());
		searchData.setTotalPages(totalcount / searchData.getRecordsPerPage());
		searchData.setEvalSearchData(searchDataList);
		searchData.setSortingType(searchCriteria.getSortingType());
		searchData.setOrderByColumn(searchCriteria.getOrderByColumn());														 
		return searchData;
	}
	 
}
