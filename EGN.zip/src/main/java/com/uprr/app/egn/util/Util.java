package com.uprr.app.egn.util;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Strings;
import com.uprr.app.egn.dto.SendMailVO;

public class Util {

	private static final String className = Util.class.getName();

	private static final Logger logger = LoggerFactory.getLogger(className);

	private final static boolean isInfoEnabled = logger.isInfoEnabled();

	private static final String localAppUrl = "http://localhost:9000/index.html#/search";

	private static final String devAppUrl = "https://xdev.home.www.uprr.com/egn/ui/secure/index.html#/search";

	private static final String testAppUrl = "https://xtest.home.www.uprr.com/egn/ui/secure/index.html#/search";

	private static final String prodAppUrl = "https://home.www.uprr.com/egn/ui/secure/index.html#/search";

	private static final String devMailGroup = "EGN_Dev_Team";
	
	public static final String ENCRYPT_KEY = "EGN_APP_UPRR_14A";
	
	public static final int THREE = 3;
	
	public static final String DEV_ENVIRONMENT = "dev";
	
	public static final String TEST_ENVIRONMENT = "test";
	
	public static final String PROD_ENVIRONMENT = "prod";
	
	public static final String EGN_Specialist_Mail_Group = "EGN_Specialist";

	private static final String EGN_BuildingSupplies_Mail_Group = "EGN_BuildingSupplies";

	private static final String EGN_HealthandMedical_Mail_Group = "EGN_HealthandMedical";
	
	public static final String EGN_IH_Mail_group = "EGN_Support_Team";
	

	private enum environmentEnum {
		/** The jetty. */
		jetty,
		/** The jetty. */
		tomcat,
		/** The desktop. */
		desktop,
		/** The local. */
		ci, local,
		/** The dev. */
		dev,
		/** The test. */
		test,
		/** The prod. */
		prod
	};

	private enum serviceNameEnum {
		ECHOSERVICE ("/echo"),
		UPLOADSERVICE ("/utility/managed-content/upload-document/1.0"),
		DOWNLAODSERVICE ("/utility/managed-content/download-document/1.0");
		private final String serviceName;
		serviceNameEnum(String serviceName) { this.serviceName = serviceName; }
	};

	public static String getEchoServiceName() {
		return serviceNameEnum.ECHOSERVICE.serviceName;
	}

	public static String getUploadServiceName() {
		return serviceNameEnum.UPLOADSERVICE.serviceName;
	}

	public static String getDownloadServiceName() {
		return serviceNameEnum.DOWNLAODSERVICE.serviceName;
	}

	public static String getOwnerName() {
		return "degn001";
	}

	public static String getAppName() {
		return "ErgonomicsWebApplication";
	}

	public static String getEnvironment() {
		return System.getProperty("uprr.implementation.environment");
	}

	/**
	 * Checks if is local mode.
	 *
	 * @return true, if is local mode
	 */
	public static boolean isLocalMode() {
		String environment = getEnvironment();
		boolean islocalEnvironment = (environment == null) ? true : false;
		if ((!Strings.isNullOrEmpty(environment))) {
			switch (environmentEnum.valueOf(environment)) {
			case jetty: {
				islocalEnvironment = true;
				break;
			}

			case local: {
				islocalEnvironment = true;
				break;
			}

			case desktop: {
				islocalEnvironment = true;
				break;
			}

			case tomcat: {
				islocalEnvironment = true;
				break;
			}

			default: {
				islocalEnvironment = false;
				break;
			}
			}
		}
		return islocalEnvironment;
	}

	public static boolean isDevMode() {
		String environment = getEnvironment();
		logger.info(environment);
		return (environment.equalsIgnoreCase("dev")) ? true : false;
	}

	public static boolean isTestMode() {
		String environment = getEnvironment();
		logger.info(environment);
		return (environment.equalsIgnoreCase("test")) ? true : false;
	}

	public static boolean isProdMode() {
		String environment = getEnvironment();
		logger.info(environment);
		return (environment.equalsIgnoreCase("prod")) ? true : false;
	}
	/*public static List<UserVO> getUsersNameById(List<RequestHistory> list){
		Set<String> set = new HashSet<>(list.size());
		list.stream().filter(p -> set.add(p.getChangedBy()));
	}*/
	
	public static String getCommaSeperatedUserIds(List<String> list){
		list.forEach( userId -> logger.info(userId));
		int count = 0;
		String userIds = "";
		for(String userId : list){
			if(count == list.size()-1){
				userIds = userIds +"'"+ userId +"'";
			}else{
				userIds = userIds +"'"+ userId +"'"+  ",";
			}
			count++;
		}
		logger.info(userIds);
		return userIds;
	}

	public static SendMailVO setEmailForEmployee(String toAddress,String requestId,String oldStatus,String newStatus) throws Exception{
		SendMailVO email = new SendMailVO();
		List<String> toAddresLst = new ArrayList<String>();

		email.setContentType("text/html");
		String subject = "Test";
		String link = "";
		String environment = getEnvironment();
		if ((!Strings.isNullOrEmpty(environment))) {
			switch (environmentEnum.valueOf(environment)) {
			case local: {
				subject = "LOCAL : EGN workstation evaluation request " + requestId + " update";
				link = "<a href='" + localAppUrl + "?q=" + encrypt(requestId,ENCRYPT_KEY) + "'> click here </a>";
				 toAddresLst.add("xprk408");
				//toAddresLst.add(devMailGroup);
				break;
			}
			case dev: {
				subject = "DEV : EGN workstation evaluation request " + requestId + " update";
				link = "<a href='" + devAppUrl + "?q=" + encrypt(requestId,ENCRYPT_KEY) + "'> click here </a>";
				 toAddresLst.add("xprk408");
				//toAddresLst.add(devMailGroup);
				break;
			}
			case test: {
				subject = "TEST: EGN workstation evaluation request " + requestId + " update";
				link = "<a href='" + testAppUrl + "?q=" + encrypt(requestId,ENCRYPT_KEY) + "'> click here </a>";
				toAddresLst.add(devMailGroup);
				break;
			}
			case prod: {
				subject = "PROD : EGN workstation evaluation request " + requestId + " update";
				link = "<a href='" + prodAppUrl + "?q=" + encrypt(requestId,ENCRYPT_KEY) + "'> click here </a>";
				toAddresLst.add(toAddress);
				break;
			}
			default:
				break;

			}
		}

		email.setToAddressLst(toAddresLst);
		email.setSubject(subject);
		email.setBodyContent(
				"<strong>TO :</strong> EGN_Dev_Team <br/><strong>FROM :</strong> noreply@UP.com <br/>"
						+ "<br/>Your workstation request "
						+ link + " status has changed from <strong>" + oldStatus + "</strong> to <strong>" + newStatus
						+ "</strong>.");

		return email;
	}
	
	/**
	 * Populates SendMailVO with appropriate data when Supervisor rejects a request.
	 * @param emplId
	 * @param supvId
	 * @param rejectReason
	 * @param status
	 * @return
	 */
	public static SendMailVO getNonMedicalRejectNotification(String emplId,String supvId,String rejectReason,String status){
		SendMailVO email = new SendMailVO();
		List<String> toAddresLst = new ArrayList<String>();
		List<String> ccAddresLst = new ArrayList<String>();
		
		email.setContentType("text/html");
      	String subject = "";
      	String content = "";
      	String environment = getEnvironment();
      	if ((!Strings.isNullOrEmpty(environment))) {
			switch(environmentEnum.valueOf(environment)) {
				case local: {
					subject = "LOCAL : Ergonomics Request";
		      		toAddresLst.add("xprk408");//emplId
		      		//ccAddresLst.add(devMailGroup);
		      		break;
				}

				case dev: {
					subject = "DEV : Ergonomics Request";
		      		toAddresLst.add("xprk408");//emplId
		      		ccAddresLst.add(devMailGroup);
		      		
		      		break;
				}

				case test: {
					subject = "TEST : Ergonomics Request";
		      		toAddresLst.add("xprk408");
		      		ccAddresLst.add(devMailGroup);//add supervisor and egn_IH team
					break;
				}
				
				case prod: {
					subject ="PROD: Ergonomics Request";
		      		toAddresLst.add(emplId);
		      		ccAddresLst.add(supvId);
		      		ccAddresLst.add(EGN_IH_Mail_group);
					break;
				}
				default:
					break;
				
			}
		}
      	
      	email.setToAddressLst(toAddresLst);
      	email.setCcAddressLst(ccAddresLst);
      	email.setSubject(subject);
      	content = "<strong>TO :</strong> "+emplId+" <br/><strong>CC :</strong> "+supvId+", "+EGN_IH_Mail_group+" <br/><strong>FROM :</strong> noreply@UP.com <br/>"
      			+ "<br/>Your Request for an Ergonomics assessment has been denied by your manager.  "
  				+ "Please see the reason below:<br/>"+rejectReason+"<br/><br/>Please contact the EGN_Support group via Lotus Notes if you have questions or concerns regarding this request.";
     	email.setBodyContent(content);
      	
		return email;
	}
	
	
	
	/**
	 * Populates SendMailVO with appropriate data when Supervisor OR ADA Nurse approves a request. 
	 * @param emplId
	 * @param supvId
	 * @param rejectReason
	 * @param status
	 * @return
	 * @throws Exception 
	 */
	public static SendMailVO getRequestApprovedNotification(String emplId,String name,String requestId) throws Exception{
		SendMailVO email = new SendMailVO();
		List<String> toAddresLst = new ArrayList<String>();
		List<String> ccAddresLst = new ArrayList<String>();
		
		email.setContentType("text/html");
      	String subject = "";
      	String content = "";
      	String link = "";
      	String environment = getEnvironment();
      	if ((!Strings.isNullOrEmpty(environment))) {
			switch(environmentEnum.valueOf(environment)) {
				case local: {
					subject = "LOCAL : New Ergonomics Assessment";
		      		toAddresLst.add("xprk408");//emplId
		      		//ccAddresLst.add("xsat860");
		      		ccAddresLst.add("xprk408");
		      		link = "<a href='"+localAppUrl+"?q="+encrypt(requestId,ENCRYPT_KEY)+"'> Please click here </a>";
		      		//link = "<a href='"+localAppUrl+"?q="+requestId+"'> Please click here </a>";
		      		break;
				}

				case dev: {
					subject = "DEV : New Ergonomics Assessment";
		      		toAddresLst.add("xprk408");//emplId
		      		ccAddresLst.add(devMailGroup);
		      		link = "<a href='"+devAppUrl+"?q="+encrypt(requestId,ENCRYPT_KEY)+"'> Please click here </a>";
		      		
		      		break;
				}

				case test: {
					subject = "TEST : New Ergonomics Assessment";
		      		toAddresLst.add("xprk408");
		      		ccAddresLst.add(devMailGroup);//add supervisor and egn_IH team
		      		link = "<a href='"+testAppUrl+"?q="+encrypt(requestId,ENCRYPT_KEY)+"'> Please click here </a>";
					break;
				}
				
				case prod: {
					subject ="PROD: New Ergonomics Assessment";
		      		toAddresLst.add("xprk408");
		      		ccAddresLst.add(devMailGroup);//add supervisor and egn_IH team
		      		link = "<a href='"+prodAppUrl+"?q="+encrypt(requestId,ENCRYPT_KEY)+"'> Please click here </a>";
					break;
				}
				default:
					break;
				
			}
		}
      	
      	email.setToAddressLst(toAddresLst);
      	email.setCcAddressLst(ccAddresLst);
      	email.setSubject(subject);
      	content = "<strong>TO :</strong> "+EGN_Specialist_Mail_Group+" <br/><strong>CC :</strong>  "+emplId+", "+EGN_IH_Mail_group+" <br/><strong>FROM :</strong> noreply@UP.com <br/>"
      			+ "<br/>"+name+" has submitted a new Ergonomics Request. "+link+" to review the request and schedule the Assessment." 
  				+ "<br/><br/>Please contact the EGN_Support group via Lotus Notes if you have questions or concerns regarding this request.";
     	email.setBodyContent(content);
      	
		return email;
	}
	
	public static SendMailVO setEmailForMdclRejectsToSupvsrEGNIHTeam(String requestSupvsrId, String employeeName,String requestId,String emailGroup) throws Exception {
		SendMailVO email = new SendMailVO();
		List<String> toAddresLst = new ArrayList<String>();
		List<String> ccAddresLst = new ArrayList<String>();
		email.setContentType("text/html");
		String subject = "Test";
		String link = "";

		String environment = getEnvironment();
		if ((!Strings.isNullOrEmpty(environment))) {
			switch (environmentEnum.valueOf(environment)) {
			case local: {
				subject = "LOCAL : Ergonomics Request";
				link = "<a href='" + localAppUrl + "?q=" + encrypt(requestId,ENCRYPT_KEY) + "'> click here </a>";
				
				//toAddresLst.add(requestSupvsrId);
				//ccAddresLst.add(EGN_IH_Mail_group);
				toAddresLst.add("xprk408");
				break;
			}
			case dev: {
				subject = "DEV : Ergonomics Request";
				link = "<a href='" + devAppUrl + "?q=" + encrypt(requestId,ENCRYPT_KEY) + "'> click here </a>";
				//toAddresLst.add(requestSupvsrId);
				ccAddresLst.add(EGN_IH_Mail_group);
				toAddresLst.add("xsat860");
				break;
			}
			case test: {
				subject = "TEST : Ergonomics Request";
				link = "<a href='" + testAppUrl + "?q=" + encrypt(requestId,ENCRYPT_KEY) + "'> click here </a>";
				//toAddresLst.add(requestSupvsrId);
				toAddresLst.add("xsat860");
				ccAddresLst.add(EGN_IH_Mail_group);
				break;
			}
			case prod: {
				subject = "PROD: Ergonomics Request";
				link = "<a href='" + prodAppUrl + "?q=" + encrypt(requestId,ENCRYPT_KEY) + "'> click here </a>";
				//toAddresLst.add(requestSupvsrId);
				toAddresLst.add("xsat860");
				ccAddresLst.add(EGN_IH_Mail_group);
				break;
			}
			default:
				break;

			}
		}

		email.setToAddressLst(toAddresLst);
		email.setCcAddressLst(ccAddresLst);
		email.setSubject(subject);
		email.setBodyContent("<strong>TO :</strong> "+requestSupvsrId+" <br/><strong>CC :</strong>"+EGN_IH_Mail_group+" <br/><strong>FROM :</strong> noreply@UP.com <br/>"
				+ "<br/>" + employeeName + " has submitted a new Ergonomics Request. Please "
				+ link
				+ " to approve or reject the request.  The Cost Center identified on the record will be charged for the Assessment."
				+ "<br/><br/> Please contact the EGN_Support group via Lotus Notes if you have questions or concerns regarding this request.");
		return email;
	}

	public static SendMailVO setEmlForAsmtCmpltWithPurchaseItems(String requestSupvsrId,String empId, String employeeName,String assmtId,String emailGroup) throws Exception {
		SendMailVO email = new SendMailVO();
		List<String> toAddresLst = new ArrayList<String>();
		List<String> ccAddresLst = new ArrayList<String>();
		email.setContentType("text/html");
		String subject = "Test";
		String link = "";

		String environment = getEnvironment();
		if ((!Strings.isNullOrEmpty(environment))) {
			switch (environmentEnum.valueOf(environment)) {
			case local: {
				subject = "LOCAL : Ergonomics Assessment Completed";
				link = "<a href='" + localAppUrl + "?q=" + encrypt(assmtId,ENCRYPT_KEY) + "'> click here </a>";
				toAddresLst.add("xprk408");
				//toAddresLst.add(requestSupvsrId);
				ccAddresLst.add(EGN_IH_Mail_group);
				break;
			}
			case dev: {
				subject = "DEV : Ergonomics Assessment Completed";
				link = "<a href='" + devAppUrl + "?q=" + encrypt(assmtId,ENCRYPT_KEY) + "'> click here </a>";
				//toAddresLst.add(requestSupvsrId);
				ccAddresLst.add(EGN_IH_Mail_group);
				toAddresLst.add("xsat860");
				break;
			}
			case test: {
				subject = "TEST : Ergonomics Assessment Completed";
				link = "<a href='" + testAppUrl + "?q=" + encrypt(assmtId,ENCRYPT_KEY) + "'> click here </a>";
				//toAddresLst.add(requestSupvsrId);
				ccAddresLst.add(EGN_IH_Mail_group);
				toAddresLst.add("xsat860");
				break;
			}
			case prod: {
				subject = "PROD: Ergonomics Assessment Completed";
				link = "<a href='" + prodAppUrl + "?q=" + encrypt(assmtId,ENCRYPT_KEY) + "'> click here </a>";
				//toAddresLst.add(requestSupvsrId);
				toAddresLst.add("xsat860");
				ccAddresLst.add(EGN_IH_Mail_group);
				break;
			}
			default:
				break;

			}
		}
		email.setToAddressLst(toAddresLst);
		email.setCcAddressLst(ccAddresLst);
		email.setSubject(subject);
		email.setBodyContent("<strong>TO :</strong> "+empId+" <br/><strong>CC :</strong>"+EGN_IH_Mail_group+" <br/><strong>FROM :</strong> noreply@UP.com <br/>"
				+ "<br/> The Ergonomics Assessment has been completed for " + employeeName + ".  Please " 
				+ link + 
				" to review the Assessment and provide the required approvals for items to be purchased."+ 
				"<br/><br/> Please contact the EGN_Support group via Lotus Notes if you have questions or concerns regarding this request.");
		return email;
	}

	public static SendMailVO setEmlForAsmtCmpltWithoutPurchaseItems(String requestSupvsrId,String empId, String employeeName,String assmtId,String emailGroup) throws Exception {
		SendMailVO email = new SendMailVO();
		List<String> toAddresLst = new ArrayList<String>();
		List<String> ccAddresLst = new ArrayList<String>();
		email.setContentType("text/html");
		String subject = "Test";
		String link = "";

		String environment = getEnvironment();
		if ((!Strings.isNullOrEmpty(environment))) {
			switch (environmentEnum.valueOf(environment)) {
			case local: {
				subject = "LOCAL : Ergonomics Assessment Completed";
				link = "<a href='" + localAppUrl + "?q=" + encrypt(assmtId,ENCRYPT_KEY) + "'> click here </a>";
				toAddresLst.add("xprk408");
				//toAddresLst.add(requestSupvsrId);
				ccAddresLst.add(EGN_IH_Mail_group);
				break;
			}

			case dev: {
				subject = "DEV : Ergonomics Assessment Completed";
				link = "<a href='" + devAppUrl + "?q=" + encrypt(assmtId,ENCRYPT_KEY) + "'> click here </a>";
				toAddresLst.add("xsat860");
				ccAddresLst.add(EGN_IH_Mail_group);
				// toAddresLst.add("xsat860");
				break;
			}

			case test: {
				subject = "TEST : Ergonomics Assessment Completed";
				link = "<a href='" + testAppUrl + "?q=" + encrypt(assmtId,ENCRYPT_KEY) + "'> click here </a>";
				toAddresLst.add("xsat860");
				ccAddresLst.add(EGN_IH_Mail_group);
				break;
			}

			case prod: {
				subject = "PROD: Ergonomics Assessment Completed";
				link = "<a href='" + prodAppUrl + "?q=" + encrypt(assmtId,ENCRYPT_KEY) + "'> click here </a>";
				toAddresLst.add(requestSupvsrId);
				ccAddresLst.add(EGN_IH_Mail_group);
				break;
			}
			default:
				break;

			}
		}

		email.setToAddressLst(toAddresLst);
		email.setCcAddressLst(ccAddresLst);
		email.setSubject(subject);
		email.setBodyContent("<strong>TO :</strong> "+requestSupvsrId+" <br/><strong>CC :</strong>"+EGN_IH_Mail_group+" <br/><strong>FROM :</strong> noreply@UP.com <br/><br/> Your Ergonomics Assessment has been completed.  Please " + link
				+ " to review the findings. <br/><br/> Please contact the EGN_Support group via Lotus Notes if you have questions or concerns regarding this request.");
		return email;
	}

	public static SendMailVO setEmlForAsmtCmpltdNPrchseItmsCmpltd(String requestSupvsrId, String employeeName,String requestId,String emailGroup) throws Exception {
		SendMailVO email = new SendMailVO();
		List<String> toAddresLst = new ArrayList<String>();
		List<String> ccAddresLst = new ArrayList<String>();

		email.setContentType("text/html");
		String subject = "Test";
		String link = "";

		String environment = getEnvironment();
		if ((!Strings.isNullOrEmpty(environment))) {
			switch (environmentEnum.valueOf(environment)) {
			case local: {
				subject = "LOCAL : Ergonomics Assessment Completed and Purchases are complete";
				link = "<a href='" + localAppUrl + "?q=" + encrypt(requestId,ENCRYPT_KEY) + "'> click here </a>";
				toAddresLst.add("xprk408"); 
				//toAddresLst.add(requestSupvsrId);
				ccAddresLst.add(EGN_IH_Mail_group);
				break;
			}

			case dev: {
				subject = "DEV : Ergonomics Assessment Completed and Purchases are complete";
				link = "<a href='" + devAppUrl + "?q=" + encrypt(requestId,ENCRYPT_KEY) + "'> click here </a>";
				toAddresLst.add("xsat860");
				ccAddresLst.add(EGN_IH_Mail_group);
				// toAddresLst.add("xsat860");
				break;
			}
			case test: {
				subject = "TEST : Ergonomics Assessment Completed and Purchases are complete";
				link = "<a href='" + testAppUrl + "?q=" + encrypt(requestId,ENCRYPT_KEY) + "'> click here </a>";
				toAddresLst.add("xsat860");
				ccAddresLst.add(EGN_IH_Mail_group);
				break;
			}
			case prod: {
				subject = "PROD: Ergonomics Assessment Completed and Purchases are complete";
				link = "<a href='" + prodAppUrl + "?q=" + encrypt(requestId,ENCRYPT_KEY) + "'> click here </a>";
				toAddresLst.add(requestSupvsrId);
				ccAddresLst.add(EGN_IH_Mail_group);
				break;
			}
			default:
				break;

			}
		}
		email.setToAddressLst(toAddresLst);
		email.setCcAddressLst(ccAddresLst);
		email.setSubject(subject);
		email.setBodyContent(
				"<strong>TO :</strong> "+requestSupvsrId+" <br/><strong>CC :</strong>"+EGN_IH_Mail_group+" <br/><strong>FROM :</strong> noreply@UP.com <br/><br/> All items to be purchased have been addressed.  The Ergonomics Assessment process is now complete.  Please "
						+ link
						+ " to view the request. <br/><br/> Please contact the EGN_Support group via Lotus Notes if you have questions or concerns regarding this request.");
		return email;
	}
	
	public static SendMailVO setEmlForAsmtPrvidedNPrchseItmsRqrd(String requestSupvsrId, String employeeId,String assmtId,String emailGroup) throws Exception {
		SendMailVO email = new SendMailVO();
		List<String> toAddresLst = new ArrayList<String>();
		List<String> ccAddresLst = new ArrayList<String>();

		email.setContentType("text/html");
		String subject = "Test";
		String link = "";

		String environment = getEnvironment();
		if ((!Strings.isNullOrEmpty(environment))) {
			switch (environmentEnum.valueOf(environment)) {
			case local: {
				subject = "LOCAL : Ergonomics Assessment Provided "+"-"+" Approved Purchases Required";
				link = "<a href='" + localAppUrl + "?q=" + encrypt(assmtId,ENCRYPT_KEY) + "'> click here </a>";
				toAddresLst.add("xprk408");
				
			/*	toAddresLst.add(EGN_BuildingSupplies_Mail_Group);
				ccAddresLst.add("xsat860");
				ccAddresLst.add("xsat860");
				ccAddresLst.add(EGN_IH_Mail_group);*/
				break;
			}

			case dev: {
				subject = "DEV : Ergonomics Assessment Provided "+"-"+" Approved Purchases Required";
				link = "<a href='" + devAppUrl + "?q=" + encrypt(assmtId,ENCRYPT_KEY) + "'> click here </a>";
				/*toAddresLst.add(devEGNBuildingSuppliesMailGroup);
				ccAddresLst.add(requestSupvsrId);
				ccAddresLst.add(employeeId);
				ccAddresLst.add(devIHTeamMailGroup);*/
				toAddresLst.add("xprk408");
				ccAddresLst.add("xsat860");
				break;
			}
			case test: {
				subject = "TEST : Ergonomics Assessment Provided "+"-"+" Approved Purchases Required";
				link = "<a href='" + testAppUrl + "?q=" + encrypt(assmtId,ENCRYPT_KEY) + "'> click here </a>";
				/*toAddresLst.add(devEGNBuildingSuppliesMailGroup);
				ccAddresLst.add(requestSupvsrId);
				ccAddresLst.add(employeeId);
				ccAddresLst.add(devIHTeamMailGroup);*/
				toAddresLst.add("xsat860");
				ccAddresLst.add("xsat860");
				ccAddresLst.add("xsat860");
				ccAddresLst.add("xsat860");
				break;
			}
			case prod: {
				subject = "PROD: Ergonomics Assessment Provided "+"-"+" Approved Purchases Required";
				link = "<a href='" + prodAppUrl + "?q=" + encrypt(assmtId,ENCRYPT_KEY) + "'> click here </a>";
				/*toAddresLst.add(devEGNBuildingSuppliesMailGroup);
				ccAddresLst.add(requestSupvsrId);
				ccAddresLst.add(employeeId);
				ccAddresLst.add(devIHTeamMailGroup);*/
				toAddresLst.add("xsat860");
				ccAddresLst.add("xsat860");
				ccAddresLst.add("xsat860");
				ccAddresLst.add("xsat860");
				break;
			}
			default:
				break;

			}
		}
		email.setToAddressLst(toAddresLst);
		email.setCcAddressLst(ccAddresLst);
		email.setSubject(subject);
		email.setBodyContent(
				"<strong>TO :</strong> "+EGN_BuildingSupplies_Mail_Group+" <br/><strong>CC :</strong>"+EGN_IH_Mail_group+" <br/><strong>FROM :</strong> noreply@UP.com <br/><br/> The completion of an Ergonomics Assessment has resulted in the need to order and purchase certain office supplies for.  Please "
						+ link +
						" to review the list of items. <br/> Please change the status for the item to Ordered once the order has been submitted. Then change the  status to Complete for the item has been delivered to the employee. <br/> <br/>Please contact the EGN_Support group via Lotus Notes if you have questions or concerns regarding this request.");
		return email;
	}
	
	public static SendMailVO setEmlForNonMedicalRequestSubmitted(String requestSupvsrId, String employeeId,String submitterEmpId , String reqId,String employeeName) throws Exception {
		SendMailVO email = new SendMailVO();
		List<String> toAddresLst = new ArrayList<String>();
		List<String> ccAddresLst = new ArrayList<String>();

		email.setContentType("text/html");
		String subject = "Test";
		String link = "";

		String environment = getEnvironment();
		if ((!Strings.isNullOrEmpty(environment))) {
			switch (environmentEnum.valueOf(environment)) {
			case local: {
				subject = "LOCAL : New Ergonomics Request Requires Approval";
				link = "<a href='" + localAppUrl + "?q=" + encrypt(reqId,ENCRYPT_KEY) + "'> click here </a>";
				toAddresLst.add("xprk408");
				
				/*toAddresLst.add("xsat860");
				ccAddresLst.add("xsat860");
				ccAddresLst.add("xsat860");
				ccAddresLst.add(EGN_IH_Mail_group);*/
				break;
			}

			case dev: {
				subject = "DEV : New Ergonomics Request Requires Approval";
				link = "<a href='" + devAppUrl + "?q=" + encrypt(reqId,ENCRYPT_KEY) + "'> click here </a>";
				/*toAddresLst.add(devEGNBuildingSuppliesMailGroup);
				ccAddresLst.add(requestSupvsrId);
				ccAddresLst.add(employeeId);
				ccAddresLst.add(devIHTeamMailGroup);*/
				toAddresLst.add("xsat860");
				ccAddresLst.add("xsat860");
				ccAddresLst.add("xsat860");
				ccAddresLst.add("xsat860");
				break;
			}
			case test: {
				subject = "TEST : New Ergonomics Request Requires Approval";
				link = "<a href='" + testAppUrl + "?q=" + encrypt(reqId,ENCRYPT_KEY) + "'> click here </a>";
				/*toAddresLst.add(devEGNBuildingSuppliesMailGroup);
				ccAddresLst.add(requestSupvsrId);
				ccAddresLst.add(employeeId);
				ccAddresLst.add(devIHTeamMailGroup);*/
				toAddresLst.add("xsat860");
				ccAddresLst.add("xsat860");
				ccAddresLst.add("xsat860");
				ccAddresLst.add("xsat860");
				break;
			}
			case prod: {
				subject = "PROD: New Ergonomics Request Requires Approval";
				link = "<a href='" + prodAppUrl + "?q=" + encrypt(reqId,ENCRYPT_KEY) + "'> click here </a>";
				/*toAddresLst.add(devEGNBuildingSuppliesMailGroup);
				ccAddresLst.add(requestSupvsrId);
				ccAddresLst.add(employeeId);
				ccAddresLst.add(devIHTeamMailGroup);*/
				toAddresLst.add("xsat860");
				ccAddresLst.add("xsat860");
				ccAddresLst.add("xsat860");
				ccAddresLst.add("xsat860");
				break;
			}
			default:
				break;

			}
		}
		email.setToAddressLst(toAddresLst);
		email.setCcAddressLst(ccAddresLst);
		email.setSubject(subject);
		email.setBodyContent(
				"<strong>TO :</strong> "+requestSupvsrId+" <br/><strong>CC :</strong>"+EGN_IH_Mail_group+","+employeeId+","+submitterEmpId+" <br/><strong>FROM :</strong> noreply@UP.com <br/><br/>  "+employeeName+" has submitted a new Ergonomics Request.  Please "
						+ link +
						" to approve or reject the request. <br/> The Cost Center identified on the record will be charged for the Assessment. <br/><br/> Please contact the EGN_Support group via Lotus Notes if you have questions or concerns regarding this request.");
		return email;
	}
	public static SendMailVO setEmlForMedicalRequestSubmitted(String requestSupvsrId, String employeeId,String reqId,String employeeName) throws Exception {
		SendMailVO email = new SendMailVO();
		List<String> toAddresLst = new ArrayList<String>();
		List<String> ccAddresLst = new ArrayList<String>();

		email.setContentType("text/html");
		String subject = "Test";
		String link = "";

		String environment = getEnvironment();
		if ((!Strings.isNullOrEmpty(environment))) {
			switch (environmentEnum.valueOf(environment)) {
			case local: {
				subject = "LOCAL : New Ergonomics Health and Medical Request Requires Approval";
				link = "<a href='" + localAppUrl + "?q=" + encrypt(reqId,ENCRYPT_KEY) + "'> click here </a>";
				toAddresLst.add("xprk408");
				
			/*	toAddresLst.add(EGN_HealthandMedical_Mail_Group);
				ccAddresLst.add("xsat860");
				ccAddresLst.add("xsat860");
				ccAddresLst.add(EGN_IH_Mail_group);*/
				break;
			}

			case dev: {
				subject = "DEV : New Ergonomics Health and Medical Request Requires Approval";
				link = "<a href='" + devAppUrl + "?q=" + encrypt(reqId,ENCRYPT_KEY) + "'> click here </a>";
				/*toAddresLst.add(devEGNBuildingSuppliesMailGroup);
				ccAddresLst.add(requestSupvsrId);
				ccAddresLst.add(employeeId);
				ccAddresLst.add(devIHTeamMailGroup);*/
				toAddresLst.add(EGN_HealthandMedical_Mail_Group);
				/*ccAddresLst.add("xsat860");*/
				ccAddresLst.add("xsat860");
				ccAddresLst.add(EGN_IH_Mail_group);
				break;
			}
			case test: {
				subject = "TEST : New Ergonomics Health and Medical Request Requires Approval";
				link = "<a href='" + testAppUrl + "?q=" + encrypt(reqId,ENCRYPT_KEY) + "'> click here </a>";
				/*toAddresLst.add(devEGNBuildingSuppliesMailGroup);
				ccAddresLst.add(requestSupvsrId);
				ccAddresLst.add(employeeId);
				ccAddresLst.add(devIHTeamMailGroup);*/
				toAddresLst.add(EGN_HealthandMedical_Mail_Group);
				/*ccAddresLst.add("xsat860");*/
				ccAddresLst.add("xsat860");
				ccAddresLst.add(EGN_IH_Mail_group);
				break;
			}
			case prod: {
				subject = "PROD: New Ergonomics Health and Medical Request Requires Approval";
				link = "<a href='" + prodAppUrl + "?q=" + encrypt(reqId,ENCRYPT_KEY) + "'> click here </a>";
				/*toAddresLst.add(devEGNBuildingSuppliesMailGroup);
				ccAddresLst.add(requestSupvsrId);
				ccAddresLst.add(employeeId);
				ccAddresLst.add(devIHTeamMailGroup);*/
				toAddresLst.add(EGN_HealthandMedical_Mail_Group);
				/*ccAddresLst.add("xsat860");*/
				ccAddresLst.add("xsat860");
				ccAddresLst.add(EGN_IH_Mail_group);
				break;
			}
			default:
				break;

			}
		}
		email.setToAddressLst(toAddresLst);
		email.setCcAddressLst(ccAddresLst);
		email.setSubject(subject);
		email.setBodyContent(
				"<strong>TO :</strong> "+EGN_HealthandMedical_Mail_Group+" <br/><strong>CC :</strong>"+EGN_IH_Mail_group+","+employeeId+" <br/><strong>FROM :</strong> noreply@UP.com <br/><br/> "+employeeName+" has submitted a new Ergonomics Request.  Please "
						+ link +
						" to approve or reject the request. <br/> The Cost Center identified on the record will be charged for the Assessment. <br/><br/> Please contact the EGN_Support group via Lotus Notes if you have questions or concerns regarding this request.");
		return email;
	}
	
	public static String encrypt(String strClearText,String strKey) throws Exception{
		String strData= randomAlphaNumeric(6) + "#" + strClearText;
		
		String asB64 = Base64.getEncoder().encodeToString(strData.getBytes("utf-8"));
		System.out.println(asB64); // Output will be: c29tZSBzdHJpbmc=
		
		/*try {
			SecretKeySpec skeyspec=new SecretKeySpec(strKey.getBytes(StandardCharsets.UTF_8),"AES");
			Cipher cipher=Cipher.getInstance("AES/CBC/PKCS5Padding");
			cipher.init(Cipher.ENCRYPT_MODE, skeyspec);
			byte[] encrypted=cipher.doFinal(strClearText.getBytes(StandardCharsets.UTF_8));
			strData=new String(encrypted);
			
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e);
		}*/
		return asB64;
	}
	
	public static String decrypt(String strEncrypted,String strKey) throws Exception{
		String strData="";
		
		byte[] asBytes = Base64.getDecoder().decode(strEncrypted);
		strData = new String(asBytes, "utf-8");
		System.out.println(strData); // And the output is: some string
		/*try {
			SecretKeySpec skeyspec=new SecretKeySpec(strKey.getBytes(StandardCharsets.UTF_8),"AES");
			Cipher cipher=Cipher.getInstance("AES/CBC/PKCS5Padding");
			cipher.init(Cipher.DECRYPT_MODE, skeyspec);
			byte[] decrypted=cipher.doFinal(strEncrypted.getBytes(StandardCharsets.UTF_8));
			strData=new String(decrypted);
			
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e);
		}*/
		
		String temp[] = strData.split("#");
		
		return temp[1];
	}

	public static String randomAlphaNumeric(int count) {
		StringBuilder builder = new StringBuilder();
		while (count-- != 0) {
		int character = (int)(Math.random()*EGNConstants.ALPHA_NUMERIC_STRING.length());
		builder.append(EGNConstants.ALPHA_NUMERIC_STRING.charAt(character));
		}
		return builder.toString();
	}

}