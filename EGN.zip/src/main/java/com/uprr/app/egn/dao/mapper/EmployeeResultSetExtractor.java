package com.uprr.app.egn.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.uprr.app.egn.dto.LoggedUserVO;

public class EmployeeResultSetExtractor<T> implements ResultSetExtractor<T> {

	public T extractData(ResultSet rs) throws SQLException,
	DataAccessException {
		LoggedUserVO emp = new LoggedUserVO();
		
		emp.setUserId("");
		emp.setEmployeeId(rs.getString("emplid"));
		emp.setFirstName(rs.getString("first_name"));
		emp.setMiddleName(rs.getString("middle_name"));
		emp.setLastName(rs.getString("last_name"));
		emp.setFullName(rs.getString("name"));
		emp.setCostCenter(rs.getString("upc_cost_center"));
		emp.setBuilding(rs.getString("upc_bldg_address1"));
		emp.setCity(rs.getString("upc_bldg_city"));
		emp.setState(rs.getString("upc_bldg_state"));
		emp.setWorkstationId(rs.getString("upc_wrk_space"));
		emp.setPhone(rs.getString("work_phone"));
		emp.setEmail(rs.getString("email_addr"));
		emp.setSupervisorUserId("");
		emp.setSupervisorName(rs.getString("supervisor_name"));
		emp.setSupervisorEmail(rs.getString("supervisor_email"));
		emp.setSupervisorEmpId(rs.getString("supervisor_id"));
		emp.setSupervisorPh(rs.getString("supervisor_ph"));
		
		return (T) emp;
	}

}
