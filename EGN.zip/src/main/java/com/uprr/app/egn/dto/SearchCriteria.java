package com.uprr.app.egn.dto;

public class SearchCriteria {
	int currentPage;
	int endIndex;
	String orderByColumn;
	int recordsCount;
	String sortingType;
	int startIndex;
	int totalPages;
	int recordsPerPage;
	boolean isExportExcel;
	private String fromDate;
	private String toDate;
	private String employeeId;
	private String status;
	private String role;
	private String supvId;
	
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getSupvId() {
		return supvId;
	}
	public void setSupvId(String supvId) {
		this.supvId = supvId;
	}
	public int getCurrentPage() {
		return currentPage;
	}
	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}
	public int getEndIndex() {
		return endIndex;
	}
	public void setEndIndex(int endIndex) {
		this.endIndex = endIndex;
	}
	public String getOrderByColumn() {
		return orderByColumn;
	}
	public void setOrderByColumn(String orderByColumn) {
		this.orderByColumn = orderByColumn;
	}
	public int getRecordsCount() {
		return recordsCount;
	}
	public void setRecordsCount(int recordsCount) {
		this.recordsCount = recordsCount;
	}
	public String getSortingType() {
		return sortingType;
	}
	public void setSortingType(String sortingType) {
		this.sortingType = sortingType;
	}
	public int getStartIndex() {
		return startIndex;
	}
	public void setStartIndex(int startIndex) {
		this.startIndex = startIndex;
	}
	public int getTotalPages() {
		return totalPages;
	}
	public void setTotalPages(int totalPages) {
		this.totalPages = totalPages;
	}
	public int getRecordsPerPage() {
		return recordsPerPage;
	}
	public void setRecordsPerPage(int recordsPerPage) {
		this.recordsPerPage = recordsPerPage;
	}
	public boolean isExportExcel() {
		return isExportExcel;
	}
	public void setExportExcel(boolean isExportExcel) {
		this.isExportExcel = isExportExcel;
	}
	
	public SearchCriteria() {
		super();
		// TODO Auto-generated constructor stub
	}
	public SearchCriteria(int currentPage, int endIndex, String orderByColumn, int recordsCount, String sortingType,
			int startIndex, int totalPages, int recordsPerPage, boolean isExportExcel, String fromDate, String toDate,
			String employeeId, String status, String role, String supvId) {
		super();
		this.currentPage = currentPage;
		this.endIndex = endIndex;
		this.orderByColumn = orderByColumn;
		this.recordsCount = recordsCount;
		this.sortingType = sortingType;
		this.startIndex = startIndex;
		this.totalPages = totalPages;
		this.recordsPerPage = recordsPerPage;
		this.isExportExcel = isExportExcel;
		this.fromDate = fromDate;
		this.toDate = toDate;
		this.employeeId = employeeId;
		this.status = status;
		this.role = role;
		this.supvId = supvId;
	}
	@Override
	public String toString() {
		return "SearchCriteria [currentPage=" + currentPage + ", endIndex=" + endIndex + ", orderByColumn="
				+ orderByColumn + ", recordsCount=" + recordsCount + ", sortingType=" + sortingType + ", startIndex="
				+ startIndex + ", totalPages=" + totalPages + ", recordsPerPage=" + recordsPerPage + ", isExportExcel="
				+ isExportExcel + ", fromDate=" + fromDate + ", toDate=" + toDate + ", employeeId=" + employeeId
				+ ", status=" + status + ", role=" + role + ", supvId=" + supvId + "]";
	}
	
		
	
	
}
