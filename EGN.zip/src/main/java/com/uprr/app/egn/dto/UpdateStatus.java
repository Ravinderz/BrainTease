package com.uprr.app.egn.dto;

import java.util.List;

public class UpdateStatus {

	private String status;
	private String empId;
	private String evalRequestByEmplId;
	private String rejectReason;
	private List<String> requestIds;
	private List<WorkstationEvaluation> workstationEvaluationList;
	
	
	
	
	
	public String getEvalRequestByEmplId() {
		return evalRequestByEmplId;
	}
	public void setEvalRequestByEmplId(String evalRequestByEmplId) {
		this.evalRequestByEmplId = evalRequestByEmplId;
	}
	public String getRejectReason() {
		return rejectReason;
	}
	public void setRejectReason(String rejectReason) {
		this.rejectReason = rejectReason;
	}
	public List<WorkstationEvaluation> getWorkstationEvaluationList() {
		return workstationEvaluationList;
	}
	public void setWorkstationEvaluation(List<WorkstationEvaluation> workstationEvaluationList) {
		this.workstationEvaluationList = workstationEvaluationList;
	}
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public List<String> getRequestIds() {
		return requestIds;
	}
	public void setRequestIds(List<String> requestIds) {
		this.requestIds = requestIds;
	}
	
	
	public UpdateStatus() {
		super();
	}
	
	
	public UpdateStatus(String status, String empId, String rejectReason, List<String> requestIds,
			List<WorkstationEvaluation> workstationEvaluationList) {
		super();
		this.status = status;
		this.empId = empId;
		this.rejectReason = rejectReason;
		this.requestIds = requestIds;
		this.workstationEvaluationList = workstationEvaluationList;
	}
	@Override
	public String toString() {
		return "UpdateStatus [status=" + status + ", empId=" + empId + ", rejectReason=" + rejectReason
				+ ", requestIds=" + requestIds + ", workstationEvaluationList=" + workstationEvaluationList + "]";
	}
	
	
	
	
	
	
	
}
