package com.uprr.app.egn.service;

import java.util.List;

import org.springframework.jms.JmsException;

public interface IEmpCostCenterService {

	public List<String> getCostCenterDetails(String employeeId) throws Exception, JmsException;
}
