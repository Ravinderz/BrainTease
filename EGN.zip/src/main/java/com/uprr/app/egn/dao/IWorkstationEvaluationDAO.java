package com.uprr.app.egn.dao;

import java.util.List;

import com.uprr.app.egn.dto.Document;
import com.uprr.app.egn.dto.SearchCriteria;
import com.uprr.app.egn.dto.UpdateStatus;
import com.uprr.app.egn.dto.WorkstationEvaluation;


public interface IWorkstationEvaluationDAO {


	 List<WorkstationEvaluation> getRequestData(String supvid);
	 
	 List<WorkstationEvaluation> getMedicalRejectedRequestsForSupervisorData(String supvid);
	 
	 List<WorkstationEvaluation> getAllMedicalRequests();
	 
	 List<WorkstationEvaluation> getRequestData();
	 
	 List<WorkstationEvaluation> getPaginatedRequestData(SearchCriteria searchCriteria);
	 
	 List<WorkstationEvaluation> getAllRequestsByUser(String userId,SearchCriteria searchCriteria);

	 /*boolean submitWorkStationRequest(WorkstationEvaluation WSEvaluation);*/
	 
	 int submitWorkStationRequest(WorkstationEvaluation WSEvaluation);

	 boolean updateWorkStationRequest(WorkstationEvaluation WSEvaluation);

	 boolean updateStatus(UpdateStatus updateStatus);
	
	 WorkstationEvaluation getRequestById(String requestId);
	 
	 List<WorkstationEvaluation> getRequestByUser(String emplId);
	
	 List<Document> getDocumentsByRequestId(String requestId);
	 
	 int saveWorkStationRequest(WorkstationEvaluation wSEvaluation);
	 
	 List<WorkstationEvaluation> getNonMedicalRequests(String supvId,SearchCriteria searchCriteria);
	 
	 List<WorkstationEvaluation> searchNonMedicalRequests(String supvId,SearchCriteria searchCriteria);
	 
	 int getUserRequestsCount(String userId);
	 
	 int getResultsForSpecialistCount();
	 
	 List<WorkstationEvaluation> getResultsForSpecialist(SearchCriteria searchCriteria);

	List<WorkstationEvaluation> getResultsForFacilitiesMgmt(SearchCriteria searchCriteria);
	
	public boolean updateStatus(String reqId,String empId,String status);

	int getResultsForFacilitiesMgmtCount();

	List<WorkstationEvaluation> getResultsForFacilitiesMgmtWithCrtrea(SearchCriteria searchCriteria);

	int getResultsForFacilitiesMgmtCountWithCrtrea(SearchCriteria searchCriteria);

}
