package com.uprr.app.egn.service;

import org.springframework.jms.JmsException;

import com.uprr.app.egn.dto.SendMailVO;

public interface IEmailService {

	void sendEmailNotification(SendMailVO sendMailVO) throws Exception, JmsException;
}
