package com.uprr.app.egn.service;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.uprr.app.egn.dto.Document;

/**
 * Doc class to fetch/store documents for EGN Project.
 * @Author: (Krish)nappan Muthuraman (iots242)
 * Date: 05/14/18
 */

public interface IDocService {

	void callEchoService() throws Exception;
	Document persistDoc(MultipartFile file) throws Exception;
	byte[] getDoc(String docId) throws Exception;
	public boolean saveDocs(List<Document> docs);
}
