/**
Author: (Krish)nappan Muthuraman (iots242)
Date: 05/01/18
*/

package com.uprr.app.egn.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.uprr.ui.shared.user.ActiveUserId;


public class EgnInterceptor extends HandlerInterceptorAdapter {

	Logger logger = LogManager.getLogger(EgnInterceptor.class);

	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
		logger.info("inside preHandle inteceptor");
		logger.info(request.getRequestURI());	
		logger.info(request.getHeader(ActiveUserId.SMHEADER_USER));
		logger.info(request.getHeader(ActiveUserId.SMHEADER_EMPLOYEE_ID));
		logger.info("response "+response);
		return true;
	}

	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
		// Default implementation used.
	}

}
