package com.uprr.app.egn.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.uprr.app.egn.dto.Document;

public class DocumentResultSetExtractor<T> implements ResultSetExtractor<T> {
	

	public T extractData(ResultSet rs) throws SQLException,
			DataAccessException {
		Document doc = new Document();
		doc.setRequestId(rs.getString("req_id"));
		doc.setDocumentGuid(rs.getString("doc_guid"));
		doc.setDocumentName(rs.getString("doc_name"));
		doc.setDocumentDesc(rs.getString("doc_desc"));
		doc.setCreatedBy(rs.getString("crtd_user_id"));
		doc.setCreationDate(rs.getString("crtn_tmst"));
		doc.setUpdatedBy(rs.getString("last_uptd_user_id"));
		doc.setUpdatedDate(rs.getString("last_uptd_tmst"));
		return (T) doc;
	}
	

}