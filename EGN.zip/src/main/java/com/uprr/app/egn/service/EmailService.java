package com.uprr.app.egn.service;

import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;

import com.uprr.app.egn.dto.SendMailVO;
import com.uprr.app.egn.util.EGNConstants;
import com.uprr.app.xmf.MessageUtilities;
import com.uprr.app.xmf.client.ServiceProxy;

/**
 * Service to send Email from EGN
 * @author xprk408
 * Date : May 5, 2018.
 */
@Service
public class EmailService implements IEmailService{

	@Autowired
	JmsTemplate jmsTemplate;
	
	@Autowired
	ServiceProxy serviceProxy;
	
	@Autowired
	MessageUtilities messageUtilities;
	
	@Autowired
	JAXBContext context;
	
	Logger logger = LogManager.getLogger(EmailService.class);

	@Override
	public void sendEmailNotification(SendMailVO sendMailVO) throws Exception { 
		logger.info("entered the send email notification method");
		if (sendMailVO.getToAddressLst().size() < 1) { // min of 1 recipient
			logger.error("Sending ENA Notification -- To Address cannot be empty.");
		};
		if (sendMailVO.getBodyContent() == null || sendMailVO.getBodyContent().equals("")) {
			logger.error("Sending ENA Notification -- Message body cannot be empty.");
		}
		
		//JAXBContext context = JAXBContext.newInstance(ObjectFactory.class);
		Marshaller marshallerObj = context.createMarshaller();  
	    //marshallerObj.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		marshallerObj.setProperty("jaxb.fragment", Boolean.TRUE);
	    StringWriter sw = new StringWriter();
	    marshallerObj.marshal(sendMailVO.buildNotificationRequest(), sw);
		
		String emailMsgString = sw.toString();
		logger.info(emailMsgString);
		sendMessage(emailMsgString);
	}
	
	private void sendMessage(final String strmsg) {
		
		String responseXML = null;
		try {
		
		String serviceName = EGNConstants.EMAIL_SERVICE_NAME;
		
		String requestor = EGNConstants.EMAIL_SERVICE_REQUESTOR;
		
		String xmfHeader = messageUtilities.createXMFRequestHeader(requestor, serviceName);
		logger.info(xmfHeader);
		String requestMessage = messageUtilities.createXMFMessage(xmfHeader, strmsg );
		logger.info(requestMessage);
        
		String replyMessage = serviceProxy.invoke(requestMessage, 100000);
		logger.info(replyMessage);
		
    	/* Validate XMF response */
		if (replyMessage == null) {
			logger.error("XMF Service [" + serviceName + "] response is null. \nService [" + serviceName + "] Timeout [10000]");
			throw new Exception("XMF Service [" + serviceName + "] response is null");
		}
		
		/* Extract the body from XMF response */
		responseXML = messageUtilities.getXMFBody(replyMessage);
		logger.info("Service [" + serviceName + "] response: \n" + responseXML);
		
		/* Verify the response body */
		String errorDetails = null;
		if (messageUtilities.isFault(responseXML)) {
			// Get the error details
			errorDetails = messageUtilities.getFaultDetail(responseXML);
			// could be infrastructure connectivity is up but the service is not in working state
			logger.error("XMF Service [" + serviceName + "] response is faulty. " + errorDetails);
			throw new Exception("XMF Service [" + serviceName + "] response is faulty. " + errorDetails);
		}
		logger.info("Response XML : " + replyMessage);
		
	} catch (Exception e) {
		logger.error("Error occured while sending email notification . : " + e.getMessage());
	}
	} 

}
