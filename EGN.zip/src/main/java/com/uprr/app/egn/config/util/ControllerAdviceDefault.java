package com.uprr.app.egn.config.util;

/**
 * Default Advice for EGN Project
 * @Author: (Krish)nappan Muthuraman (iots242)
 * Date: 05/01/18
*/

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

@ControllerAdvice
public class ControllerAdviceDefault {
	private static final String className = ControllerAdviceDefault.class.getName();

	@ExceptionHandler(RuntimeException.class)
	@ResponseBody
	public ResponseEntity<ClientError> handleSystemException(final RuntimeException ex) {
		final ClientError error = new ClientError("System Error ", "System error has occurred. ");
		return new ResponseEntity<ClientError>(error, HttpStatus.INTERNAL_SERVER_ERROR);
	}

}
