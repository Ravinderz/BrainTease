package com.uprr.app.egn.dto;

public class WorkstationEvaluation {

	private String requestId;
	private String assessmentId;
	private String empName;
	private String empId;
	private String empWorkstationLocCity;
	private String empWorkstationLocBld;
	private String empShiftHrs;
	private String requestingSupervisor;
	private String requestDate;
	private String requestingSupervisorPhNo;
	private String requestingSupervisorEmail;
	private String requestingSupervisorId;
	private String costCenter;
	private String workAddressOther;
	private boolean medical;
	private boolean nonMedical;
	private String expDateOfReturn;
	private String fFDNurseName;
	private String physicianName;
	private String physicianPhNo;
	private String wsEvalDesc;
	private String status;
	private Checkbox checkbox;
	private String empWrkActOthr;
	private String wrkEvalScopOthr;
	private String strAddr;
	private String cityInfo;
	private String zipCode;
	private String createdBy;
	private String createdDate;
	private String updatedBy;
	private String updatedDate;						
	
	
	public String getStrAddr() {
		return strAddr;
	}
	public void setStrAddr(String strAddr) {
		this.strAddr = strAddr;
	}
	public String getCityInfo() {
		return cityInfo;
	}
	public void setCityInfo(String cityInfo) {
		this.cityInfo = cityInfo;
	}
	public String getZipCode() {
		return zipCode;
	}
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public String getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(String updatedDate) {
		this.updatedDate = updatedDate;
	}
	public String getAssessmentId() {
		return assessmentId;
	}
	public void setAssessmentId(String assessmentId) {
		this.assessmentId = assessmentId;
	}
	public String getRequestId() {
		return requestId;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	public Checkbox getCheckbox() {
		return checkbox;
	}
	public void setCheckbox(Checkbox checkbox) {
		this.checkbox = checkbox;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public String getEmpWorkstationLocCity() {
		return empWorkstationLocCity;
	}
	public void setEmpWorkstationLocCity(String empWorkstationLocCity) {
		this.empWorkstationLocCity = empWorkstationLocCity;
	}
	public String getEmpWorkstationLocBld() {
		return empWorkstationLocBld;
	}
	public void setEmpWorkstationLocBld(String empWorkstationLocBld) {
		this.empWorkstationLocBld = empWorkstationLocBld;
	}
	public String getEmpShiftHrs() {
		return empShiftHrs;
	}
	public void setEmpShiftHrs(String empShiftHrs) {
		this.empShiftHrs = empShiftHrs;
	}
	public String getRequestingSupervisor() {
		return requestingSupervisor;
	}
	public void setRequestingSupervisor(String requestingSupervisor) {
		this.requestingSupervisor = requestingSupervisor;
	}
	public String getRequestDate() {
		return requestDate;
	}
	public void setRequestDate(String requestDate) {
		this.requestDate = requestDate;
	}
	public String getRequestingSupervisorPhNo() {
		return requestingSupervisorPhNo;
	}
	public void setRequestingSupervisorPhNo(String requestingSupervisorPhNo) {
		this.requestingSupervisorPhNo = requestingSupervisorPhNo;
	}
	public String getRequestingSupervisorEmail() {
		return requestingSupervisorEmail;
	}
	public void setRequestingSupervisorEmail(String requestingSupervisorEmail) {
		this.requestingSupervisorEmail = requestingSupervisorEmail;
	}
	public String getCostCenter() {
		return costCenter;
	}
	public void setCostCenter(String costCenter) {
		this.costCenter = costCenter;
	}
	public String getWorkAddressOther() {
		return workAddressOther;
	}
	public void setWorkAddressOther(String workAddressOther) {
		this.workAddressOther = workAddressOther;
	}
	public boolean isMedical() {
		return medical;
	}
	public void setMedical(boolean medical) {
		this.medical = medical;
	}
	public boolean isNonMedical() {
		return nonMedical;
	}
	public void setNonMedical(boolean nonMedical) {
		this.nonMedical = nonMedical;
	}
	public String getExpDateOfReturn() {
		return expDateOfReturn;
	}
	public void setExpDateOfReturn(String expDateOfReturn) {
		this.expDateOfReturn = expDateOfReturn;
	}
	public String getfFDNurseName() {
		return fFDNurseName;
	}
	public void setfFDNurseName(String fFDNurseName) {
		this.fFDNurseName = fFDNurseName;
	}
	public String getPhysicianName() {
		return physicianName;
	}
	public void setPhysicianName(String physicianName) {
		this.physicianName = physicianName;
	}
	public String getPhysicianPhNo() {
		return physicianPhNo;
	}
	public void setPhysicianPhNo(String physicianPhNo) {
		this.physicianPhNo = physicianPhNo;
	}
	
	public String getWsEvalDesc() {
		return wsEvalDesc;
	}
	public void setWsEvalDesc(String wsEvalDesc) {
		this.wsEvalDesc = wsEvalDesc;
	}
	 
	public String getEmpWrkActOthr() {
		return empWrkActOthr;
	}
	public void setEmpWrkActOthr(String empWrkActOthr) {
		this.empWrkActOthr = empWrkActOthr;
	}
	
	public String getRequestingSupervisorId() {
		return requestingSupervisorId;
	}
	public void setRequestingSupervisorId(String requestingSupervisorId) {
		this.requestingSupervisorId = requestingSupervisorId;
	}
	public String getWrkEvalScopOthr() {
		return wrkEvalScopOthr;
	}
	public void setWrkEvalScopOthr(String wrkEvalScopOthr) {
		this.wrkEvalScopOthr = wrkEvalScopOthr;
	}
	public WorkstationEvaluation(){
		
	}
	public WorkstationEvaluation(String requestId, String assessmentId, String empName, String empId,
			String empWorkstationLocCity, String empWorkstationLocBld, String empShiftHrs, String requestingSupervisor,
			String requestDate, String requestingSupervisorPhNo, String requestingSupervisorEmail,
			String requestingSupervisorId, String costCenter, String workAddressOther, boolean medical,
			boolean nonMedical, String expDateOfReturn, String fFDNurseName, String physicianName, String physicianPhNo,
			String wsEvalDesc, String status, Checkbox checkbox, String empWrkActOthr, String wrkEvalScopOthr) {
		super();
		this.requestId = requestId;
		this.assessmentId = assessmentId;
		this.empName = empName;
		this.empId = empId;
		this.empWorkstationLocCity = empWorkstationLocCity;
		this.empWorkstationLocBld = empWorkstationLocBld;
		this.empShiftHrs = empShiftHrs;
		this.requestingSupervisor = requestingSupervisor;
		this.requestDate = requestDate;
		this.requestingSupervisorPhNo = requestingSupervisorPhNo;
		this.requestingSupervisorEmail = requestingSupervisorEmail;
		this.requestingSupervisorId = requestingSupervisorId;
		this.costCenter = costCenter;
		this.workAddressOther = workAddressOther;
		this.medical = medical;
		this.nonMedical = nonMedical;
		this.expDateOfReturn = expDateOfReturn;
		this.fFDNurseName = fFDNurseName;
		this.physicianName = physicianName;
		this.physicianPhNo = physicianPhNo;
		this.wsEvalDesc = wsEvalDesc;
		this.status = status;
		this.checkbox = checkbox;
		this.empWrkActOthr = empWrkActOthr;
		this.wrkEvalScopOthr = wrkEvalScopOthr;
	}
	@Override
	public String toString() {
		return "WorkstationEvaluation [requestId=" + requestId + ", assessmentId=" + assessmentId + ", empName="
				+ empName + ", empId=" + empId + ", empWorkstationLocCity=" + empWorkstationLocCity
				+ ", empWorkstationLocBld=" + empWorkstationLocBld + ", empShiftHrs=" + empShiftHrs
				+ ", requestingSupervisor=" + requestingSupervisor + ", requestDate=" + requestDate
				+ ", requestingSupervisorPhNo=" + requestingSupervisorPhNo + ", requestingSupervisorEmail="
				+ requestingSupervisorEmail + ", requestingSupervisorId=" + requestingSupervisorId + ", costCenter="
				+ costCenter + ", workAddressOther=" + workAddressOther + ", medical=" + medical + ", nonMedical="
				+ nonMedical + ", expDateOfReturn=" + expDateOfReturn + ", fFDNurseName=" + fFDNurseName
				+ ", physicianName=" + physicianName + ", physicianPhNo=" + physicianPhNo + ", wsEvalDesc=" + wsEvalDesc
				+ ", status=" + status + ", checkbox=" + checkbox + ", empWrkActOthr=" + empWrkActOthr
				+ ", wrkEvalScopOthr=" + wrkEvalScopOthr + ", strAddr=" + strAddr + ", cityInfo=" + cityInfo
				+ ", zipCode=" + zipCode + ", createdBy=" + createdBy + ", createdDate=" + createdDate + ", updatedBy="
				+ updatedBy + ", updatedDate=" + updatedDate + "]";
	}
	
	
	
}
