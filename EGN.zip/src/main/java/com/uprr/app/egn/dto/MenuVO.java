package com.uprr.app.egn.dto;

public class MenuVO {

	private String name;
	private String url;
	private int order;
	
	public MenuVO() {
		super();
	}
	
	public MenuVO(String name, String url, int order) {
		super();
		this.name = name;
		this.url = url;
		this.order = order;
	}
	
	public int getOrder() {
		return order;
	}

	public void setOrder(int order) {
		this.order = order;
	}

	

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}

	@Override
	public String toString() {
		return "MenuVO [name=" + name + ", url=" + url + ", order=" + order + "]";
	}
	
	
	
}
