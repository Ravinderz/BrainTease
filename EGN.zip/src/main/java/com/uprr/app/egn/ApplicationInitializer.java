package com.uprr.app.egn;

import javax.servlet.ServletContext;
import javax.servlet.ServletRegistration;

import org.springframework.web.WebApplicationInitializer;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.servlet.DispatcherServlet;

import com.uprr.app.egn.config.MVCConfig;

public class ApplicationInitializer implements WebApplicationInitializer {
	private static final String SECURE_JAS_DISPATCHER_MAPPING = "/secure/jas/*";
  
	@Override
	public void onStartup(ServletContext servletContext) {
		registerAndMapDispatcherServlet(servletContext);
	}

	protected AnnotationConfigWebApplicationContext registerAndMapDispatcherServlet(ServletContext servletContext) {
		// Create the dispatcher servlet's Spring application context
		AnnotationConfigWebApplicationContext dispatcherContext = new AnnotationConfigWebApplicationContext();
		dispatcherContext.register(MVCConfig.class);

		final ServletRegistration.Dynamic dispatcher = servletContext.addServlet("/", new DispatcherServlet(dispatcherContext));
		dispatcher.setLoadOnStartup(1);
		dispatcher.addMapping(SECURE_JAS_DISPATCHER_MAPPING);
		return dispatcherContext;
	}
}
