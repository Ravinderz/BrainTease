package com.uprr.app.egn.dto;

public class FollowUpVO {

	private String noteId;
	private String asmtId;
	private String noteDesc;
	private String createdBy;
	private String createdDate;
	private String updatedBy;
	private String updatedDate;
	public String getNoteId() {
		return noteId;
	}
	public void setNoteId(String noteId) {
		this.noteId = noteId;
	}
	public String getAsmtId() {
		return asmtId;
	}
	public void setAsmtId(String asmtId) {
		this.asmtId = asmtId;
	}
	public String getNoteDesc() {
		return noteDesc;
	}
	public void setNoteDesc(String noteDesc) {
		this.noteDesc = noteDesc;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public String getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(String updatedDate) {
		this.updatedDate = updatedDate;
	}
	public FollowUpVO(String noteId, String asmtId, String noteDesc, String createdBy, String createdDate,
			String updatedBy, String updatedDate) {
		super();
		this.noteId = noteId;
		this.asmtId = asmtId;
		this.noteDesc = noteDesc;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.updatedBy = updatedBy;
		this.updatedDate = updatedDate;
	}
	public FollowUpVO() {
		super();
	}
	@Override
	public String toString() {
		return "FollowUpVO [noteId=" + noteId + ", asmtId=" + asmtId + ", noteDesc=" + noteDesc + ", createdBy="
				+ createdBy + ", createdDate=" + createdDate + ", updatedBy=" + updatedBy + ", updatedDate="
				+ updatedDate + "]";
	}
	
	
}
