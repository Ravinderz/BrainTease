package com.uprr.app.egn.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;															  
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PropertiesLoaderUtils;
import org.springframework.stereotype.Service;

import com.uprr.app.egn.dto.LoggedUserVO;
import com.uprr.app.egn.dto.MenuVO;
import com.uprr.app.egn.util.EGNConstants;
import com.uprr.app.egn.util.Util;								  

@Service
public class AppService {

	Logger logger = LogManager.getLogger(AppService.class);	
	@Autowired
	IAuthorizationService authService;
	
	@Autowired
	IEmplService empService;

	public List<MenuVO> getMenuItems(String role) throws IOException{
		logger.info("inside getMenuItems");
		List<MenuVO> list = new ArrayList<MenuVO>();

		Resource resource = new ClassPathResource("/menu.properties");
		Properties props = PropertiesLoaderUtils.loadProperties(resource);

		for ( Map.Entry< Object, Object > entry : props.entrySet() ) {
				MenuVO vo = new MenuVO();
				vo.setName((String)entry.getKey());
				String value = (String)entry.getValue();
				vo.setUrl(value.split("#")[0]);
				vo.setOrder(Integer.parseInt(value.split("#")[1]));
				list.add(vo); 
		}
		
		
		list = list.stream().sorted(Comparator.comparing(MenuVO::getOrder)).collect(Collectors.toList());
		list = getMenuItemsBasedOnRole(list, role);
		logger.info("Menu List"+list);
		return list;
	}

	public List<MenuVO> getHomeListItems(String role) throws IOException{
		logger.info("inside getHomeListItems");
		List<MenuVO> list = new ArrayList<MenuVO>();

		Resource resource = new ClassPathResource("/home.properties");
		Properties props = PropertiesLoaderUtils.loadProperties(resource);
		
		for ( Map.Entry< Object, Object > entry : props.entrySet() ) {
			MenuVO vo = new MenuVO();
			String name = (String)entry.getKey();
			name = name.replace("_", " ");
			vo.setName(name);
			String value = (String)entry.getValue();
			vo.setUrl(value.split("#")[0]);
			vo.setOrder(Integer.parseInt(value.split("#")[1]));
			list.add(vo);
		}
		
		Collections.sort(list,(m1,m2) -> m1.getOrder() - m2.getOrder());
		list = list.stream().sorted(Comparator.comparing(MenuVO::getOrder)).collect(Collectors.toList());
		list = getHomeMenuItemsBasedOnRole(list, role);
		logger.info("Home menu List"+list);
		return list;
	}

	public List<MenuVO> getMenuItemsBasedOnRole(List<MenuVO> list,String role){
		if(role.equalsIgnoreCase(EGNConstants.USER_ROLE)){
			list.removeIf(vo -> vo.getUrl().equalsIgnoreCase("ergonomics.facilitiesmgmtsearch"));
		}
		if(role.equalsIgnoreCase(EGNConstants.SUPERVISOR_ROLE) || role.equalsIgnoreCase(EGNConstants.ADA_NURSE_ROLE)){
			list.removeIf(vo -> vo.getUrl().equalsIgnoreCase("ergonomics.facilitiesmgmtsearch"));
		}else if(role.equalsIgnoreCase(EGNConstants.INDUSTRY_HYGIENE_SPECIALIST_ROLE)){
			list.removeIf(vo -> vo.getUrl().equalsIgnoreCase("ergonomics.facilitiesmgmtsearch"));
			list.removeIf(vo -> vo.getUrl().equalsIgnoreCase("ergonomics.approveRequest"));
		}else if(role.equalsIgnoreCase(EGNConstants.ERGONOMICS_SPECIALIST_ROLE)){
			list.removeIf(vo -> vo.getUrl().equalsIgnoreCase("ergonomics.facilitiesmgmtsearch"));
			list.removeIf(vo -> vo.getUrl().equalsIgnoreCase("ergonomics.create"));
			list.removeIf(vo -> vo.getUrl().equalsIgnoreCase("ergonomics.approveRequest"));
			list.removeIf(vo -> vo.getUrl().equalsIgnoreCase("ergonomics.assessment"));
		}else if(role.equalsIgnoreCase(EGNConstants.FACILITIES_MANAGEMENT_ROLE)){
			getMenuOrHomeMenuItemsForFacilitiesmgmtRole(list,role);
		}

		return list;
	}

	public List<MenuVO> getHomeMenuItemsBasedOnRole(List<MenuVO> list,String role){
		if(role.equalsIgnoreCase(EGNConstants.USER_ROLE)){
			list.removeIf(vo -> vo.getUrl().equalsIgnoreCase("ergonomics.assessment"));
			list.removeIf(vo -> vo.getUrl().equalsIgnoreCase("ergonomics.facilitiesmgmtsearch"));
		}
		else if(role.equalsIgnoreCase(EGNConstants.SUPERVISOR_ROLE) || role.equalsIgnoreCase(EGNConstants.ADA_NURSE_ROLE)){
			//list.removeIf(vo -> vo.getUrl().equals("ergonomics.create"));
			list.removeIf(vo -> vo.getUrl().equalsIgnoreCase("ergonomics.assessment"));
			list.removeIf(vo -> vo.getUrl().equalsIgnoreCase("ergonomics.facilitiesmgmtsearch"));
		}
		else if(role.equalsIgnoreCase(EGNConstants.ERGONOMICS_SPECIALIST_ROLE)){
			list.removeIf(vo -> vo.getUrl().equalsIgnoreCase("ergonomics.approveRequest"));
			list.removeIf(vo -> vo.getUrl().equalsIgnoreCase("ergonomics.assessment"));
			list.removeIf(vo -> vo.getUrl().equalsIgnoreCase("ergonomics.facilitiesmgmtsearch"));
			list.removeIf(vo -> vo.getUrl().equalsIgnoreCase("ergonomics.create"));
		} 
		else if(role.equalsIgnoreCase(EGNConstants.INDUSTRY_HYGIENE_SPECIALIST_ROLE)){
			list.removeIf(vo -> vo.getUrl().equalsIgnoreCase("ergonomics.approveRequest"));
			list.removeIf(vo -> vo.getUrl().equalsIgnoreCase("ergonomics.assessment"));
			list.removeIf(vo -> vo.getUrl().equalsIgnoreCase("ergonomics.facilitiesmgmtsearch"));
		} else if(role.equalsIgnoreCase(EGNConstants.FACILITIES_MANAGEMENT_ROLE)){
			getMenuOrHomeMenuItemsForFacilitiesmgmtRole(list,role);
		}
		return list;
	}
	
	private void getMenuOrHomeMenuItemsForFacilitiesmgmtRole(List<MenuVO> list,String role){
		list.removeIf(vo -> vo.getUrl().equalsIgnoreCase("ergonomics.approveRequest"));
		list.removeIf(vo -> vo.getUrl().equalsIgnoreCase("ergonomics.assessment"));
		list.removeIf(vo -> vo.getUrl().equalsIgnoreCase("ergonomics.search"));
		list.removeIf(vo -> vo.getUrl().equalsIgnoreCase("ergonomics.welcome"));
		list.removeIf(vo -> vo.getUrl().equalsIgnoreCase("ergonomics.create"));
	}

	public String getRole(String empId){
		
		String role = null;
			
		if(Util.isLocalMode()){
			role = getRolesForLocalMode(empId);
		}else{
			role = CheckIfUserIsADANurse(empId,role);
			logger.info("ADA "+role);
			role = CheckIfUserIsEGNSpecialist(empId,role);
			logger.info("EGNSpe "+role);
			role = CheckIfUserIsIHSpecialist(empId,role);
			logger.info("IHA "+role);
			role = CheckIfUserIsFacilitiesManagement(empId,role);
			logger.info("FACMAn "+role);
			if(role == null){
				role = EGNConstants.SUPERVISOR_ROLE;
				logger.info("SUPV "+role);
			}
		}
		
		return role;
	}
	
	public String CheckIfUserIsADANurse(String empId,String role){
		
		if(role == null){
			if(authService.canApproveMedicalRequest(empId) && authService.canViewMedicalRecords(empId)){
				role = EGNConstants.ADA_NURSE_ROLE;
			}
		}
		
		return role;
	}
	
	public String CheckIfUserIsEGNSpecialist(String empId,String role){

		if(role == null){
			if(authService.canCreateAssessment(empId) && authService.canViewMedicalRecords(empId)){
				role = EGNConstants.ERGONOMICS_SPECIALIST_ROLE;
			}	
		}
		
		return role;
	}
	
	public String CheckIfUserIsIHSpecialist(String empId,String role){
	
		if(role == null){
			if(!authService.canCreateAssessment(empId) && authService.canCreateCostItems(empId)){
				role = EGNConstants.INDUSTRY_HYGIENE_SPECIALIST_ROLE;
			}
		}
		
		return role;
	}
	
	public String CheckIfUserIsFacilitiesManagement(String empId,String role){

		if(role == null){
			if(!authService.canCreateAssessment(empId) && authService.canEditCostItems(empId)){
				role = EGNConstants.FACILITIES_MANAGEMENT_ROLE;
			}
		}
		
		return role;
	}
	
	public String getRolesForLocalMode(String empId){
		
		String role = null;
		
		switch(empId){
		
		case EGNConstants.XMIE001:{
			role = EGNConstants.USER_ROLE;
			break;
		}
		
		case EGNConstants.XMIE002:{
			role= EGNConstants.SUPERVISOR_ROLE;
			break;
		}
		
		case EGNConstants.XMIE003:{
			role = EGNConstants.ERGONOMICS_SPECIALIST_ROLE;
			break;
		}
		
		case EGNConstants.XMIE004:{
			role =EGNConstants.INDUSTRY_HYGIENE_SPECIALIST_ROLE;
			break;
		}
		
		case EGNConstants.XMIE005:{
			role = EGNConstants.ADA_NURSE_ROLE;
			break;
		}
		
		case EGNConstants.XMIE006:{
			role = EGNConstants.FACILITIES_MANAGEMENT_ROLE;
			break;
		}
		
		default: {
			role = EGNConstants.SUPERVISOR_ROLE;
			break;
		}
		}
		
		return role;
	}
	
		
	
	public LoggedUserVO populateUser(String userId,String role,String empId){
		LoggedUserVO user = null;

		if(Util.isLocalMode()){
			user = this.populateUserForLocalMode(userId, role, empId);
		}else if(Util.isDevMode()){
			user = this.populateUserForDevMode(userId, role, empId);
		}	
		return user;
	}
	
	public LoggedUserVO populateUserForLocalMode(String userId, String role, String empId) {
		LoggedUserVO user1 = null;
		switch (userId) {
		case EGNConstants.XMIE001: {
				user1 = new LoggedUserVO(userId, "9999999", role, "Test", "1", "User", "Test 1 User", "xmie001@up.com", "0022338899", "iots276", "9999998", "Test 1 Supervisor", "xmie002@up.com", "99999", "Test 1 Supervisor", "", "Omaha", "NE", "BD321", "123");
				user1.setSupervisorPh("4025448901");
				break;
			}
		case EGNConstants.XMIE002: {
				user1 = new LoggedUserVO(userId, "9999998", role, "Test", "1", "Supervisor", "Test 1 Supervisor", "xmie002@up.com", "0022338899", "iots255", "0452571", "Jeffrey B Roberts", "JBROBERT@UP.COM", "99999", "Jeffrey B Roberts", "", "Omaha", "NE", "BD321", "123");
				user1.setSupervisorPh("4025448901");
				break;
			}
		case EGNConstants.XMIE003: {
				user1 = new LoggedUserVO(userId, "9999997", role, "Test", "1", "Specialist", "Test 1 Specialist", "xmie003@up.com", "0022338899", "iots276", "0439971", "Gorantla Vishnu Naidu", "VNGORANT@UP.COM", "99999", "Gorantla Vishnu Naidu", "", "Omaha", "NE", "BD321", "123");
				user1.setSupervisorPh("4025448901");
				break;
			}
		case EGNConstants.XMIE004: {
				user1 = new LoggedUserVO(userId, "9999996", role, "Test", "1", "IHA", "Test 1 IHA", "xmie004@up.com", "0022338899", "iots276", "0439971", "Gorantla Vishnu Naidu", "VNGORANT@UP.COM", "99999", "Gorantla Vishnu Naidu", "", "Omaha", "NE", "BD321", "123");
				user1.setSupervisorPh("4025448901");
				break;
			}
		case EGNConstants.XMIE005: {
				user1 = new LoggedUserVO(userId, "9999995", role, "Test", "1", " ADA Nurse", "Test 1 ADA Nurse", "xmie005@up.com", "0022338899", "iots276", "0439971", "Gorantla Vishnu Naidu", "VNGORANT@UP.COM", "99999", "Gorantla Vishnu Naidu", "", "Omaha", "NE", "BD321", "123");
				user1.setSupervisorPh("4025448901");
				break;
			}
		case EGNConstants.XMIE006: {
				/*user1 = new LoggedUserVO(userId, "9999994", role, "Test", "1", "facilities management", "Test 1 Facilities", "pjoshi02@upcontractor.up.com", "0022338899", "iots276", "0439971", "Prasanna Joshi", "pjoshi02@upcontractor.up.com", "99999", "Prasanna JOshi", "", "Omaha", "NE", "BD321", "123");
				user1.setSupervisorPh("4025448901");*/
				user1 = new LoggedUserVO(userId, "9999993", role, "Test", "1", "user 2", "Test 1 User 2", "xmie006@up.com", "0022338899", "iots276", "9999998", "Test 1 ADA Nurse", "xmie001@up.com", "99999", "Test 1 ADA Nurse", "", "Omaha", "NE", "BD321", "123");
				user1.setSupervisorPh("4025448901");
				break;
			}
		}
		return user1;

	}
	public LoggedUserVO populateUserForDevMode(String userId, String role, String empId) {
		LoggedUserVO user1 = null;
		switch (userId) {
		case EGNConstants.XMIE001: {
				user1 = new LoggedUserVO(userId, "9999998", role, "Test", "1", " ADA Nurse", "Test 1 ADA Nurse", "xmie001@up.com", "0022338899", "iots276", "9999998", "Test 1 Supervisor", "xmie002@up.com", "99999", "Test 1 Supervisor", "", "Omaha", "NE", "BD321", "123");
				user1.setSupervisorPh("4025448901");
				break;
			}
		case EGNConstants.XMIE002: {
				user1 = new LoggedUserVO(userId, "9999997", role, "Test", "1", "facilities management", "Test 1 Facilities", "xmie002@up.com", "0022338899", "iots255", "0452571", "Jeffrey B Roberts", "JBROBERT@UP.COM", "99999", "Jeffrey B Roberts", "", "Omaha", "NE", "BD321", "123");
				user1.setSupervisorPh("4025448901");
				break;
			}
		case EGNConstants.XMIE003: {
				user1 = new LoggedUserVO(userId, "9999996", role, "Test", "1", "Specialist", "Test 1 Specialist", "xmie003@up.com", "0022338899", "iots276", "0439971", "Gorantla Vishnu Naidu", "VNGORANT@UP.COM", "99999", "Gorantla Vishnu Naidu", "", "Omaha", "NE", "BD321", "123");
				user1.setSupervisorPh("4025448901");
				break;
			}
		case EGNConstants.XMIE004: {
				user1 = new LoggedUserVO(userId, "9999995", role, "Test", "1", "IHA", "Test 1 IHA", "xmie004@up.com", "0022338899", "iots276", "0439971", "Gorantla Vishnu Naidu", "VNGORANT@UP.COM", "99999", "Gorantla Vishnu Naidu", "", "Omaha", "NE", "BD321", "123");
				user1.setSupervisorPh("4025448901");
				break;
			}
		case EGNConstants.XMIE005: {
				user1 = new LoggedUserVO(userId, "9999994", role, "Test", "1", "User 1", "Test 1 User 1", "xmie005@up.com", "0022338899", "iots276", "9999993", "Test 1 User 2", "xmie006@up.com", "99999", "Test 1 User 2", "", "Omaha", "NE", "BD321", "123");
				user1.setSupervisorPh("4025448901");
				break;
			}
		case EGNConstants.XMIE006: {
				user1 = new LoggedUserVO(userId, "9999993", role, "Test", "1", "user 2", "Test 1 User 2", "xmie006@up.com", "0022338899", "iots276", "9999998", "Test 1 ADA Nurse", "xmie001@up.com", "99999", "Test 1 ADA Nurse", "", "Omaha", "NE", "BD321", "123");
				user1.setSupervisorPh("4025448901");
				break;
			}
		default: {
				user1 = empService.getEmployeeFromView(empId);
				if(role == null)
					user1.setRole("supervisor");
				else
					user1.setRole(role);
				break;
			}
		}
		return user1;
	}

}
