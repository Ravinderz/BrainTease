package com.uprr.app.egn.dto;

public class UserVO {

	private String userID;
	private String employeeID;
	private String employeeFullName;							 
	private String role;
	
	
	public String getEmployeeFullName() {
		return employeeFullName;
	}
	public void setEmployeeFullName(String employeeFullName) {
		this.employeeFullName = employeeFullName;
	}
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public String getEmployeeID() {
		return employeeID;
	}
	public void setEmployeeID(String employeeID) {
		this.employeeID = employeeID;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	
	
	public UserVO() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public UserVO(String userID, String employeeID, String role) {
		super();
		this.userID = userID;
		this.employeeID = employeeID;
		this.role = role;
	}
	@Override
	public String toString() {
		return "UserVO [userID=" + userID + ", employeeID=" + employeeID + ", employeeFullName=" + employeeFullName
				+ ", role=" + role + "]";
	}
	
	
	
	
}
