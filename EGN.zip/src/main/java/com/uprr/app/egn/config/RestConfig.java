package com.uprr.app.egn.config;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;

/**
 * Rest Config class to invoke ESB2 services for EGN Project.
 * @Author: (Krish)nappan Muthuraman (iots242)
 * Date: 05/07/18
*/

import com.uprr.app.egn.service.DocService;
import com.uprr.app.egn.service.IDocService;
import com.uprr.enterprise.security.credential.CredentialProvider;
import com.uprr.enterprise.security.credential.simple.SimpleCredentialProvider;

@Configuration
@PropertySource("classpath:application.properties")
public class RestConfig {

	@Value("${egn.esb2.userid}")
	private String esb2UserId;

	@Value("${egn.esb2.cyberark.password}")
	private String esb2Password;

	@Value("${esb2.url}")
	private String esbUrl;

	@Bean
	public CredentialProvider enterpriseSoftwareCredentials() {
		return new SimpleCredentialProvider(esb2UserId, esb2Password);
	}

	@Bean
	public IDocService docService(RestTemplateBuilder builder) {
		return new DocService(builder, esbUrl);
	}

	@Bean
	public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() throws IOException {
		return new PropertySourcesPlaceholderConfigurer();
	}

	/*
	@Bean
	public CredentialProvider enterpriseSoftwareCredentials() {
		if (isLocalMode()) {
			return new SimpleCredentialProvider(esb2UserId, esb2Password);
		} else {
			FallbackTimeoutCyberArkCredentialProvider credentialsProvider = new FallbackTimeoutCyberArkCredentialProvider
					("Enterprise-Software-CredentialsUnmanaged", "", getEnvironment(), "EGN", "d00031c");
			credentialsProvider.setTimeout(1000);
			return credentialsProvider;
		}
	}
	*/
}
