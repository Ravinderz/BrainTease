package com.uprr.app.egn.dao;

import java.util.List;

import com.uprr.app.egn.dto.FollowUpVO;

public interface IFollowUpDAO {

	public boolean addFollowUp(FollowUpVO followUp);
	
	public List<FollowUpVO> getAllFollowUpNotesByAsmtId(String asmtId);
}
