package com.uprr.app.egn.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.uprr.app.egn.dto.FollowUpVO;

public class FollowUpResultSetExtractor<T> implements ResultSetExtractor<T> {

	public T extractData(ResultSet rs) throws SQLException,
	DataAccessException {
		FollowUpVO note = new FollowUpVO();
		note.setAsmtId(rs.getString("ASMT_ID"));
		note.setNoteId(rs.getString("FLW_UP_ID"));
		note.setNoteDesc(rs.getString("FLW_UP_DESC"));
		note.setCreatedBy(rs.getString("CRTD_USER_ID"));
		note.setCreatedDate(rs.getString("CRTN_TMST").split(" ")[0]);
		note.setUpdatedBy(rs.getString("LAST_UPDT_USER_ID"));
		note.setUpdatedDate(rs.getString("LAST_UPDT_TMST").split(" ")[0]);
		
		return (T) note;
	}

}
