package com.uprr.app.egn.service;


public interface IAuthorizationService {

	boolean canCreateEvalRequest(String userId);
	
	boolean canApproveMedicalRequest(String userId);
	
	boolean canCreateAssessment(String userId);
	
	boolean canViewMedicalRecords(String userId);
	
	boolean canCreateCostItems(String userId);
	
	boolean canEditCostItems(String userId); 

}
