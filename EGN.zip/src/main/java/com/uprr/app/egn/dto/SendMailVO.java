package com.uprr.app.egn.dto;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.uprr.netcontrol.shared.xml_bindings.jaxb2.notification.send_enterprise_notification_2_0.CCListType;
import com.uprr.netcontrol.shared.xml_bindings.jaxb2.notification.send_enterprise_notification_2_0.DeliveryType;
import com.uprr.netcontrol.shared.xml_bindings.jaxb2.notification.send_enterprise_notification_2_0.EmailType;
import com.uprr.netcontrol.shared.xml_bindings.jaxb2.notification.send_enterprise_notification_2_0.MessageWithAttachmentType;
import com.uprr.netcontrol.shared.xml_bindings.jaxb2.notification.send_enterprise_notification_2_0.NotificationListType;
import com.uprr.netcontrol.shared.xml_bindings.jaxb2.notification.send_enterprise_notification_2_0.NotificationRequest;
import com.uprr.netcontrol.shared.xml_bindings.jaxb2.notification.send_enterprise_notification_2_0.NotificationType;
import com.uprr.netcontrol.shared.xml_bindings.jaxb2.notification.send_enterprise_notification_2_0.ToAddressListType;

public class SendMailVO {
	
	
	private static final Log LOGGER = LogFactory.getLog(SendMailVO.class);
	
	private static final long serialVersionUID = 1L;
	private String contentType = "text/html";
	private String subject = null;
	private String bodyContent = null;
	private String fromAddress = null;
	private List<String> toAddressLst = new ArrayList<String>(3);
	private List<String> ccAddressLst = new ArrayList<String>(3);
	private List<String> bccAddressLst = new ArrayList<String>(3);
	private byte[] attachmentBytes = null;
	private String attachedDocMimeType = "application/x-pdf";
	private String attachedDocName = "EGN_doc";

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getBodyContent() {
		return bodyContent;
	}

	public void setBodyContent(String bodyContent) {
		this.bodyContent = bodyContent;
	}

	public String getFromAddress() {
		return fromAddress;
	}

	public void setFromAddress(String fromAddress) {
		this.fromAddress = fromAddress;
	}

	public List<String> getToAddressLst() {
		return toAddressLst;
	}

	public void setToAddressLst(List<String> toAddressLst) {
		this.toAddressLst = toAddressLst;
	}

	public List<String> getCcAddressLst() {
		return ccAddressLst;
	}

	public void setCcAddressLst(List<String> ccAddressLst) {
		this.ccAddressLst = ccAddressLst;
	}

	public List<String> getBccAddressLst() {
		return bccAddressLst;
	}

	public void setBccAddressLst(List<String> bccAddressLst) {
		this.bccAddressLst = bccAddressLst;
	}

	public byte[] getAttachmentBytes() {
		return attachmentBytes;
	}

	public void setAttachmentBytes(byte[] attachmentBytes) {
		
		byte[] myArray;
		if(attachmentBytes == null) { 
			myArray = new byte[0]; 
		} else { 
			myArray = Arrays.copyOf(attachmentBytes, attachmentBytes.length); 
		} 
		this.attachmentBytes = myArray;
	}

	public String getAttachedDocMimeType() {
		return attachedDocMimeType;
	}

	public void setAttachedDocMimeType(String attachedDocMimeType) {
		this.attachedDocMimeType = attachedDocMimeType;
	}

	public String getAttachedDocName() {
		return attachedDocName;
	}

	public void setAttachedDocName(String attachedDocName) {
		this.attachedDocName = attachedDocName;
	}
	
	
	@Override
	public String toString() {
		return "SendMailVO [contentType=" + contentType + ", subject=" + subject + ", bodyContent=" + bodyContent
				+ ", fromAddress=" + fromAddress + ", toAddressLst=" + toAddressLst + ", ccAddressLst=" + ccAddressLst
				+ ", bccAddressLst=" + bccAddressLst + ", attachmentBytes=" + Arrays.toString(attachmentBytes)
				+ ", attachedDocMimeType=" + attachedDocMimeType + ", attachedDocName=" + attachedDocName + "]";
	}
		
	public NotificationRequest buildNotificationRequest(){ 
		
		NotificationRequest request = new NotificationRequest();
		String content = "<html><head><META http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"><title>"+ this.getSubject()+ "</title></head><body><br/><p>"+this.getBodyContent()+"</p><br/><p>Regards<br/>Ergonomics Admin</p></body></html>";
		request.setDescription("TEST Mail From EGN");
		request.setIsInternalOnly(true);
		request.setPublisherId("cn=degn001,ou=uprr,o=up");
		
		NotificationListType notificationList = new NotificationListType();
		NotificationType notification = new NotificationType();
		
		DeliveryType deliveryType = new DeliveryType();
		
		EmailType email = new EmailType();
		
		ToAddressListType toAddressList = new ToAddressListType();
		toAddressList.getToAddress().addAll(getToAddressLst()); 
		
		CCListType ccAddressList = new CCListType();
		ccAddressList.getCcAddress().addAll(getCcAddressLst());
		
		email.setToAddresses(toAddressList);
		email.setCcAddresses(ccAddressList);
		
		MessageWithAttachmentType msg = new MessageWithAttachmentType();
		msg.setContentMimeType(this.getContentType());
		msg.setSubject(this.getSubject());
		msg.setContent(content);
		
		email.setFromAddress("EGN_Support_Team");
		email.setMessage(msg);
		
		deliveryType.setEmail(email);
		notification.setDirect(deliveryType);
		notificationList.getNotification().add(notification);
		
		
		request.setNotificationList(notificationList);
		
		return request;
	}
	
	
	public String getCurrentTime(){
		
		try{
			SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
			return  sdf.format(new Date());
		}catch(Exception e){
			LOGGER.error(e);
			return "";
		}
	}
	
}