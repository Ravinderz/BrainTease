package com.uprr.app.egn.dao;

import java.util.List;

import com.uprr.app.egn.dto.ActionItem;
import com.uprr.app.egn.dto.WorkstationEvaluation;												  

public interface IItemDAO {

	public int insertPurchaseItem(ActionItem item);
	
	public boolean updatePurchaseItem(ActionItem item);
	
	public List<ActionItem> getAllItemsByAsmtId(String assessmentId);
	
	/*public List<ActionItem> getItemsAssignedToSupervisor(String assessmentId);*/				
	
	public List<WorkstationEvaluation> getItemsAssignedToSupervisor(String assessmentId);													   
}
