package com.uprr.app.egn.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.JmsException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.uprr.app.egn.dao.IItemDAO;
import com.uprr.app.egn.dao.IRequestUpdateHistoryDAO;
import com.uprr.app.egn.dao.IWorkstationAssessmentDAO;
import com.uprr.app.egn.dao.IWorkstationEvaluationDAO;
import com.uprr.app.egn.dto.ActionItem;
import com.uprr.app.egn.dto.LoggedUserVO;										 
import com.uprr.app.egn.dto.RequestHistory;
import com.uprr.app.egn.dto.SendMailVO;
import com.uprr.app.egn.dto.WorkstationEvaluation;
import com.uprr.app.egn.util.EGNConstants;
import com.uprr.app.egn.util.Util;

@Service
public class ItemService {

	Logger logger = LogManager.getLogger(ItemService.class);
	
	@Autowired
	IItemDAO itemDao;
	
	@Autowired
	IWorkstationAssessmentDAO wsDao;
	
	@Autowired
	IRequestUpdateHistoryDAO reqHistDao;
	
	@Autowired
	private IWorkstationEvaluationDAO wsEvalDao;
	
	@Autowired
    private IEmailService emailService;
	
	@Autowired
	private IEmplService emplService;
	
	
	@Transactional
	public ActionItem insertPurchaseItem(ActionItem item){
		int i = itemDao.insertPurchaseItem(item);
		item.setItemId(i);
		reqHistDao.insertRequestUpdateHistory(EGNConstants.ITEM_STATUS_NA, item.getItemOrderStatus(), null, item.getCreatedById(),null, item.getAssessmentId(), Integer.toString(item.getItemId()));
		return item;
	}
	
@Transactional
	public boolean updatePurchaseItem(ActionItem item) throws JmsException, Exception{
		
		boolean flag = itemDao.updatePurchaseItem(item);
		logger.info(flag);
		List<ActionItem> items = itemDao.getAllItemsByAsmtId(item.getAssessmentId());
									
		if(flag){
			getNotificationBasedOnStatus(item, items);
			logger.info(item.getOldStatus());
			logger.info(item.getItemOrderStatus());
			if(!(item.getOldStatus().equalsIgnoreCase(item.getItemOrderStatus()))){
				reqHistDao.insertRequestUpdateHistory(item.getOldStatus(), item.getItemOrderStatus(), item.getNote(), item.getUpdatedById(),null, item.getAssessmentId(), Integer.toString(item.getItemId()));
			}

		}
		
		return flag;
	}	
	private void getNotificationBasedOnStatus(ActionItem item, List<ActionItem> items) throws JmsException, Exception{
		int itemOrderedCancelledCount = 0;
			for (ActionItem acItem: items) {
				logger.info(acItem.getItemOrderStatus());
				if (acItem.getItemOrderStatus().equalsIgnoreCase(EGNConstants.ITEM_ORDER_STATUS_COMPLETE) || acItem.getItemOrderStatus().equalsIgnoreCase(EGNConstants.ITEM_ORDER_STATUS_CANCELLED) || acItem.getItemOrderStatus().equalsIgnoreCase(EGNConstants.ITEM_ORDER_STATUS_REJECTED)) {
					itemOrderedCancelledCount++;
				}
				logger.info(itemOrderedCancelledCount);
				if (itemOrderedCancelledCount == items.size()) {
					boolean result = wsDao.updateWorkstationAssessmentStatus(item.getAssessmentId(), EGNConstants.ITEM_STATUS_ASSESSMENT_COMPLETE);
					if(result){
						sendNotificationBasedOnResult(item, acItem);
					}
				}
			}
	}
	
	private void sendNotificationBasedOnResult(ActionItem item, ActionItem acItem) throws JmsException, Exception {
		wsEvalDao.updateStatus(item.getRequestId(), acItem.getAssignedToEmployeeId(), EGNConstants.ITEM_STATUS_ASSESSMENT_COMPLETE);
		reqHistDao.insertRequestUpdateHistory(EGNConstants.ITEM_STATUS_ASSESSMENT_PROVIDED, EGNConstants.ITEM_STATUS_ASSESSMENT_COMPLETE, null,acItem.getUpdatedById(), item.getRequestId(), acItem.getAssessmentId(), null);
		SendMailVO specialistEmail = Util.setEmlForAsmtCmpltdNPrchseItmsCmpltd("xprk408", "Ravinder Singh",item.getAssessmentId(), "");
		emailService.sendEmailNotification(specialistEmail);
	}


	public List<ActionItem> getAllItemsByAsmtId(String asmtId){
		return itemDao.getAllItemsByAsmtId(asmtId);
	}
	
	/*public List<ActionItem> getItemsAssignedToSupervisor(String empId){
		return itemDao.getItemsAssignedToSupervisor(empId);
	}*/
	
	public List<WorkstationEvaluation> getItemsAssignedToSupervisor(String empId){
		return itemDao.getItemsAssignedToSupervisor(empId);
	}
	
	public List<RequestHistory> getItemHistory(String itemId){
		logger.info("entering getItemHistory method in ItemService");
		List<RequestHistory> list = reqHistDao.getItemHistoryByItemId(itemId);
		Set<String> set = new HashSet<>(list.size());
		list.forEach(hist -> set.add(hist.getChangedBy()));
		List<LoggedUserVO> userList = emplService.getUserDetails(set);
		List<RequestHistory> updatedList = new ArrayList<>();
		for(RequestHistory hist : list){
			for(LoggedUserVO user: userList){
				if(hist.getChangedBy().equalsIgnoreCase(user.getEmployeeId())){
					hist.setChangedByName(user.getFullName());
					updatedList.add(hist);
				}
				
			}
		} 
		return updatedList;
	}
}
