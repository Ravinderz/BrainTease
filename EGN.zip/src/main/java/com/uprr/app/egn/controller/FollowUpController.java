package com.uprr.app.egn.controller;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.uprr.app.egn.dto.FollowUpVO;
import com.uprr.app.egn.service.FollowUpService;
import com.uprr.azm.shared.mvc.security.authorization.Attribute;
import com.uprr.azm.shared.mvc.security.authorization.Authorize;

@RestController
@RequestMapping("followUpNote")
public class FollowUpController {

	@Autowired
	FollowUpService followUpService;
	
	Logger logger = LogManager.getLogger(FollowUpController.class);
	
	@PostMapping("addFollowUpNote")
	 @Authorize(
	    	    actions = {@Attribute(key="action-id", value="access")},
	    	    resources = {@Attribute(key="resource-id", value="ergonomics"),@Attribute(key="feature-id", value="create-assessment")}
	    	    )
	public @ResponseBody ResponseEntity<FollowUpVO> addFollowUpNote(@RequestBody FollowUpVO followUp){
		
		logger.info("entering addFollowUpNote method in controller");
		
		boolean flag = followUpService.addFollowUpNote(followUp);
		
		if(flag){
			return new ResponseEntity<FollowUpVO>(followUp, HttpStatus.OK);
		}else{
			FollowUpVO followUpNote = new FollowUpVO();
			return new ResponseEntity<FollowUpVO>(followUpNote, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping("getAllFollowUpNotes/{asmtId}")
	public @ResponseBody ResponseEntity<List<FollowUpVO>> getFollowUpNotesByAsmtId(@PathVariable("asmtId") String asmtId){
		logger.info("entering getFollowUpNotesByAsmtId in FollowUpController "+asmtId);
		List<FollowUpVO> list = followUpService.getAllNotesByAsmtId(asmtId);
		return new ResponseEntity<List<FollowUpVO>>(list, HttpStatus.OK);
	}
	
	
}
