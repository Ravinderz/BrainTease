package com.uprr.app.egn.dto;

public class SearchRequest {

	private String fromDate;
	private String toDate;
	private String employeeId;
	private String status;
	private String role;
	private String supvId;
	
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getSupvId() {
		return supvId;
	}
	public void setSupvId(String supvId) {
		this.supvId = supvId;
	}
	public SearchRequest() {
		super();
		// TODO Auto-generated constructor stub
	}
	public SearchRequest(String fromDate, String toDate, String employeeId, String status, String role, String supvId) {
		super();
		this.fromDate = fromDate;
		this.toDate = toDate;
		this.employeeId = employeeId;
		this.status = status;
		this.role = role;
		this.supvId = supvId;
	}
	@Override
	public String toString() {
		return "SearchRequest [fromDate=" + fromDate + ", toDate=" + toDate + ", employeeId=" + employeeId + ", status="
				+ status + ", role=" + role + ", supvId=" + supvId + "]";
	}
	
	
	
	
	
	
}
