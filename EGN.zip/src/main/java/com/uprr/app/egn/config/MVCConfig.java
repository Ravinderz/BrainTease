package com.uprr.app.egn.config;

import java.io.IOException;

/**
 * MVC specific Config class for EGN Project.
 * @Author: (Krish)nappan Muthuraman (iots242)
 * Date: 05/01/18
*/

import java.util.List;

import javax.sql.DataSource;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.multipart.MultipartResolver;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.mvc.WebContentInterceptor;

import com.uprr.app.azm.common.AzmSecurityUtils;
import com.uprr.app.egn.interceptor.EgnInterceptor;
import com.uprr.app.egn.util.CyberArkUtil;
import com.uprr.app.egn.util.Util;
import com.uprr.azm.shared.mvc.security.authorization.AuthorizationInterceptor;
import com.uprr.azm.shared.mvc.security.authorization.AuthorizationManager;
import com.uprr.azm.shared.mvc.security.authorization.impl.AzmAuthorizationManager;
import com.uprr.netcontrol.shared.xml_bindings.jaxb2.notification.send_enterprise_notification_2_0.ObjectFactory;
import com.uprr.ui.shared.user.spring.mvc.ActiveUserHandlerMethodArgumentResolver;

@Configuration
@PropertySource("classpath:application.properties")
public class MVCConfig extends WebMvcConfigurerAdapter {
	
	
	Logger LOGGER = LogManager.getLogger(MVCConfig.class);
	
	@Value("${spring.datasource.username}")
	private String dbUserName;
	
	@Value("${app.database.instance}")
	private String dbInstance;

	@Value("${app.database.type}")
	private String dbType;

	@Value("${spring.datasource.url}")
	private String dbUrl;
	
	@Value("${app.tla}")
	private String appTLA;
	
	@Value("${local.spring.datasource.password}")
	private String localInstancePwd;
	
	@Autowired
	AzmSecurityUtils azmSecurityUtils;

	@Override
	public void addInterceptors(final InterceptorRegistry registry) {
		registry.addInterceptor(buildWebContentInterceptor());
		registry.addInterceptor(new AuthorizationInterceptor(authorizationManager()));
		registry.addInterceptor(new EgnInterceptor()).addPathPatterns("/**");
		super.addInterceptors(registry);
	}

	@Override
    public void addArgumentResolvers(List<HandlerMethodArgumentResolver> argumentResolvers) {
        argumentResolvers.add(new ActiveUserHandlerMethodArgumentResolver());
        super.addArgumentResolvers(argumentResolvers);
    }
	
	@Bean
	  public AuthorizationManager authorizationManager() {
	    return new AzmAuthorizationManager(azmSecurityUtils);
	  }

	private HandlerInterceptor buildWebContentInterceptor() {
		final WebContentInterceptor interceptor = new WebContentInterceptor();
		interceptor.setCacheSeconds(0);
		//interceptor.setUseExpiresHeader(Boolean.TRUE);
		//interceptor.setUseCacheControlHeader(Boolean.TRUE);
		//interceptor.setUseCacheControlNoStore(Boolean.TRUE);
		return interceptor;
	}
	
	@Bean
	public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() throws IOException {
		return new PropertySourcesPlaceholderConfigurer();
	}
	
	@Bean
    public MultipartResolver multipartResolver(){
    	return new CommonsMultipartResolver();
    }
	
	@Bean
	public JAXBContext getJAXBContext(){
		JAXBContext context = null;
		try {
			context =  JAXBContext.newInstance(ObjectFactory.class);
		} catch (JAXBException e) {
			LOGGER.info(e.getMessage());
		}
		return context;
	}
	
	@Bean
	public DataSource dataSource() {
		
		CyberArkUtil pwdUtil = new CyberArkUtil();
		pwdUtil.setInstance(dbInstance);
		pwdUtil.setType(dbType);
		pwdUtil.setUserID(dbUserName);
		pwdUtil.setUsername(dbUserName);
		pwdUtil.setAppTLA("EGN");
		pwdUtil.setRunEnv(Util.getEnvironment());
		pwdUtil.setLocalEnvPassword(localInstancePwd);
		
	    DataSourceBuilder dataSourceBuilder = DataSourceBuilder.create();
	        dataSourceBuilder.url(dbUrl);
	        dataSourceBuilder.username(dbUserName);
			//dataSourceBuilder.password(localInstancePwd);
	        dataSourceBuilder.password(pwdUtil.getPasswordFrmCyberArk());
	        return dataSourceBuilder.build();   
	}
}
