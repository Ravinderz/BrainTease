package com.uprr.app.egn.controller;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.uprr.app.egn.dto.RequestSearchData;
import com.uprr.app.egn.dto.SearchCriteria;
import com.uprr.app.egn.dto.SearchRequest;
import com.uprr.app.egn.dto.WorkstationEvaluation;
import com.uprr.app.egn.service.IAuthorizationService;
import com.uprr.app.egn.service.SearchService;
import com.uprr.app.egn.util.Util;
import com.uprr.azm.shared.mvc.security.authorization.Attribute;
import com.uprr.azm.shared.mvc.security.authorization.Authorize;
import com.uprr.ui.shared.user.ActiveUserId;
import com.uprr.ui.shared.user.spring.mvc.ActiveUser;

@RestController
@RequestMapping("search")
public class SearchController {
	
	Logger logger = LogManager.getLogger(SearchController.class);
	
	@Autowired
	SearchService searchService;
	
	@Autowired
	IAuthorizationService authService;	   

	@PostMapping("search/{role}")
	public List<WorkstationEvaluation> searchRequest(@PathVariable("role") String role,@RequestBody SearchRequest request){
		logger.info(request);
		return searchService.searchRequest(request,role);
	}
	
	@PostMapping("searchCriteria/{role}")
	public RequestSearchData getSearchRequest(@PathVariable("role") String role,@RequestBody SearchCriteria searchCriteria){
		SearchRequest request = new SearchRequest(searchCriteria.getFromDate(),searchCriteria.getToDate(),searchCriteria.getEmployeeId(),searchCriteria.getStatus(),searchCriteria.getRole(),searchCriteria.getSupvId());
		logger.info(request);
		logger.info(searchCriteria);
		return searchService.getSearchRequest(request,role,searchCriteria);
	}
	
	@PostMapping("search/{userRole}/{supvId}")
	public ResponseEntity<RequestSearchData> initialSearchRequest(@PathVariable("userRole") String role, @PathVariable("supvId") String supvId,@RequestBody SearchCriteria searchCriteria,@ActiveUser ActiveUserId activeUser){
		logger.info("inside search based on role");
		if(Util.isLocalMode() || activeUser.getEmployeeId().equalsIgnoreCase(supvId)){
			return new ResponseEntity<RequestSearchData>(searchService.initialSearchRequest(role,supvId,searchCriteria), HttpStatus.OK);
		}else{
			RequestSearchData data = null;
			return new ResponseEntity<RequestSearchData>(data, HttpStatus.FORBIDDEN);
		}
	}
	
	@PostMapping("getResultsForSpecialist")
	@Authorize(
			actions = {@Attribute(key="action-id", value="access")},
			resources = {@Attribute(key="resource-id", value="ergonomics"),@Attribute(key="feature-id", value="create-assessment")}
			)
	public RequestSearchData getResultsForSpecialist(@RequestBody SearchCriteria searchCriteria){
		logger.info("inside search based on role");
		return searchService.getResultsForSpecialist(searchCriteria);
	}

	@PostMapping(value = "getSearchResults")
	public ResponseEntity<RequestSearchData> getSearchResults(@RequestBody SearchCriteria searchCriteria,@ActiveUser ActiveUserId activeUser) {
		logger.info(searchCriteria);
		if(Util.isLocalMode() || authService.canApproveMedicalRequest(activeUser.getUserId()) || authService.canCreateCostItems(activeUser.getUserId())){
			return new ResponseEntity<RequestSearchData>(searchService.getSearchResults(searchCriteria),HttpStatus.OK);	
		}else{
			RequestSearchData data = null;
			return new ResponseEntity<RequestSearchData>(data, HttpStatus.FORBIDDEN);
		}
		
	} 
	
	
	@PostMapping("getUserRequests/{userId}")
	public ResponseEntity<RequestSearchData> initialSearchRequest(@PathVariable("userId") String userId,@RequestBody SearchCriteria searchCriteria,@ActiveUser ActiveUserId activeUser){
		logger.info("inside search based on role");
		if(Util.isLocalMode() || activeUser.getEmployeeId().equalsIgnoreCase(userId)){
			return new ResponseEntity<RequestSearchData>(searchService.getUserRequests(userId,searchCriteria), HttpStatus.OK);
		}else{
			RequestSearchData data = null;
			return new ResponseEntity<RequestSearchData>(data, HttpStatus.FORBIDDEN);
		}
		
	}
	
	@PostMapping("getResultsForFacilitiesMgmt")
	@Authorize(
			actions = {@Attribute(key="action-id", value="access")},
			resources = {@Attribute(key="resource-id", value="ergonomics"),@Attribute(key="feature-id", value="edit-cost")}
			)
	public RequestSearchData getResultsForFacilitiesMgmt(@RequestBody SearchCriteria searchCriteria){
		logger.info("inside search based on role");
		return searchService.getResultsForFacilitiesMgmt(searchCriteria);
	}
	
	@PostMapping("searchCriteriaFacilitiesMgmt/{role}")
	@Authorize(
			actions = {@Attribute(key="action-id", value="access")},
			resources = {@Attribute(key="resource-id", value="ergonomics"),@Attribute(key="feature-id", value="edit-cost")}
			)
	public RequestSearchData getSearchRequestFacilitiesMgmt(@PathVariable("role") String role,@RequestBody SearchCriteria searchCriteria){
		SearchRequest request = new SearchRequest(searchCriteria.getFromDate(),searchCriteria.getToDate(),searchCriteria.getEmployeeId(),searchCriteria.getStatus(),searchCriteria.getRole(),searchCriteria.getSupvId());
		logger.info(request);
		logger.info(searchCriteria);
		return searchService.getResultsForFacilitiesMgmtWithCrtrea(searchCriteria);
	}
	
}
