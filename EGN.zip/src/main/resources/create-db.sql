CREATE SCHEMA egn;

create sequence egn.egn_wkst_evln_q1;
create sequence egn.egn_wkst_asmt_q1;

CREATE TABLE egn.egn_role (
  role_id INTEGER PRIMARY KEY,
  role_name VARCHAR(30),
  role_desc VARCHAR(100),
  crtd_user_id varchar(100),
  crtn_tmst TIMESTAMP,
  last_updt_user_id varchar(100),
  last_updt_tmst TIMESTAMP
);

CREATE TABLE egn.egn_empl (
  empl_id VARCHAR(20) PRIMARY KEY,
  empl_name VARCHAR(30),
  empl_wkst_loca_city VARCHAR(100),
  empl_wkst_loca_bldg VARCHAR(100),
  empl_shft_hrs VARCHAR(50),
  role_id INTEGER,
  rqng_supv VARCHAR(100),
  rqng_supv_emal VARCHAR(100),
  rqng_supv_ph INTEGER,
  crtd_user_id varchar(100),
  crtn_tmst TIMESTAMP,
  last_updt_user_id varchar(100),
  last_updt_tmst TIMESTAMP,
  CONSTRAINT role_fk FOREIGN KEY (role_id) REFERENCES egn.egn_role(role_id)
);

CREATE TABLE egn.egn_wkst_evln (
  req_id VARCHAR(20) PRIMARY KEY,
  empl_id VARCHAR(20),
  req_date DATE,
  cost_cent_info VARCHAR(20),
  dept_cas_Pyer_name VARCHAR(20),
  mdcl_req_flag BOOLEAN,
  non_mdcl_req_flag BOOLEAN,
  expd_rtrn_date DATE,
  ffd_nrs_name VARCHAR(25),
  pcp_name VARCHAR(50),
  pcp_ph INTEGER,
  evln_desc VARCHAR(255),
  req_stat_info VARCHAR(10),
  cad_wkst_flag BOOLEAN,
  shpg_mail_room_stk_flag BOOLEAN,
  dsph_cust_svc_flag BOOLEAN,
  part_asby_flag BOOLEAN,
  admn_clcl_flag BOOLEAN,
  comp_kybd_mous_flag BOOLEAN,
  chr_foot_rest_flag BOOLEAN,
  sit_stnd_desk_flag BOOLEAN,
  comp_mntr_flag BOOLEAN,
  genl_wkst_eval_flag BOOLEAN,
  crtd_user_id varchar(100),
  crtn_tmst TIMESTAMP,
  last_updt_user_id varchar(100),
  last_updt_tmst TIMESTAMP,
  CONSTRAINT wsevaluation_fk FOREIGN KEY (empl_id) REFERENCES egn.egn_empl(empl_id)
);

CREATE TABLE egn.egn_wkst_asmt (
	req_id VARCHAR(20),
	asmt_id VARCHAR(20) PRIMARY KEY,
	acct_info VARCHAR(20),
	empl_info VARCHAR(20),
	asmt_date DATE,
	admn_id VARCHAR(225),
	rpts_sent_by_id VARCHAR(225),
	loca_info VARCHAR(225),
	wkst_asmt_name VARCHAR(225),
	rpts_sent_to_id VARCHAR(225),
	asmt_resn_info VARCHAR(255),
	cur_symp_info VARCHAR(20),
	asmt_wkst_pstr_desc VARCHAR(225),
	cur_chr_desc VARCHAR(225),
	mntr_desc VARCHAR(225),
	seat_hgt VARCHAR(225),
	mntr_hgt INTEGER,
	seat_deph VARCHAR(225),
	kybd_tray_mous_desc VARCHAR(225),
	back_rest_desc VARCHAR(225),
	asmt_cmnt VARCHAR(225),
	arm_rest_desc VARCHAR(225),
	adj_made_info VARCHAR(225),
	chr_rcmn_desc VARCHAR(225),
	oth_eqmt_need VARCHAR(225),
	flw_up_thrp_name VARCHAR(200),
	asmt_stat_info VARCHAR(20),
	asmt_smry_desc varchar(255),
	crtd_user_id varchar(100),
    crtn_tmst TIMESTAMP,
    last_updt_user_id varchar(100),
    last_updt_tmst TIMESTAMP,
	CONSTRAINT wsassessment_request_fk FOREIGN KEY (req_id) REFERENCES egn.egn_wkst_evln(req_id),
	CONSTRAINT wsassessment_employee_fk FOREIGN KEY (empl_info) REFERENCES egn.egn_empl(empl_id)
);


create table egn.egn_drop_down_lkup (
	fld_name varchar(255),
	fld_valu varchar(255),
	crtd_user_id varchar(100),
	crtn_tmst TIMESTAMP,
	last_updt_user_id varchar(100),
	last_updt_tmst TIMESTAMP
);

create table egn.egn_updt_docs (
	req_id varchar(255),
	doc_guid varchar(255),
	doc_name varchar(255),
	doc_desc varchar(255),
	crtd_user_id varchar(100),
	crtn_tmst TIMESTAMP,
	last_updt_user_id varchar(100),
	last_updt_tmst TIMESTAMP,
	CONSTRAINT document_created_by_fk FOREIGN KEY (crtd_user_id) REFERENCES egn.egn_empl(empl_id),
	CONSTRAINT document_updated_by_fk FOREIGN KEY (last_updt_user_id) REFERENCES egn.egn_empl(empl_id)
);
