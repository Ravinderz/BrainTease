package com.uprr.app.egn.dao.impl;

import java.util.List;

import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.Assert;

import com.uprr.app.egn.EgnApplication;
import com.uprr.app.egn.config.TestConfig;
import com.uprr.app.egn.dao.IRequestUpdateHistoryDAO;
import com.uprr.app.egn.dto.RequestHistory;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = {TestConfig.class,EgnApplication.class})
@TestPropertySource(locations="classpath:test-application.properties")
@Rollback(true)
public class RequestUpdateHistoryDAOTest {

	@Autowired
	IRequestUpdateHistoryDAO reqHistDao;
	
	@BeforeClass
	public static void before(){
		System.setProperty("uprr.implementation.environment", "local");
	}
	
	
	@Test
	public void getEvalRequestHistoryByRequestIdTest(){
		List<RequestHistory> list = reqHistDao.getEvalRequestHistoryByRequestId("1");
		Assert.notNull(list,"got all documents from in memory-DB");
	}
	
	@Test
	public void insertRequestUpdateHistoryTest(){
		RequestHistory history = new RequestHistory();
		history.setReqHistoryId("1");
		history.setEvalReqId("1");
		history.setEvalAsmtId("1");
		history.setItemId("1");
		history.setOldStatusValue("Submitted");
		history.setNewStatusValue("Supervisor Approved");
		history.setChangedBy("0454897");
		history.setCreatedBy("0454897");
		history.setUpdatedBy("0454897");
		boolean result = reqHistDao.insertRequestUpdateHistory("Submitted", "Supervisor Approved", "", "0454897", "1", "1", "1");
		Assert.isTrue(result,"inserted successfully");
	}
}
