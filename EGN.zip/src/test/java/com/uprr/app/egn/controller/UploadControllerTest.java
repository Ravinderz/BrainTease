package com.uprr.app.egn.controller;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.uprr.app.egn.dto.Document;
import com.uprr.app.egn.service.IAuthorizationService;
import com.uprr.app.egn.service.IDocService;
import com.uprr.ui.shared.user.ActiveUserId;

public class UploadControllerTest {
	private MockMvc mockMvc;

	@Mock
	IDocService docService;
	
	@Mock
	ActiveUserId userId;
	
	@Mock
	IAuthorizationService authService;
	
	@InjectMocks
	UploadController uploadController;

	@Before
    public void setup() {
        // Process mock annotations
        MockitoAnnotations.initMocks(this);
        // Setup Spring test in standalone mode
        mockMvc = MockMvcBuilders.standaloneSetup(uploadController).build();
    }
	
	@Test
	public void callEchoServicesTest() throws Exception{
		 doNothing().when(docService).callEchoService();
		 mockMvc.perform(get("/upload/callEchoService")).andDo(print())
		         .andExpect(status().isOk());
		 }
	
	/*@Test
	public void uploadFileToEdocsTest() throws Exception{
		 doNothing().when(docService).callEchoService();
		 mockMvc.perform(get("/upload/callEchoService")).andDo(print())
		         .andExpect(status().isOk());
		 }*/
	
	@Test
	public void downloadFileFromEdocsTestForSpecialist() throws Exception{
		 when(docService.getDoc("123e-sdfr-234x-4vdfzx")).thenReturn("successfull".getBytes());
		 when(userId.getUserId()).thenReturn("xmie003");
		 when(authService.canApproveMedicalRequest("xmie003")).thenReturn(true);
		 uploadController.downloadFileFromEdocs("9999997", "123e-sdfr-234x-4vdfzx", userId);
		 }
	
	
	@Test
	public void downloadFileFromEdocsTestForNurse() throws Exception{
		 when(docService.getDoc("123e-sdfr-234x-4vdfzx")).thenReturn("successfull".getBytes());
		 when(userId.getUserId()).thenReturn("xmie003");
		 when(authService.canApproveMedicalRequest("xmie003")).thenReturn(false);
		 when(authService.canCreateAssessment("xmie003")).thenReturn(true);
		 uploadController.downloadFileFromEdocs("9999997", "123e-sdfr-234x-4vdfzx", userId);
		 }
	
	
	@Test
	public void downloadFileFromEdocsTestForEmployee() throws Exception{
		 when(docService.getDoc("123e-sdfr-234x-4vdfzx")).thenReturn("successfull".getBytes());
		 when(userId.getUserId()).thenReturn("xmie003");
		 when(authService.canApproveMedicalRequest("xmie003")).thenReturn(false);
		 when(authService.canCreateAssessment("xmie003")).thenReturn(true);
		 when(userId.getEmployeeId()).thenReturn("9999997");
		 uploadController.downloadFileFromEdocs("9999997", "123e-sdfr-234x-4vdfzx", userId);
		 }
	
	
	@Test
	public void saveFileToDatabaseTest() throws Exception{
		List<Document> docs = new ArrayList<>();
		Document doc = new Document();
		docs.add(doc);
		 when(docService.saveDocs(docs)).thenReturn(true);
		 mockMvc.perform(post("/upload/saveUploadedFiles").content(asJsonString(docs)).contentType(MediaType.APPLICATION_JSON_UTF8))
				 .andDo(print())
		         .andExpect(status().isOk());
		 }
	
	public static String asJsonString(final Object obj) {
	    try {
	        final ObjectMapper mapper = new ObjectMapper();
	        final String jsonContent = mapper.writeValueAsString(obj);
	        return jsonContent;
	    } catch (Exception e) {
	        throw new RuntimeException(e);
	    }
	} 
}
