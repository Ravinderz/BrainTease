package com.uprr.app.egn.controller;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyList;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import javax.jms.JMSException;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.uprr.app.egn.dto.Checkbox;
import com.uprr.app.egn.dto.Document;
import com.uprr.app.egn.dto.UpdateStatus;
import com.uprr.app.egn.dto.WorkstationEvaluation;
import com.uprr.app.egn.service.EmpCostCenterService;
import com.uprr.app.egn.service.IAuthorizationService;
import com.uprr.app.egn.service.WorkstationEvaluationService;
import com.uprr.ui.shared.user.ActiveUserId;

@RunWith(SpringJUnit4ClassRunner.class)
public class WorkstationRequestControllerTest {
	private MockMvc mockMvc;

	@Mock
	WorkstationEvaluationService wsEvalService;
	
	@Mock
	EmpCostCenterService costCenterService;
	
	@Mock
	ActiveUserId userId;
	
	@Mock
	IAuthorizationService authService;
	
	@InjectMocks
	WorkstationRequestController workstationRequestController;
	
	@Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(workstationRequestController).build();
    }
	
	@Test
	public void getWorkstationRequestDataFromDBTest() throws Exception{
		List<WorkstationEvaluation> records = new ArrayList<WorkstationEvaluation>();
		Checkbox checkbox = new Checkbox();
		checkbox.setComputerKeyboardMouse(true);
		checkbox.setChairFootrest(true);
		checkbox.setcADWS(true);
		checkbox.setrMCC(true);

		WorkstationEvaluation record1 = new WorkstationEvaluation("John Smith", "041890", "04C 288","", "9 to 6 PM", "Jack", "10/14/2017", "982346", "jim@up.com", "1234567890", "Pual George", null, null,  "", false, false, "12/24/2018", "Beth", "Jack", "402544134", "","Open",checkbox, null,"0454897");
		WorkstationEvaluation record2 = new WorkstationEvaluation("Scott osbourne", "043990", "04C 288", "","9 to 6 PM", "Jack", "10/20/2017", "982346", "jacob@up.com", "1234567890", "Pual George", null, null,"", false, false, "12/24/2018", "Beth", "Jack", "402544134", "", "Open",checkbox, null,"0454897");
		WorkstationEvaluation record3 = new WorkstationEvaluation("Jason Ray", "051790", "04C 288", "","9 to 6 PM", "Jack", "11/10/2017", "982346", "robert@up.com", "1234567890", "Pual George", null, null,"", false, false, "12/24/2018", "Beth", "Jack", "402544134", "", "Open",checkbox, null,"0454897");
		records.add(record1);
		records.add(record2);
		records.add(record3);
		when(wsEvalService.getRequestDataFromDB("0454897")).thenReturn(records);
		when(userId.getEmployeeId()).thenReturn("0454897");
		workstationRequestController.getWorkstationRequestsForSupvId("0454897", userId);

	}
	
	@Test
	public void getWorkstationRequestDataFromDBForbiddenTest() throws Exception{
		List<WorkstationEvaluation> records = new ArrayList<WorkstationEvaluation>();
		Checkbox checkbox = new Checkbox();
		checkbox.setComputerKeyboardMouse(true);
		checkbox.setChairFootrest(true);
		checkbox.setcADWS(true);
		checkbox.setrMCC(true);

		WorkstationEvaluation record1 = new WorkstationEvaluation("John Smith", "041890", "04C 288","", "9 to 6 PM", "Jack", "10/14/2017", "982346", "jim@up.com", "1234567890", "Pual George", null, null,  "", false, false, "12/24/2018", "Beth", "Jack", "402544134", "","Open",checkbox, null,"0454897");
		WorkstationEvaluation record2 = new WorkstationEvaluation("Scott osbourne", "043990", "04C 288", "","9 to 6 PM", "Jack", "10/20/2017", "982346", "jacob@up.com", "1234567890", "Pual George", null, null,"", false, false, "12/24/2018", "Beth", "Jack", "402544134", "", "Open",checkbox, null,"0454897");
		WorkstationEvaluation record3 = new WorkstationEvaluation("Jason Ray", "051790", "04C 288", "","9 to 6 PM", "Jack", "11/10/2017", "982346", "robert@up.com", "1234567890", "Pual George", null, null,"", false, false, "12/24/2018", "Beth", "Jack", "402544134", "", "Open",checkbox, null,"0454897");
		records.add(record1);
		records.add(record2);
		records.add(record3);
		when(wsEvalService.getRequestDataFromDB("0454897")).thenReturn(records);
		when(userId.getEmployeeId()).thenReturn("0454898");
		workstationRequestController.getWorkstationRequestsForSupvId("0454897", userId);
	}
	
	@Test
	public void submitWorkstationRequestTestWithInvalidRequest() throws Exception{
		WorkstationEvaluation wsEval = new WorkstationEvaluation();
		when(wsEvalService.submitWorkStationRequest(any(WorkstationEvaluation.class))).thenReturn(wsEval);
		mockMvc.perform(post("/workstationRequest/submitWorkstationRequest").content(asJsonString(wsEval)).contentType(MediaType.APPLICATION_JSON_UTF8))
				 .andDo(print())
		         .andExpect(status().is(500))
		         .andReturn();
		}
	
	@Test
	public void submitWorkstationRequestTestWithvalidRequest() throws Exception {
		WorkstationEvaluation wsEval = new WorkstationEvaluation();
		wsEval.setRequestId("1");
		when(wsEvalService.submitWorkStationRequest(any(WorkstationEvaluation.class))).thenReturn(wsEval);
		mockMvc.perform(post("/workstationRequest/submitWorkstationRequest").content(asJsonString(wsEval)).contentType(MediaType.APPLICATION_JSON_UTF8))
				 .andDo(print())
		         .andExpect(status().is(200))
		         .andReturn();
		}
	
	@Test
	public void updateWorkstationRequestTestWithvalidRequest() throws Exception {
		Checkbox checkbox = new Checkbox();
		checkbox.setComputerKeyboardMouse(true);
		checkbox.setChairFootrest(true);
		checkbox.setcADWS(true);
		checkbox.setrMCC(true);
		WorkstationEvaluation wsEval = new WorkstationEvaluation("John Smith", "041890", "04C 288","", "9 to 6 PM", "Jack", "10/14/2017", "982346", "jim@up.com", "1234567890", "Pual George", null, null,"", false, false, "12/24/2018", "Beth", "Jack", "402544134", "","Open",checkbox, null,"0454897");
		when(wsEvalService.updateWorkStationRequest(any(WorkstationEvaluation.class))).thenReturn(true);
		mockMvc.perform(post("/workstationRequest/updateWorkstationRequest").content(asJsonString(wsEval)).contentType(MediaType.APPLICATION_JSON_UTF8))
				 .andDo(print())
		         .andExpect(status().is(200))
		         .andReturn();
		}
	
	@Test
	public void updateWorkstationRequestTestWithInvalidRequest() throws Exception {
		WorkstationEvaluation wsEval = new WorkstationEvaluation();
		when(wsEvalService.updateWorkStationRequest(wsEval)).thenReturn(false);
		mockMvc.perform(post("/workstationRequest/updateWorkstationRequest").content(asJsonString(wsEval)).contentType(MediaType.APPLICATION_JSON_UTF8))
				 .andDo(print())
		         .andExpect(status().is(500))
		         .andReturn();
	}
	
	@Test
	public void saveWorkstationRequestTestWithInvalidRequest() throws Exception{
		WorkstationEvaluation wsEval = new WorkstationEvaluation();
		when(wsEvalService.saveWorkStationRequest(any(WorkstationEvaluation.class))).thenReturn(wsEval);
		mockMvc.perform(post("/workstationRequest/saveWorkstationRequest").content(asJsonString(wsEval)).contentType(MediaType.APPLICATION_JSON_UTF8))
				 .andDo(print())
		         .andExpect(status().is(500))
		         .andReturn();
		}
	
	@Test
	public void saveWorkstationRequestTestWithvalidRequest() throws Exception {
		WorkstationEvaluation wsEval = new WorkstationEvaluation();
		wsEval.setRequestId("1");
		when(wsEvalService.saveWorkStationRequest(any(WorkstationEvaluation.class))).thenReturn(wsEval);
		mockMvc.perform(post("/workstationRequest/saveWorkstationRequest").content(asJsonString(wsEval)).contentType(MediaType.APPLICATION_JSON_UTF8))
				 .andDo(print())
		         .andExpect(status().is(200))
		         .andReturn();
		}
	
	@Test
	public void updateStatusTestWithInvalidRequest() throws Exception {
		UpdateStatus updateStatus = new UpdateStatus();
		List<WorkstationEvaluation> list = new ArrayList<>();
		WorkstationEvaluation eval = new WorkstationEvaluation();
		eval.setRequestingSupervisorId("9999998");
		list.add(eval);
		updateStatus.setWorkstationEvaluation(list);
		when(wsEvalService.updateStatus(updateStatus)).thenReturn(false);
		when(userId.getUserId()).thenReturn("xmie003");
		when(authService.canApproveMedicalRequest("xmie003")).thenReturn(true);
		workstationRequestController.updateStatus(updateStatus, userId);
	}
	
	@Test
	public void updateStatusTestWithvalidRequestForNurse() throws Exception {
		UpdateStatus updateStatus = new UpdateStatus();
		List<WorkstationEvaluation> list = new ArrayList<>();
		WorkstationEvaluation eval = new WorkstationEvaluation();
		eval.setRequestingSupervisorId("9999998");
		list.add(eval);
		updateStatus.setWorkstationEvaluation(list);
		when(wsEvalService.updateStatus(updateStatus)).thenReturn(true);
		when(userId.getUserId()).thenReturn("xmie003");
		when(authService.canApproveMedicalRequest("xmie003")).thenReturn(true);
		workstationRequestController.updateStatus(updateStatus, userId);
		}
	
	@Test
	public void updateStatusTestWithvalidRequestForSupv() throws Exception {
		UpdateStatus updateStatus = new UpdateStatus();
		List<WorkstationEvaluation> list = new ArrayList<>();
		WorkstationEvaluation eval = new WorkstationEvaluation();
		eval.setRequestingSupervisorId("9999998");
		list.add(eval);
		updateStatus.setWorkstationEvaluation(list);
		when(wsEvalService.updateStatus(updateStatus)).thenReturn(true);
		when(userId.getUserId()).thenReturn("xmie003");
		when(userId.getEmployeeId()).thenReturn("9999998");
		when(authService.canApproveMedicalRequest("xmie003")).thenReturn(false);
		workstationRequestController.updateStatus(updateStatus, userId);
		}
	
	@Test
	public void updateStatusTestWithvalidRequestForEmpl() throws Exception {
		UpdateStatus updateStatus = new UpdateStatus();
		List<WorkstationEvaluation> list = new ArrayList<>();
		WorkstationEvaluation eval = new WorkstationEvaluation();
		eval.setRequestingSupervisorId("9999998");
		list.add(eval);
		updateStatus.setWorkstationEvaluation(list);
		updateStatus.setEmpId("9999993");
		when(wsEvalService.updateStatus(updateStatus)).thenReturn(true);
		when(userId.getUserId()).thenReturn("xmie003");
		when(userId.getEmployeeId()).thenReturn("9999993");
		when(authService.canApproveMedicalRequest("xmie003")).thenReturn(false);
		workstationRequestController.updateStatus(updateStatus, userId);
		}
	
	@Test
	public void updateStatusTestThrowsJmsException() throws Exception {
		UpdateStatus updateStatus = new UpdateStatus();
		List<WorkstationEvaluation> list = new ArrayList<>();
		WorkstationEvaluation eval = new WorkstationEvaluation();
		eval.setRequestingSupervisorId("9999998");
		list.add(eval);
		updateStatus.setWorkstationEvaluation(list);
		when(wsEvalService.updateStatus(updateStatus)).thenThrow(new JMSException("failed"));
		when(userId.getUserId()).thenReturn("xmie003");
		when(authService.canApproveMedicalRequest("xmie003")).thenReturn(true);
		workstationRequestController.updateStatus(updateStatus, userId);
		}
	
	@Test
	public void updateStatusTestThrowsException() throws Exception {
		UpdateStatus updateStatus = new UpdateStatus();
		List<WorkstationEvaluation> list = new ArrayList<>();
		WorkstationEvaluation eval = new WorkstationEvaluation();
		eval.setRequestingSupervisorId("9999998");
		list.add(eval);
		updateStatus.setWorkstationEvaluation(list);
		when(wsEvalService.updateStatus(updateStatus)).thenThrow(Exception.class);
		when(userId.getUserId()).thenReturn("xmie003");
		when(authService.canApproveMedicalRequest("xmie003")).thenReturn(true);
		workstationRequestController.updateStatus(updateStatus, userId);
	}	
	
	@Test
	@Ignore
	public void getRequestByIdTestWithValidRequest() throws Exception {
		WorkstationEvaluation wsEval = new WorkstationEvaluation();
		when(wsEvalService.getRequestById("1")).thenReturn(wsEval);
		mockMvc.perform(post("/workstationRequest/getRequestById/{requestId}","1"))
				 .andDo(print())
		         .andExpect(status().isOk())
		         .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8) )
		         .andReturn();
	}
	
	@Test
	@Ignore
	public void getRequestByIdTestWithInValidRequest() throws Exception {
		when(wsEvalService.getRequestById(anyString())).thenReturn(null);
		mockMvc.perform(post("/workstationRequest/getRequestById/{requestId}","1"))
				 .andDo(print())
		         .andExpect(status().is(500))
		         .andReturn();
	}
	
	@Test
	public void getDocumentByIdTestWithValidRequestForEmployee() throws Exception {
		Document doc1 = new Document();
		Document doc2 = new Document();
		List<Document> docList = new ArrayList<>();
		docList.add(doc1);
		docList.add(doc2);
		when(wsEvalService.getDocumentsByRequestId("1")).thenReturn(docList);
		when(userId.getEmployeeId()).thenReturn("9999998");
		workstationRequestController.getDocumentsByRequestId("9999998", "1", userId);
	}
	
	@Test
	public void getDocumentByIdTestWithValidRequestForNurse() throws Exception {
		Document doc1 = new Document();
		Document doc2 = new Document();
		List<Document> docList = new ArrayList<>();
		docList.add(doc1);
		docList.add(doc2);
		when(wsEvalService.getDocumentsByRequestId("1")).thenReturn(docList);
		when(userId.getEmployeeId()).thenReturn("9999997");
		when(userId.getUserId()).thenReturn("xmie003");
		when(authService.canApproveMedicalRequest("xmie003")).thenReturn(true);
		workstationRequestController.getDocumentsByRequestId("9999998", "1", userId);
	}
	
	@Test
	public void getDocumentByIdTestWithInValidRequest() throws Exception {
		when(wsEvalService.getDocumentsByRequestId("1")).thenReturn(null);
		when(userId.getEmployeeId()).thenReturn("9999997");
		when(userId.getUserId()).thenReturn("xmie003");
		when(authService.canApproveMedicalRequest("xmie003")).thenReturn(false);
		workstationRequestController.getDocumentsByRequestId("9999998", "1", userId);
	}

	public static String asJsonString(final Object obj) {
	    try {
	        final ObjectMapper mapper = new ObjectMapper();
	        final String jsonContent = mapper.writeValueAsString(obj);
	        return jsonContent;
	    } catch (Exception e) {
	        throw new RuntimeException(e);
	    }
	} 
	
	@Test
	public void getCostCenterDtlsTestWithValidRequest() throws Exception {
		List<String> wsEval = new ArrayList<String>();
		
		when(costCenterService.getCostCenterDetails("0452571")).thenReturn(anyList());
		mockMvc.perform(get("/workstationRequest/getCostCenterDtls/{employeeId}","0452571"))
				 .andDo(print())
		         .andExpect(status().isOk())
		         .andReturn();
	}
	@Test
	public void getCostCenterDtlsTestWithInValidRequest() throws Exception {
		when(costCenterService.getCostCenterDetails(anyString())).thenReturn(null);
		mockMvc.perform(get("/workstationRequest/getCostCenterDtls/{employeeId}","0000000"))
				 .andDo(print())
		         .andExpect(status().is(500))
		         .andReturn();
	}
	
	
	
	@Test
	public void getWorkstationRequestsFromDBTest() throws Exception {
		mockMvc.perform(get("/workstationRequest/getDataFromDB"))
				 .andDo(print())
		         .andExpect(status().is(200))
		         .andReturn();
	}
	
	@Test
	public void getAllMedicalRequestsTest() throws Exception {
		mockMvc.perform(get("/workstationRequest/getAllMedicalRequests"))
				 .andDo(print())
		         .andExpect(status().is(204))
		         .andReturn();
	}
	
	@Test
	public void getRequestByUserTest() throws Exception {
		mockMvc.perform(get("/workstationRequest/getRequestByUser/"+"0454897"))
				 .andDo(print())
		         .andExpect(status().is(405))
		         .andReturn();
	}
	
	@Test
	public void getRequestHistoryTest() throws Exception {
		mockMvc.perform(get("/workstationRequest/getRequestHistory/"+"1"))
				 .andDo(print())
		         .andExpect(status().is(500))
		         .andReturn();
	}
}