package com.uprr.app.egn.controller;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.uprr.app.egn.dto.ActionItem;
import com.uprr.app.egn.dto.RequestHistory;
import com.uprr.app.egn.dto.WorkstationEvaluation;
import com.uprr.app.egn.service.IAuthorizationService;
import com.uprr.app.egn.service.ItemService;
import com.uprr.ui.shared.user.ActiveUserId;

@RunWith(SpringJUnit4ClassRunner.class)
public class ItemControllerTest {


	private MockMvc mockMvc;

	@Mock
	ItemService itemService;
	
	@Mock
	ActiveUserId userId;
	
	@Mock
	IAuthorizationService authService;
	
	@InjectMocks
	ItemController itemController;
	
	@Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(itemController).build();
    }
	
	@Test
	public void addPurchaseItemForIHATest() throws Exception{
		ActionItem item = new ActionItem();
		item.setItemId(2);
		when(itemService.insertPurchaseItem(any(ActionItem.class))).thenReturn(item);
		when(userId.getUserId()).thenReturn("xmie003");
		when(authService.canCreateAssessment("xmie003")).thenReturn(false);
		when(authService.canCreateCostItems("xmie003")).thenReturn(true);
		itemController.insertPurchaseItem(item, userId);
		
	}
	
	@Test
	public void addPurchaseItemForEGNSpecialistTest() throws Exception{
		ActionItem item = new ActionItem();
		item.setItemId(2);
		when(itemService.insertPurchaseItem(any(ActionItem.class))).thenReturn(item);
		when(userId.getUserId()).thenReturn("xmie003");
		when(authService.canCreateAssessment("xmie003")).thenReturn(true);
		itemController.insertPurchaseItem(item, userId);
		
	}
	
	@Test
	public void addPurchaseItemForFaclitiesManagementTest() throws Exception{
		ActionItem item = new ActionItem();
		item.setItemId(2);
		when(itemService.insertPurchaseItem(any(ActionItem.class))).thenReturn(item);
		when(userId.getUserId()).thenReturn("xmie003");
		when(authService.canCreateAssessment("xmie003")).thenReturn(false);
		when(authService.canCreateCostItems("xmie003")).thenReturn(false);
		when(authService.canEditCostItems("xmie003")).thenReturn(true);
		itemController.insertPurchaseItem(item, userId);
		
	}
	
	@Test
	public void addPurchaseItemTestWithResultFalse() throws Exception{
		ActionItem item = new ActionItem();
		item.setItemId(0);
		when(itemService.insertPurchaseItem(item)).thenReturn(item);
		when(userId.getUserId()).thenReturn("xmie003");
		when(authService.canCreateAssessment("xmie003")).thenReturn(true);
		itemController.insertPurchaseItem(item, userId);
	}
	
	@Test
	public void addPurchaseItemTestWithForbiddenStatus() throws Exception{
		ActionItem item = new ActionItem();
		item.setItemId(0);
		when(itemService.insertPurchaseItem(any(ActionItem.class))).thenReturn(item);
		when(userId.getUserId()).thenReturn("xmie003");
		when(authService.canCreateAssessment("xmie003")).thenReturn(false);
		when(authService.canCreateCostItems("xmie003")).thenReturn(false);
		when(authService.canEditCostItems("xmie003")).thenReturn(false);
		itemController.insertPurchaseItem(item, userId);
	}
	
	@Test
	public void updatePurchaseItemTestForFacilitiesManagement() throws Exception{
		ActionItem item = new ActionItem();
		item.setItemId(2);
		when(itemService.updatePurchaseItem(item)).thenReturn(true);
		when(userId.getUserId()).thenReturn("xmie003");
		when(authService.canEditCostItems("xmie003")).thenReturn(true);
		itemController.updatePurchaseItem(item, userId);
	}
	
	@Test
	public void updatePurchaseItemTestForAssignedEmployee() throws Exception{
		ActionItem item = new ActionItem();
		item.setItemId(2);
		item.setAssignedToEmployeeId("9999999");
		when(itemService.updatePurchaseItem(item)).thenReturn(true);
		when(userId.getUserId()).thenReturn("xmie003");
		when(userId.getEmployeeId()).thenReturn("9999999");
		when(authService.canEditCostItems("xmie003")).thenReturn(false);
		itemController.updatePurchaseItem(item, userId);
	}
	
	@Test
	public void updatePurchaseItemTest() throws Exception{
		ActionItem item = new ActionItem();
		item.setItemId(2);
		when(itemService.updatePurchaseItem(item)).thenReturn(true);
		when(userId.getUserId()).thenReturn("xmie003");
		when(authService.canEditCostItems("xmie003")).thenReturn(true);
		itemController.updatePurchaseItem(item, userId);
	}
	
	@Test
	public void updatePurchaseItemTestWithResultFalse() throws Exception{
		ActionItem item = new ActionItem();
		item.setItemId(0);
		when(itemService.updatePurchaseItem(item)).thenReturn(false);
		when(userId.getUserId()).thenReturn("xmie003");
		when(authService.canEditCostItems("xmie003")).thenReturn(true);
		itemController.updatePurchaseItem(item, userId);
	}
	
	@Test
	public void getItemHistoryTest() throws Exception{
		List<RequestHistory> records = new ArrayList<>();
		RequestHistory hist = new RequestHistory();
		hist.setReqHistoryId("1");
		records.add(hist);
		when(itemService.getItemHistory("1")).thenReturn(records);
		
		mockMvc.perform(get("/purchaseItem/getItemHistory/1"))
				 .andDo(print())
		         .andExpect(status().isOk())
		         .andReturn();

	}
	
	@Test
	public void getItemHistoryTestWithNoRecords() throws Exception{
		List<RequestHistory> records = new ArrayList<>();
		when(itemService.getItemHistory("1")).thenReturn(records);
		
		mockMvc.perform(get("/purchaseItem/getItemHistory/1"))
				 .andDo(print())
		         .andExpect(status().isInternalServerError())
		         .andReturn();

	}
	
	
	@Test
	public void getItemAssignedToSupervisorTest() throws Exception{
		List<WorkstationEvaluation> records = new ArrayList<>();
		WorkstationEvaluation workEval = new WorkstationEvaluation();
		workEval.setRequestId("1");
		records.add(workEval);
		when(userId.getEmployeeId()).thenReturn("0439971");
		when(itemService.getItemsAssignedToSupervisor("0439971")).thenReturn(records);
		itemController.getItemsAssignedToSupervisor("0439971",userId);
	}

	
	public static String asJsonString(final Object obj) {
	    try {
	        final ObjectMapper mapper = new ObjectMapper();
	        final String jsonContent = mapper.writeValueAsString(obj);
	        return jsonContent;
	    } catch (Exception e) {
	        throw new RuntimeException(e);
	    }
	} 
}
