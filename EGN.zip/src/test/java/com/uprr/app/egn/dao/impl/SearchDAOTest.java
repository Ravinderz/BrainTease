package com.uprr.app.egn.dao.impl;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.uprr.app.egn.EgnApplication;
import com.uprr.app.egn.config.TestConfig;
import com.uprr.app.egn.dao.ISearchDAO;
import com.uprr.app.egn.dto.SearchCriteria;
import com.uprr.app.egn.dto.SearchRequest;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = {TestConfig.class,EgnApplication.class})
@TestPropertySource(locations="classpath:test-application.properties")
@Rollback(true)
public class SearchDAOTest {
	
	@Autowired
	ISearchDAO searchDao;
	
	@BeforeClass
	public static void before(){
		System.setProperty("uprr.implementation.environment", "local");
	}
	
	@Ignore
	@Test
	public void initialSearchRequestTest(){
		searchDao.initialSearchWorkstationRequest("user", "0454897");
	}
	
	@Test
	public void initialSearchRequestForSupervisorTest(){
		searchDao.initialSearchWorkstationRequest("supervisor", "00112233");
	}
	
	@Test
	public void searchWorkstationRequestWithIdTest(){
		SearchRequest request = new SearchRequest("","","0454897","","ada nurse","00112233");
		searchDao.searchWorkstationRequest(request, "ada nurse");
	}
	
	
	@Test
	public void searchWorkstationRequestWithDateTest(){
		SearchRequest request = new SearchRequest("2017-12-10","2018-6-28","","","ada nurse","00112233");
		searchDao.searchWorkstationRequest(request, "ada nurse");
	}
	
	@Test
	public void searchWorkstationRequestWithStatusTest(){
		SearchRequest request = new SearchRequest("","","","Submitted","ada nurse","00112233");
		searchDao.searchWorkstationRequest(request, "ada nurse");
	}
	
	@Test
	public void searchWorkstationRequestForSupervisorTest(){
		SearchRequest request = new SearchRequest("","","","Submitted","supervisor","00112233");
		searchDao.searchWorkstationRequest(request, "supervisor");
	}
	
	@Test
	public void getSearchWorkstationRequestsForSupervisor(){
		SearchRequest request = new SearchRequest("","","0454897","","supervisor","00112233");
		SearchCriteria criteria = new SearchCriteria(1,10,"crtn_tmst",5,"desc",1,1,10,false,null,null,null,null,"supervisor","00112233");
		searchDao.getSearchWorkstationRequests(request, "supervisor", criteria);
	}
	
	@Test
	public void getSearchWorkstationRequestsWithDate(){
		SearchRequest request = new SearchRequest("2017-12-10","2018-6-28","","","supervisor","00112233");
		SearchCriteria criteria = new SearchCriteria(1,10,"crtn_tmst",5,"desc",1,1,10,false,null,null,null,null,"supervisor","00112233");
		searchDao.getSearchWorkstationRequests(request, "supervisor", criteria);
	}
	
	@Test
	public void getSearchWorkstationRequestsWithStatus(){
		SearchRequest request = new SearchRequest("","","","Submitted","supervisor","00112233");
		SearchCriteria criteria = new SearchCriteria(1,10,"crtn_tmst",5,"desc",1,1,10,false,null,null,null,null,"supervisor","00112233");
		searchDao.getSearchWorkstationRequests(request, "supervisor", criteria);
	}
	
	@Test
	public void getSearchWorkstationRequestsWithOtherRole(){
		SearchRequest request = new SearchRequest("","","","Submitted","ada nurse","00112233");
		SearchCriteria criteria = new SearchCriteria(1,10,"crtn_tmst",5,"desc",1,1,10,false,null,null,null,null,"ada nurse","00112233");
		searchDao.getSearchWorkstationRequests(request, "ada nurse", criteria);
	}
	
	@Test
	public void getSearchCriteriaCount(){
		SearchRequest request = new SearchRequest("","","","Submitted","supervisor","00112233");
		SearchCriteria criteria = new SearchCriteria(1,10,"crtn_tmst",5,"desc",1,1,10,false,null,null,null,null,"supervisor","00112233");
		searchDao.getSearchCriteriaCount(criteria, request, "supervisor");
	}
	
	@Test
	public void getSearchCriteriaCountWithDate(){
		SearchRequest request = new SearchRequest("2017-12-10","2018-6-28","","","supervisor","00112233");
		SearchCriteria criteria = new SearchCriteria(1,10,"crtn_tmst",5,"desc",1,1,10,false,null,null,null,null,"supervisor","00112233");
		searchDao.getSearchCriteriaCount(criteria, request, "supervisor");
	}
	
	@Test
	public void getSearchCriteriaCountWithUser(){
		SearchRequest request = new SearchRequest("","","0454897","","supervisor","00112233");
		SearchCriteria criteria = new SearchCriteria(1,10,"crtn_tmst",5,"desc",1,1,10,false,null,null,null,null,"supervisor","00112233");
		searchDao.getSearchCriteriaCount(criteria, request, "supervisor");
	}
	
	@Test
	public void getSearchCriteriaCountForOtherUsers(){
		SearchRequest request = new SearchRequest("","","","Submitted","ada nurse","00112233");
		SearchCriteria criteria = new SearchCriteria(1,10,"crtn_tmst",5,"desc",1,1,10,false,null,null,null,null,"ada nurse","00112233");
		searchDao.getSearchCriteriaCount(criteria, request, "ada nurse");
	}

	
	@Test
	public void getWorkstationEvalSearchTotalCount(){
		SearchCriteria criteria = new SearchCriteria(1,10,"crtn_tmst",5,"desc",1,1,10,false,null,null,null,null,"ada nurse","00112233");
		searchDao.getWorkstationEvalSearchTotalCount(criteria);
	}
}
