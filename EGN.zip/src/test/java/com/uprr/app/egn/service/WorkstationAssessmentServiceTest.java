package com.uprr.app.egn.service;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyObject;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.jms.JmsException;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.uprr.app.egn.dao.IItemDAO;
import com.uprr.app.egn.dao.IRequestUpdateHistoryDAO;
import com.uprr.app.egn.dao.IWorkstationAssessmentDAO;
import com.uprr.app.egn.dao.IWorkstationEvaluationDAO;
import com.uprr.app.egn.dto.ActionItem;
import com.uprr.app.egn.dto.Dropdown;
import com.uprr.app.egn.dto.LoggedUserVO;
import com.uprr.app.egn.dto.SendMailVO;
import com.uprr.app.egn.dto.WorkstationAssessment;
import com.uprr.app.egn.dto.WorkstationEvaluation;

@RunWith(SpringJUnit4ClassRunner.class)
public class WorkstationAssessmentServiceTest {

    @Mock
    IWorkstationAssessmentDAO wsAssessmentdao;
    
    @Mock
    IRequestUpdateHistoryDAO reqHistDao;
    
    @Mock
    IItemDAO itemDao;
    
    @Mock
    IWorkstationEvaluationDAO wsEvalDao;

    @Mock
    IEmailService emailService;
    
    @InjectMocks
    WorkstationAssessmentService wsaService;
    
    

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void submitWorkstationAssessmentTest() throws JmsException, Exception {
        WorkstationAssessment wsAssessment = mock(WorkstationAssessment.class);
        WorkstationEvaluation wsEval = mock(WorkstationEvaluation.class);
        LoggedUserVO emp = mock(LoggedUserVO.class);
        when(wsEvalDao.getRequestById("1")).thenReturn(wsEval);
        when(wsAssessmentdao.submitWorkstationAssessment(wsAssessment)).thenReturn(1);
        when(wsAssessment.getStatus()).thenReturn("Assessment Complete");
        when(wsAssessment.getLoggedEmployee()).thenReturn(emp);
        when(emp.getEmployeeId()).thenReturn("123456");
        when(wsAssessment.getRequestId()).thenReturn("1");
        when(wsAssessment.getAssessmentId()).thenReturn("1");        
        LoggedUserVO vo = mock(LoggedUserVO.class);
        when(wsAssessment.getLoggedEmployee()).thenReturn(vo);
        when(wsAssessment.getLoggedEmployee().getEmployeeId()).thenReturn("9999999");
        when(wsAssessment.getStatus()).thenReturn("Submitted");
        when(wsEval.getStatus()).thenReturn("submitted");
        when(wsEvalDao.updateStatus(wsAssessment.getRequestId(), wsAssessment.getLoggedEmployee().getEmployeeId(), wsAssessment.getStatus())).thenReturn(true);
        when(reqHistDao.insertRequestUpdateHistory(anyString(), anyString(), any(), anyString(), anyString(), anyString(), any())).thenReturn(true);
        doNothing().when(emailService).sendEmailNotification(anyObject());
        wsaService.submitWorkstationAssessment(wsAssessment);
    }

    @Test
    public void getRequestByIdTest() {
        when(wsAssessmentdao.getRequestById(anyString())).thenReturn(new WorkstationAssessment());
        List<ActionItem> itemList = new ArrayList<>();
        when(itemDao.getAllItemsByAsmtId(anyString())).thenReturn(itemList);
        wsaService.getRequestById(anyString());
    }

    @Test
    public void updateWorkStationAssessmentTest() {
        WorkstationAssessment wsAssessment = mock(WorkstationAssessment.class);
        WorkstationAssessment wsAssessment2 = mock(WorkstationAssessment.class);
        when(wsAssessmentdao.updateWorkStationAssessment(wsAssessment)).thenReturn(true);
        when(wsAssessmentdao.getRequestById(anyString())).thenReturn(wsAssessment2);
        when(wsAssessment2.getStatus()).thenReturn("New");
        when(wsAssessment.getRequestId()).thenReturn("1");
        LoggedUserVO vo = mock(LoggedUserVO.class);
        LoggedUserVO userVo = new LoggedUserVO();
        userVo.setCanAccessApplication(true);
        userVo.setCanApproveMedicalRequests(true);
        userVo.setCanCreateAssessment(true);
        userVo.setCanCreateCostItems(true);
        userVo.setCanCreateRequest(true);
        userVo.setCanViewMedicalDocs(true);
        userVo.setCity("");
        userVo.setCostCenter("");;
        userVo.setDeptPayorName("");
        userVo.setEmail("");
        userVo.setEmployeeId("");
        userVo.setFirstName("");
        userVo.setFullName("");
        userVo.setLastName("");
        userVo.setLocation("");
        userVo.setMiddleName("");
        userVo.setPhone("");
        userVo.setRole("");
        userVo.setState("");
        userVo.setSupervisorEmail("");
        userVo.setSupervisorEmpId("");
        userVo.setSupervisorName("");
        userVo.setSupervisorUserId("");
        userVo.setUserId("");
        userVo.setWorkstationId("");
        userVo.setBuilding("");
        
        userVo.getCity();
        userVo.getCostCenter();;
        userVo.getDeptPayorName();
        userVo.getEmail();
        userVo.getEmployeeId();
        userVo.getFirstName();
        userVo.getFullName();
        userVo.getLastName();
        userVo.getLocation();
        userVo.getMiddleName();
        userVo.getPhone();
        userVo.getRole();
        userVo.getState();
        userVo.getSupervisorEmail();
        userVo.getSupervisorEmpId();
        userVo.getSupervisorName();
        userVo.getSupervisorUserId();
        userVo.getUserId();
        userVo.getWorkstationId();
        userVo.getBuilding();
        userVo.isCanAccessApplication();
        userVo.isCanApproveMedicalRequests();
        userVo.isCanCreateAssessment();
        userVo.isCanCreateCostItems();
        userVo.isCanCreateRequest();
        userVo.isCanViewMedicalDocs();
        userVo.toString();
        userVo = new LoggedUserVO("" ,"" ,"" ,"" ,"" ,"","" ,"" ,"" ,"" ,"" ,"" ,"" ,"" ,"" ,"" ,"" ,"" ,"" ,"");
        
        when(wsAssessment.getLoggedEmployee()).thenReturn(vo);
        when(wsAssessment.getLoggedEmployee().getEmployeeId()).thenReturn("9999999");
        when(wsAssessment.getStatus()).thenReturn("Submitted");
        when(wsAssessment.getAssessmentId()).thenReturn("1");
        when(wsEvalDao.updateStatus(wsAssessment.getRequestId(), wsAssessment.getLoggedEmployee().getEmployeeId(), wsAssessment.getStatus())).thenReturn(true);
        when(reqHistDao.insertRequestUpdateHistory(anyString(), anyString(), anyString(), anyString(),anyString(), anyString(), anyString())).thenReturn(true);
        wsaService.updateWorkStationAssessment(wsAssessment);
    }

    @Test
    public void getDropdownValuesTestWithEmptyList() {
        when(wsAssessmentdao.getDropdownValues()).thenReturn(new ArrayList());
        wsaService.getDropdownValues();
    }

    @Test
    public void getDropdownValuesTestWithNonEmptyList() {
        List<Dropdown> list = new ArrayList<Dropdown>();
        Dropdown dropdown1 = new Dropdown("ReasonForAssessment", "Medical provider referral");
        Dropdown dropdown2 = new Dropdown("ReasonForAssessment", "Employee request");
        Dropdown dropdown3 = new Dropdown("CurrentChair", "Criterion");
        Dropdown dropdown4 = new Dropdown("CurrentChair", "Body Bilt - standard");
        Dropdown dropdown5 = new Dropdown("SeatHeight", "High");
        Dropdown dropdown6 = new Dropdown("SeatHeight", "Low");
        list.add(dropdown1);
        list.add(dropdown2);
        list.add(dropdown3);
        list.add(dropdown4);
        list.add(dropdown5);
        list.add(dropdown6);

        when(wsAssessmentdao.getDropdownValues()).thenReturn(list);
        wsaService.getDropdownValues();
    }
    
    @Test
    public void saveWorkstationAssessmentTest() throws JmsException, Exception {
        WorkstationAssessment wsAssessment = mock(WorkstationAssessment.class);
        WorkstationEvaluation wsEval = mock(WorkstationEvaluation.class);
        LoggedUserVO emp = mock(LoggedUserVO.class);
        when(wsEvalDao.getRequestById("1")).thenReturn(wsEval);
        when(wsAssessmentdao.submitWorkstationAssessment(wsAssessment)).thenReturn(1);
        when(wsAssessment.getStatus()).thenReturn("Assessment Complete");
        when(wsAssessment.getLoggedEmployee()).thenReturn(emp);
        when(emp.getEmployeeId()).thenReturn("123456");
        when(wsAssessment.getRequestId()).thenReturn("1");
        when(wsAssessment.getAssessmentId()).thenReturn("1");        
        LoggedUserVO vo = mock(LoggedUserVO.class);
        when(wsAssessment.getLoggedEmployee()).thenReturn(vo);
        when(wsAssessment.getLoggedEmployee().getEmployeeId()).thenReturn("9999999");
        when(wsAssessment.getStatus()).thenReturn("Submitted");
        when(wsEval.getStatus()).thenReturn("submitted");
        when(wsEvalDao.updateStatus(wsAssessment.getRequestId(), wsAssessment.getLoggedEmployee().getEmployeeId(), wsAssessment.getStatus())).thenReturn(true);
        when(reqHistDao.insertRequestUpdateHistory(anyString(), anyString(), any(), anyString(), anyString(), anyString(), any())).thenReturn(true);
        doNothing().when(emailService).sendEmailNotification(anyObject());
        wsaService.saveWorkstationAssessment(wsAssessment);
    }
    
    @Test
    public void updateWorkStationAssessmentTest1() {
        WorkstationAssessment wsAssessment = mock(WorkstationAssessment.class);
        WorkstationAssessment wsAssessment2 = mock(WorkstationAssessment.class);
        when(wsAssessmentdao.updateWorkStationAssessment(wsAssessment)).thenReturn(true);
        when(wsAssessmentdao.getRequestById(anyString())).thenReturn(wsAssessment2);
        when(wsAssessment2.getStatus()).thenReturn("New");
        when(wsAssessment.getRequestId()).thenReturn("1");
        LoggedUserVO vo = mock(LoggedUserVO.class);
        LoggedUserVO userVo = new LoggedUserVO();
        userVo.setCanAccessApplication(true);
        userVo.setCanApproveMedicalRequests(true);
        userVo.setCanCreateAssessment(true);
        userVo.setCanCreateCostItems(true);
        userVo.setCanCreateRequest(true);
        userVo.setCanViewMedicalDocs(true);
        userVo.setCity("");
        userVo.setCostCenter("");;
        userVo.setDeptPayorName("");
        userVo.setEmail("");
        userVo.setEmployeeId("");
        userVo.setFirstName("");
        userVo.setFullName("");
        userVo.setLastName("");
        userVo.setLocation("");
        userVo.setMiddleName("");
        userVo.setPhone("");
        userVo.setRole("");
        userVo.setState("");
        userVo.setSupervisorEmail("");
        userVo.setSupervisorEmpId("");
        userVo.setSupervisorName("");
        userVo.setSupervisorUserId("");
        userVo.setUserId("");
        userVo.setWorkstationId("");
        userVo.setBuilding("");
        
        userVo.getCity();
        userVo.getCostCenter();;
        userVo.getDeptPayorName();
        userVo.getEmail();
        userVo.getEmployeeId();
        userVo.getFirstName();
        userVo.getFullName();
        userVo.getLastName();
        userVo.getLocation();
        userVo.getMiddleName();
        userVo.getPhone();
        userVo.getRole();
        userVo.getState();
        userVo.getSupervisorEmail();
        userVo.getSupervisorEmpId();
        userVo.getSupervisorName();
        userVo.getSupervisorUserId();
        userVo.getUserId();
        userVo.getWorkstationId();
        userVo.getBuilding();
        userVo.isCanAccessApplication();
        userVo.isCanApproveMedicalRequests();
        userVo.isCanCreateAssessment();
        userVo.isCanCreateCostItems();
        userVo.isCanCreateRequest();
        userVo.isCanViewMedicalDocs();
        userVo.toString();
        userVo = new LoggedUserVO("" ,"" ,"" ,"" ,"" ,"","" ,"" ,"" ,"" ,"" ,"" ,"" ,"" ,"" ,"" ,"" ,"" ,"" ,"");
        
        
        when(wsAssessment.getLoggedEmployee()).thenReturn(vo);
        when(wsAssessment.getLoggedEmployee().getEmployeeId()).thenReturn("9999999");
        when(wsAssessment.getStatus()).thenReturn("Assessment Provided");
        when(wsAssessment.getAssessmentId()).thenReturn("1");
        when(wsEvalDao.updateStatus(wsAssessment.getRequestId(), wsAssessment.getLoggedEmployee().getEmployeeId(), wsAssessment.getStatus())).thenReturn(true);
        when(reqHistDao.insertRequestUpdateHistory(anyString(), anyString(), anyString(), anyString(),anyString(), anyString(), anyString())).thenReturn(true);
        
        List<ActionItem> AcItemLst= new ArrayList<ActionItem>();
        ActionItem  actItem= mock(ActionItem.class);
        AcItemLst.add(actItem);
        wsAssessment.setActionItemList(AcItemLst);
       WorkstationAssessment wsAssessTemp = new WorkstationAssessment();
       wsAssessTemp.setStatus("Assessment Provided");
       wsAssessTemp.setActionItemList(AcItemLst);
        wsaService.updateWorkStationAssessment(wsAssessment);
        //wsaService.updateWorkStationAssessment(wsAssessTemp);
        wsaService.updateWorkstationAssessmentStatus(wsAssessment);
    }
    
    @Test
    public void submitWorkstationAssessmentTest1() throws JmsException, Exception {
        WorkstationAssessment wsAssessment = mock(WorkstationAssessment.class);
        WorkstationEvaluation wsEval = mock(WorkstationEvaluation.class);
        LoggedUserVO emp = mock(LoggedUserVO.class);
        when(wsEvalDao.getRequestById("1")).thenReturn(wsEval);
        when(wsAssessmentdao.submitWorkstationAssessment(wsAssessment)).thenReturn(1);
        when(wsAssessment.getStatus()).thenReturn("Assessment Complete");
        when(wsAssessment.getLoggedEmployee()).thenReturn(emp);
        when(emp.getEmployeeId()).thenReturn("123456");
        when(wsAssessment.getRequestId()).thenReturn("1");
        when(wsAssessment.getAssessmentId()).thenReturn("1");        
        LoggedUserVO vo = mock(LoggedUserVO.class);
        when(wsAssessment.getLoggedEmployee()).thenReturn(vo);
        when(wsAssessment.getLoggedEmployee().getEmployeeId()).thenReturn("9999999");
        when(wsAssessment.getStatus()).thenReturn("Assessment Complete");
        when(wsEval.getStatus()).thenReturn("Assessment Complete");
        when(wsEvalDao.updateStatus(wsAssessment.getRequestId(), wsAssessment.getLoggedEmployee().getEmployeeId(), wsAssessment.getStatus())).thenReturn(true);
        when(reqHistDao.insertRequestUpdateHistory(anyString(), anyString(), any(), anyString(), anyString(), anyString(), any())).thenReturn(true);
        doNothing().when(emailService).sendEmailNotification(anyObject());
        wsaService.submitWorkstationAssessment(wsAssessment);
    }
}
