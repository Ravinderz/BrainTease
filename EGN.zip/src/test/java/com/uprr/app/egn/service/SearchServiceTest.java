package com.uprr.app.egn.service;

import static org.mockito.Matchers.anyObject;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.uprr.app.egn.dao.ISearchDAO;
import com.uprr.app.egn.dao.IWorkstationEvaluationDAO;
import com.uprr.app.egn.dto.SearchCriteria;
import com.uprr.app.egn.dto.SearchRequest;
import com.uprr.app.egn.dto.WorkstationEvaluation;

@RunWith(SpringJUnit4ClassRunner.class)
public class SearchServiceTest {

	@Mock
	IWorkstationEvaluationDAO wsEvalDao;

	@Mock
	ISearchDAO searchDao;

	@InjectMocks
	SearchService searchService;

	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void searchRequest(){
		List<WorkstationEvaluation> list = new ArrayList<>(); 
		list.add(new WorkstationEvaluation());
		when(searchDao.searchWorkstationRequest(anyObject(), anyObject())).thenReturn(list);
		searchService.searchRequest(new SearchRequest(), "user");
		verify(searchDao, times(1)).searchWorkstationRequest(anyObject(), anyObject());
	}
	
	@Test
	public void getSearchRequest(){
		List<WorkstationEvaluation> list = new ArrayList<>();
		list.add(new WorkstationEvaluation());

		when(searchDao.getSearchWorkstationRequests(anyObject(), anyObject(),anyObject())).thenReturn(list);
		when(searchDao.getSearchCriteriaCount(anyObject(), anyObject(),anyObject())).thenReturn(10);
		searchService.getSearchRequest(new SearchRequest(), "user",new SearchCriteria());
		verify(searchDao, times(1)).getSearchWorkstationRequests(anyObject(), anyObject(), anyObject());
	}
	
	@Test
	public void initialSearchRequest(){
		List<WorkstationEvaluation> list = new ArrayList<>();
		SearchCriteria searchCriteria = new SearchCriteria();
		list.add(new WorkstationEvaluation());

		when(wsEvalDao.searchNonMedicalRequests(anyObject(), anyObject())).thenReturn(list);
		searchService.initialSearchRequest("supervisor", "0454897",searchCriteria);
		verify(wsEvalDao, times(1)).searchNonMedicalRequests("0454897", searchCriteria);
	}
	
	@Test
	public void getSearchRequestWithCriteriaForSupervisor(){
		List<WorkstationEvaluation> list = new ArrayList<>();
		list.add(new WorkstationEvaluation());
		SearchCriteria criteria = new SearchCriteria(1,10,"desc",0,"desc",0,10,10,false,null,null,"0454897","","supervisor","0454897");
		when(searchDao.getWorkstationEvalSearchTotalCount(criteria)).thenReturn(64);
		//when(searchDao.getSearchWorkstationRequests(anyObject(), anyObject(),anyObject())).thenReturn(list);
		searchService.getSearchResults(criteria);
		verify(searchDao, times(1)).getWorkstationEvalSearchTotalCount(criteria);
	}
	
	@Test
	public void getSearchRequestWithCriteriaForOtherRole(){
		List<WorkstationEvaluation> list = new ArrayList<>();
		list.add(new WorkstationEvaluation());
		SearchCriteria criteria = new SearchCriteria(1,10,"desc",0,"desc",0,10,10,false,null,null,"0454897","","ADA Nurse","0454897");
		when(searchDao.getWorkstationEvalSearchTotalCount(criteria)).thenReturn(64);
		when( wsEvalDao.getPaginatedRequestData(criteria)).thenReturn(list);
		searchService.getSearchResults(criteria);
		verify(searchDao, times(1)).getWorkstationEvalSearchTotalCount(criteria);
		verify(wsEvalDao, times(1)).getPaginatedRequestData(criteria);
	}
	
	@Test
	public void getUserRequests(){
		List<WorkstationEvaluation> list = new ArrayList<>();
		list.add(new WorkstationEvaluation());
		SearchCriteria criteria = new SearchCriteria(1,10,"desc",0,"desc",0,10,10,false,null,null,"0454897","","supervisor","0454897");
		when(wsEvalDao.getAllRequestsByUser("0454897",criteria)).thenReturn(list);
		when(wsEvalDao.getUserRequestsCount("0454897")).thenReturn(10);
		searchService.getUserRequests("0454897",criteria);
		verify(wsEvalDao, times(1)).getAllRequestsByUser("0454897",criteria);
	}
	
	@Test
	public void getResultsForSpecialistTest(){
		SearchCriteria criteria = new SearchCriteria(1,10,"desc",0,"desc",0,10,10,false,null,null,"0454897","","supervisor","0454897");
		searchService.getResultsForSpecialist(criteria);
	}
	
	@Test
	public void getResultsForFacilitiesMgmtTest(){
		SearchCriteria criteria = new SearchCriteria(1,10,"desc",0,"desc",0,10,10,false,null,null,"0454897","","supervisor","0454897");
		searchService.getResultsForFacilitiesMgmt(criteria);
	}
	
	@Test
	public void getResultsForFacilitiesMgmtWithCrtreaTest(){
		SearchCriteria criteria = new SearchCriteria(1,10,"desc",0,"desc",0,10,10,false,null,null,"0454897","","supervisor","0454897");
		searchService.getResultsForFacilitiesMgmtWithCrtrea(criteria);
		criteria.setFromDate("");
		criteria.setToDate("");
		criteria.setEmployeeId("");
		criteria.setStatus("");
		criteria.setRole("");
		criteria.setSupvId("");
		criteria.setCurrentPage(1);
		criteria.setEndIndex(1);
		criteria.setOrderByColumn("");
		criteria.setRecordsCount(1);
		criteria.setSortingType("");
		criteria.setStartIndex(1);
		criteria.setTotalPages(1);
		criteria.setRecordsPerPage(1);
		criteria.setExportExcel(false);
		criteria.getFromDate();
		criteria.getToDate();
		criteria.getEmployeeId();
		criteria.getStatus();
		criteria.getRole();
		criteria.getSupvId();
		criteria.getCurrentPage();
		criteria.getEndIndex();
		criteria.getOrderByColumn();
		criteria.getRecordsCount();
		criteria.getSortingType();
		criteria.getStartIndex();
		criteria.getTotalPages();
		criteria.getRecordsPerPage();
		criteria.isExportExcel();
		searchService.getResultsForFacilitiesMgmtWithCrtrea(criteria);

	}
	
	
	
}