package com.uprr.app.egn.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.Assert;

import com.uprr.app.egn.EgnApplication;
import com.uprr.app.egn.config.TestConfig;
import com.uprr.app.egn.dao.IWorkstationEvaluationDAO;
import com.uprr.app.egn.dto.Checkbox;
import com.uprr.app.egn.dto.Document;
import com.uprr.app.egn.dto.SearchCriteria;
import com.uprr.app.egn.dto.UpdateStatus;
import com.uprr.app.egn.dto.WorkstationEvaluation;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {TestConfig.class,EgnApplication.class})
@TestPropertySource(locations="classpath:test-application.properties")
@Rollback(true)
public class WorkstationEvaluationDAOTest {

	@Autowired
	IWorkstationEvaluationDAO wsEvalDao;

	@BeforeClass
	public static void before(){
		System.setProperty("uprr.implementation.environment", "local");
	}
	
	@Test
	public void getRequestDataTest(){
		List<WorkstationEvaluation> list = wsEvalDao.getRequestData("9999999");
		Assert.notNull(list,"got all requests from in memory-DB");
		
	}
	
	@Test
	public void getUserRequestsCountTest(){
		int count = wsEvalDao.getUserRequestsCount("9999999");
		Assert.notNull(count,"got all requests from in memory-DB");
		
	}
	
	@Ignore
	@Test
	public void getRequestByIdNotNullTest(){
		WorkstationEvaluation wsEval = wsEvalDao.getRequestById("6");
		Assert.notNull(wsEval, "Test for WorkstationEvaluation is not null");
	}
	
	@Test
	public void getDocumentsByRequestIdTest(){
		List<Document> list = wsEvalDao.getDocumentsByRequestId("1");
		Assert.notNull(list,"got all documents from in memory-DB");
	}
	
	@Test
	public void getAllRequestDataTest(){
		List<WorkstationEvaluation> list = wsEvalDao.getRequestData();
		Assert.notNull(list,"got all documents from in memory-DB");
	}
	
	@Test
	public void getAllMedicalRequestsTest(){
		List<WorkstationEvaluation> list = wsEvalDao.getAllMedicalRequests();
		Assert.notNull(list,"got all documents from in memory-DB");
	}
	
	@Test
	public void getAllNonMedicalRequestsTest(){
		SearchCriteria criteria = new SearchCriteria(1,10,"",5,"desc",1,1,10,false,null,null,null,null,"supervisor","00112233");
		List<WorkstationEvaluation> list = wsEvalDao.getNonMedicalRequests("00112233", criteria);
		Assert.notNull(list,"got all documents from in memory-DB");
	}
	
	@Test
	public void getResultsForSpecialistTest(){
		SearchCriteria criteria = new SearchCriteria(1,10,"",5,"desc",1,1,10,false,null,null,null,null,"supervisor","00112233");
		List<WorkstationEvaluation> list = wsEvalDao.getResultsForSpecialist(criteria);
		Assert.notNull(list,"got all documents from in memory-DB");
	}
	
	@Test
	public void getResultsForSpecialistCountTest(){
		int i = wsEvalDao.getResultsForSpecialistCount();
		Assert.notNull(i,"got all documents from in memory-DB");
	}
	
	@Test
	public void getAllRequestsByUserTest(){
		SearchCriteria criteria = new SearchCriteria(1,10,"",5,"desc",1,1,10,false,null,null,null,null,"user","00112233");
		List<WorkstationEvaluation> list = wsEvalDao.getAllRequestsByUser("9999999", criteria);
		Assert.notNull(list,"got all documents from in memory-DB");
	}
	
	@Test
	public void getMedicalRejectedRequestsForSupervisorDataTest(){
		List<WorkstationEvaluation> list = wsEvalDao.getMedicalRejectedRequestsForSupervisorData("00112233");
		Assert.notNull(list,"got all documents from in memory-DB");
	}
	
	@Test
	public void getPaginatedRequestData(){
		SearchCriteria criteria = new SearchCriteria(1,10,"",5,"desc",1,1,10,false,null,null,null,null,"ada nurse","00112233");
		List<WorkstationEvaluation> list = wsEvalDao.getPaginatedRequestData(criteria);
		Assert.notNull(list,"got all documents from in memory-DB");
	}
	
	
	
	@Test(expected = NullPointerException.class)
	public void submitWorkstationRequestTest(){
		Checkbox checkbox = new Checkbox();
		checkbox.setComputerKeyboardMouse(true);
		checkbox.setChairFootrest(true);
		checkbox.setcADWS(true);
		checkbox.setrMCC(true);
		WorkstationEvaluation wsEval = new WorkstationEvaluation("1", "1", "User", "0000001", "Omaha", "bld", "9 - 6", "Vishnu", "2018-06-12", "0123456789", "jeff@up.com", "2345678","", "other", false, true, "2018-12-24", "Beth", "jack", "402544234", "", "New", checkbox, "other", "other");
		wsEvalDao.submitWorkStationRequest(wsEval);
	}
	
	@Ignore
	@Test(expected = NullPointerException.class)
	public void savetWorkstationRequestTest(){
		Checkbox checkbox = new Checkbox();
		checkbox.setComputerKeyboardMouse(true);
		checkbox.setChairFootrest(true);
		checkbox.setcADWS(true);
		checkbox.setrMCC(true);
		WorkstationEvaluation wsEval = new WorkstationEvaluation("10", "11", "User", "0000001", "Omaha", "bld", "9 - 6", "Vishnu", "2018-06-12", "0123456789", "jeff@up.com", "2345678", "98008", "other", false, true, "2018-12-24", "Beth", "jack", "402544234", "", "New", checkbox, "other", "other");
		wsEvalDao.saveWorkStationRequest(wsEval);
	}
	
	@Test
	public void updateWorkStationRequestTest(){
		Checkbox checkbox = new Checkbox();
		checkbox.setComputerKeyboardMouse(true);
		checkbox.setChairFootrest(true);
		checkbox.setcADWS(true);
		checkbox.setrMCC(true);
		WorkstationEvaluation wsEval = new WorkstationEvaluation("1", "1", "User", "0000001", "Omaha", "bld", "9 - 6", "Vishnu", "2018-06-12", "0123456789", "jeff@up.com", "2345678", "98008", "other", false, true, "2018-12-24", "Beth", "jack", "402544234", "", "New", checkbox, "other", "other");
		wsEvalDao.updateWorkStationRequest(wsEval);
	}
	
	@Test
	public void updateStatusTest(){
		Checkbox checkbox = new Checkbox();
		checkbox.setComputerKeyboardMouse(true);
		checkbox.setChairFootrest(true);
		checkbox.setcADWS(true);
		checkbox.setrMCC(true);
		List<String> list = new ArrayList<>();
		list.add("1");
		List<WorkstationEvaluation> wsList = new ArrayList<>();
		WorkstationEvaluation wsEval = new WorkstationEvaluation("1", "1", "User", "0000001", "Omaha", "bld", "9 - 6", "Vishnu", "2018-06-12", "0123456789", "jeff@up.com", "2345678", "98008", "other", false, true, "2018-12-24", "Beth", "jack", "402544234", "", "New", checkbox, "other", "other");
		wsList.add(wsEval);
		UpdateStatus updateStatus = new UpdateStatus("Approved","0000001",null, list,wsList);
		wsEvalDao.updateStatus(updateStatus);
	}
	
	@Test
	public void updateStatusTest1(){
		Checkbox checkbox = new Checkbox();
		checkbox.setComputerKeyboardMouse(true);
		checkbox.setChairFootrest(true);
		checkbox.setcADWS(true);
		checkbox.setrMCC(true);
		List<String> list = new ArrayList<>();
		list.add("1");
		List<WorkstationEvaluation> wsList = new ArrayList<>();
		WorkstationEvaluation wsEval = new WorkstationEvaluation("1", "1", "User", "0000001", "Omaha", "bld", "9 - 6", "Vishnu", "2018-06-12", "0123456789", "jeff@up.com", "2345678", "98008", "other", false, true, "2018-12-24", "Beth", "jack", "402544234", "", "New", checkbox, "other", "other");
		wsList.add(wsEval);
		wsEvalDao.updateStatus(wsEval.getRequestId(),wsEval.getEmpId(),wsEval.getStatus());
	}
	
	@Test
	public void getRequestByIdTest(){
		WorkstationEvaluation wsEval = new WorkstationEvaluation("2", "1", "User", "0000001", "Omaha", "bld", "9 - 6", "Vishnu", "2018-06-12", "0123456789", "jeff@up.com", "2345678", "98008", "other", false, true, "2018-12-24", "Beth", "jack", "402544234", "", "New", null, "other", "other");
		try {
			wsEvalDao.getRequestById(wsEval.getRequestId());
		} catch (Exception e) {
		}
	}
	
	@Test
	public void getRequestByUserTest(){
		WorkstationEvaluation wsEval = new WorkstationEvaluation("1", "1", "User", "0000001", "Omaha", "bld", "9 - 6", "Vishnu", "2018-06-12", "0123456789", "jeff@up.com", "2345678", "98008", "other", false, true, "2018-12-24", "Beth", "jack", "402544234", "", "New", null, "other", "other");
		wsEvalDao.getRequestByUser(wsEval.getEmpId());
	}
	
	
	@Test
	public void searchNonMedicalRequestsTest(){
		SearchCriteria criteria = new SearchCriteria(1,10,"",5,"empl_id",1,1,10,false,null,null,null,null,"supervisor","00112233");
		List<WorkstationEvaluation> list = wsEvalDao.searchNonMedicalRequests("00112233", criteria);
		Assert.notNull(list,"got all documents from in memory-DB");
	}
	
	@Test
	public void getResultsForFacilitiesMgmtCountTest(){
		wsEvalDao.getResultsForFacilitiesMgmtCount();
	}
	
	@Test
	public void saveWorkStationRequestTest1(){
		Checkbox checkbox = new Checkbox();
		checkbox.setComputerKeyboardMouse(true);
		checkbox.setChairFootrest(true);
		checkbox.setcADWS(true);
		checkbox.setrMCC(true);
		WorkstationEvaluation wsEval = new WorkstationEvaluation("1", "1", "User", "0000001", "Omaha", "bld", "9 - 6", "Vishnu", "2018-06-12", "0123456789", "jeff@up.com", "2345678", "98008", "other", false, true, "2018-06-12", "Beth", "jack", "402544234", "", "New", checkbox, "other", "other");
		wsEval.setRequestId(null);
		try {
			wsEvalDao.saveWorkStationRequest(wsEval);
		} catch (Exception e) {
		}
	}
	
	@Test
	public void getResultsForFacilitiesMgmtWithCrtreaTest(){
		SearchCriteria criteria = new SearchCriteria(1,10,"",5,"empl_id",1,1,10,false,null,null,null,null,"supervisor","00112233");
		wsEvalDao.getResultsForFacilitiesMgmtWithCrtrea(criteria);
	}
	
	@Test
	public void getResultsForFacilitiesMgmtCountWithCrtreaTest(){
		SearchCriteria criteria = new SearchCriteria(1,10,"",5,"empl_id",1,1,10,false,null,null,null,null,"supervisor","00112233");
		wsEvalDao.getResultsForFacilitiesMgmtCountWithCrtrea(criteria);
	}
	
	@Test
	public void getResultsForFacilitiesMgmtTest(){
		SearchCriteria criteria = new SearchCriteria(1,10,"",5,"empl_id",1,1,10,false,null,null,null,null,"supervisor","00112233");
		wsEvalDao.getResultsForFacilitiesMgmt(criteria);
	}
	
	
}
