package com.uprr.app.egn.controller;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.uprr.app.egn.dto.WorkstationAssessment;
import com.uprr.app.egn.service.IAuthorizationService;
import com.uprr.app.egn.service.WorkstationAssessmentService;
import com.uprr.ui.shared.user.ActiveUserId;

@RunWith(SpringJUnit4ClassRunner.class)
public class WorkstationAssessmentControllerTest {
	
	private MockMvc mockMvc;

	@Mock
	WorkstationAssessmentService workstationAssessmentService;
	
	@Mock
	ActiveUserId userId;
	
	@Mock
	IAuthorizationService authService;
	
	@InjectMocks
	WorkstationAssessmentController workstationAssessmentController;
	
	@Before
    public void setup() {
 	    MockitoAnnotations.initMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(workstationAssessmentController).build();
    }
	
	@Test
	public void getDropDownValuesTest() throws Exception {
		mockMvc.perform(get("/workstationAssessment/getDropdownValues"))
			 .andDo(print())
	         .andExpect(status().isOk())
	         .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8) )
	         .andReturn();
	}
	
	@Test
	public void getRequestByIdTestWithNotNullId() throws Exception {
		when(workstationAssessmentService.getRequestById(anyString())).thenReturn(new WorkstationAssessment());
		mockMvc.perform(get("/workstationAssessment/getAssessmentRequestById/{requestId}","1"))
			 .andDo(print())
	         .andExpect(status().isOk())
	         .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8) )
	         .andReturn();
	}
	
	@Test
	public void submitWorkstationAssessmentTestWithInValidRequest() throws Exception{
		
		WorkstationAssessment wsAssessment = new WorkstationAssessment();
		when(workstationAssessmentService.submitWorkstationAssessment(wsAssessment)).thenReturn(0);
		mockMvc.perform(post("/workstationAssessment/submitWorkstationAssessment").content(asJsonString(wsAssessment)).contentType(MediaType.APPLICATION_JSON_UTF8))
				 .andDo(print())
		         .andExpect(status().is(500))
		         .andReturn();
				
		}
	
	@Test
	public void submitWorkstationAssessmentTestWithValidRequest() throws Exception {
		WorkstationAssessment wsAssessment = new WorkstationAssessment();
		when(workstationAssessmentService.submitWorkstationAssessment(any(WorkstationAssessment.class))).thenReturn(1);
		mockMvc.perform(post("/workstationAssessment/submitWorkstationAssessment").content(asJsonString(wsAssessment)).contentType(MediaType.APPLICATION_JSON_UTF8))
				 .andDo(print())
		         .andExpect(status().is(200))
		         .andReturn();

	}
	
	@Test
	public void saveWorkstationAssessmentTestWithValidRequest() throws Exception {
		WorkstationAssessment wsAssessment = new WorkstationAssessment();
		when(workstationAssessmentService.saveWorkstationAssessment(any(WorkstationAssessment.class))).thenReturn(1);
		mockMvc.perform(post("/workstationAssessment/saveWorkstationAssessment").content(asJsonString(wsAssessment)).contentType(MediaType.APPLICATION_JSON_UTF8))
				 .andDo(print())
		         .andExpect(status().is(200))
		         .andReturn();

	}
	
	@Test
	public void saveWorkstationAssessmentTestWithInValidRequest() throws Exception {
		WorkstationAssessment wsAssessment = new WorkstationAssessment();
		when(workstationAssessmentService.saveWorkstationAssessment(wsAssessment)).thenReturn(0);
		mockMvc.perform(post("/workstationAssessment/saveWorkstationAssessment").content(asJsonString(wsAssessment)).contentType(MediaType.APPLICATION_JSON_UTF8))
				 .andDo(print())
		         .andExpect(status().is(500))
		         .andReturn();

	}
	
	@Test
	public void updateWorkstationAssessmentTestWithInValidRequest() throws Exception {
		WorkstationAssessment wsAssessment = new WorkstationAssessment();
		when(workstationAssessmentService.updateWorkStationAssessment(wsAssessment)).thenReturn(false);
		when(userId.getUserId()).thenReturn("xmie003");
		when(authService.canCreateAssessment("xmie003")).thenReturn(true);
		workstationAssessmentController.updateWorkstationAssessment(wsAssessment, userId);
	}
	
	@Test
	public void updateWorkstationAssessmentTestWithValidRequest() throws Exception{
		WorkstationAssessment wsAssessment = new WorkstationAssessment();
		when(workstationAssessmentService.updateWorkStationAssessment(any(WorkstationAssessment.class))).thenReturn(true);
		when(userId.getUserId()).thenReturn("xmie003");
		when(authService.canCreateAssessment("xmie003")).thenReturn(false);
		when(authService.canCreateCostItems("xmie003")).thenReturn(true);
		workstationAssessmentController.updateWorkstationAssessment(wsAssessment, userId);
	}
	
	@Test
	public void updateWorkstationAssessmentTestWithForbiddenRequest() throws Exception{
		WorkstationAssessment wsAssessment = new WorkstationAssessment();
		when(workstationAssessmentService.updateWorkStationAssessment(any(WorkstationAssessment.class))).thenReturn(true);
		when(userId.getUserId()).thenReturn("xmie003");
		when(authService.canCreateAssessment("xmie003")).thenReturn(false);
		when(authService.canCreateCostItems("xmie003")).thenReturn(false);
		workstationAssessmentController.updateWorkstationAssessment(wsAssessment, userId);
	}
	
	public static String asJsonString(final Object obj) {
	    try {
	        final ObjectMapper mapper = new ObjectMapper();
	        final String jsonContent = mapper.writeValueAsString(obj);
	        return jsonContent;
	    } catch (Exception e) {
	        throw new RuntimeException(e);
	    }
	} 
}
