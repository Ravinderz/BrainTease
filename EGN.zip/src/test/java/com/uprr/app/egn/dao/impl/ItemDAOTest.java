package com.uprr.app.egn.dao.impl;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

import com.uprr.app.egn.EgnApplication;
import com.uprr.app.egn.config.TestConfig;
import com.uprr.app.egn.dao.IItemDAO;
import com.uprr.app.egn.dto.ActionItem;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {TestConfig.class,EgnApplication.class})
@TestPropertySource(locations="classpath:test-application.properties")
@Rollback(true)
public class ItemDAOTest {

	@Autowired
	IItemDAO itemDao;

	@BeforeClass
	public static void before(){
		System.setProperty("uprr.implementation.environment", "local");
	}
	
	@Test
	public void insertPurchaseItemTest(){
		ActionItem item = new ActionItem();
		item.setAssessmentId("1");
		item.setAssignedToEmployeeId("112233");
		item.setAssignedToEmployeeName("Ravinder Singh");
		item.setCreatedBy("Ravinder Singh");
		item.setCreatedById("112233");
		item.setDateAssigned("07-08-2018");
		item.setEstimatedCost("234");
		item.setItemTextDesc("This is test");
		item.setNote("testing note");
		item.setOldStatus("New");
		item.setRequestId("1");
		item.setSupvAprvlStatus("Ordered");
		item.setUpdatedBy("Ravinder Singh");
		item.setUpdatedById("112233");
		itemDao.insertPurchaseItem(item);
	}
	
	@Ignore
	@Test
	public void updatePurchaseItemTest(){
		ActionItem item = new ActionItem();
		item.setItemId(84);
		item.setAssessmentId("44");
		item.setAssignedToEmployeeId("112233");
		item.setAssignedToEmployeeName("Ravinder Singh");
		item.setCreatedBy("Ravinder Singh");
		item.setCreatedById("112233");
		item.setDateAssigned("07-08-2018");
		item.setEstimatedCost("234");
		item.setItemTextDesc("This is test");
		item.setNote("testing note");
		item.setOldStatus("New");
		item.setRequestId("1");
		item.setSupvAprvlStatus("Approved");
		item.setItemOrderStatus("Ordered");
		item.setUpdatedBy("Ravinder Singh");
		item.setUpdatedById("112233");
		itemDao.updatePurchaseItem(item);
	}
	
	@Ignore
	@Test
	public void getAllItemsByAsmtIdTest(){
		itemDao.getAllItemsByAsmtId("73");
	}
}

