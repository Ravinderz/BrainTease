package com.uprr.app.egn.dao.impl;

import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

import com.uprr.app.egn.EgnApplication;
import com.uprr.app.egn.config.TestConfig;
import com.uprr.app.egn.dao.IFollowUpDAO;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {TestConfig.class,EgnApplication.class})
@TestPropertySource(locations="classpath:test-application.properties")
@Rollback(true)
public class FollowUpDAOTest {

	@Autowired
	IFollowUpDAO followUpDao;

	@BeforeClass
	public static void before(){
		System.setProperty("uprr.implementation.environment", "local");
	}
	
	@Test
	public void getAllFollowUpNotesByAsmtIdTest(){
		followUpDao.getAllFollowUpNotesByAsmtId("1");
	}
}

