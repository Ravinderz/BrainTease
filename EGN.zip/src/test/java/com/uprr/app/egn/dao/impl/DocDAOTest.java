package com.uprr.app.egn.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.uprr.app.egn.EgnApplication;
import com.uprr.app.egn.config.TestConfig;
import com.uprr.app.egn.dao.IDocDAO;
import com.uprr.app.egn.dto.Document;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = {TestConfig.class,EgnApplication.class})
@TestPropertySource(locations="classpath:test-application.properties")
@Rollback(true)
public class DocDAOTest {

	@Autowired
	IDocDAO docDao;
	
	@BeforeClass
	public static void before(){
		System.setProperty("uprr.implementation.environment", "local");
	}
	
	@Test
	public void saveMultipleDocs(){
		Document doc = new Document();
		doc.setCreatedBy("0454897");
		doc.setUpdatedBy("0454897");
		doc.setDocumentDesc("Test doc");
		doc.setDocumentGuid("93jd-49fjhse-4sf4-sdf");
		doc.setDocumentName("Test");
		doc.setRequestId("1");
		List<Document> list = new ArrayList<>();
		list.add(doc);
		docDao.saveMultipleDocs(list);
	}
}
