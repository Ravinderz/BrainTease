package com.uprr.app.egn.service;

import static org.mockito.Mockito.when;									   
import java.io.IOException;

import org.junit.Before;
import org.junit.Ignore;						
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.uprr.app.egn.util.EGNConstants;

@RunWith(SpringJUnit4ClassRunner.class)
public class AppServiceTest {

	AppService appService;
	
	@Mock
	EGNConstants  egnConstants;
	
	@Mock
	IAuthorizationService authService;

	@Before
	public void before(){
		this.appService = new AppService();
	}

	@Test
	public void getMenuItemsTestForUser() throws IOException{
		appService.getMenuItems("user");
	}

	@Test
	public void getMenuItemsTestForSupervisor() throws IOException{
		appService.getMenuItems("Supervisor");
	}
	
	@Test
	public void getMenuItemsTestForADANurse() throws IOException{
		appService.getMenuItems("ADA Nurse");
	}
	
	@Test
	public void getMenuItemsTestForIHA() throws IOException{
		appService.getMenuItems("Industrial Hygiene Specialist");
	}

	@Test
	public void getMenuItemsTestForSpecialist() throws IOException{
		appService.getMenuItems("Ergonomics Specialist");
	}
	
	@Test
	public void getMenuItemsTestForFacilitiesManagement() throws IOException{
		appService.getMenuItems("facilities management");
	}

	@Test
	public void getHomeListItemsTestForUser() throws IOException{
		appService.getHomeListItems("user");
	}
	
	@Test
	public void getHomeListItemsTestForSupervisor() throws IOException{
		appService.getHomeListItems("Supervisor");
	}
	
	@Test
	public void getHomeListItemsTestForADANurse() throws IOException{
		appService.getHomeListItems("ADA Nurse");
	}
	
	@Test
	public void getHomeListItemsTestForIHA() throws IOException{
		appService.getHomeListItems("Industrial Hygiene Specialist");
	}
	
	@Test
	public void getHomeListItemsTestForSpecialist() throws IOException{
		appService.getHomeListItems("Ergonomics Specialist");
	}
	
	@Test
	public void getHomeListItemsTestForFacilitiesManagement() throws IOException{
		appService.getHomeListItems("facilities management");
	}
	
	

	@Test
	@Ignore
	public void getRoleForUser1(){
		when(authService.canApproveMedicalRequest("xprk408")).thenReturn(true);
		when(authService.canViewMedicalRecords("xprk408")).thenReturn(true);
		when(authService.canCreateAssessment("xprk408")).thenReturn(false);
		when(authService.canCreateCostItems("xprk408")).thenReturn(false);
		when(authService.canEditCostItems("xprk408")).thenReturn(false);
		appService.getRole("xprk408");
	}
	
	@Test
	@Ignore
	public void getRoleForUser2(){
		when(authService.canApproveMedicalRequest("xmie001")).thenReturn(false);
		when(authService.canViewMedicalRecords("xmie001")).thenReturn(true);
		when(authService.canCreateAssessment("xmie001")).thenReturn(true);
		when(authService.canCreateCostItems("xmie001")).thenReturn(false);
		when(authService.canEditCostItems("xmie001")).thenReturn(false);
		appService.getRole("xmie001");
	}
	
	@Test
	@Ignore
	public void getRoleForUser3(){
		when(authService.canApproveMedicalRequest("xmie002")).thenReturn(false);
		when(authService.canViewMedicalRecords("xmie002")).thenReturn(false);
		when(authService.canCreateAssessment("xmie002")).thenReturn(false);
		when(authService.canCreateCostItems("xmie002")).thenReturn(true);
		when(authService.canEditCostItems("xmie002")).thenReturn(false);
		appService.getRole("xmie002");
	}
	
	@Test
	@Ignore
	public void getRoleForUser4(){
		when(authService.canApproveMedicalRequest("xmie003")).thenReturn(false);
		when(authService.canViewMedicalRecords("xmie003")).thenReturn(false);
		when(authService.canCreateAssessment("xmie003")).thenReturn(false);
		when(authService.canCreateCostItems("xmie003")).thenReturn(false);
		when(authService.canEditCostItems("xmie003")).thenReturn(true);
		appService.getRole("xmie003");
	}
	
	@Test
	@Ignore
	public void getRoleForUser5(){
		when(authService.canApproveMedicalRequest("xmie004")).thenReturn(false);
		when(authService.canViewMedicalRecords("xmie004")).thenReturn(false);
		when(authService.canCreateAssessment("xmie004")).thenReturn(false);
		when(authService.canCreateCostItems("xmie004")).thenReturn(false);
		when(authService.canEditCostItems("xmie004")).thenReturn(false);
		appService.getRole("xmie004");
	}
	
	@Test
	@Ignore
	public void getRoleForUser6(){
		when(authService.canApproveMedicalRequest("xmie005")).thenReturn(false);
		when(authService.canViewMedicalRecords("xmie005")).thenReturn(false);
		when(authService.canCreateAssessment("xmie005")).thenReturn(false);
		when(authService.canCreateCostItems("xmie005")).thenReturn(false);
		when(authService.canEditCostItems("xmie005")).thenReturn(false);
		appService.getRole("xmie005");
	}
	
	@Test
	@Ignore
	public void getRoleForUser7(){
		when(authService.canApproveMedicalRequest("iots276")).thenReturn(false);
		when(authService.canViewMedicalRecords("iots276")).thenReturn(false);
		when(authService.canCreateAssessment("iots276")).thenReturn(false);
		when(authService.canCreateCostItems("iots276")).thenReturn(false);
		when(authService.canEditCostItems("iots276")).thenReturn(false);
		appService.getRole("iots276");
	}
	
	@Test 
	@Ignore
	public void getRoleForUser8(){
		when(authService.canApproveMedicalRequest("iots255")).thenReturn(false);
		when(authService.canViewMedicalRecords("iots255")).thenReturn(false);
		when(authService.canCreateAssessment("iots255")).thenReturn(false);
		when(authService.canCreateCostItems("iots255")).thenReturn(false);
		when(authService.canEditCostItems("iots255")).thenReturn(false);
		appService.getRole("iots255");
	}
	
	@Test
	@Ignore
	public void getRoleForUser9(){
		when(authService.canApproveMedicalRequest("xmie006")).thenReturn(false);
		when(authService.canViewMedicalRecords("xmie006")).thenReturn(false);
		when(authService.canCreateAssessment("xmie006")).thenReturn(false);
		when(authService.canCreateCostItems("xmie006")).thenReturn(false);
		when(authService.canEditCostItems("xmie006")).thenReturn(false);
		appService.getRole("xmie006");
	}
	
	@Test
	public void populateUser(){
		appService.populateUser("xmie001", "user","");
		appService.populateUser("xmie002", "user","");
		appService.populateUser("xmie003", "user","");
		appService.populateUser("xmie004", "user","");
		appService.populateUser("xmie005", "user","");
		appService.populateUser("xmie006", "user","");
	}
	
	@Test
	public void populateUserForDev(){
		appService.populateUserForDevMode("xmie001", "user", "0439971");
		appService.populateUserForDevMode("xmie002", "user", "0439971");
		appService.populateUserForDevMode("xmie003", "user", "0439971");
		appService.populateUserForDevMode("xmie004", "user", "0439971");
		appService.populateUserForDevMode("xmie005", "user", "0439971");
		appService.populateUserForDevMode("xmie006", "user", "0439971");
	}
	
	@SuppressWarnings("static-access")
	@Test
	public void egnConstantsTest(){
		 String s1 =null;
		 s1 = egnConstants.ITEM_ORDER_STATUS_NEW;			
		 s1 = egnConstants.ITEM_ORDER_STATUS_ORDERED	;	
		 s1 = egnConstants.ITEM_ORDER_STATUS_CANCELLED;	
		 s1 = egnConstants.ITEM_ORDER_STATUS_COMPLETE;		
		 s1 = egnConstants.ITEM_ORDER_STATUS_REJECTED;		
		 s1 = egnConstants.SUPVSR_APRVL_STATUS_NEW;			
		 s1 = egnConstants.SUPVSR_APRVL_STATUS_APPROVED;	
		 s1 = egnConstants.SUPVSR_APRVL_STATUS_REJECTED;	
		 s1 = egnConstants.ITEM_STATUS_NA; 					
		 s1 = egnConstants.ITEM_STATUS_ASSESSMENT_COMPLETE; 
		 s1 = egnConstants.ITEM_STATUS_ASSESSMENT_PROVIDED; 
		 s1 = egnConstants.EMAIL_SERVICE_NAME; 				
		 s1 = egnConstants.EMAIL_SERVICE_REQUESTOR; 	
	}
}
