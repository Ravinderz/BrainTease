package com.uprr.app.egn.service;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Matchers.anyObject;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.uprr.app.azm.common.AzmSecurityUtils;
import com.uprr.app.xmf.MessageUtilities;
import com.uprr.app.xmf.client.ServiceProxy;
import com.uprr.app.xmf.client.ServiceProxyException;

@RunWith(SpringJUnit4ClassRunner.class)
public class AuthorizationServiceTest {

	
	@InjectMocks
    EmpCostCenterService empCostCenterService;
	
	@InjectMocks
    AuthorizationService authorizationservice;
	
	@Mock
	AzmSecurityUtils azmSecurityUtils;
	
	
	@Mock
	MessageUtilities messageUtilities;
	
	@Mock
	ServiceProxy serviceProxy;
	
	@Test
	public void canCreateEvalRequestTest(){
		String  employeeId = "0452571";
		when(azmSecurityUtils.isAuthorized(anyObject())).thenReturn(false);
		assertThat(authorizationservice.canCreateEvalRequest(employeeId), is(false));
	}
	
	@Test
	public void canApproveMedicalRequestTest(){
		String  employeeId = "0452571";
		when(azmSecurityUtils.isAuthorized(anyObject())).thenReturn(false);
		assertThat(authorizationservice.canApproveMedicalRequest(employeeId), is(false));
	}
	
	@Test
	public void canViewMedicalRecordsTest(){
		String  employeeId = "0452571";
		when(azmSecurityUtils.isAuthorized(anyObject())).thenReturn(false);
		assertThat(authorizationservice.canViewMedicalRecords(employeeId), is(false));
	}
	
	@Test
	public void canCreateAssessmentTest(){
		String  employeeId = "0452571";
		when(azmSecurityUtils.isAuthorized(anyObject())).thenReturn(false);
		assertThat(authorizationservice.canCreateAssessment(employeeId), is(false));
	}
	
	@Test
	public void canCreateCostItemsTest(){
		String  employeeId = "0452571";
		when(azmSecurityUtils.isAuthorized(anyObject())).thenReturn(false);
		assertThat(authorizationservice.canCreateCostItems(employeeId), is(false));
	}
	
	@Test
	public void canEditCostItemsTest(){
		String  employeeId = "0452571";
		when(azmSecurityUtils.isAuthorized(anyObject())).thenReturn(false);
		assertThat(authorizationservice.canEditCostItems(employeeId), is(false));
	}
}
