package com.uprr.app.egn.config.util;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)

public class ClientErrorTest {
	
	ClientError clientErrorMock;

	@Test
	public void clientErrorMockTest() throws Exception {
		ClientError ce = new ClientError("Test", "Test");
		ce.setMessage("");
		ce.setTitle("");
		ce.toString();
		ce.getMessage();
		ce.getTitle();
	}
}
