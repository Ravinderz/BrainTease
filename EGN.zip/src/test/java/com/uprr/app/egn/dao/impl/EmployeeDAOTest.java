package com.uprr.app.egn.dao.impl;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.uprr.app.egn.EgnApplication;
import com.uprr.app.egn.config.TestConfig;
import com.uprr.app.egn.dao.IEmployeeDAO;
import com.uprr.app.egn.dto.Checkbox;
import com.uprr.app.egn.dto.WorkstationEvaluation;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = {TestConfig.class,EgnApplication.class})
@TestPropertySource(locations="classpath:test-application.properties")
@Rollback(true)
public class EmployeeDAOTest {

	
	@Autowired
	IEmployeeDAO employeeDao;
	
	@BeforeClass
	public static void before(){
		System.setProperty("uprr.implementation.environment", "local");
	}
	
	@Test
	public void insertEmployeeRecord(){
		Checkbox checkbox = new Checkbox();
		checkbox.setComputerKeyboardMouse(true);
		checkbox.setChairFootrest(true);
		checkbox.setcADWS(true);
		checkbox.setrMCC(true);
		WorkstationEvaluation wsEval = new WorkstationEvaluation("1","1","medical User", "0000001", "04C 288","", "9 to 6 PM", "Jack", "2017-10-14", "1234567890", "jim@up.com", "982346", "Pual George","",  false, true, "2018-12-24", "Beth", "Jack", "402544234", "","Open",checkbox, null,"0454897");
		employeeDao.insertEmployeeRecord(wsEval);
	}
	
	@Test
	public void getEmployeeCount(){
		employeeDao.getEmployeeCount("0454897");
	}
	
	@Ignore
	@Test
	public void getEmployeeFromViewTest(){
		employeeDao.getEmployeeFromView("0454897");
	}
}
