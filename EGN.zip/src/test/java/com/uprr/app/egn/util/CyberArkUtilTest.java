
package com.uprr.app.egn.util;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@SuppressWarnings("static-access")
@RunWith(SpringJUnit4ClassRunner.class)
public class CyberArkUtilTest {

	
	@InjectMocks
	CyberArkUtil cyberarkutil;
	
	@Test
	public void isJmxEnabledTest()throws Exception{
		cyberarkutil.isJmxEnabled();      
	}
	@Test
	public void isPoolSweeperEnabledTest()throws Exception{
		cyberarkutil.isPoolSweeperEnabled();       
	}
	
	@Test
	public void getUsernameTest() throws Exception{
		cyberarkutil.getUsername();       
	}
	@Test
	public void getPasswordTest() throws Exception{
		cyberarkutil.getPassword();       
	}
	
	@Test
	public void getPasswordFrmCyberArkTest() throws Exception{
		cyberarkutil.getPasswordFrmCyberArk();       
	}
	
	@Test
	public void isValidEnvTest() throws Exception{
		System.setProperty("uprr.implementation.environment","test");
		cyberarkutil.isValidEnv();       
	}
	
	@Test
	public void getListOfEnvironemntsTest() throws Exception{
		cyberarkutil.getListOfEnvironemnts();       
	}
	
	@Test
	public void getInstanceTest() throws Exception{
		cyberarkutil.getInstance();       
	}
	
	@Test
	public void getUserIDTest() throws Exception{
		cyberarkutil.setUserID("");      
		cyberarkutil.getUserID();       
	}
	
	@Test
	public void getTypeTest() throws Exception{
		cyberarkutil.setType("");      
		cyberarkutil.getType();       
	}
	
	@Test
	public void getRunEnvTest() throws Exception{
		cyberarkutil.getRunEnv();       
	}
	
	@Test
	public void getLocalEnvPasswordTest() throws Exception{
		cyberarkutil.getLocalEnvPassword();       
	}
	
	@Test
	public void setAppTLATest() throws Exception{
		cyberarkutil.setAppTLA("");       
	}
	
	@Test
	public void setLocalEnvPasswordTest() throws Exception{
		cyberarkutil.setLocalEnvPassword("");       
	}
}

