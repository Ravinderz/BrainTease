package com.uprr.app.egn.service;

import static org.mockito.Matchers.anyObject;
import static org.mockito.Matchers.anySet;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.jms.JmsException;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.uprr.app.egn.dao.IRequestUpdateHistoryDAO;
import com.uprr.app.egn.dao.IWorkstationEvaluationDAO;
import com.uprr.app.egn.dto.Checkbox;
import com.uprr.app.egn.dto.LoggedUserVO;
import com.uprr.app.egn.dto.RequestHistory;
import com.uprr.app.egn.dto.UpdateStatus;
import com.uprr.app.egn.dto.WorkstationEvaluation;					  

@RunWith(SpringJUnit4ClassRunner.class)
public class WorkstationEvaluationServiceTest {
	@Mock
    IWorkstationEvaluationDAO wsEvaluationdao;
	
	@Mock
	IRequestUpdateHistoryDAO reqHistDao;
	
	@Mock
	IEmailService emailService;
	
	@Mock
	IEmplService emplService;
	
	@InjectMocks
	WorkstationEvaluationService wsEvaluationService;
	
	@Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        
    }
	
	@Test
	public void getRequestDataFromDBTest(){
		when(wsEvaluationdao.getRequestData("0454897")).thenReturn(new ArrayList());
		wsEvaluationService.getRequestDataFromDB("0454897");
		verify(wsEvaluationdao, times(1)).getRequestData("0454897");
	}
	
	@Test
	public void submitWorkStationRequestTest(){
		WorkstationEvaluation wsEvaluation = mock(WorkstationEvaluation.class);
		when(emplService.insertEmployeeRecord(wsEvaluation)).thenReturn(true);
		when(wsEvaluationdao.submitWorkStationRequest(wsEvaluation)).thenReturn(1);
		try {
			wsEvaluationService.submitWorkStationRequest(wsEvaluation);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		verify(wsEvaluationdao, times(1)).submitWorkStationRequest(wsEvaluation);
	}
	
	@Test
	public void updateWorkStationRequestTest() throws JmsException, Exception{
		WorkstationEvaluation wsEvaluation = mock(WorkstationEvaluation.class);
		when(wsEvaluationdao.updateWorkStationRequest(wsEvaluation)).thenReturn(true);
		when(wsEvaluation.getStatus()).thenReturn("Submitted");
		when(reqHistDao.insertRequestUpdateHistory(anyString(),anyString(), anyString(),anyString(), anyString(), anyString(), anyString())).thenReturn(true);
		wsEvaluationService.updateWorkStationRequest(wsEvaluation);
		verify(wsEvaluationdao, times(1)).updateWorkStationRequest(wsEvaluation);
	}
	
	@Test
	public void saveWorkStationRequestTest(){
		WorkstationEvaluation wsEvaluation = mock(WorkstationEvaluation.class);
		when(wsEvaluationdao.saveWorkStationRequest(wsEvaluation)).thenReturn(1);
		wsEvaluationService.saveWorkStationRequest(wsEvaluation);
		verify(wsEvaluationdao, times(1)).saveWorkStationRequest(wsEvaluation);
	}
	
	@Test
	public void updateStatusTestWithBooleanTrue() throws JmsException, Exception{
		UpdateStatus updateStatus = mock(UpdateStatus.class);
		when(wsEvaluationdao.updateStatus(updateStatus)).thenReturn(true);
		Checkbox checkbox = new Checkbox();
		checkbox.setComputerKeyboardMouse(true);
		checkbox.setChairFootrest(true);
		checkbox.setcADWS(true);
		checkbox.setrMCC(true);
		WorkstationEvaluation wsEval = new WorkstationEvaluation("1","1","medical User", "0000001", "04C 288","", "9 to 6 PM", "Jack", "2017-10-14", "1234567890", "jim@up.com", "982346", "Pual George", "", false, true, "2018-12-24", "Beth", "Jack", "402544234", "","Open",checkbox, null,"0454897");
		List<WorkstationEvaluation> list = new ArrayList<>();
		list.add(wsEval);
		when(updateStatus.getWorkstationEvaluationList()).thenReturn(list);
		when(updateStatus.getStatus()).thenReturn("rejected");
		doNothing().when(emailService).sendEmailNotification(anyObject());
		wsEvaluationService.updateStatus(updateStatus);
		
		verify(wsEvaluationdao, times(1)).updateStatus(updateStatus);
	}
	
	@Test
	public void updateStatusTestWithApprovedStatus() throws JmsException, Exception{
		UpdateStatus updateStatus = mock(UpdateStatus.class);
		when(wsEvaluationdao.updateStatus(updateStatus)).thenReturn(true);
		when(reqHistDao.insertRequestUpdateHistory(anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), anyString())).thenReturn(true);
		Checkbox checkbox = new Checkbox();
		checkbox.setComputerKeyboardMouse(true);
		checkbox.setChairFootrest(true);
		checkbox.setcADWS(true);
		checkbox.setrMCC(true);
		WorkstationEvaluation wsEval = new WorkstationEvaluation("1","1","medical User", "0000001", "04C 288","", "9 to 6 PM", "Jack", "2017-10-14", "1234567890", "jim@up.com", "982346", "Pual George","",  false, true, "2018-12-24", "Beth", "Jack", "402544234", "","Open",checkbox, null,"0454897");
		List<WorkstationEvaluation> list = new ArrayList<>();
		list.add(wsEval);
		when(updateStatus.getWorkstationEvaluationList()).thenReturn(list);
		when(updateStatus.getStatus()).thenReturn("Supervisor Approved");
		doNothing().when(emailService).sendEmailNotification(anyObject());
		wsEvaluationService.updateStatus(updateStatus);
		
		verify(wsEvaluationdao, times(1)).updateStatus(updateStatus);
	}
	
	@Test
	public void updateStatusTestWhenMedicalApproved() throws JmsException, Exception{
		UpdateStatus updateStatus = mock(UpdateStatus.class);
		when(wsEvaluationdao.updateStatus(updateStatus)).thenReturn(true);
		when(reqHistDao.insertRequestUpdateHistory(anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), anyString())).thenReturn(true);
		Checkbox checkbox = new Checkbox();
		checkbox.setComputerKeyboardMouse(true);
		checkbox.setChairFootrest(true);
		checkbox.setcADWS(true);
		checkbox.setrMCC(true);
		WorkstationEvaluation wsEval = new WorkstationEvaluation("1","1","medical User", "0000001", "04C 288","", "9 to 6 PM", "Jack", "2017-10-14", "1234567890", "jim@up.com", "982346", "Pual George", "", false, true, "2018-12-24", "Beth", "Jack", "402544234", "","Open",checkbox, null,"0454897");
		List<WorkstationEvaluation> list = new ArrayList<>();
		list.add(wsEval);
		when(updateStatus.getWorkstationEvaluationList()).thenReturn(list);
		when(updateStatus.getStatus()).thenReturn("Medical Approved");
		doNothing().when(emailService).sendEmailNotification(anyObject());
		wsEvaluationService.updateStatus(updateStatus);
		
		verify(wsEvaluationdao, times(1)).updateStatus(updateStatus);
	}
	
	@Test
	public void updateStatusAndSendEmailWhenSupervisorApproved() throws JmsException, Exception{
		UpdateStatus updateStatus = mock(UpdateStatus.class);
		when(wsEvaluationdao.updateStatus(updateStatus)).thenReturn(true);
		when(reqHistDao.insertRequestUpdateHistory(anyString(), anyString(), anyString(), anyString(), anyString(), anyString(), anyString())).thenReturn(true);
		Checkbox checkbox = new Checkbox();
		checkbox.setComputerKeyboardMouse(true);
		checkbox.setChairFootrest(true);
		checkbox.setcADWS(true);
		checkbox.setrMCC(true);
		WorkstationEvaluation wsEval = new WorkstationEvaluation("1","1","medical User", "0000001", "04C 288","", "9 to 6 PM", "Jack", "2017-10-14", "1234567890", "jim@up.com", "982346", "Pual George", "", false, true, "2018-12-24", "Beth", "Jack", "402544234", "","Open",checkbox, null,"0454897");
		List<WorkstationEvaluation> list = new ArrayList<>();
		list.add(wsEval);
		when(updateStatus.getWorkstationEvaluationList()).thenReturn(list);
		when(updateStatus.getStatus()).thenReturn("Supervisor rejected");
		doNothing().when(emailService).sendEmailNotification(anyObject());
		wsEvaluationService.updateStatus(updateStatus);
		
		verify(wsEvaluationdao, times(1)).updateStatus(updateStatus);
	}
	
	
	@Test
	public void updateStatusTestWithBooleanFalse() throws JmsException, Exception{
		UpdateStatus updateStatus = mock(UpdateStatus.class);
		when(wsEvaluationdao.updateStatus(updateStatus)).thenReturn(false);
		wsEvaluationService.updateStatus(updateStatus);
		verify(wsEvaluationdao, times(1)).updateStatus(updateStatus);
	}
	
	@Test
	public void getRequestByIdTest(){
		WorkstationEvaluation wsEvaluation = mock(WorkstationEvaluation.class);
		when(wsEvaluationdao.getRequestById(anyString())).thenReturn(wsEvaluation);
		wsEvaluationService.getRequestById(anyString());
		verify(wsEvaluationdao, times(1)).getRequestById(anyString());
	}
	
	@Test
	public void getDocumentsByRequestIdTest(){
		when(wsEvaluationdao.getDocumentsByRequestId(anyString())).thenReturn(new ArrayList());
		wsEvaluationService.getDocumentsByRequestId(anyString());
		verify(wsEvaluationdao, times(1)).getDocumentsByRequestId(anyString());
	}
	
	@Test
	public void getEvalRequestHistoryTest(){
		List<LoggedUserVO> userList = new ArrayList<LoggedUserVO>();
		LoggedUserVO loggeduservo = new LoggedUserVO();
		loggeduservo.setEmployeeId("0000000");
		userList.add(loggeduservo);
		List<RequestHistory> list = new ArrayList<RequestHistory>();
		RequestHistory requesthistory = new RequestHistory();
		requesthistory.setChangedBy("0000000");
		list.add(requesthistory);
		
		when(reqHistDao.getEvalRequestHistoryByRequestId(anyString())).thenReturn(list);
		when(emplService.getUserDetails(anySet())).thenReturn(userList);
		wsEvaluationService.getEvalRequestHistory("1");
	}
	
	@Test
	public void getAllMedicalRequestsTest(){
		wsEvaluationService.getAllMedicalRequests();
	}
	
	@Test
	public void getRequestDataFromDBTest1(){
		wsEvaluationService.getRequestDataFromDB();
	}
	
}