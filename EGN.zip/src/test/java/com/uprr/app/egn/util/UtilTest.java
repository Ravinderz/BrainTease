
package com.uprr.app.egn.util;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@SuppressWarnings("static-access")
@RunWith(SpringJUnit4ClassRunner.class)
public class UtilTest {

	
	@InjectMocks
	Util utilService;
	
	@Test
	public void setEmailForSupvsrEGNIHTeamTest()throws Exception{
		utilService.setEmailForMdclRejectsToSupvsrEGNIHTeam("xsat860", "xsat860","xsat860","xsat860");       
	}
	@Test
	public void setEmlForAsmtCmpltdNPrchseItmsCmpltdTest()throws Exception{
		utilService.setEmlForAsmtCmpltdNPrchseItmsCmpltd("xsat860", "xsat860","xsat860","xsat860");       
	}
	
	@Test
	public void setEmlForAsmtCmpltWithoutPurchaseItemsTest() throws Exception{
		utilService.setEmlForAsmtCmpltWithoutPurchaseItems("xsat860", "xsat860","xsat860","xsat860", null);       
	}
	@Test
	public void setEmlForAsmtCmpltWithPurchaseItemsTest() throws Exception{
		utilService.setEmlForAsmtCmpltWithPurchaseItems("xsat860", "xsat860","xsat860","xsat860", null);       
	}
	
	@SuppressWarnings("static-access")
	@Test
	public void getEchoServiceNameTest() throws Exception{
		utilService.getEchoServiceName();       
	}
	
	@Test
	public void getUploadServiceNameTest() throws Exception{
		utilService.getUploadServiceName();       
	}
	
	@Test
	public void getDownloadServiceNameTest() throws Exception{
		utilService.getDownloadServiceName();       
	}
	
	@Test
	public void getOwnerNameTest() throws Exception{
		utilService.getOwnerName();       
	}
	
	@Test
	public void getAppNameTest() throws Exception{
		utilService.getAppName();       
	}
	
	@Test
	public void isLocalModeTest() throws Exception{
		utilService.isLocalMode();
		System.setProperty("uprr.implementation.environment","local");
		utilService.isLocalMode();
		System.setProperty("uprr.implementation.environment","jetty");
		utilService.isLocalMode();
		System.setProperty("uprr.implementation.environment","desktop");
		utilService.isLocalMode();
		System.setProperty("uprr.implementation.environment","tomcat");
		utilService.isLocalMode();
	}
	
	@Test
	public void isDevModeTest() throws Exception{
		utilService.isDevMode();       
	}
	
	@Test
	public void isTestModeTest() throws Exception{
		System.setProperty("uprr.implementation.environment","test");
		utilService.isTestMode();       
	}
	
	@Test
	public void isProdModeTest() throws Exception{
		System.setProperty("uprr.implementation.environment","prod");
		utilService.isProdMode();       
	}
	
	@Test
	public void getCommaSeperatedUserIdsTest() throws Exception{
		List<String> userIds = new ArrayList<>();
		userIds.add("xmie001");
		userIds.add("xmie002");
		userIds.add("xmie003");
		utilService.getCommaSeperatedUserIds(userIds);       
	}
	
	@Test
	public void setEmailForEmployeeTest() throws Exception{
		utilService.setEmailForEmployee("","","","");    
		System.setProperty("uprr.implementation.environment","local");
		utilService.setEmailForEmployee("","","","");    
		System.setProperty("uprr.implementation.environment","dev");
		utilService.setEmailForEmployee("","","","");    
		System.setProperty("uprr.implementation.environment","test");
		utilService.setEmailForEmployee("","","","");    
		System.setProperty("uprr.implementation.environment","prod");
		utilService.setEmailForEmployee("","","","");    
	}
	
	@Test
	public void getNonMedicalRejectNotificationTest() throws Exception{
		utilService.getNonMedicalRejectNotification("","","","");
		System.setProperty("uprr.implementation.environment","local");
		utilService.getNonMedicalRejectNotification("","","","");
		System.setProperty("uprr.implementation.environment","dev");
		utilService.getNonMedicalRejectNotification("","","","");
		System.setProperty("uprr.implementation.environment","test");
		utilService.getNonMedicalRejectNotification("","","","");
		System.setProperty("uprr.implementation.environment","prod");
		utilService.getNonMedicalRejectNotification("","","",""); 
	}
	
	@Test
	public void getRequestApprovedNotificationTest() throws Exception{
		utilService.getRequestApprovedNotification("","","");
		System.setProperty("uprr.implementation.environment","local");
		utilService.getRequestApprovedNotification("","","");
		System.setProperty("uprr.implementation.environment","dev");
		utilService.getRequestApprovedNotification("","","");
		System.setProperty("uprr.implementation.environment","test");
		utilService.getRequestApprovedNotification("","","");
		System.setProperty("uprr.implementation.environment","prod");
		utilService.getRequestApprovedNotification("","","");
	}
	
	@Test
	public void setEmailForMdclRejectsToSupvsrEGNIHTeamTest() throws Exception{
		utilService.setEmailForMdclRejectsToSupvsrEGNIHTeam("","","","");
		System.setProperty("uprr.implementation.environment","local");
		utilService.setEmailForMdclRejectsToSupvsrEGNIHTeam("","","","");
		System.setProperty("uprr.implementation.environment","dev");
		utilService.setEmailForMdclRejectsToSupvsrEGNIHTeam("","","","");
		System.setProperty("uprr.implementation.environment","test");
		utilService.setEmailForMdclRejectsToSupvsrEGNIHTeam("","","","");
		System.setProperty("uprr.implementation.environment","prod");
		utilService.setEmailForMdclRejectsToSupvsrEGNIHTeam("","","",""); 
	}
	
	@Test
	public void setEmlForAsmtCmpltWithPurchaseItemsTest1() throws Exception{
		System.setProperty("uprr.implementation.environment","local");
		utilService.setEmlForAsmtCmpltWithPurchaseItems("xsat860", "xsat860","xsat860","xsat860", null);
		System.setProperty("uprr.implementation.environment","dev");
		utilService.setEmlForAsmtCmpltWithPurchaseItems("","","","","");
		System.setProperty("uprr.implementation.environment","test");
		utilService.setEmlForAsmtCmpltWithPurchaseItems("","","","","");
		System.setProperty("uprr.implementation.environment","prod");
		utilService.setEmlForAsmtCmpltWithPurchaseItems("","","","",""); 
	}
	
	@Test
	public void setEmlForAsmtCmpltWithoutPurchaseItemsTest2() throws Exception{
		System.setProperty("uprr.implementation.environment","local");
		utilService.setEmlForAsmtCmpltWithoutPurchaseItems("xsat860", "xsat860","xsat860","xsat860", null);
		System.setProperty("uprr.implementation.environment","dev");
		utilService.setEmlForAsmtCmpltWithoutPurchaseItems("","","","","");
		System.setProperty("uprr.implementation.environment","test");
		utilService.setEmlForAsmtCmpltWithoutPurchaseItems("","","","","");
		System.setProperty("uprr.implementation.environment","prod");
		utilService.setEmlForAsmtCmpltWithoutPurchaseItems("","","","",""); 
	}
	
	@Test
	public void setEmlForAsmtCmpltdNPrchseItmsCmpltdTest1() throws Exception{
		System.setProperty("uprr.implementation.environment","local");
		utilService.setEmlForAsmtCmpltdNPrchseItmsCmpltd("xsat860", "xsat860","xsat860","xsat860");
		System.setProperty("uprr.implementation.environment","dev");
		utilService.setEmlForAsmtCmpltdNPrchseItmsCmpltd("xsat860", "xsat860","xsat860","xsat860");
		System.setProperty("uprr.implementation.environment","test");
		utilService.setEmlForAsmtCmpltdNPrchseItmsCmpltd("xsat860", "xsat860","xsat860","xsat860");
		System.setProperty("uprr.implementation.environment","prod");
		utilService.setEmlForAsmtCmpltdNPrchseItmsCmpltd("xsat860", "xsat860","xsat860","xsat860"); 
	}
	
	@Test
	public void setEmlForAsmtPrvidedNPrchseItmsRqrdTest() throws Exception{
		System.setProperty("uprr.implementation.environment","local");
		utilService.setEmlForAsmtPrvidedNPrchseItmsRqrd("xsat860", "xsat860","xsat860","xsat860");
		System.setProperty("uprr.implementation.environment","dev");
		utilService.setEmlForAsmtPrvidedNPrchseItmsRqrd("xsat860", "xsat860","xsat860","xsat860");
		System.setProperty("uprr.implementation.environment","test");
		utilService.setEmlForAsmtPrvidedNPrchseItmsRqrd("xsat860", "xsat860","xsat860","xsat860");
		System.setProperty("uprr.implementation.environment","prod");
		utilService.setEmlForAsmtPrvidedNPrchseItmsRqrd("xsat860", "xsat860","xsat860","xsat860");
	}
	
	@Test
	public void setEmlForNonMedicalRequestSubmittedTest() throws Exception{
		System.setProperty("uprr.implementation.environment","local");
		utilService.setEmlForNonMedicalRequestSubmitted("xsat860", "xsat860","xsat860","xsat860","");
		System.setProperty("uprr.implementation.environment","dev");
		utilService.setEmlForNonMedicalRequestSubmitted("xsat860", "xsat860","xsat860","xsat860","");
		System.setProperty("uprr.implementation.environment","test");
		utilService.setEmlForNonMedicalRequestSubmitted("xsat860", "xsat860","xsat860","xsat860","");
		System.setProperty("uprr.implementation.environment","prod");
		utilService.setEmlForNonMedicalRequestSubmitted("xsat860", "xsat860","xsat860","xsat860","");
	}
	
	@Test
	public void setEmlForMedicalRequestSubmittedTest() throws Exception{
		System.setProperty("uprr.implementation.environment","local");
		utilService.setEmlForMedicalRequestSubmitted("xsat860", "xsat860","xsat860","xsat860");
		System.setProperty("uprr.implementation.environment","dev");
		utilService.setEmlForMedicalRequestSubmitted("xsat860", "xsat860","xsat860","xsat860");
		System.setProperty("uprr.implementation.environment","test");
		utilService.setEmlForMedicalRequestSubmitted("xsat860", "xsat860","xsat860","xsat860");
		System.setProperty("uprr.implementation.environment","prod");
		utilService.setEmlForMedicalRequestSubmitted("xsat860", "xsat860","xsat860","xsat860");
	}
}

