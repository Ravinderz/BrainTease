package com.uprr.app.egn.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.uprr.app.egn.dto.SearchRequest;
import com.uprr.app.egn.service.SearchService;

@RunWith(SpringJUnit4ClassRunner.class)
public class SearchControllerTest {

	private MockMvc mockMvc;

	@Mock
	SearchService searchServiceMock;

	@InjectMocks
	SearchController searchController;

	@Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(searchController).build();
    }
	
	@Test
	public void searchRequestTestWithUserID() throws Exception{
		MvcResult result =  mockMvc.perform(post("/search/search/{role}","supervisor").content(asJsonString(new SearchRequest(null,null, "0454897",null, null, null)))
				 .contentType(MediaType.APPLICATION_JSON_UTF8))
				 .andDo(print())
		         .andExpect(status().isOk())
		         .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8) )
		         .andReturn();
	}
	
	@Test
	public void searchRequestTestWithStatus() throws Exception{
		MvcResult result =  mockMvc.perform(post("/search/search/{role}","supervisor").content(asJsonString(new SearchRequest(null,null, null, "Open", null, null)))
				 .contentType(MediaType.APPLICATION_JSON_UTF8))
				 .andDo(print())
		         .andExpect(status().isOk())
		         .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8) )
		         .andReturn();
	}
	
	@Test
	public void searchRequestTestWithDateRange() throws Exception{
		MvcResult result =  mockMvc.perform(post("/search/search/{role}","supervisor").content(asJsonString(new SearchRequest("2017-01-01","2018-03-01", null, null, null, null)))
				 .contentType(MediaType.APPLICATION_JSON_UTF8))
				 .andDo(print())
		         .andExpect(status().isOk())
		         .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8) )
		         .andReturn();
	}
	
	@Test
	public void searchRequestTestWithAllValues() throws Exception{
		MvcResult result =  mockMvc.perform(post("/search/search/{role}","supervisor").content(asJsonString(new SearchRequest("2017-01-01","2018-03-01", "0454897", "Open", null, null)))
				 .contentType(MediaType.APPLICATION_JSON_UTF8))
				 .andDo(print())
		         .andExpect(status().isOk())
		         .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8) )
		         .andReturn();
	}
	
	public static String asJsonString(final Object obj) {
	    try {
	        final ObjectMapper mapper = new ObjectMapper();
	        final String jsonContent = mapper.writeValueAsString(obj);
	        return jsonContent;
	    } catch (Exception e) {
	        throw new RuntimeException(e);
	    }
	}
}