package com.uprr.app.egn;

import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
public class EgnApplicationTest {
	
	@InjectMocks
	private EgnApplication egnApplication;

	@Test
	public void type() throws Exception {
		assertThat(EgnApplication.class, notNullValue());
	}

	@Test
	public void instantiation() throws Exception {
		assertThat(egnApplication, notNullValue());
	}
	
	@Before
	public void setUp(){
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void main_A$StringArray() throws Exception {
		String[] args = new String[] {};
		System.setProperty("uprr.implementation.environment", "local");
		egnApplication.main(args);
	}

	@Test
	public void main_A$StringArray_Case1() throws Exception {
		try {
			String[] args = new String[] {};
			System.setProperty("uprr.implementation.environment", "dev");
			egnApplication.main(args);
		} catch (Exception e) {
			assertFalse(false);
		}
	}

	@Test
	public void configure_A$SpringApplicationBuilder() throws Exception {
		SpringApplicationBuilder application = new SpringApplicationBuilder(egnApplication);
		egnApplication.configure(application);
	}

	@Test
	public void testDispatchServletRegistration() throws Exception{
		try {
			System.setProperty("uprr.implementation.environment", "dev");
			egnApplication.dispatchServletRegistration();
		} catch (Exception e) {
			assertFalse(false);
		}
	}
}
