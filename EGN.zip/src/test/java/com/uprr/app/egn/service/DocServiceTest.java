package com.uprr.app.egn.service;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

@RunWith(SpringJUnit4ClassRunner.class)
public class DocServiceTest {
	
	@Mock
	RestTemplate restTemplate;
	
	@Mock
	RestTemplateBuilder builder;

	@Mock
	ResponseEntity responseEntity;
	
    
    DocService docService;
    
    @Before
    public void setup() {
    	when(builder.build()).thenReturn(restTemplate);
    	docService = new DocService(builder,"string");
    }
    
   
    @Test
	public void callEchoServiceTest() throws Exception {
    	when(restTemplate.getForEntity(anyString(), any(Class.class))).thenReturn(responseEntity);
    	when(responseEntity.getStatusCodeValue()).thenReturn(200);
        docService.callEchoService();
	}
	
    @Test
    public void getDocTest() throws Exception {
    	String test ="this is get docs test";
        when(restTemplate.exchange(anyString(),any(),any(),any(Class.class))).thenReturn(responseEntity);
        when(responseEntity.getBody()).thenReturn(test.getBytes());
        docService.getDoc("123456");
        
    }
    
    @Test
    public void persistDocTest() throws Exception {
    	String test ="{'document-identifiers':{'dcoument-id':'123456'}}";
    	MultipartFile file = mock(MultipartFile.class);
    	when(file.getOriginalFilename()).thenReturn("test");
    	when(file.getBytes()).thenReturn(test.getBytes());
        when(restTemplate.exchange(anyString(),any(),any(),any(Class.class))).thenReturn(responseEntity);
        when(responseEntity.getBody()).thenReturn(test);
        docService.persistDoc(file);
        
    }
}
