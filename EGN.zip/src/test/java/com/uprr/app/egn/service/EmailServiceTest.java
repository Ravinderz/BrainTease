package com.uprr.app.egn.service;

import static org.mockito.Matchers.anyObject;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.text.SimpleDateFormat;
import java.util.ArrayList;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.uprr.app.azm.common.AzmSecurityUtils;
import com.uprr.app.egn.dto.SendMailVO;
import com.uprr.app.xmf.MessageUtilities;
import com.uprr.app.xmf.client.ServiceProxy;

@RunWith(SpringJUnit4ClassRunner.class)
public class EmailServiceTest {

	
	@InjectMocks
    EmpCostCenterService empCostCenterService;
	
	@InjectMocks
    EmailService emailservice;
	
	@Mock
	AzmSecurityUtils azmSecurityUtils;
	
	
	@Mock
	MessageUtilities messageUtilities;
	
	@Mock
	ServiceProxy serviceProxy;
	
	@Mock
	JAXBContext context;
	
	@Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        
    }
	
	@Test
	public void sendEmailNotificationTest(){
		try {
		Marshaller marshallerObj = mock(Marshaller.class);
		MessageUtilities messageUtilities = mock(MessageUtilities.class);
		String responseXML =  new String();
		SendMailVO sendMailVO = new SendMailVO();
		sendMailVO.getContentType();
		sendMailVO.setContentType("");
		sendMailVO.getSubject();
		sendMailVO.setSubject("");
		sendMailVO.getBodyContent();
		sendMailVO.setBodyContent("");
		sendMailVO.getFromAddress();
		sendMailVO.setFromAddress("");
		sendMailVO.getToAddressLst();
		sendMailVO.setToAddressLst(new ArrayList<String>());
		sendMailVO.getCcAddressLst();
		sendMailVO.setCcAddressLst(new ArrayList<String>());
		sendMailVO.getBccAddressLst();
		sendMailVO.setBccAddressLst(new ArrayList<String>());
		sendMailVO.getAttachmentBytes();
		sendMailVO.getAttachedDocMimeType();
		sendMailVO.setAttachedDocMimeType("");
		sendMailVO.getAttachedDocName();
		sendMailVO.setAttachedDocName("");
		sendMailVO.getCurrentTime();
		byte[] attachmentBytes = null;
		sendMailVO.setAttachmentBytes(attachmentBytes);
		sendMailVO.toString();
		sendMailVO.buildNotificationRequest();
		
		
		
		when(azmSecurityUtils.isAuthorized(anyObject())).thenReturn(false);
		when(context.createMarshaller()).thenReturn(marshallerObj);
		when(messageUtilities.getXMFBody(anyString())).thenReturn(responseXML);
		
			emailservice.sendEmailNotification(sendMailVO);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}	
}
