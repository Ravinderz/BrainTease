package com.uprr.app.egn.service;

import static org.mockito.Matchers.anyObject;
import static org.mockito.Matchers.anySet;										  
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.jms.JmsException;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.uprr.app.egn.dao.IItemDAO;
import com.uprr.app.egn.dao.IRequestUpdateHistoryDAO;
import com.uprr.app.egn.dao.IWorkstationAssessmentDAO;
import com.uprr.app.egn.dao.IWorkstationEvaluationDAO;
import com.uprr.app.egn.dto.ActionItem;
import com.uprr.app.egn.dto.LoggedUserVO;										 
import com.uprr.app.egn.dto.RequestHistory;
import com.uprr.app.egn.dto.SendMailVO;
import com.uprr.app.egn.util.Util;

@RunWith(SpringJUnit4ClassRunner.class)
public class ItemServiceTest {

	@Mock
	IItemDAO itemDao;
	
	@Mock
	IWorkstationAssessmentDAO wsDao;
	
	@Mock
	IRequestUpdateHistoryDAO reqHistDao;
	
	@Mock
	private IWorkstationEvaluationDAO wsEvalDao;
	
	@Mock
    private IEmailService emailService;
	
	@Mock
	private IEmplService emplService;
	@InjectMocks
	ItemService itemService;
	
	@Test
	public void insertPurchaseItemTest(){
		ActionItem item = mock(ActionItem.class);
		when(itemDao.insertPurchaseItem(item)).thenReturn(1);
		when(reqHistDao.insertRequestUpdateHistory(anyString(), anyString(), anyObject(), anyString(), anyObject(), anyString(), anyString())).thenReturn(true);
		itemService.insertPurchaseItem(item);
	}
	
	@Test
	public void getItemHistoryTest(){
		List<RequestHistory> list = new ArrayList<>();
		RequestHistory hist = new RequestHistory();
		hist.setReqHistoryId("1");
		hist.setChangedBy("1122334");
		list.add(hist);
		when(reqHistDao.getItemHistoryByItemId("1")).thenReturn(list);
		List<LoggedUserVO> userList = new ArrayList<>();
		when(emplService.getUserDetails(anySet())).thenReturn(userList);
		
		itemService.getItemHistory("1");
	}
	
	@Test
	public void getAllItemsByAsmtIdTest(){
		List<ActionItem> list = new ArrayList<>();
		ActionItem item = new ActionItem();
		item.setItemId(1);
		list.add(item);
		when(itemDao.getAllItemsByAsmtId("1")).thenReturn(list);
		itemService.getAllItemsByAsmtId("1");
	}
	
	
	@Test
	public void updatePurchaseItemTests() throws JmsException, Exception{
		ActionItem item = new ActionItem();
		item.setItemId(1);
		item.setAssessmentId("2");
		item.setRequestId("1");
		item.setAssignedToEmployeeId("112233");
		item.setOldStatus("New");
		item.setSupvAprvlStatus("Completed");
		item.setItemOrderStatus("Completed");							   
		item.setUpdatedById("112233");
		when(itemDao.updatePurchaseItem(item)).thenReturn(true);
		List<ActionItem> list =  new ArrayList<>();
		list.add(item);
		when(itemDao.getAllItemsByAsmtId("2")).thenReturn(list);
		when(wsDao.updateWorkstationAssessmentStatus("2", "Assessment Complete")).thenReturn(true);
		when(wsEvalDao.updateStatus("1","112233","Assessment Complete")).thenReturn(true);
		when(reqHistDao.insertRequestUpdateHistory("Assessment Provided", "Assessment Complete", null, "112233", "1", "2", null)).thenReturn(true);
		
		doNothing().when(emailService).sendEmailNotification(anyObject());
		when(reqHistDao.insertRequestUpdateHistory("New", "Completed", null, "112233", null, "2", "1")).thenReturn(true);
		
		itemService.updatePurchaseItem(item);
		
	}
	
	
	
}
