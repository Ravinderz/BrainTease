package com.uprr.app.egn.dao.impl;

import static org.hamcrest.CoreMatchers.notNullValue;
import static org.junit.Assert.assertThat;

import java.util.ArrayList;
import java.util.List;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.uprr.app.egn.EgnApplication;
import com.uprr.app.egn.config.TestConfig;
import com.uprr.app.egn.dao.IWorkstationAssessmentDAO;
import com.uprr.app.egn.dto.ActionItem;
import com.uprr.app.egn.dto.LoggedUserVO;
import com.uprr.app.egn.dto.WorkstationAssessment;


@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = {TestConfig.class,EgnApplication.class})
@TestPropertySource(locations="classpath:test-application.properties")
@Rollback(true)
public class WorkstationAssessmentDAOTest {

	@Autowired
	IWorkstationAssessmentDAO wsaDao;
	
	@BeforeClass
	public static void before(){
		System.setProperty("uprr.implementation.environment", "local");
	}

	
	@Test(expected = NullPointerException.class)
	public void submitWorkstationAssessmentTest(){
		
		LoggedUserVO user = new LoggedUserVO("xmie001","9999999","user","Test","1","User","Test 1 User","xmie001@up.com","0022338899","iots276", "0439971", "Gorantla Vishnu Naidu", "VNGORANT@UP.COM", "99999",  "Gorantla Vishnu Naidu", "", "Omaha", "NE", "BD321", "123");
		WorkstationAssessment wsAssessment = new WorkstationAssessment("1","1","2018-06-18","Testing","Lower Back Pain","None","bad","Test","test","12",12,"low","ergo","low","none","low","none","none","none","none","none","none","open",user,new ArrayList<ActionItem>());
		wsaDao.submitWorkstationAssessment(wsAssessment);
	}
	
	@Test(expected = NullPointerException.class)
	public void saveWorkstationAssessmentTest(){
		
		LoggedUserVO user = new LoggedUserVO("xmie001","9999999","user","Test","1","User","Test 1 User","xmie001@up.com","0022338899","iots276", "0439971", "Gorantla Vishnu Naidu", "VNGORANT@UP.COM", "99999",  "Gorantla Vishnu Naidu", "", "Omaha", "NE", "BD321", "123");
		WorkstationAssessment wsAssessment = new WorkstationAssessment("1","1","2018-06-18","Testing","Lower Back Pain","None","bad","Test","test","12",12,"low","ergo","low","none","low","none","none","none","none","none","none","open",user,new ArrayList<ActionItem>());
		wsaDao.saveWorkstationAssessment(wsAssessment);
	}

	@Test
	public void updateWorkStationAssessmentReturnFalse(){
		LoggedUserVO user = new LoggedUserVO("xmie001","9999999","user","Test","1","User","Test 1 User","xmie001@up.com","0022338899","iots276", "0439971", "Gorantla Vishnu Naidu", "VNGORANT@UP.COM", "99999",  "Gorantla Vishnu Naidu", "", "Omaha", "NE", "BD321", "123");
		WorkstationAssessment wsAssessment = new WorkstationAssessment("1","1","2018-06-18","Testing","Lower Back Pain","None","bad","Test","test","12",12,"low","ergo","low","none","low","none","none","none","none","none","none","open",user,new ArrayList<ActionItem>());
		boolean i = wsaDao.updateWorkStationAssessment(wsAssessment);
        assertThat(i, notNullValue());
	}
	
	@Test
	public void getDropdownValuesTest(){
		wsaDao.getDropdownValues();
	}
	
	@Test
	public void getRequestByIdTest(){
		wsaDao.getRequestById("1");
	}
	
	@Test
	public void getAllItemsByAsmtIdTest(){
		wsaDao.getAllItemsByAsmtId("73");
	}
	
	@Test
	public void saveActionItemsTest(){
		ActionItem item = new ActionItem();
		item.setAssessmentId("1");
		item.setAssignedToEmployeeId("0454897");
		item.setAssignedToEmployeeName("Ravinder Singh");
		item.setDateAssigned("");
		item.setEstimatedCost("244");
		item.setItemId(1);
		item.setItemTextDesc("testing 1");
		item.setNote("This is note");
		item.setSupvAprvlStatus("Ordered");
		List<ActionItem> list = new ArrayList<>();
		list.add(item);
		wsaDao.saveActionItems(list, 1);
	}
	
	@Test
	public void udpateActionItemsTest(){
		ActionItem item = new ActionItem();
		item.setAssessmentId("1");
		item.setAssignedToEmployeeId("0454897");
		item.setAssignedToEmployeeName("Ravinder Singh");
		item.setDateAssigned("");
		item.setEstimatedCost("244");
		item.setItemId(1);
		item.setItemTextDesc("testing 1");
		item.setNote("This is note");
		item.setSupvAprvlStatus("Ordered");
		List<ActionItem> list = new ArrayList<>();
		list.add(item);
		wsaDao.updateActionItems(list);
	}
	
	@Test
	public void updateWorkstationAssessmentStatusTest(){
		boolean i = wsaDao.updateWorkstationAssessmentStatus("1","Assessment Provided");
	}
	
	@Test
	public void getAssessmentForReqIdCountTest(){
		wsaDao.getAssessmentForReqIdCount("1");
	}

}
