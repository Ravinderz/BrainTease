package com.uprr.app.egn.service;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.uprr.app.xmf.MessageUtilities;
import com.uprr.app.xmf.client.ServiceProxy;
import com.uprr.app.xmf.client.ServiceProxyException;

@RunWith(SpringJUnit4ClassRunner.class)
public class EmpCostCenterServiceTest {

	
	@InjectMocks
    EmpCostCenterService empCostCenterService;
	
	@Mock
	MessageUtilities messageUtilities;
	
	@Mock
	ServiceProxy serviceProxy;
	
	@Test
	public void getCostCenterDetailsTestWithValidEmployeeId(){
		String  employeeId = "0452571";
		
		try {
			when(serviceProxy.invoke(anyString(), anyLong())).thenReturn("00000");
			when(messageUtilities.getXMFBody(anyString())).thenReturn("<cost-center>81307</cost-center>");

			List<String>  costCenter = empCostCenterService.getCostCenterDetails(employeeId);
			assertThat(costCenter.isEmpty(), is(costCenter.isEmpty()));

		} catch (ServiceProxyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Test
	public void getCostCenterDetailsTestException() throws ServiceProxyException{
			when(serviceProxy.invoke(anyString(), anyLong())).thenThrow(new NullPointerException());
			empCostCenterService.getCostCenterDetails("0452571");       
	}
	
	@Test
	public void getCostCenterDetailsTestWithNullreplyMessage() throws ServiceProxyException{
		String employeeId = "0452571";
			when(serviceProxy.invoke(anyString(), anyLong())).thenReturn(null);
		    empCostCenterService.getCostCenterDetails(employeeId);
        
	}
	
	@Test
	public void getCostCenterDetailsTestWithNullresponseXML() throws ServiceProxyException{
		String employeeId = "0452571";

		when(serviceProxy.invoke(anyString(), anyLong())).thenReturn("00000");
		when(messageUtilities.getXMFBody(anyString())).thenReturn(null);
		empCostCenterService.getCostCenterDetails(employeeId);
	}
}
