package com.uprr.app.egn.controller;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.uprr.app.egn.dto.MenuVO;
import com.uprr.app.egn.service.AppService;
import com.uprr.app.egn.service.IAuthorizationService;
import com.uprr.ui.shared.user.ActiveUserId;

@RunWith(SpringJUnit4ClassRunner.class)

public class AppControllerTest {

	private MockMvc mockMvc;
	
	@Mock
	AppService appServiceMock;
	
	@InjectMocks
	AppController appController;
	
	@Mock
	ActiveUserId userId;
	
	@Mock
	IAuthorizationService authService;
	
	
	@Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(appController).build();
 
    }

	@Test
	public void getMenuTestWithRoleUser() throws Exception{
		List<MenuVO> list = new ArrayList<MenuVO>();
		list.add(new MenuVO("Home","ergonomics.welcome",1));
		list.add(new MenuVO("Search","ergonomics.search",2));
		list.add(new MenuVO("Create","ergonomics.create",3));
		list.add(new MenuVO("Assessment","ergonomics.assessment",4));
		
		when(appServiceMock.getRole("xmie001")).thenReturn("user");
		when(appServiceMock.getMenuItems("user")).thenReturn(list);
		when(userId.getEmployeeId()).thenReturn("9999998");
		appController.getMenu("9999998", userId);
	}
	
	@Test
	public void getMenuTestWithRoleUserForbidden() throws Exception{
		List<MenuVO> list = new ArrayList<MenuVO>();
		list.add(new MenuVO("Home","ergonomics.welcome",1));
		list.add(new MenuVO("Search","ergonomics.search",2));
		list.add(new MenuVO("Create","ergonomics.create",3));
		list.add(new MenuVO("Assessment","ergonomics.assessment",4));
		
		when(appServiceMock.getRole("xmie001")).thenReturn("user");
		when(appServiceMock.getMenuItems("user")).thenReturn(list);
		when(userId.getEmployeeId()).thenReturn("9999998");
		appController.getMenu("9999993", userId);
	}
	
	@Test
	public void getHomeListTestWithRoleUser() throws Exception {
		
		List<MenuVO> list = new ArrayList<MenuVO>();
		list.add(new MenuVO("Create Request","ergonomics.create",1));
		list.add(new MenuVO("Search Request","ergonomics.search",2));
		
		when(appServiceMock.getRole("xmie001")).thenReturn("user");
		when(appServiceMock.getHomeListItems("user")).thenReturn(list);
		when(userId.getEmployeeId()).thenReturn("9999998");
		appController.getMenu("9999998", userId);
	}
	
	@Test
	public void getHomeListTestWithRoleUserForbidden() throws Exception {
		
		List<MenuVO> list = new ArrayList<MenuVO>();
		list.add(new MenuVO("Create Request","ergonomics.create",1));
		list.add(new MenuVO("Search Request","ergonomics.search",2));
		
		when(appServiceMock.getRole("xmie001")).thenReturn("user");
		when(appServiceMock.getHomeListItems("user")).thenReturn(list);
		when(userId.getEmployeeId()).thenReturn("9999998");
		appController.getMenu("9999993", userId);
	}
	
	
	@Ignore
	@Test
	public void getLoggedInUserIsNullTest() throws Exception{
		
		when(userId.getEmployeeId()).thenReturn(null);
		
		
		
	}
}
